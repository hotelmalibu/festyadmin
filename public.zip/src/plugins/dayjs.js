import Vue from 'vue'
import dayjs from 'dayjs'
import 'dayjs/locale/es'
import relativeTime from 'dayjs/plugin/relativeTime'
import localizedFormat from 'dayjs/plugin/localizedFormat'
import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'

dayjs.extend(relativeTime)
dayjs.extend(localizedFormat)
dayjs.extend(utc)
dayjs.extend(timezone)

dayjs.locale('es')

// Bridge de compatibilidad para evitar cambiar miles de líneas de código
Vue.prototype.$dayjs = dayjs
Vue.prototype.$moment = dayjs 

// Filtro global para mantener compatibilidad con templates
Vue.filter('moment', (date, action, arg) => {
  if (!date) return ''
  const d = dayjs(date)
  if (action === 'from') {
    return d.from(dayjs(arg || undefined))
  }
  // Si action es un formato (ej: 'lll'), lo aplicamos
  return d.format(action || 'lll')
})

export default dayjs
