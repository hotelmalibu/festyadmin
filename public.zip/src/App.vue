<template>
  <v-app class="myFont">
    <v-app-bar
      app
      color="#f6f6f6"
      class="d-print-none"
    >
      <v-app-bar-nav-icon v-if="authenticate" @click="active = !active"></v-app-bar-nav-icon>

      <div class="d-flex align-center" style="color: #64625e;">
        <h2>Tomahawk Beta</h2>
      </div>

      <v-spacer></v-spacer>
      <v-btn
        class="d-none d-sm-flex"
        to="/orders"
        text
        v-if="authenticate"
      >
        <v-icon>mdi-clock-fast</v-icon>
        <span class="mr-2">Ver ordenes</span>
      </v-btn>

      <v-btn
        class="d-none d-sm-flex"
        to="/stores"
        text
        v-if="authenticate"
      >
        <v-icon>mdi-storefront</v-icon>
        <span class="mr-2">Ver comercios</span>
      </v-btn>

      <v-btn
        class="d-none d-sm-flex"
        to="/riders"
        text
        v-if="authenticate"
      >
        <v-icon>mdi-bike-fast</v-icon>
        <span class="mr-2">Ver domiciliarios</span>
      </v-btn>

      <v-btn
        v-if="authenticate"
        @click="logOut()"
        text
        class="d-none d-sm-flex"
      >
        <v-icon color="red">mdi-logout</v-icon>
        <span class="mr-2" style="color: red;">Logout</span>
      </v-btn>

      <!--<v-btn
        class="d-none d-sm-flex"
        href="https://festyapp.com/"
        target="_blank"
        text
      >
        <span class="mr-2" style="color: green;">FestyApp</span>
        <v-icon color="green">mdi-android</v-icon>
      </v-btn>-->
    </v-app-bar>
    
    <v-navigation-drawer
      v-model="active"
      temporary
      app
      class="d-print-none"
    >
      <v-list-item>
        <v-list-item-avatar>
          <v-img :src="require('./assets/user.png')"></v-img>
        </v-list-item-avatar>

        <v-list-item-content>
          <v-list-item-title v-if="authenticate">{{authenticate.attributes.name}}</v-list-item-title>
          <v-list-item-title v-else> Falso positivo </v-list-item-title>
        </v-list-item-content>
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense>

        <v-list-item to="/orders" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-clock-fast</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver ordenes</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/orders-delivered" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-text-box-check</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver entregas recientes</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/stores" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-storefront</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver comercios</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/riders" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-bike-fast</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver domiciliarios</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/push-sms-template" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-text-box-search</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver plantillas Push/SMS</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/promo-code-crud" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-tag</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Códigos promocionales</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/masive-notifications" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-bell-ring</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Notificaciones Masivas</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/banners" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-folder-multiple-image</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver banners</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        
        <v-list-item to="/zones" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-map-clock</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver zonas</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        
        <v-list-item to="/app/categories" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-sitemap</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver categorías del app</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item to="/reports" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-chart-areaspline</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Ver reportes</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item @click="logOut()" @click.stop="active = false">
          <v-list-item-icon>
            <v-icon>mdi-logout</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>LogOut</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        

      </v-list>
    </v-navigation-drawer>

    <v-main class="pa-0">
      <div class="d-print-none" style="margin-top: 64px;"></div>
      <router-view :key="$route.fullPath"></router-view>
    </v-main>

    <vue-snotify></vue-snotify>

    <audio id="alert_new_order" controls style="display:none;">
      <source :src="require('./assets/alert.mp3')" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>

    <audio id="alert_change_status" controls style="display:none;">
      <source :src="require('./assets/alert.mp3')" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>

    <v-snackbar bottom right :value="updateExists" :timeout="-1" color="primary">
      Actualización disponible
      <v-btn text @click="refreshApp()">
        Refrescar
      </v-btn>
    </v-snackbar>

    <v-snackbar
      v-model="$store.state.isCloseconectionSocket"
      :timeout="-1"
    >
      La conexión se ha perdido

      <template v-slot:action="{ attrs }">
        <v-btn
          color="info"
          text
          v-bind="attrs"
          @click="$store.state.isCloseconectionSocket = false"
        >
          Cerrar
        </v-btn>
      </template>
    </v-snackbar>

  </v-app>
</template>

<script>
import Parse from 'parse'
import update from './mixins/update.js'

export default {
  name: 'App',

  components: {
   
  },

  mixins: [update],

  data: () => ({
    authenticate: Parse.User.current(),
    active: false
  }),

  methods: {
    logOut() {
      Parse.User.logOut();
      window.location.reload()
    },
  },
};
</script>

<style lang="scss">
@import "~vue-snotify/styles/material";
</style>

<style lang="css">

  .myFont {
    font-family: 'Quicksand' !important;
  }

  .swal-modal {
    font-family: Helvetica Neue, Arial, sans-serif;
  }

</style>