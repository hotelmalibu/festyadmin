import Vue from 'vue'
import Vuex from 'vuex'
import Parse from 'parse'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    isCloseconectionSocket: false,
    orders_pre_created: [],
    orders_created: [],
    orders_preparing: [],
    orders_delivering: [],
    orders_delivered: [],
    orders_nn: [],
    status: [
      {
        id: 6,
        name: "pre-created",
        color: "blue darken-2",
        total: 0,
        title: 'Pendientes transferencia'
      },
      {
        id: 1,
        name: "created",
        color: "yellow darken-2",
        total: 0,
        title: 'Recibidos'
      },
      {
        id: 2,
        name: "preparing",
        color: "orange lighten-1",
        total: 0,
        title: 'Preparando'
      },
      {
        id: 3,
        name: "delivering",
        color: "purple lighten-1",
        total: 0,
        title: 'En camino'
      },
      {
        id: 4,
        name: "delivered",
        color: "green lighten-1",
        total: 0,
        title: 'Entregados'
      },
      {
        id: 5,
        name: "other",
        color: "grey lighten-1",
        total: 0,
        title: 'Otros'
      }
    ],
    statusToma: [
      {
        id: 6,
        name: "pre-created",
        color: "blue darken-2",
        total: 0,
        title: 'Pendientes transferencia'
      },
      {
        id: 1,
        name: "created",
        color: "yellow darken-2",
        total: 0,
        title: 'Recibidos'
      },
      {
        id: 2,
        name: "preparing",
        color: "orange lighten-1",
        total: 0,
        title: 'Preparando'
      },
      {
        id: 3,
        name: "delivering",
        color: "purple lighten-1",
        total: 0,
        title: 'En camino'
      },
      {
        id: 5,
        name: "other",
        color: "grey lighten-1",
        total: 0,
        title: 'Otros'
      }
    ],
    statusDelivered: [
      {
        id: 4,
        name: "delivered",
        color: "green lighten-1",
        total: 0,
        title: 'Entregados'
      },
      {
        id: 5,
        name: "other",
        color: "grey lighten-1",
        total: 0,
        title: 'Otros'
      }
    ],
    categories: {
      food: [
        'Almuerzos',
        'Arepas',
        'Alitas',
        'Arabe',
        'Bebidas',
        'Batidos',
        'Bolws',
        'Cafetería',
        'Carnes',
        'China',
        'Internacional',
        'Japonesa',
        'Mexicana',
        'Peruana',
        'Vegetariana',
        'Crepes',
        'Desayunos',
        'Desgranados',
        'Empanadas',
        'Ensaladas',
        'Hamburguesas',
        'Helados',
        'Jugos',
        'Licuados',
        'Parrilla',
        'Pastas',
        'Patacones',
        'Pescados',
        'Mariscos',
        'Panaderia',
        'Picadas',
        'Pizzas',
        'Pollo',
        'Perros Calientes',
        'Postres',
        'Pulpas',
        'Quibbes',
        'Reposteria',
        'Sándwiches',
        'Salchipapas',
        'Sushi',
        'Wraps',
        'Waffles',
      ],
      drink: [
        'Cervezas',
        'Whiskey',
        'Vodka',
        'Micheladas',
        'Ron',
        'Aguardiente',
      ],
      market: [
        'Canasta Familiar',
        'Productos Naturales',
        'Diseño de interiores',
        'Hogar',
        'Farmacia',
        'Ferreteria',
        'Herramientas',
        'Artesanias',
        'Tecnología',
        'Mascotas',
        'Moda',
        'Belleza',
        'Deportes',
      ]
    },
  },
  getters: {
    getOrdersPreCreated: state => {
      return state.orders_pre_created
    },
    getOrdersCreated: state => {
      return state.orders_created
    },
    getOrdersPreparing: state => {
      return state.orders_preparing
    },
    getOrdersDelivering: state => {
      return state.orders_delivering
    },
    getOrdersDelivered: state => {
      return state.orders_delivered
    },
    getOrdersNn: state => {
      return state.orders_nn
    },
    getState: state => {
      return state.status
    }
  },
  mutations: {
    setOrdersPreCreated(state, value) {
      state.orders_pre_created = value;
    },
    setOrdersCreated(state, value) {
      state.orders_created = value;
    },
    setOrdersPreparing(state, value) {
      state.orders_preparing = value;
    },
    setOrdersDelivering(state, value) {
      state.orders_delivering = value;
    },
    setOrdersDelivered(state, value) {
      state.orders_delivered = value;
    },
    setOrdersNn(state, value) {
      state.orders_nn = value;
    },
    addOrdersPreCreated(state, value) {
      state.orders_pre_created.unshift(value);
    },
    addOrdersCreated(state, value) {
      state.orders_created.unshift(value);
    },
    addOrdersPreparing(state, value) {
      state.orders_preparing.unshift(value);
    },
    addOrdersDelivering(state, value) {
      state.orders_delivering.unshift(value);
    },
    addOrdersDelivered(state, value) {
      state.orders_delivered.unshift(value);
    },
    addOrdersNn(state, value) {
      state.orders_nn.unshift(value);
    },
    removeLastElementOfOrdersDelivered(state){
      state.orders_delivered.splice(-1,1)
    }
  },
  actions: {
    //eslint-disable-next-line
    async getStoreOrders({ commit, state }) {
      try {
        
        state.orders_pre_created = []
        state.orders_created = []
        state.orders_preparing = []
        state.orders_delivering = []
        state.orders_delivered = []
        state.orders_nn = []

        /*const params =  {
          storeId: 'qab9u94Qdz',
          status: 'delivered'
        };*/
        let orders = await Parse.Cloud.run("getAllStoresOrdersBO");

        //eslint-disable-next-line
        //console.log(orders);
        /* eslint-disable */
        let orders_pre_created = orders.filter(function(order) {
          return order.attributes.status === 'pre-created';
        });
        let orders_created = orders.filter(function(order) {
          return order.attributes.status === 'created';
        });
        let orders_preparing = orders.filter(function(order) {
          return order.attributes.status === 'preparing';
        });
        let orders_delivering = orders.filter(function(order) {
          return order.attributes.status === 'delivering';
        });
        let orders_delivered = orders.filter(function(order) {
          return order.attributes.status === 'delivered';
        });
        let orders_nn = orders.filter(function(order) {
          return order.attributes.status !== 'created' && order.attributes.status !== 'preparing' && order.attributes.status !== 'delivering' && order.attributes.status !== 'delivered' && order.attributes.status !== 'pre-created';
        });

        commit('setOrdersPreCreated', orders_pre_created)
        commit('setOrdersCreated', orders_created)
        commit('setOrdersPreparing', orders_preparing)
        commit('setOrdersDelivering', orders_delivering)
        commit('setOrdersDelivered', orders_delivered)
        commit('setOrdersNn', orders_nn)
                
        /* state.orders_created = orders_created
        state.orders_preparing = orders_preparing
        state.orders_delivering = orders_delivering
        state.orders_delivered = orders_delivered
        state.orders_nn = orders_nn */
        
        /* eslint-disable */
        /*console.log('Array for status');
        console.log(state.orders_created);
        console.log(state.orders_preparing);
        console.log(state.orders_delivering);
        console.log(state.orders_delivered);
        console.log(state.orders_nn);*/
        
      } catch (error) {
        //eslint-disable-next-line
        console.log(error.message)
      }
      
    },
  },
  modules: {
  }
})
