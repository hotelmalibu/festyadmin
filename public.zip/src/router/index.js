import Vue from 'vue'
import VueRouter from 'vue-router'
import Parse from 'parse'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../views/Login.vue'),
  },
  {
    path: '/orders',
    name: 'orders',
    alias: '/admin',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "orders" */ '../views/Admin.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/orders-delivered',
    name: 'ordersDelivered',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "orders-delivered" */ '../views/OrdersDelivered.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/stores',
    name: 'stores',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "stores" */ '../views/Stores.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/stores-maps',
    name: 'storesmaps',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "stores-maps" */ '../views/StoresMaps.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/store/:store_id',
    name: 'store',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "invoice-store" */ '../views/InvoiceStore.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/customers/:store_id',
    name: 'customers',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "customers" */ '../views/Customers.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/store-info/:store_id',
    name: 'store_info',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "view-store" */ '../views/ViewStore.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/invoice/:invoice_id',
    name: 'invoice',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "invoice-print" */ '../views/InvoicePrint.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/invoice-payments/:invoice_id',
    name: 'invoicePayments',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "invoice-payments" */ '../views/InvoicePayments.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/products/:store_id',
    name: 'products',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "products" */ '../views/Products.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/categories/:store_id',
    name: 'categories',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "product-categories" */ '../views/ProductCategories.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/riders',
    name: 'riders',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "riders" */ '../views/Riders.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/riders-map',
    name: 'ridersMap',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "riders-map" */ '../views/RidersMaps.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/rider-orders/:rider_id',
    name: 'riderOrders',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "rider-orders" */ '../views/RiderOrders.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/push-sms-template',
    name: 'smspushtemplate',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "push-sms" */ '../views/PushSmsTemplate.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/geo-coverage/:store_id',
    name: 'geocoverage',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "geo-coverage" */ '../views/StoreCreatePolygon.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/invoices-payment-due',
    name: 'invoicesPaymentDue',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "invoices-due" */ '../views/StoresInvoucesDue.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/reports',
    name: 'Reports',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "reports-general" */ '../views/Report.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/reports/:store_id',
    name: 'reportsByStore',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "reports-store" */ '../views/ReportByStore.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/report/:report_id',
    name: 'Report',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "report-detail" */ '../views/reports/General.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/promo-code-uses',
    name: 'promoCode',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "promo-code-uses" */ '../views/PromoCode.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/promo-code-crud',
    name: 'promoCodeCrud',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "promo-code-crud" */ '../views/PromoCodeCrud.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/config/schedule/:store_id',
    name: 'schedule',
    component: () => import(/* webpackChunkName: "schedule-config" */ '../views/WeekDaysConfig.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/history-orders/:user_id',
    name: 'historyOrdersUser',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "history-orders" */ '../views/HistoryOrder.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/masive-notifications',
    name: 'masiveNotifications',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "notifications-massive" */ '../views/SendNotificationMasive.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/logs-store/:store_id',
    name: 'logsStore',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "logs-store" */ '../views/logsStore.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/products/discount/:store_id',
    name: 'productDiscount',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "products-discount" */ '../views/ProductsDiscount.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/banners',
    name: 'appBanner',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "app-banner" */ '../views/AppBanner.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/zones',
    name: 'zones',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "zones" */ '../views/zones.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/app/categories',
    name: 'appCategories',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "app-categories" */ '../views/AppCategories.vue'),
    meta: { requiresAuth: true, role: ['Administrador', 'support'] }
  },
  {
    path: '/stores/banners/:store_id',
    name: 'storeBanners',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "store-banners" */ '../views/storeBanners.vue'),
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
})

router.beforeEach( async (to, from, next) => {
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  const loggedIn = Parse.User.current();
  const roles_array = to.meta.role;

  if (requiresAuth && !loggedIn) {
    return next('/');
  }

  if (roles_array) {
    const params = {
      roles: roles_array
    }

    try {
      const isRoleUser = await Parse.Cloud.run("checkIfRoleIsWell", params);

      //eslint-disable-next-line
      //console.log(roles_array);
      //console.log(isRoleUser);
      if(!isRoleUser){
        Parse.User.logOut();
        return next({
          path: '/',
          query: {
            err: '403',
          }
        });
      }
      
    } catch (error) {
      if (error && error.code == 209) {
        Parse.User.logOut();
        window.location.reload();
      }
    }

  }
  next();
})

export default router
