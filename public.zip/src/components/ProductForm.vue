<template>
  <v-container>
    <validation-observer v-slot="{ invalid, validate }">

      <v-img :src="product.imageUrl"
            contain
            aspect-ratio="1.7778"
            v-if="hasImageUrl()"
      ></v-img>

      <v-file-input prepend-inner-icon="mdi-camera"
                    accept="image/*"
                    label="Cambiar foto"
                    class="ma-1"
                    prepend-icon=""
                    color="black"
                    messages="La imagen no debe contener números de teléfono"
                    v-model="productImageFile"
                    @change="setUploadImageAsTrue()"
                    small-chips
                    filled
      >
        <template v-slot:append>
          <v-btn icon
                 color="green"
                 style="margin-top: -4px"
                 v-if="canUploadProductImage"
                 :loading="sending.image"
                 @click="uploadProductImage()">
            <v-icon>mdi-cloud-upload</v-icon>
          </v-btn>
        </template>
      </v-file-input>

      <form @submit.prevent="validate().then(save())">
        <v-row class="ma-0">
          <v-col :cols="canShowComboOptionTextFields() ? 4 : 6">

            <validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="nombre"
            >
              <v-text-field outlined
                            class="mt-3"
                            v-model="product.name"
                            label="Nombre"
                            color="black"
                            :error-messages="errors"
              ></v-text-field>
            </validation-provider>

            <validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="precio"
            >
              <v-text-field outlined
                            class="mt-3"
                            v-model.number="product.price"
                            label="Precio"
                            color="black"
                            messages="No es necesario ponerle puntos"
                            :error-messages="errors"
              ></v-text-field>
            </validation-provider>

            
            <validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="newCategoria"
                                 v-if="newCategories"
            >
              <v-autocomplete outlined
                              solo
                              color="black"
                              placeholder="Nueva Categoría"
                              no-data-text="No se encontraron categorias"
                              item-text="attributes.name"
                              return-object
                              v-model="product.newCategory"
                              :items="newCategories"></v-autocomplete>
            </validation-provider>

            <!--<validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="categoria"
            >
            <v-autocomplete outlined
                              solo
                              color="black"
                              no-data-text="No se encontraron categorias"
                              placeholder="Categoría (Anterior)"
                              v-model="product.category"
                              :items="productCategories"></v-autocomplete>
            </validation-provider>-->

            <validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="descripcion"
            >
              <v-textarea outlined
                          class="mt-3"
                          v-model="product.description"
                          label="Descripción"
                          color="black"
                          :error-messages="errors"
              ></v-textarea>
            </validation-provider>
          </v-col>

          <v-col :cols="canShowComboOptionTextFields() ? 4 : 6">
            <p>Disponible para los usuarios</p>
            <v-radio-group v-model="product.status"
                           row
            >
              <v-radio label="Si"
                       value="active"
                       color="black"
              ></v-radio>
              <v-radio label="No"
                       value="inactive"
                       color="black"
              ></v-radio>
            </v-radio-group>

            <p>Costo del Domicilio</p>
            <v-radio-group v-model="deliveryCostPayment"
                           row
            >
              <v-radio label="Gratis"
                       :value="false"
                       color="black"
              ></v-radio>
              <v-radio label="Pago"
                       :value="true"
                       color="black"
              ></v-radio>
            </v-radio-group>

            <validation-provider v-slot="{ errors }"
                                 rules="required"
                                 name="costo del envio"
                                 v-if="canShowDeliveryCostPaymentTextField()"
            >
              <v-text-field outlined
                            class="mt-3"
                            v-model.number="product.deliveryCost"
                            label="Costo del Envío"
                            color="black"
                            :error-messages="errors"
              ></v-text-field>
            </validation-provider>

            <p>¿Es un producto exclusivo?</p>
            <v-radio-group v-model="product.exclusive"
                           row
            >
              <v-radio label="Si"
                       v-bind:value="true"
                       color="black"
              ></v-radio>
              <v-radio label="No"
                       v-bind:value="false"
                       color="black"
              ></v-radio>
            </v-radio-group>

            <p>Tiene opción de combo</p>
            <v-radio-group v-model="product.comboOption"
                           row
            >
              <v-radio label="Si"
                       v-bind:value="true"
                       color="black"
              ></v-radio>
              <v-radio label="No"
                       v-bind:value="false"
                       color="black"
              ></v-radio>
            </v-radio-group>
          </v-col>

          <v-col :cols="canShowComboOptionTextFields() ? 4 : 6">
            <validation-provider v-slot="{ errors }"
                                 rules="required"
                                 name="precio del combo"
                                 v-if="canShowComboOptionTextFields()"
            >
              <v-text-field outlined
                            class="mt-3"
                            v-model.number="product.comboPrice"
                            label="Precio del Combo"
                            color="black"
                            messages="No es necesario ponerle puntos"
                            :error-messages="errors"
              ></v-text-field>
            </validation-provider>

            <validation-provider v-slot="{ errors }"
                                 rules="required|min:3"
                                 name="notas del combo"
                                 v-if="canShowComboOptionTextFields()"
            >
              <v-textarea outlined
                          class="mt-3"
                          v-model="product.comboNotes"
                          label="Notas del Combo"
                          color="black"
                          :error-messages="errors"
              ></v-textarea>
            </validation-provider>
          </v-col>
        </v-row>

        <v-row>
          <v-col>
            <v-btn class="white--text ma-1"
                   color="black"
                   @click.stop="emitCanceled()"
            >
              Cancelar
            </v-btn>

            <v-btn type="submit"
                   class="white--text ma-1"
                   color="green"
                   :loading="sending.form"
                   :disabled="invalid"
            >
              Guardar
            </v-btn>
          </v-col>
        </v-row>
      </form>
    </validation-observer>
  </v-container>
</template>

<script>
import Parse from "parse"
import {ValidationProvider, ValidationObserver} from "vee-validate"
import {extend, localize} from "vee-validate";
import {digits, image, min, required} from "vee-validate/dist/rules";
import es from 'vee-validate/dist/locale/es.json'

extend('required', required)
extend('min', min)
extend('digits', digits)
extend('image', image)
localize('es', es)

export default {
  name: "ProductForm",
  props: {
    merchantId: {
      type: String,
      required: true
    },
    isUpdating: {
      type: Boolean,
      default: false
    },
    product: {
      type: Object,
      required: false,
      default: () => ({
        id: '',
        name: '',
        category: '',
        imageUrl: '',
        price: '',
        description: '',
        status: 'inactive',
        deliveryCost: 0,
        comboOption: false,
        comboNotes: '',
        comboPrice: 0,
        superCategory: '',
        newCategory: '',
        exclusive: false
      })
    },
    newCategories: {
      type: Array,
      required: false
    },
  },
  data() {
    return {
      deliveryCostPayment: false,
      canUploadProductImage: false,
      productCategories: [],
      productImageFile: {},
      sending: {
        form: false,
        image: false
      },
    }
  },
  components: {
    ValidationObserver,
    ValidationProvider
  },

  mounted() {
    if (this.isDeliveryCostPayment()) {
      this.setDeliveryCostPaymentAsTrue()
    }

    this.fetchSuperCategoryOfThisMerchant()
        .then(response => {
          let subcategory = response.attributes.category
          this.product.superCategory = response.attributes.category
          this.productCategories = this.getCategoriesInState(subcategory)
        })
  },
  methods: {
    hasImageUrl() {
      return this.product.imageUrl !== ''
    },

    isDeliveryCostPayment() {
      return this.product.deliveryCost > 0
    },

    getCategoriesInState(subcategory) {
      return this.$store.state.categories[subcategory]
    },

    setDeliveryCostPaymentAsTrue() {
      this.deliveryCostPayment = true
    },

    setUploadImageAsTrue() {
      this.canUploadProductImage = true
    },

    setUploadImageAsFalse() {
      this.canUploadProductImage = false
    },

    setSendingImageAsTrue() {
      this.sending.image = true
    },

    setSendingImageAsFalse() {
      this.sending.image = false
    },

    setSendingFormAsTrue() {
      this.sending.form = true
    },

    setSendingFormAsFalse() {
      this.sending.form = false
    },

    canShowDeliveryCostPaymentTextField() {
      return this.deliveryCostPayment === true
    },

    canShowComboOptionTextFields() {
      return this.product.comboOption === true
    },

    getAction() {
      return 'newPromoBO'
    },

    save() {
      this.setSendingFormAsTrue()
        /* eslint-disable */
      this.runParseCloud(this.getAction(), this.getParams())
          .then(response => this.emitSaved())
          .catch(error => this.showErrorMessage('Error', error.message))
          .finally(() => this.setSendingFormAsFalse())
    },

    getParams() {
      let params = {
        name: this.product.name,
        imageUrl: this.product.imageUrl,
        description: this.product.description,
        price: this.product.price,
        status: this.product.status,
        category: this.product.newCategory ? this.product.newCategory.attributes.name : '', //this.product.category,
        deliveryCost: this.product.deliveryCost,
        comboOption: this.product.comboOption,
        comboPrice: this.product.comboPrice,
        comboNotes: this.product.comboNotes,
        superCategory: this.product.superCategory,
        productCategory: this.product.newCategory ? this.product.newCategory.id : '',
        exclusive: this.product.exclusive
      }

      if (this.isUpdating) {
        params.id = this.product.id
      } else {
        params.storeId = this.merchantId
      }

      return params
    },

    uploadProductImage() {
      this.setSendingImageAsTrue()
      this.uploadImage()
    },

    uploadImage() {
      this.getBase64(this.productImageFile)
          .then(response => {
            let splitImage = response.split(',')

            let file = new Parse.File(
                this.productImageFile.name,
                {base64: splitImage[1]},
                this.productImageFile.type
            )

            file.save()
                .then(response => this.product.imageUrl = response._url)
                .catch(error => this.showErrorMessage('Error', error.message))
                .finally(() => {
                  this.setSendingImageAsFalse()
                  this.setUploadImageAsFalse()
                })
          })
    },

    getBase64(file) {
      return new Promise(((resolve, reject) => {
        const fileReader = new FileReader()
        fileReader.readAsDataURL(file)
        fileReader.onload = () => resolve(fileReader.result)
        fileReader.onerror = error => reject(error)
      }))
    },

    fetchSuperCategoryOfThisMerchant() {
      return this.runParseCloud('getStoreBO', {id: this.merchantId})
    },

    runParseCloud(name, params, options = {}) {
      return Parse.Cloud.run(name, params, options)
    },

    emitSaved() {
      this.$emit('product:saved')
    },

    emitCanceled() {
      this.$emit('product:canceled')
    },

    showErrorMessage(title, message) {
      this.$snotify.error(message, title, {timeout: 4000, preventDuplicates: true});
    }
  }
}
</script>

<style scoped>

</style>