<template>
   <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn
                icon
                v-on="on"
              >
                <v-icon >mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="modalCall(order, 'store')">
                <v-list-item-title>Llamar al comercio</v-list-item-title>
              </v-list-item>
              <v-list-item @click="modalCall(order, 'client')">
                <v-list-item-title>Llamar al cliente</v-list-item-title>
              </v-list-item>
              <v-list-item @click="openPushDialog(order)">
                <v-list-item-title>Enviar Push</v-list-item-title>
              </v-list-item>
              <v-list-item @click="markAsDelivered(order)">
                <v-list-item-title>Marcar como entregada</v-list-item-title>
              </v-list-item>
              <v-list-item @click="cancelOrderModal(order)">
                  <v-list-item-title>Cancelar orden</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
</template>

<script>
export default {
    
}
</script>