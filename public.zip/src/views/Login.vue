<template>

      <v-container fluid style="height: 100%;">

        <v-row align="center" justify="center" style="height: 100%;">
          <v-col cols="12" sm="6" md="4">
            <v-card class="elevation-12">
              <v-toolbar dark color="#f0e633">
                <v-toolbar-title class="black--text">Formulario de ingreso</v-toolbar-title>
                <v-spacer></v-spacer>
              </v-toolbar>
      
              <v-form @submit.prevent="login" id="login-form">
              <v-card-text>
                  <v-text-field id="email" prepend-icon="mdi-account" name="email" label="Correo electrónico" type="text" v-model="user.email"></v-text-field>
                  <v-text-field id="password" prepend-icon="mdi-lock" name="password" label="Contraseña" type="password" v-model="user.password"></v-text-field>
              </v-card-text>
              
              <v-card-actions>
                <v-row>
                    <v-col cols="12" sm="12" md="12">
                        <v-btn dark block large color="black" form="login-form" type="submit">Ingresar</v-btn>
                    </v-col>
                    <v-col cols="12" sm="12" md="12" class="text-center">
                        <a @click="resetModal = true" style="color: #3371e7; text-decoration: none;">¿Olvidaste tu contraseña?</a>
                    </v-col>
                </v-row>
              </v-card-actions>

              </v-form>

            </v-card>

              <div v-if="error">
                  <v-alert
                    v-model="alert"
                    dismissible
                    type="error"
                  >
                    {{ error.message }}
                  </v-alert>
              </div>

              <div v-if="success">
                  <v-alert
                    v-model="alertSuccess"
                    dismissible
                    type="success"
                  >
                    {{ success.message }}
                  </v-alert>
              </div>

          </v-col>
        </v-row>

    
        <v-dialog
        v-model="resetModal"
        max-width="500"
        scrollable
        >
        <v-card>
            <v-toolbar dark color="#f0e633">
            <v-btn icon dark @click="resetModal = false">
                <v-icon>mdi-arrow-left-circle</v-icon>
            </v-btn>
            <v-toolbar-title>Regresar</v-toolbar-title>
            </v-toolbar>
            <v-form
                ref="form"
                
            >
            <v-card-title 
                class="headline grey lighten-2"
                primary-title
                style="color: #4a4a4a;"
            >
            Recuperar contraseña
            </v-card-title>
            
            <v-card-text>
                <v-text-field 
                prepend-icon="mdi-account" 
                name="email" 
                label="Correo electrónico" 
                type="text" 
                v-model="emailReset"
                hint="Por favor ingrese la dirección de correo electrónico que utilizó en el registro para que podamos enviarle un enlace de restablecimiento de contraseña."
                persistent-hint>
                </v-text-field>
            </v-card-text>
            </v-form>
            
            <v-divider ma-0 style="margin-left:1px;"></v-divider>
            <v-card-actions style="padding: 15px;">
                <v-row wrap>                    
                    <v-btn dark block large color="#3371e7" @click="resetPassword">Enviar</v-btn>
                </v-row>
            </v-card-actions>
            
        </v-card>
        </v-dialog>


      </v-container>

</template>

<script>
/* eslint-disable */
import Parse from 'parse'

  export default {
    mounted (){
      //console.log(Parse.User.current())
      this.$store.state.admin_view = true
      this.$store.state.isValueDeterminate = false
      if(Parse.User.current()){
         this.$router.push('/orders')
      }

      if (this.$route.query.err == '403') {
        this.$snotify.error('Usted no posee los permisos suficientes.' , 'No autorizado', {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },
    data: () => ({
      drawer: null,
      user: {
        email: null,
        password: null
      },
      error: null,
      alert: true,
      success: null,
      alertSuccess: true,
      emailReset: '',
      resetModal: false
    }),
    props: {
      source: String
    },
    methods: {
      async login () {
        let self = this
        self.error = null

        try {

          if (!self.user.email || !self.user.password) {
            self.error = { message: "Los campos no deben estar vacios" };
            throw self.error;
          }

          let email_login = self.user.email.trim();
          email_login = email_login.toLowerCase();

          await Parse.User.logIn(email_login, self.user.password);
          //self.$emit('loginSuccess', res)
          const loggedIn = Parse.User.current();
          const isAdmin = loggedIn.attributes.assistant;

          /*if(!isAdmin){
            Parse.User.logOut()
            //this.loggedUser = null
            throw self.error = { message: "No eres administrador." };
          }*/

          this.$router.go('/')

        } catch (error) {
          this.alert = true
          this.error = error
          console.log(error.message)
        }
      },
      resetPassword(){

        if (!this.emailReset) {
            this.$snotify.error('Debe diligenciar correctamente el formulario.' , 'Formulario', {
                  timeout: 4000,
                  preventDuplicates: true
                });
            return;
        }
        Parse.User.requestPasswordReset(this.emailReset)
            .then(() => {

                this.$snotify.success('Correo de recuperación enviado correctamente.' , 'Enviado', {
                  timeout: 4000,
                  preventDuplicates: true
                });

                this.resetModal = false
            
            }).catch((error) => {
            // Show the error message somewhere
            this.$snotify.error(error.message , error.code, {
                  timeout: 4000,
                  preventDuplicates: true
                });
        });
      }
    }
  }
</script>