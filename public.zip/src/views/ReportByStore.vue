<template>
    <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;" v-if="companie">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Reporte <strong>({{ companie.attributes.name }})</strong> </v-toolbar-title>

          <v-spacer></v-spacer>

            <download-excel
                class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
                :data = "monthTotalOrders"
                :fields = "headers_export"
                worksheet = "Festy reporte mensual"
                name = "ReportMonthValues.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
            </download-excel>

        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
            
            <v-row>
                 <v-col cols="12" >
                    <div>
                        <month-total-chart v-if="datacollection" :chart-data="datacollection" :options="{ responsive: true, maintainAspectRatio: false }"></month-total-chart>
                    </div>
                </v-col>
                <v-col cols="12">
                    <v-data-table
                        :loading="loading"
                        loading-text="Cargando... Por favor espere"
                        :headers="headers"
                        :items="monthTotalOrders"
                        :search="search"
                        :footer-props="pagination"
                        :header-props="{
                        sortByText: 'Ordenar por'
                        }"
                        class="elevation-1"
                    >
                        <template v-slot:top>
                        <v-toolbar flat color="white">
                            <v-toolbar-title>Reporte mes a mes</v-toolbar-title>
                            <v-spacer></v-spacer>
                            <v-text-field
                                v-model="search"
                                append-icon="mdi-magnify"
                                label="Buscar.."
                                single-line
                                hide-details
                                class="d-print-none mr-2"
                            ></v-text-field>
                            <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
                        </v-toolbar>
                        </template>
                        
                        <template v-slot:item.attributes.logoUrl="{ item }">
                        <v-avatar
                            size="36px"
                            color="teal"
                            >
                            <img
                                v-if="item.attributes.logoUrl"
                                alt="Avatar"
                                :src="item.attributes.logoUrl"
                            >
                            <span v-else class="white--text">FT</span>
                        </v-avatar>
                        </template>


                        <template v-slot:item.total="{ item }">
                            {{ item.total | currency }}
                        </template>

                        <template v-slot:item.totalPOS="{ item }">
                            {{ item.totalPOS | currency }}
                        </template>

                        <template v-slot:item.totalClient="{ item }">
                            {{ item.totalClient | currency }}
                        </template>

                        <template v-slot:item.totalEfecty="{ item }">
                            {{ item.totalEfecty | currency }}
                        </template>

                        <template v-slot:item.totalTransfer="{ item }">
                            {{ item.totalTransfer | currency }}
                        </template>

                        <!--<template v-slot:item.action="{ item }">
                        <v-icon
                            class="mr-2"
                            @click="sendInvoice(item)"
                        >
                            mdi-email-send-outline
                        </v-icon>
                        </template>-->
                        <template v-slot:no-data>
                        <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
                        </template>
                    </v-data-table>
                </v-col>
               
            </v-row>
        </v-card-text>
      </v-card>
    </v-card>

  </v-container>
   
</template>

<script>
import MonthTotalChart from './../Charts/MonthTotalChart'
import Parse from 'parse'
import JsonExcel from 'vue-json-excel'

export default {

    components: {
      MonthTotalChart,
       'download-excel': JsonExcel
    },

    data() {
        return {
            companie: '',
            datacollection: null,
            monthTotalOrders: [],
            months: [],
            loading: true,
            search: '',
            headers: [
              { text: 'Mes', align: 'left', value: 'month' },
              { text: 'Valor POS', align: 'center', value: 'totalPOS' },
              { text: 'Valor Festy', align: 'center', value: 'totalClient' },
              { text: 'Valor Efectivo', align: 'center', value: 'totalEfecty' },
              { text: 'Valor Tranferencias', align: 'center', value: 'totalTransfer' },
              { text: 'Valor Total', align: 'center', value: 'total' },

              { text: 'Total POS', align: 'center', value: 'lengthPOS' },
              { text: 'Total Festy', align: 'center', value: 'lengthClient' },
              //{ text: 'Total Efectivo', align: 'center', value: 'lengthEfecty' },
              //{ text: 'Total Tranferencias', align: 'center', value: 'lengthTransfer' },
              { text: 'Total ordenes', align: 'center', value: 'length' },
              //{ text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            headers_export: {
                'Mes': 'month',
                'Valor POS': 'totalPOS',
                'Valor Festy': 'totalClient',
                'Valor Efectivo': 'totalEfecty',
                'Valor Tranferencias': 'totalTransfer',
                'Valor': 'total',
                'Total POS': 'lengthPOS',
                'Total Festy': 'lengthClient',
                'Total ordenes': 'length',
            },
        }
    },

    mounted() {
        this.initialize()
    },

    methods: {
        async initialize() {
            this.loading = true
            const params = {
                id: this.$route.params.store_id
            };

            try {
                let companie = await Parse.Cloud.run("getStoreBO", params);
                this.companie = companie;
                //eslint-disable-next-line
                //console.log(this.companie);
                this.getReport(this.companie);
            } catch (error) {
                this.$swal({
                title: "Comercio",
                text: "Algo salío mal consultado el comercio.",
                icon: "warning",
                buttons: ["Salir", "Entiendo"],
                dangerMode: true
                }).then(ok => {
                if (ok) {
                    this.$router.push("/stores");
                } else {
                    this.$router.push("/stores");
                }
                });
            }
        },
        async getReport(store){
            let arrayData = []

            let params = {
                id: store.id
            }

            try {
                let monthTotalOrders = await Parse.Cloud.run("reportByStoreBO", params);
                this.monthTotalOrders = monthTotalOrders

                if (monthTotalOrders && monthTotalOrders.length > 0) {
                    let months = monthTotalOrders.map(a => a.month);
                    let totals = monthTotalOrders.map(a => a.total);
                    let lengths = monthTotalOrders.map(a => a.length);

                    let totalPOS = monthTotalOrders.map(a => a.totalPOS);
                    let totalClient = monthTotalOrders.map(a => a.totalClient);

                    arrayData.push(
                        {
                            label: 'Valor Total',
                            backgroundColor: '#f87979',
                            data: totals
                        },
                        {
                            label: 'Valor POS',
                            backgroundColor: '#FFFFF',
                            data: totalPOS
                        },
                        {
                            label: 'Valor Festy',
                            backgroundColor: '#FFEB3B',
                            data: totalClient
                        },
                        {
                            label: 'Total ordenes',
                            backgroundColor: '#0000FF',
                            data: lengths
                        },
                    )

                    this.datacollection = {
                        labels: months,
                        datasets: arrayData
                    }
                }else{
                    this.monthTotalOrders = []
                }

                //eslint-disable-next-line
                //console.log(this.payments);
                this.loading = false
            
            } catch (error) {
                this.$swal({
                    title: "Datos del reporte",
                    text: "Algo salío mal consultado los datos del reporte.",
                    icon: "warning",
                    buttons: ['Salir', 'Entiendo'],
                    dangerMode: true,
                    })
                    .then((ok) => {
                    if (ok) {
                        this.$router.push('/')
                    }else{
                        this.$router.push('/')
                    }
                });
            }
            
        },
    }
    
}
</script>