<template>
 <v-container fluid ma-0 pa-0 style="height: 100%;">
   <!--<v-system-bar
         color="primary"
         dark
         class="d-none d-sm-flex"
        >
          <v-icon>mdi-store-outline</v-icon>
          <span class="mr-2">{{ riders.filter(rider => rider[0].rider_store.attributes.status === 'active').length }} domiciliarios activos</span>
          <span class="mr-2">|</span>
          <v-icon>mdi-sleep</v-icon>
          <span class="mr-2">{{ riders.filter(rider => rider[0].rider_store.attributes.status === 'inactive').length }} domiciliarios inactivos</span>
          <v-spacer></v-spacer>
          <v-icon>mdi-wifi-strength-4</v-icon>
          <v-icon>mdi-signal-cellular-outline</v-icon>
          <v-icon>mdi-battery</v-icon>
          <span>12:30</span>
        </v-system-bar>-->
   <GmapMap
        v-if="riders"       
        :center="center"
        :zoom="zoom"
        map-type-id="terrain"
        style="width: 100%; height: 100%"
        :options="{
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false,
            disableDefaultUi: false
        }"
    >
        <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false"></GmapInfoWindow>
        <!--<GmapCluster>-->
        <GmapMarker
            v-for="(item, index) in riders" :key="index"
            :position="{lat: item[0].location ? item[0].location.attributes.location.latitude : 0, lng: item[0].location ? item[0].location.attributes.location.longitude : 0}"
            :clickable="true"
            :draggable="false"
            :label="{text: item[0].rider_store.attributes.rider.attributes.name, color: item[0].rider_store.attributes.status == 'online' ? '#1B5E20' : '#DD2C00', fontWeight: 'bold'}"
            @click="toggleInfoWindow({lat: item[0].location ? item[0].location.attributes.location.latitude : 0, lng: item[0].location ? item[0].location.attributes.location.longitude : 0}, `<strong>Domiciliario:</strong> ${item[0].rider_store.attributes.rider.attributes.name} <br> <strong>Comercios:</strong> ${getStoreByItem(item)}`)"
            :icon="{ url: item[0].rider_store.attributes.status == 'online' ? require('../assets/market-rider.png') : require('../assets/market-rider-offline.png'), labelOrigin: {x: 30, y: 55}}"
        />
        <!--</GmapCluster>-->

    </GmapMap>
    
  </v-container>
</template>

<script>
import Parse from 'parse'
//import GmapCluster from 'vue2-google-maps/dist/components/cluster'
import { _ } from "vue-underscore";

export default {

    components: {
        //'GmapCluster': GmapCluster
    },

    data() {
        return {
            riders: [],
            infoWindowPos: null,
            infoWinOpen: false,
            infoOptions: {
                content: '',
                //optional: offset infowindow so it visually sits nicely on top of our marker
                pixelOffset: {
                width: 0,
                height: -35
                }
            },
            zoom: 13,
            center: {
                lat: 9.2963691,
                lng: -75.3859901
            },
        }
    },
    computed: {
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    created () {
      this.initialize()
    },

    methods: {
        async initialize () {
            try {
                let riders = await Parse.Cloud.run("getRidersLocationBO");
                //this.riders = riders
                
                this.loading = false
                let riders_structure = _.groupBy(_.sortBy(riders, function(rider){
                    return rider
                }), function(rider) {
                    return rider.rider_store.attributes.rider.id;
                })
                //eslint-disable-next-line
                //console.log(riders_structure);
                this.riders = riders_structure

                this.infoWinOpen = false,
                this.zoom = 13  
                //this.center = {lat: riders[20].attributes.location.latitude, lng: riders[20].attributes.location.longitude}
            
            } catch (error) {
            this.$snotify.error(`${error}` , 'Comercios', {
                timeout: 4000,
                preventDuplicates: true
            });
            }
            
        },

        toggleInfoWindow(position, infoText) {
            this.infoWindowPos = position;
            this.infoOptions.content = infoText;
            this.infoWinOpen = !this.infoWinOpen;
        },

        getStoreByItem(items){
            //eslint-disable-next-line
            //console.log(items);
            let string_stores = ''
            items.forEach((element, index) => {
                if (element.rider_store.attributes.store.attributes.name) {
                    string_stores += element.rider_store.attributes.store.attributes.name
                }
                if (index < items.length-1) {
                    string_stores += ', '
                }
            });
            
            return string_stores
        }
    },
}
</script>