<template>

    <v-container fluid>
        
   
    <div class="invoice-box" v-if="invoice && orders">
        
        <v-sheet color="success" class="headline text-center white--text d-print-none mb-2" v-if="invoice.attributes.status === 'paid'"> <v-icon class="white--text">mdi-check-outline</v-icon> PAGADA</v-sheet>
        <v-btn color="black" class="mb-2 white--text float-right d-print-none" @click.prevent="print_detail_invoice()"><v-icon left>mdi-printer</v-icon>Imprimir</v-btn>
       
        <table cellpadding="0" cellspacing="0" ref="printMe" class="">
            <tr class="top">
                <td colspan="4">
                    <table>
                        <tr>
                            <td class="title">
                                <img :src="require('../assets/logo.png')" style="width:100%; max-width:100px;">
                            </td>

                            <td class="d-none d-md-flex">
                            </td>
 
                            <td class="d-none d-md-flex">
                            </td>
                            
                            <td class="text-capitalize">
                                <strong>Reporte #:</strong> {{invoice.id}}<br>
                                <strong>Año:</strong> {{ $moment(invoice.createdAt).format('YYYY')}}<br>
                                <strong>Periodo:</strong> {{ $moment(invoice.attributes.endDate).format('MMMM') }}
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="4">
                    <table>
                        <tr>
                            <td>
                                FESTY APP SAS<br>
                                Sincelejo, Sucre<br>
                                Nit: 901348823-8
                            </td>

                            <td class="d-none d-md-flex">
                            </td>

                            <td class="d-none d-md-flex">
                            </td>
                            
                            <td>
                                {{ invoice.attributes.store.attributes.name }}<br>
                                {{ invoice.attributes.store.attributes.address }}<br>
                                {{ invoice.attributes.store.attributes.phone }}
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading" v-if="!invoice.attributes.noDiscountApplies && invoice.attributes.discount > 0">
                <td>
                    Descuentos
                </td>

                <td>
                </td>

                 <td>
                </td>
                
                <td>
                    Total
                </td>
            </tr>
            
            <tr class="details" v-if="!invoice.attributes.noDiscountApplies && invoice.attributes.discount > 0">
                <td>
                    Códigos promocionales
                </td>

                <td>
                </td>

                 <td>
                </td>
                
                <td>
                    {{ invoice.attributes.discount | currency }}
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Pedidos
                </td>

                <td style="width: 200px;">
                    Fecha
                </td>
                
                <td>
                    Precio
                </td>
                <td>
                    Facturable
                </td>
            </tr>
            
            <tr :class="index != Object.keys(orders).length - 1 ? 'item last' : 'item'" v-for="(order, index) in orders" :key="index">
                <td>
                    {{getPedidoText(order.attributes.items)}}
                </td>

                <td>
                    {{ $moment(order.createdAt).format('LLL')}}
                </td>
                
                <td>
                    {{ (order.attributes.total - order.attributes.deliveryCost) > 10000 ? $options.filters.currency(order.attributes.store.attributes.plan.attributes.order_price) : '$0' }}
                </td>
                
                <td>
                    <v-icon v-if="(order.attributes.total - order.attributes.deliveryCost) > 10000">mdi-check</v-icon>
                </td>
            </tr>

            <tr class="item last">
                <td>
                    Total de pedidos
                </td>

                <td>
                </td>

                <td>
                </td>
                
                <td>
                    {{ orders.length }}
                </td>
            </tr>

            <tr class="item last">
                <td>
                    Total de pedidos facturables
                </td>

                <td>
                </td>

                <td>
                </td>
                
                <td>
                    {{ orders.filter(order => (order.attributes.total - order.attributes.deliveryCost) > 10000).length }}
                </td>
            </tr>

            <tr class="item last">
                <td>
                    IVA
                </td>

                <td>
                </td>

                <td>
                </td>
                
                <td>
                    {{ invoice.attributes.tax | currency }}
                </td>
            </tr>

            <tr class="item last">
                <td>
                    Precio base para el plan {{ invoice.attributes.planName }}
                </td>

                <td>
                </td>

                <td>
                </td>
                
                <td>
                    {{ invoice.attributes.baseCost | currency }}
                </td>
            </tr>
            
            <tr class="total">
                <td>
                </td>

                <td>
                </td>

                <td>
                </td>

                <td>
                   Total: {{ invoice.attributes.total | currency }}
                </td>
            </tr>
        </table>
    </div>
    </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    
    data() {
        return {
            invoice: '',
            orders: '',
        }
    },

    mounted() {
        this.getInvoice()
    },

    methods: {

        async getInvoice(){
            const params = {
                id: this.$route.params.invoice_id
            }

            try {
            let invoce = await Parse.Cloud.run("getInvoceBO", params);
            this.invoice = invoce
            //eslint-disable-next-line
            //console.log(this.invoice);
            this.loading_invoices = false

            this.getOrdersByInvoice(this.invoice)
            
            } catch (error) {
                this.$swal({
                    title: "Facturas",
                    text: "Algo salío mal consultado la factura.",
                    icon: "warning",
                    buttons: ['Salir', 'Entiendo'],
                    dangerMode: true,
                    })
                    .then((ok) => {
                    if (ok) {
                        this.$router.push('/stores')
                    }else{
                        this.$router.push('/stores')
                    }
                });
            }
        },

        async getOrdersByInvoice(invoice){

            let params = {
                store_id : invoice.attributes.store.id,
                init : invoice.attributes.startDate,
                end : invoice.attributes.endDate
            }

            try {
                let orders = await Parse.Cloud.run("getOrderByPeriodBO", params);
                this.orders = orders
                //eslint-disable-next-line
                //console.log(this.orders);
            } catch (error) {
                this.$snotify.error(`Error consultado las ordenes de la factura` , 'Facturas', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        print_detail_invoice(){
            window.print();
        },

        getPedidoText(items, slice_text){
            let pedido_text = ''
            let pedido_text_temp = ''
            if (items) {
                items.forEach((item, index) => {
                pedido_text += `(${item.attributes.quantity}) - ${item.attributes.name} - (${this.$options.filters.currency(item.attributes.price)} c/u) ${item.attributes.comboOption ? ' + (' + this.$options.filters.currency(item.attributes.comboPrice) + ')' : ''}`
                if (index+1 < items.length) {            
                    pedido_text += ', '
                }
                });

                pedido_text_temp = pedido_text

                if (slice_text) {
                pedido_text_temp = pedido_text.substring(0, 150)
                if (pedido_text.length > 150) {
                    pedido_text_temp += '....'
                }
                }

                return pedido_text_temp
            }
        }
    },
}
</script>

<style scoped>
    .invoice-box {
        max-width: 950px;
        margin: auto;
        padding: 30px;
        border: 3px solid #eee;
        /*box-shadow: 0 0 10px rgba(0, 0, 0, .15);*/
        font-size: 16px;
        line-height: 24px;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(4) {
        text-align: right;
    }

    .invoice-box table tr td:nth-child(3) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 4px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(4) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }

        @media print {
            body { 
                overflow: auto;
                height: auto; 
                display: none !important;
            }
            .container {
                width: 100%;
                padding: 0;
                margin-right: auto;
                margin-left: auto;
            }
            .invoice-box {
                max-width: 800px;
                margin: auto;
                padding: 30px;
                border: 1px solid #eee;
               -webkit-box-shadow: none !important;
                box-shadow: none !important;
                font-size: 16px;
                line-height: 24px;
                color: #555;
            }
        }
    }
    
</style>