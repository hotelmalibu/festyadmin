<template>
   <v-container fuild>
        <v-card flat>
        <v-toolbar color="grey darken-4" dark extended flat>
            <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
        </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
            <v-toolbar-title class="black--text"> Horarios <strong v-if="this.companie"> - ({{this.companie.attributes.name}})</strong> </v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn dark @click="saveScheduleStore()">
                <v-icon left>mdi-content-save</v-icon>
                Guardar cambios
            </v-btn>
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text class="pt-0">
            <v-row>
                <v-col cols="12" class="pl-4">
                    <v-switch
                    v-model="schedule"
                    inset
                    :label="`Activar programación de horarios`"
                    color="success"
                    true-value="active"
                    false-value="inactive"
                    hide-details
                    @change="closePanels"
                    ></v-switch>
                </v-col>

                <v-col cols="12" class="pt-1 pb-0" v-if="schedule == 'active'">
                    <p class="ma-0 pl-2">Seleccione los días laborares para su comercio</p>
                    <v-chip-group
                        column
                        multiple
                        :disabled="!(schedule  == 'active')"
                        v-model="daysActive"
                        @change="activeOrInactiveDays()"
                        color="info"
                    >
                        <v-chip
                            v-for="(item, index) in weekdays.weekdays" :key="index"
                            filter
                            outlined
                        >
                        {{ trasleteWeekDay(item.name) }}
                        </v-chip>
                    </v-chip-group>
                </v-col>

                 <v-col cols="12">
                    <v-expansion-panels focusable :disabled="!(schedule  == 'active')" v-model="panels">
                        <v-expansion-panel
                            v-for="(item, i) in weekdays.weekdays" :key="i"
                            :disabled="item.status == 'active' ? false : true"
                            :class="`${item.name}`"
                        >
                        <v-expansion-panel-header disable-icon-rotate @click="goToTitlePanel(item.name)">
                            <strong>{{ trasleteWeekDay(item.name) }}</strong>
                            <template v-slot:actions>
                                <v-icon color="success" v-if="item.status == 'active'">
                                mdi-check
                                </v-icon>
                                <v-icon color="error" v-else>
                                mdi-sleep
                                </v-icon>
                            </template>
                        </v-expansion-panel-header>
                        <v-expansion-panel-content>
                            <v-row>
                                <v-col cols="12" md="2" v-for="(hour, index) in item.hours" :key="index" class="pa-0">
                                <v-switch
                                    inset
                                    :label="`${index}:00 Horas`"
                                    color="success"
                                    value
                                    :input-value="hour"
                                    @change="setHours($event, item, index)"
                                    hide-details
                                    dense
                                    class="pb-1 font-weight-bold"
                                ></v-switch>
                                <v-divider></v-divider>
                                </v-col>
                            </v-row>
                        </v-expansion-panel-content>
                        </v-expansion-panel>
                    </v-expansion-panels>
                 </v-col>
            </v-row>
        </v-card-text>
      </v-card>
    </v-card>
   </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    data() {
        return {
            weekdays: [],
            weekdays_default: {
                weekdays: [
                    {
                        id: 0,
                        name: "sunday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "inactive"
                    },
                    {
                        id: 1,
                        name: "monday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    },
                    {
                        id: 2,
                        name: "tuesday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    },
                    {
                        id: 3,
                        name: "wednesday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    },
                    {
                        id: 4,
                        name: "thursday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    },
                    {
                        id: 5,
                        name: "friday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    },
                    {
                        id: 6,
                        name: "saturday",
                        hours: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                        status: "active"
                    }
                ],
                status: 'inactive'
            },
            hours: [],
            schedule: false,
            panels: [],
            daysActive: [],
            companie: ''
        }
    },

    async mounted() {
        await this.initialize()
    },

    methods: {
        async initialize(){
            try {
                let params = {
                    id: this.$route.params.store_id
                }
                let companie = await Parse.Cloud.run("getStoreBO", params);
                this.companie = companie
                //eslint-disable-next-line
                //console.log(companie.attributes.hours.weekdays[0]);
            if (companie && companie.attributes.hours) {
                this.weekdays = companie.attributes.hours
                this.schedule = companie.attributes.hours.status
            } else {
                this.weekdays = this.weekdays_default
            }
            this.getActiveDays()
            this.activeOrInactiveDays()
            this.loading = false
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Horarios', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        trasleteWeekDay(weekday){
            switch (weekday) {
                case 'sunday': return 'Domingo'
                case 'monday': return 'Lunes'
                case 'tuesday': return 'Martes'
                case 'wednesday': return 'Miercoles'
                case 'thursday': return 'Jueves'
                case 'friday': return 'Viernes'
                case 'saturday': return 'Sábado'
                default: return 'Día no especificado'
            }
        },

        setHours($event, item, index){
            if (this.weekdays && this.weekdays.weekdays.length > 0) {
                this.weekdays.weekdays[item.id].hours[index] = $event ? 1 : 0
            }
        },

        closePanels(){
            this.panels = []
        },

        activeOrInactiveDays(){
            //eslint-disable-next-line
            //console.log(this.weekdays.weekdays);
          if (this.weekdays && this.weekdays.weekdays.length > 0) {
              for (let index = 0; index < this.weekdays.weekdays.length; index++) {
                  if (this.daysActive.length > 0) {
                      let checkWeekDay = this.daysActive.find(weekday => weekday == this.weekdays.weekdays[index].id)
                      if (checkWeekDay != undefined) {
                          this.weekdays.weekdays[index].status = 'active'
                      }else{
                          this.weekdays.weekdays[index].status = 'inactive'
                      }
                  }else{
                      this.weekdays.weekdays[index].status = 'inactive'
                  }
              }
            
            this.panels = []
          }
        },

        getActiveDays(){
            let daysActive = this.weekdays.weekdays.map(weekday => {
                if (weekday.status == 'active') {
                    return weekday.id
                }
            })
            this.daysActive = daysActive.filter(el => el === 0 || Boolean(el));
        },

        async saveScheduleStore(){
            try {
                if (!this.weekdays) {
                    this.$snotify.error(`horario no enviado` , 'Horarios', {
                        timeout: 4000,
                        preventDuplicates: true
                    });
                    return;
                }

                this.weekdays.status = this.schedule;
                //eslint-disable-next-line
                //console.log(this.weekdays);

                const params = {
                    id: this.companie.id,
                    hours: this.weekdays
                }
                await Parse.Cloud.run("updateHours", params);
                this.initialize();

                this.$snotify.success(`Se ha guardado el horario` , 'Horarios', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Horarios', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        goToTitlePanel(item) {
            const el = this.$el.getElementsByClassName(item)[0];
            setTimeout(function(){
                if (el) {
                    // Use el.scrollIntoView() to instantly scroll to the element
                    el.scrollIntoView({behavior: 'smooth'});
                }
            }, 500);
        }
    },
}
</script>