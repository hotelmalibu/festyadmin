<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1000"
      style="margin-top: -64px;"
    >

      <v-toolbar flat>
        <v-toolbar-title class="black--text">Categorías</v-toolbar-title>

        <v-spacer></v-spacer>

        <!--<v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
        ></v-text-field>-->

        <v-btn
            class="mr-1 ml-2 white--text d-print-none"
            color="black"
            @click="newCategoryDialog()"
            target="_blank"
        >
            <v-icon left>mdi-tag-plus</v-icon>Nueva Categoría
        </v-btn>

        <!--<v-btn
            class="mr-1 ml-2 white--text d-print-none"
            color="black"
            @click="massiveProductDialog = true"
            target="_blank"
          >
            <v-icon left>mdi-database-import</v-icon>Importar categorías
        </v-btn>-->
        

        <!--<v-btn icon>
          <v-icon>mdi-magnify</v-icon>
        </v-btn>

        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>-->
        
      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="categories"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
        >
            <!--<template v-slot:top>
              <v-toolbar flat color="white">
              </v-toolbar>
            </template>-->

            <template v-slot:body="props">
                <draggable
                v-model="categories"
                tag="tbody"
                @change="changeIndex"
                >
                <tr
                    v-for="(item, index) in props.items"
                    :key="index"
                >
                    <td>
                    <v-icon
                        small
                        class="page__grab-icon"
                    >
                        mdi-arrow-all
                    </v-icon>
                    </td>
                    <td> {{ index }} </td>
                    <td> {{ item.attributes.name }} </td>
                    <td> {{ item.attributes.color }} </td>
                    <td>  
                        <v-switch
                            v-if="item.attributes.status == 'disabled'"
                            :input-value="item.attributes.status"
                            false-value="enabled"
                            true-value="disabled"
                            color="error"
                            inset
                            @click.native="changeStatusCategory(item)"
                        ></v-switch>
                        <v-switch
                            v-else
                            :input-value="item.attributes.status"
                            false-value="disabled"
                            true-value="enabled"
                            color="success"
                            inset
                            @click.native="changeStatusCategory(item)"
                        ></v-switch>
                    </td>
                    <td>
                    <v-icon
                        class="mr-2"
                        @click="editCategory(item, index + 1)"
                    >
                        mdi-pencil
                    </v-icon>
                    </td>
                </tr>
                </draggable>
            </template>


            <!--<template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="detailProduct(item)"
            >
                mdi-eye
            </v-icon>

             <v-icon
                class="mr-2"
                @click="editCategory(item)"
            >
                mdi-pencil
            </v-icon>

            <v-icon
                class="mr-2"
                @click="copyUrlPromo(item)"
            >
                mdi-content-copy
            </v-icon>

            <a :href="item.attributes.imageUrl" download style="text-decoration:none" target="_blank">
                 <v-icon
                    class="mr-2"
                >
                    mdi-image-move
                </v-icon>
            </a>


            </template>-->
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">Reset</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

    <!-- Dialogo Detail product -->
    <v-dialog
      v-model="detailProductDialog"
      width="450"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{store.attributes.name}}  </span>
          <v-spacer></v-spacer>
          <span class="text-capitalize"> 
            <v-icon>mdi-thumb-up-outline</v-icon> {{ store.attributes.likes }}
          </span>
        </v-card-title>
        <v-img
          max-height="210"
          v-if="store.attributes.imageUrl"
          :src="store.attributes.imageUrl"
          
        ></v-img>

        <v-card-text>
            <v-row dense>
                <v-col cols="6">
                    <div class="pt-2 black--text">
                        <v-icon>mdi-bookmark-multiple</v-icon>
                        {{ store.attributes.superCategory }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 black--text">
                        <v-icon>mdi-bookmark-multiple-outline</v-icon>
                        {{ store.attributes.category }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-cash-usd</v-icon>
                        Precio: {{ store.attributes.price | currency }}
                    </div>
                </v-col>
                <v-col cols="6">
                     <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-cash-multiple</v-icon>
                        En Combo: {{ store.attributes.comboPrice | currency }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-file-eye-outline</v-icon>
                        Vistas: {{ store.attributes.views }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-moped</v-icon>
                        Ordenes: {{ store.attributes.orders }}
                    </div>
                </v-col>
            </v-row>

          <v-divider class=""></v-divider>

          <div class="pt-2 black--text">
            {{store.attributes.description}}
          </div>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="detailProductDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Detail product -->
  
  <!-- Dialogo Edit product -->
    <v-dialog
      v-model="editCategoryDialog"
      width="500"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{ formTitle }} </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-card-text>
          <v-divider class="mb-2"></v-divider>
            <v-row dense>
                <v-col cols="12" md="6">
                    <v-text-field
                      v-model="editedItem.attributes.name"
                      outlined
                      label="Nombre"
                      prepend-inner-icon="mdi-tag"
                      hide-details
                    ></v-text-field>
                </v-col>
                <!--<v-col cols="12" md="6">
                     <v-text-field
                    "
                      outlined
                      label="Orden"
                      prepend-inner-icon="mdi-numeric"
                      hide-details
                    ></v-text-field>
                </v-col>-->
                <v-col cols="12" md="6">
                     <v-text-field
                      v-model="editedItem.attributes.color"
                      outlined
                      label="Color"
                      prepend-inner-icon="mdi-palette"
                      hide-details
                    ></v-text-field>
                </v-col>
                <!--<v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.status"
                      outlined
                      label="Estado"
                      prepend-inner-icon="mdi-cash-usd"
                      prefix="$"
                      hide-details
                    ></v-text-field>
                </v-col>-->
            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
           <v-btn
            :loading="loading"
            color="success"
            outlined
            @click="saveEditCategory(store)"
          >
           <v-icon left>mdi-content-save-outline</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Product -->

    <!-- Dialogo load product massive -->
    <v-dialog
      v-model="massiveProductDialog"
      width="1200"
      v-if="store"
      scrollable
      persistent
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Importar categorías CSV </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
            <v-row dense>
                <v-col cols="12">
                  <vue-csv-import
                    v-model="csv"
                    url="#"
                    :map-fields="['sku', 'name', 'description', 'price', 'deliveryCost', 'imageUrl', 'max', 'superCategory', 'subCategory', 'category', 'featured', 'comboOption', 'comboNotes', 'status']"
                    tableClass="v-data-table theme--light"
                    tableSelectClass="v-input__control h100 display-select"
                    :headers="true"
                    :autoMatchFields="true"
                    :fileMimeTypes="['text/csv']"
                  >

                    <template slot="error">
                       <p class="red--text"><strong>El tipo de archivo es invalido. </strong></p>
                    </template>
                    
                    <template slot="thead">
                        <tr style="border: 1px solid black;">
                            <th style="border: 1px solid black;">Columnas del sistema</th>
                            <th style="border: 1px solid black;">Columnas del archivo CSV</th>
                        </tr>
                    </template>

                    <template slot="next" slot-scope="{load}">
                      <v-btn
                        class="mt-5 mb-5 white--text"
                        color="black"
                        @click.prevent="load"
                      >
                      <v-icon class="mr-1">mdi-cloud-upload</v-icon>
                       Cargar archivo CSV
                      </v-btn>
                      <v-icon>mdi-numeric-1-circle-outline</v-icon>

                    <p class="mt-3 mb-3"> <strong> En la siguiente tabla, compruebe que las columnas de su archivo CSV estén en concordancia con las columnas de la base de datos. </strong></p>
                    
                    </template>

                    <template slot="submit" slot-scope="{submit}">
                        <v-btn
                          class="mt-5 mb-5 white--text"
                          color="black"
                          @click.prevent="submit"
                        >
                        <v-icon class="mr-1">mdi-table-eye</v-icon>
                          Mostrar tabla de datos
                        </v-btn>
                        <v-icon>mdi-numeric-2-circle-outline</v-icon>
                    </template>
                </vue-csv-import>
                </v-col>

                <v-col cols="12" v-if="csv.length > 0"> 
                  <v-data-table
                    :headers="headersCsv"
                    :items="csv"
                    :footer-props="pagination"
                    class="elevation-1"
                  >
                    
                    <template v-slot:no-data>
                    <v-btn color="primary" @click="initialize">Reset</v-btn>
                    </template>
                </v-data-table>
                </v-col>
                
            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-icon>mdi-numeric-3-circle-outline</v-icon>
           <v-btn
            color="success"
            outlined
            @click="importCategories()"
          >
           <v-icon left>mdi-database-import</v-icon> Importar categorías
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Product -->

  </v-container>
</template>

<script>
import Parse from 'parse'
import { VueCsvImport } from 'vue-csv-import';
import draggable from 'vuedraggable'

export default {

  components:{
    VueCsvImport,
    draggable
  },
  
  data() {
        return {
            month_invoice: '',
            loading_invoice: false,
            valid: false,
            store: {
              attributes: {
                index: '',
                name: '',
                color: '',
                status: ''
              }
            },
            detailProductDialog: false,
            search: '',
            loading: true,
            dialog: false,
            headers: [
              //{ text: 'Imagen', align: 'left', value: 'attributes.imageUrl', sortable: false },
              { text: '', sortable: false },
              { text: 'Orden', value: 'attributes.index' },
              { text: 'Nombre', align: 'left', value: 'attributes.name' },
              { text: 'Color', value: 'attributes.color' },
              { text: 'Estado', value: 'attributes.status' },
              { text: 'Acciones', value: 'action', sortable: false },
            ],
            headersCsv: [
              { text: 'Orden', align: 'left', value: 'index', sortable: false },
              { text: 'Nombre', align: 'left', value: 'name', sortable: false },
              { text: 'Color', value: 'color', sortable: false },
              { text: 'Estado', value: 'status', sortable: false },
            ],
            pagination: {
              'items-per-page-options' : [20, 30, 50, 100, -1]
            },
            categories: [],
            editedIndex: -1,
            editedItem: {
              attributes: {
                index: '',
                name: '',
                color: '',
                status: ''
              }
            },
            defaultItem: {
              attributes: {
                index: '',
                name: '',
                color: '',
                status: ''
              }
            },
            editCategoryDialog: false,
            massiveProductDialog: false,
            csv: [],
            isHeaders: true,
            attachProductImg: '',
            attachProductImgFile: [],
            newCategories: []
        }
    },
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Nueva Categoría' : 'Editar Categoría'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    created () {
      this.initialize()
    },

    methods: {
      async initialize () {
          const params = {
              id: this.$route.params.store_id
          }
        try {
          let categories = await Parse.Cloud.run("getCategoriesBO", params);
          this.categories = categories
          //eslint-disable-next-line
          //console.log(categories);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      editCategory (item) {
        this.store = item
        this.editedIndex = this.categories.indexOf(item)
        this.editedItem = {
          attributes: {
            index: item.attributes.index,
            name: item.attributes.name,
            color: item.attributes.color,
            status: item.attributes.status
          }
        }
        this.editCategoryDialog = true
      },

      newCategoryDialog () {
        this.editedItem = {
          attributes: {
            index: '',
            name: '',
            color: '',
            status: ''
          }
        }
        this.editCategoryDialog = true
      },

      deleteItem (item) {
        const index = this.categories.indexOf(item)
        confirm('Are you sure you want to delete this item?') && this.categories.splice(index, 1)
      },

      close () {
        this.editCategoryDialog = false
        this.massiveProductDialog = false
        this.attachProductImg = '',
        this.attachProductImgFile = [],
        setTimeout(() => {
          this.editedItem = {
              attributes: {
                index: '',
                name: '',
                color: '',
                status: ''
              }
          }
          this.editedIndex = -1
        }, 300)
      },

      async saveEditCategory (item) {
        this.loading = true
        if (!this.editedItem.attributes.name) {
          this.$snotify.error(`El nombre es un campo requerido` , 'Categoría', {
            timeout: 4000,
            preventDuplicates: true
          });
          this.loading = false
          return;
        }
        //eslint-disable-next-line
        //console.log(this.editedItem.attributes.modifiers);
        const params = {
            id: this.editedIndex == -1 ? '' : item.id,
            storeId: this.$route.params.store_id,
            index: this.editedIndex == -1 ? this.categories.length : item.attributes.index, 
            name: this.editedItem.attributes.name,
            color: this.editedItem.attributes.color,
            //status: this.editedItem.attributes.status
        }

        try {
          await Parse.Cloud.run("newOrEditCategoryBO", params)
          this.initialize();
          this.loading = false

          this.$snotify.success(`Producto editado satisfactoriamente` , 'Categoría', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Categoría', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        this.close()
      },

      detailProduct(store){
        this.store = store
        this.detailProductDialog = true
      },

      goProducts(store){
        this.$router.push('/products/' + store.id)
      },

      async changeStatusCategory(store){
        try {
          let params = {
            id: store.id
          }

          this.loading = true
          await Parse.Cloud.run("changeStatusCategory", params);
        
          this.loading = false

          this.$snotify.success(`Se ha cambiado el estado del producto ${store.attributes.name}` , 'Cambio de estado', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      async changeFectureProduct(store){
        try {
          let params = {
            id: store.id
          }

          this.loading = true
          await Parse.Cloud.run("changeFectureProduct", params);
        
          this.loading = false

          this.$snotify.success(`Se ha cambiado el producto` , 'Cambio en destacado', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      copyUrlPromo(product){
        let texto = `https://promo.festyapp.com/${product.id}`;
        var textArea = document.createElement("textarea");
        //console.log(event.target.parentElement.childNodes[0].nodeValue.trim())
        textArea.value = texto;
        document.body.appendChild(textArea);
        textArea.select();
        try {
          var successful = document.execCommand('copy');
          if (successful) {
            this.$snotify.info('La URL de la promo fue copiada.', {
              timeout: 3000,
              preventDuplicates: true
            });
          }
        } catch (err) {
          this.$snotify.error(err, {
            timeout: 3000,
            preventDuplicates: true
          });
        }

        document.body.removeChild(textArea);
      },

      async importCategories(){
        
        if (this.csv.length > 0) {
          let params = {
            id: this.$route.params.store_id,
            products: this.csv
          }
          await Parse.Cloud.run("importProductsBO", params);
          this.initialize()

          this.$snotify.success(`Se han importado los producto correctamente.` , 'Importar categorías', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.close()

        }else{
          this.$snotify.error(`El archivo CSV no contiene datos.` , 'Importar Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      async uploadAttachProductImgFile(){
        let simge = this.attachProductImg.split(",");
        simge = simge[1];
        var parseFile = new Parse.File(
          "payment",
          { base64: simge },
          this.attachProductImgFile.type
        );
        let file = await parseFile.save(null);
        return file._url
      },

      fileChanged(file) {
        if (file) {
          const fr = new FileReader();
          if (file) {
            fr.readAsDataURL(file);
            fr.addEventListener("load", () => {
              //eslint-disable-next-line
              //console.log(fr.result);
              this.attachProductImg = fr.result;
            });
          }
        }
      },

      async changeIndex(){
            this.loading = true
            if (this.categories && this.categories.length > 0) {
                for (let index = 0; index < this.categories.length; index++) {
                    const element = this.categories[index];
                    let params = {
                        id: element.id,
                        newIndex: index
                    }
                    await Parse.Cloud.run("editIndexCategory", params);
                }
            }
            this.loading = false
      }

    },
}
</script>

<style lang="css">
  .csv-import-file{
    width: 100%;
    height: 70px;
    margin-top: 10px;
    background-color: white;
    outline: 2px dashed black;
  }

  .csv-import-file input{
    width: 100%;
    height: 70px;
    padding: 10px;
  }

  .vue-csv-mapping > table {
    width: 100%;
  }

  .h100{
    height: 100%;
    -webkit-appearance: auto !important;
  }

  .display-select{
    display: -webkit-box;
  }
</style>