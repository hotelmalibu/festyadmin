<template>
    <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Reportes</v-toolbar-title>

          <v-spacer></v-spacer>

          

        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
            
            <v-row>
                <v-col cols="12">
                    <v-data-table
                        :loading="loading"
                        loading-text="Cargando... Por favor espere"
                        :headers="headers"
                        :items="reports"
                        :search="search"
                        :footer-props="pagination"
                        :header-props="{
                        sortByText: 'Ordenar por'
                        }"
                        class="elevation-1"
                    >
                        <template v-slot:top>
                        <v-toolbar flat color="white">
                            <!--<v-toolbar-title>Reporte mes a mes</v-toolbar-title>-->
                            <!--<v-btn color="black" class="mb-2 mr-2 white--text" :loading="loading" :disabled="loading" @click="updateReports()"> <v-icon left>mdi-update</v-icon> Actualizar reportes</v-btn>-->
                            <v-spacer></v-spacer>
                            <v-text-field
                                v-model="search"
                                append-icon="mdi-magnify"
                                label="Buscar.."
                                single-line
                                hide-details
                                class="d-print-none mr-2"
                            ></v-text-field>
                            <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
                        </v-toolbar>
                        </template>

                        <template v-slot:item.attributes.updatedAt="{ item }">
                            {{ $moment(item.attributes.updatedAt).format('lll') }}
                        </template>

                        <template v-slot:item.attributes.status="{ item }">
                            <v-switch
                                :input-value="item.attributes.status"
                                color="success"
                                inset
                                @click.native="changeStatusReport(item)"
                            ></v-switch>
                        </template>

                        <template v-slot:item.action="{ item }">
                        <v-icon
                            class="mr-3"
                            @click="seeReport(item)"
                        >
                            mdi-eye
                        </v-icon>

                        <v-icon
                            class="mr-2"
                            :disabled="loading"
                            @click="updateReports(item.attributes.code == 'RS1' ? 'RS1': item.attributes.code == 'RV1' ? 'RV1' : 'RG1')"
                        >
                            mdi-reload
                        </v-icon>

                        </template>

                        <template v-slot:no-data>
                        <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
                        </template>
                    </v-data-table>
                </v-col>
               
            </v-row>
        </v-card-text>
      </v-card>
    </v-card>

  </v-container>
   
</template>

<script>
import Parse from 'parse'

export default {

    components: {
    },

    data() {
        return {
            reports: [],
            loading: false,
            search: '',
            headers: [
              { text: 'Name', align: 'left', value: 'attributes.name' },
              { text: 'Código', align: 'left', value: 'attributes.code' },
              { text: 'Tipo', align: 'left', value: 'attributes.type' },
              { text: 'Status', align: 'left', value: 'attributes.status' },
              { text: 'Actualización', align: 'left', value: 'attributes.updatedAt' },
              { text: 'Acciones', align: 'center', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            loader: null,
        }
    },

    mounted() {
        this.initialize()
    },

    watch: {
      loader () {
        const l = this.loader
        this[l] = !this[l]

        setTimeout(() => (this[l] = false), 30000)

        this.loader = null
      },
    },

    methods: {
        async initialize(){
            this.loading = true
            try {
                let reports = await Parse.Cloud.run("getReportsBO");
                this.reports = reports

                //eslint-disable-next-line
                //console.log(this.payments);
                this.loading = false
            
            } catch (error) {
                this.$swal({
                    title: "Reportes",
                    text: "Algo salío mal consultado los reportes.",
                    icon: "warning",
                    buttons: ['Salir', 'Entiendo'],
                    dangerMode: true,
                    })
                    .then((ok) => {
                    if (ok) {
                        this.$router.push('/')
                    }else{
                        this.$router.push('/')
                    }
                });
            }
            
        },

        changeStatusReport(){
            
        },

        seeReport(item){
            this.$router.push('/report/' + item.id);
            //window.open(routeData.href, '_blank');
        },

        async updateReports(code){
            this.loader = 'loading'
            try {
                let params = {
                    code: code
                }
                await Parse.Cloud.run("updateReportsBO", params);
            } catch (error) {
                this.$snotify.error(`${error}` , 'Actualizar reportes', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        }
    }
    
}
</script>