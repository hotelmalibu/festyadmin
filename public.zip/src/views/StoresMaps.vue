<template>
 <v-container fluid ma-0 pa-0 style="height: 100%;">
   <v-system-bar
         color="primary"
         dark
         class="d-none d-sm-flex"
        >
          <v-icon>mdi-store-outline</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'active').length }} comercios abiertos</span>
          <span class="mr-2">|</span>
          <v-icon>mdi-sleep</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'inactive').length }} comercios cerrados</span>
          <span class="mr-2">|</span>
          <v-icon>mdi-alert-octagram-outline</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'created').length }} comercios inactivos</span>
          <v-spacer></v-spacer>
          <!--<v-icon>mdi-wifi-strength-4</v-icon>
          <v-icon>mdi-signal-cellular-outline</v-icon>
          <v-icon>mdi-battery</v-icon>
          <span>12:30</span>-->
        </v-system-bar>
   <GmapMap
        v-if="companies"       
        :center="center"
        :zoom="zoom"
        map-type-id="terrain"
        style="width: 100%; height: 100%"
        :options="{
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false,
            disableDefaultUi: false
        }"
    >
        <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false"></GmapInfoWindow>
        <GmapCluster>
        <GmapMarker
            v-for="(item, index) in companies" :key="index"
            :position="{lat: item.attributes.location.latitude, lng: item.attributes.location.longitude}"
            :clickable="true"
            :draggable="false"
            @click="toggleInfoWindow({lat: item.attributes.location.latitude, lng: item.attributes.location.longitude}, `<strong>Comercio:</strong> ${item.attributes.name}`)"
            :icon="{ url: item.attributes.status == 'active' ? require('../assets/market-store.png') : require('../assets/market-store-offline.png')}"
        />
        </GmapCluster>

    </GmapMap>

  

    <!-- Dialogo Detail Store -->
    <v-dialog
      v-model="detailStoreDialog"
      width="450"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{store.attributes.name}}  </span>
          <v-spacer></v-spacer>
          <span class="text-capitalize"> 
            <v-icon>mdi-thumb-up-outline</v-icon> {{ store.attributes.likes }}
          </span>
        </v-card-title>
        <v-img
          max-height="210"
          v-if="store.attributes.logoUrl"
          :src="store.attributes.logoUrl"
          
        ></v-img>

        <v-card-text>
          <div class="pt-2 subtitle-1 black--text">
            <v-icon>mdi-home-city-outline</v-icon>
            {{ store.attributes.city }}
          </div>

          <div class="pt-2 black--text">
            <v-icon>mdi-cellphone-iphone</v-icon>
            {{ store.attributes.phone }}
          </div>

          <div class="pt-2 pb-2 black--text">
            <v-icon>mdi-file-eye-outline</v-icon>
            Vistas: {{ store.attributes.views }}
          </div>

          <v-divider class=""></v-divider>

          <div class="pt-2 black--text">
            {{store.attributes.description}}
          </div>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            :href="`https://stores.festyapp.com/me/${store.attributes.slug ? store.attributes.slug : store.id}`"
            target="_blank"
          >
           <v-icon left>mdi-open-in-new</v-icon> Ver perfil público
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="danger"
            outlined
            @click="detailStoreDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Detail Store -->

    <!-- Dialogo Confirm change -->
    <v-dialog
      v-model="dialogConfirmChange"
      width="450"
      v-if="store"
      scrollable
    >

        <v-form
          ref="form"
          v-model="valid"
        >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Comprobación  </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-text-field
            outlined
            :value="cityCheck"
            @change="v => cityCheck = v"
            :rules="cityCheckRules"
            label="Ciudad"
            placeholder="Escriba la ciudad del comercio"
            required
            hide-details
          ></v-text-field>
          
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          
          <v-btn
            color="primary"
            outlined
            @click="dialogConfirmChange = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="changeStatusStore(store, true)"
          >
           <v-icon left>mdi-content-save</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Confirm change -->


    <!-- Dialogo Confirm change -->
    <v-dialog
      v-model="dialogInvoice"
      width="450"
      scrollable
    >

        <v-form
          ref="form"
          v-model="valid"
        >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Generar facturas  </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          
          <v-select
            v-model="month_invoice"
            :items="[{id: '', text: 'Mes actual'}, {id: -1, text: 'Diciembre 2019'}, {id: 0, text: 'Enero'}, {id: 1, text: 'Febrero'}, {id: 2, text: 'Marzo'}, {id: 3, text: 'Abril'}, {id: 4, text: 'Mayo'}, {id: 5, text: 'Junio'}, {id: 6, text: 'Julio'}, {id: 7, text: 'Agosto'}, {id: 8, text: 'Septiembre'}, {id: 9, text: 'Octubre'}, {id: 10, text: 'Noviembre'}, {id: 11, text: 'Diciembre'}]"
            label="Mes de facturación"
            item-text="text"
            item-value="id"
            outlined
            hide-details
          ></v-select>
          
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          
          <v-btn
            color="primary"
            outlined
            @click="dialogInvoice = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="generateMonthlyInvoices()"
          >
           <v-icon left>mdi-content-save</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Confirm change -->
    
  </v-container>
</template>

<script>
import Parse from 'parse'
import GmapCluster from 'vue2-google-maps/dist/components/cluster'

export default {

    components: {
        'GmapCluster': GmapCluster
    },

    data() {
        return {
            month_invoice: '',
            dialogInvoice: false,
            loading_invoice: false,
            cityCheck: '',
            cityCheckRules: [
              v => !!v || 'Ciudad es requerida'
            ],
            valid: false,
            store: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            detailStoreDialog: false,
            search: '',
            loading: true,
            dialog: false,
            headers: [
              { text: 'Logo', align: 'left', value: 'attributes.logoUrl', sortable: false },
              { text: 'Nombre', align: 'left', value: 'attributes.name' },
              { text: 'Ciudad', value: 'attributes.city' },
              { text: 'Celular', value: 'attributes.phone' },
              { text: 'Vistas', value: 'attributes.views' },
              { text: 'Estado', value: 'attributes.status' },
              { text: 'Acciones', value: 'action', sortable: false },
            ],
            pagination: {
              'items-per-page-options' : [50, 60, 70, 100, -1]
            },
            companies: [],
            editedIndex: -1,
            editedItem: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            defaultItem: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            dialogConfirmChange: false,
            infoWindowPos: null,
            infoWinOpen: false,
            infoOptions: {
                content: '',
                //optional: offset infowindow so it visually sits nicely on top of our marker
                pixelOffset: {
                width: 0,
                height: -35
                }
            },
            zoom: 13,
            center: {
                lat: 9.2963691,
                lng: -75.3859901
            },
        }
    },
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Nuevo Comercio' : 'Editar Comercio'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    created () {
      this.initialize()
    },

    methods: {
      async initialize () {
        try {
          let companies = await Parse.Cloud.run("getStoresBO");
          this.companies = companies
          //eslint-disable-next-line
          //console.log(this.companies);
          this.loading = false
         
            this.infoWinOpen = false,
            this.zoom = 13  
            this.center = {lat: companies[20].attributes.location.latitude, lng: companies[20].attributes.location.longitude}
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      editItem (item) {
        this.editedIndex = this.companies.indexOf(item)
        this.editedItem = item
        this.dialog = true
      },

      deleteItem (item) {
        const index = this.companies.indexOf(item)
        confirm('Are you sure you want to delete this item?') && this.companies.splice(index, 1)
      },

      close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.companies[this.editedIndex], this.editedItem)
        } else {
          this.companies.push(this.editedItem)
        }
        this.close()
      },

      detailStore(store){
        this.store = store
        this.detailStoreDialog = true
      },

      goBillings(store){
        this.$router.push('/store/' + store.id)
      },

      goProducts(store){
        this.$router.push('/products/' + store.id)
      },
      
      async generateMonthlyInvoices(){
        try {
          this.loading_invoice = true
          
          let params = {
            month: this.month_invoice
          }
          let check_invoice = await Parse.Cloud.run("generateMonthlyInvoicesBO", params);
          //eslint-disable-next-line
          console.log(check_invoice)

          if (!check_invoice) {
            this.$snotify.error(`Hubo un problema al generar la factura.` , 'Facturas', {
              timeout: 4000,
              preventDuplicates: true
            });
            this.loading_invoice = false
            this.dialogInvoice = false
            return;
          }

          this.$snotify.info(`Facturas generadas` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.loading_invoice = false
          this.dialogInvoice = false

        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.loading_invoice = false
          this.dialogInvoice = false
        }
      },

      async changeStatusStore(store, confirm=false){
        try {

          if (confirm) {
            //eslint-disable-next-line
            //console.log('Confirmación en progreso...');
            
            if (!this.$refs.form.validate()) {
              this.$snotify.error(`Escriba la ciudad antes de guardar los cambios.` , 'Cambio de estado', {
                timeout: 4000,
                preventDuplicates: true
              });
              return;
            }
            
            this.dialogConfirmChange = false

            let params = {
              id: store.id,
              city: this.cityCheck
            }

            this.loading = true
            await Parse.Cloud.run("activeStoreBO", params);
          
            this.loading = false

            this.$snotify.success(`Se ha activado el comercio ${store.attributes.name}` , 'Activación de comercio', {
              timeout: 4000,
              preventDuplicates: true
            });

            return;
          }

          this.dialogConfirmChange = false

            let params = {
              id: store.id
            }

            this.loading = true
            await Parse.Cloud.run("changeStatusStoreBO", params);
          
            this.loading = false

          this.$snotify.success(`Se ha cambiado el estado del comercio ${store.attributes.name}` , 'Cambio de estado', {
              timeout: 4000,
              preventDuplicates: true
            });

          
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      showDialogConfirmChange(store){
        this.store = store
        this.dialogConfirmChange = true
      },

        toggleInfoWindow(position, infoText) {
            this.infoWindowPos = position;
            this.infoOptions.content = infoText;
            this.infoWinOpen = !this.infoWinOpen;
        },
    },
}
</script>