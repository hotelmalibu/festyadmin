<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Clientes <strong>({{zone}})</strong></v-toolbar-title>

          <v-spacer></v-spacer>

          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
            class="mr-2"
          ></v-text-field>

           <download-excel
            class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
            :data = "customers"
            :fields = "headers_export"
            worksheet = "Clientes Festy"
            name = "customers.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
            </download-excel>

            <v-btn icon @click="dialogFilterOrders = true" class="pa-0 ma-0 d-print-none">
                <v-icon>mdi-filter</v-icon>
            </v-btn>

            <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn icon v-on="on" class="d-print-none">
                <v-icon>mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="openSmsDialogStoreClients()">
                <v-list-item-title> <v-icon left>mdi-forum</v-icon>Enviar SMS a Clientes</v-list-item-title>
              </v-list-item>
               <v-list-item @click="openPushDialogClients()" v-if="sourceOption === 'client'">
                <v-list-item-title> <v-icon left>mdi-bullhorn</v-icon>Enviar Push a Clientes</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="customers"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >
          
            <template v-slot:item.attributes.createdAt="{ item }">
                {{ $moment(item.attributes.createdAt).format('lll') }}
            </template>
          
            <template v-slot:item.attributes.address="{ item }">
              {{ item.attributes.address.length >= 50 ? item.attributes.address.slice(0, 50)+'...' : item.attributes.address}}
            </template>

            <template v-slot:item.action="{ item }">
              <v-icon
                class="mr-2"
                @click="showDialogCustomer(item)"
              >
                mdi-eye-outline
              </v-icon>
            </template>

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo Dialogo show info customer -->
    <v-dialog
      v-model="modalCustomer"
      width="500"
      scrollable
      v-if="customer"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Detalle cliente </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12">
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-calendar</v-icon> Fecha:</strong> {{ $moment(customer.attributes.createdAt).format('lll') }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-account</v-icon> Nombre:</strong> {{ customer.attributes.name }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-map-marker</v-icon> Dirección:</strong> {{ customer.attributes.address }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-cellphone</v-icon> Teléfono:</strong> {{ customer.attributes.phone }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-tag-text</v-icon> Tags:</strong> {{ customer.attributes.tags.join(', ') }} </div>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="modalCustomer = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo show info customer -->

    <!-- Dialogo Send SMS Clients -->
    <v-dialog v-model="modalSmsClients" width="600" persistent scrollable>
      <v-form ref="formsms" v-model="validSms">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Enviar SMS a Clientes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">

              <v-col cols="12" class>
                <v-select
                  v-model="template"
                  :items="templates"
                  label="Plantillas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  @input="changeTemplate()"
                  hide-details
                ></v-select>
              </v-col>

            <v-col cols="12">
                <v-text-field
                    v-model="label"
                    label="Label"
                    outlined
                    hide-details
                    :rules="labelRules"
                    class="d-print-none mr-2"
                ></v-text-field>
            </v-col>

              <v-col cols="12">
                <v-textarea
                  outlined
                  :value="pushModel.body"
                  @change="v => pushModel.body = v"
                  :rules="bodyRules"
                  label="Mensaje"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalSmsClients = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="sendSmsClients()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send SMS Store -->

    <!-- Dialogo filter customers -->
    <v-dialog v-model="dialogFilterOrders" width="700" persistent scrollable>
      <v-form ref="formFilter" v-model="validFilter">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar clientes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row>
              <v-col cols="12" sm="6">
                <v-date-picker v-model="dates" range @change="checkDates()" locale="es"></v-date-picker>
              </v-col>
              <v-col cols="12" sm="6">
                <v-text-field v-model="dateRangeText" label="Rango de fechas" prepend-inner-icon="mdi-calendar" readonly outlined hide-details></v-text-field>
                <h3
                  ref="radio"
                  class="mt-3"
                >
                    Modelo a consultar
                </h3>
                <v-radio-group v-model="classOrTable" class="mt-1">
                    <v-radio
                        label="Usuarios"
                        value="users"
                    ></v-radio>
                    <v-radio
                        label="Ordenes"
                        value="orders"
                    ></v-radio>
                </v-radio-group>

                <v-checkbox
                    v-if="classOrTable == 'users'"
                    class="mt-0"
                    v-model="withPhone"
                    label="Verificar que los usuarios tengan número de teléfono"
                    hide-details
                ></v-checkbox>
                

                <h3
                  v-if="classOrTable == 'orders'"
                  ref="radio"
                >
                    Tipo de orden
                </h3>
                <v-radio-group
                    v-if="classOrTable == 'orders'"
                    v-model="sourceOption" class="mt-1">
                    <v-radio
                        label="Todos"
                        value="all"
                    ></v-radio>
                    <v-radio
                        label="POS"
                        value="pos"
                    ></v-radio>
                    <v-radio
                        label="Festy Ordenes"
                        value="client"
                    ></v-radio>
                </v-radio-group>

                 <v-select
                    v-if="classOrTable == 'orders'"
                    v-model="orderStatus"
                    :items="[{id:'pre-created', name:'Pendiente por transferencia'}, {id:'created', name:'Creado'}, {id:'preparing', name:'Preparando'}, {id:'delivering', name:'En camino'}, {id:'delivered', name:'Entregado'}, {id:'cancelled', name:'Cancelado'}]"
                    label="Status de las ordenes"
                    outlined
                    item-text="name"
                    item-value="id"
                    hide-details
                    multiple
                    mandatory
                    class="mb-3"
                ></v-select>

                <v-select
                    v-if="classOrTable == 'orders'"
                    v-model="zone"
                    :items="zones"
                    label="Ciudades"
                    outlined
                    item-text="attributes.name"
                    item-value="attributes.name"
                    hide-details
                ></v-select>


              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="red" outlined @click="dialogFilterOrders = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            
            <v-btn color="success" dark outlined @click="initialize()">
              <v-icon left>mdi-filter</v-icon>Filtrar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo filter customers -->

    <!-- Dialogo Send Push -->
    <v-dialog v-model="modalPush" width="600" persistent scrollable>
      <v-form ref="formPc" v-model="valid">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Enviar Push a Clientes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
              <v-col cols="12" class>
                <v-select
                  v-model="template"
                  :items="templates"
                  label="Plantillas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  @input="changeTemplate()"
                  hide-details
                ></v-select>
              </v-col>

              <v-col cols="10">
                <v-text-field
                  outlined
                  :value="pushModel.title"
                  @change="v => pushModel.title = v"
                  :rules="titleRules"
                  label="Título"
                  placeholder="Escriba el título de la notificación"
                  required
                  hide-details
                ></v-text-field>
              </v-col>

              <v-col cols="2">
                <v-menu
                  v-model="menu_emojis"
                  :close-on-content-click="false"
                  :nudge-width="200"
                  offset-x
                >
                  <template v-slot:activator="{ on }">
                    <v-btn color="indigo" fab x-small dark v-on="on">
                      <v-icon>mdi-emoticon-cool-outline</v-icon>
                    </v-btn>
                  </template>

                  <VEmojiPicker
                    v-show="menu_emojis"
                    labelSearch="Search"
                    style="{ width: 4px }"
                    @select="onSelectEmoji"
                  />
                </v-menu>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  outlined
                  :value="pushModel.body"
                  @change="v => pushModel.body = v"
                  :rules="bodyRules"
                  label="Mensaje"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>

              <v-col cols="12">
                <v-radio-group
                  v-model="radioGroupDeployed"
                  row
                  hide-details
                >
                  <v-radio label="Envío inmediato" value="1"></v-radio>
                  <v-radio label="Envío inteligente" value="2"></v-radio>
                </v-radio-group>
                
              </v-col>

              <v-col cols="12">
                <v-text-field
                  outlined
                  :value="app_url"
                  @change="v => app_url = v"
                  :rules="urlRules"
                  label="Link (opcional)"
                  placeholder="Escriba una url válida"
                  required
                  hide-details
                ></v-text-field>
              </v-col>

            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalPush = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="sendPushStoreClient()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send Push -->

  </v-container>
</template>

<script>
import Parse from "parse";
import JsonExcel from 'vue-json-excel'
import VEmojiPicker from 'v-emoji-picker';

export default {

    components: {
        VEmojiPicker,
        'download-excel': JsonExcel,
    },

  data() {
    return {
      customers: [],
      customer: '',
      search: "",
      loading: true,
      headers: [
        { text: "ID", value: "id" },
        {
          text: "Nombre",
          align: "left",
          value: "name"
        },
        { text: "Celular", value: "phone" },
        //{ text: 'Acciones', value: 'action', sortable: false, align: "center", },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      },
      headers_export: {
          'Nombre': 'name',
          'Teléfono': 'phone',
      },
      modalCustomer: '',
      massiveCustomerDialog: false,

      modalSmsClients: false,
      validSms: true,
      templates: [],
      template: "",
      pushModel: {
        title: "",
        body: ""
      },
      bodyRules: [v => !!v || "Mensaje es requerido"],
      labelRules: [v => !!v || "Label es requerido"],
      dialogFilterOrders: false,
      dates: [],
      validFilter: false,
      zones: [],
      zone: 'Sincelejo',
      authenticate: Parse.User.current(),
      label: '',
      sourceOption: 'client',

      modalPush: false,
      menu_emojis: false,
      valid: true,
      titleRules: [v => !!v || "Título es requerido"],
      urlRules: [v => !!this.validURL(v) || "Url no es válida"],
      app_url: '',
      radioGroupDeployed: '1',

      classOrTable: 'users',
      orderStatus: ['delivered'],
      withPhone: false
    };
  },

    computed: {
        dateRangeText () {
        return this.dates.join(' ~ ')
        },
    },

  mounted() {
    this.getZones()
    this.initialize();
  },

  methods: {
    async initialize() {
      try {
        
        let params = {
            city: this.zone,
            source: this.sourceOption,
            init: this.dates[0],
            end: this.dates[1],
            status: this.orderStatus,
            withPhone: this.withPhone
        }

        let customers = []
        if (this.classOrTable == 'orders') {
            customers = await Parse.Cloud.run("getOrdersByCityFilterBO", params);
        }else{
            customers = await Parse.Cloud.run("getUsersByCityFilterBO", params);
        }
        this.customers = customers;
        //eslint-disable-next-line
        //console.log(this.customers);
        this.loading = false;
        this.dialogFilterOrders = false
      } catch (error) {
        this.$snotify.error(`${error}`, "Clientes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    async getZones(){
        try {
            let zones = await Parse.Cloud.run("getAppConfigWhitoutLocation");
            this.zones = zones;
        } catch (error) {
                this.$snotify.error(`${error}`, "Ciudades", {
                timeout: 4000,
                preventDuplicates: true
            });
        }
    },

    openImageUrl(item) {
      window.open(item.attributes.rider.attributes.photoUrl, "_blank");
    },

    showDialogCustomer(item){
      this.customer = item
      this.modalCustomer = true
    },


    async changeDestination() {
        //eslint-disable-next-line
        //console.log('Cambio');

        this.template = "";
        this.pushModel.title = "";
        this.pushModel.body = "";

        let params = {
          destination:"user"
        };
        let templates = await Parse.Cloud.run("getPushTemplates", params);
        this.templates = templates;
    },

    changeTemplate() {
        //eslint-disable-next-line
        //console.log(this.template);
        if (this.template) {
          this.pushModel.title = this.template.attributes.title;
          this.pushModel.body = this.template.attributes.body;
        } else {
          this.$snotify.error(`Seleccione una plantilla`, "Plantilla", {
            timeout: 4000,
            preventDuplicates: true
          });
        }
    },
      
    openSmsDialogStoreClients() {
        this.changeDestination();
        this.modalSmsClients = true;
    },

    openPushDialogClients() {
        this.changeDestination();
        this.modalPush = true;
    },

    checkDates(){
      this.dates.sort(function(a, b) {
          var c = new Date(a);
          var d = new Date(b);
          return c-d;
      });
    },

    onSelectEmoji(dataEmoji) {
      this.pushModel.title += dataEmoji.data;
    },

    validURL(str) {
      if (str) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
          '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
          '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
          '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
          '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
          '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
          return !!pattern.test(str);
      }
      return true;
    },

    async sendSmsClients() {
      if (this.$refs.formsms.validate()) {
        try {
          if (!this.customers) {
            this.$snotify.error(
              `No hay clientes disponibles.`,
              "Notificación",
              {
                timeout: 4000,
                preventDuplicates: true
              }
            );
            return;
          }

          if (!this.label) {
            this.$snotify.error(
              `El campo label es requerido.`,
              "Notificación",
              {
                timeout: 4000,
                preventDuplicates: true
              }
            );
            return;
          }

          let phones = this.customers.filter((item) => item.phone).map(obj => {
             return `57${obj.phone}`
             //return obj.phone
          });

          phones = Array.from(new Set(phones))
          phones = phones.filter(Boolean);
          
          let params = "";

          //eslint-disable-next-line
          //console.log(phones)
          
          params = {
            title: this.pushModel.title,
            message: this.pushModel.body,
            phones: phones,
            label: `admin~${this.authenticate.id}~${this.label}`
          };
          
          //eslint-disable-next-line
          //console.log(params)
          await Parse.Cloud.run("sendSMSMasive", params);

          this.$snotify.success(`Se ha enviado el SMS`, "Envío SMS", {
            timeout: 4000,
            preventDuplicates: true
          });

          this.modalSmsClients = false;
        } catch (error) {
          this.$snotify.error(`${error}`, "SMS", {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      } else {
        this.$snotify.error(
          `Compruebe todo los campos antes de enviar el formulario`,
          "SMS",
          {
            timeout: 4000,
            preventDuplicates: true
          }
        );
      }
    },
    
    async sendPushStoreClient() {
      if (this.$refs.formPc.validate()) {
        try {

          let ids = this.customers.filter((item) => item.id).map(obj => {
            return obj.id
          });

          ids = Array.from(new Set(ids))
          ids = ids.filter(Boolean);
          
          let params = "";

          params = {
            title: this.pushModel.title,
            message: this.pushModel.body,
            ids: ids,
            app_url: this.app_url ? this.app_url : '',
            delayed_option: this.radioGroupDeployed == '2' ? 'last-active' : ''
          };

          //eslint-disable-next-line
          //console.log(params);
          await Parse.Cloud.run("notifyStoreClientBO", params);
          

          this.$snotify.success(`Se ha enviado el push a los clientes.`, "Envío push", {
            timeout: 4000,
            preventDuplicates: true
          });

          this.modalPush = false;
        } catch (error) {
          this.$snotify.error(`${error}`, "Notificación", {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      } else {
        this.$snotify.error(
          `Compruebe todo los campos antes de enviar el formulario`,
          "Notificación",
          {
            timeout: 4000,
            preventDuplicates: true
          }
        );
      }
    },
  }
};
</script>