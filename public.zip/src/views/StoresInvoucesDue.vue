<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1100"
      style="margin-top: -64px;"
      :loading="loading_invoices"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">REPORTE DE FACTURAS</v-toolbar-title>

        <v-spacer></v-spacer>
        
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Buscar.."
          single-line
          hide-details
        ></v-text-field>

      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="invoices"
            :search="search"
            :sort-by="['attributes.store.attributes.name']"
            :sort-desc="[false]"
            multi-sort
            :header-props="{ sortIcon: null }"
            class="elevation-1"
            :footer-props="pagination"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <v-toolbar-title></v-toolbar-title>
                <v-spacer></v-spacer>
                
                <v-btn icon @click="dialogFilterInvoices = true" class="pa-0 ma-0 d-print-none">
                  <v-icon>mdi-filter</v-icon>
                </v-btn>

                <download-excel
                    class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
                    :data = "invoices"
                    :fields = "headers_export"
                    worksheet = "Festy Facturas No Pagadas"
                    name = "InvoicesDue.xls">
                    <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
                </download-excel>

            </v-toolbar>
            </template>
            
            <template v-slot:item.attributes.logoUrl="{ item }">
              <v-avatar
                  size="36px"
                  color="teal"
                >
                  <img
                    v-if="item.attributes.logoUrl"
                    alt="Avatar"
                    :src="item.attributes.logoUrl"
                  >
                  <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.startDate="{ item }">
                {{$moment(item.attributes.startDate).format('ll')}}
            </template>

            <template v-slot:item.attributes.endDate="{ item }">
                {{$moment(item.attributes.endDate).format('ll')}}
            </template>

            <template v-slot:item.attributes.discount="{ item }">
                {{ !item.attributes.noDiscountApplies ? item.attributes.discount : 0 | currency }}
            </template>

            <template v-slot:item.attributes.subTotal="{ item }">
                {{ item.attributes.subTotal | currency }}
            </template>

            <template v-slot:item.attributes.total="{ item }">
                {{ item.attributes.total | currency }}
            </template>

            <template v-slot:item.attributes.status="{ item }">
                <v-chip
                    :color="item.attributes.status == 'paid' ? 'success' : 'warning' "
                    class="ml-0"
                    label
                    small
                >
                    {{ item.attributes.status == 'paid' ? 'PAGADA' : item.attributes.status == 'created' ? 'SIN PAGAR' : item.attributes.status.toUpperCase() }}
                </v-chip>
            </template>
            <template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="dialogEditInvoice(item)"
            >
                mdi-pencil
            </v-icon>
            <!--<v-icon
                class="mr-2"
                @click="goInvoicePayments(item)"
            >
                mdi-credit-card
            </v-icon>-->
            <v-icon
                @click="goInvoice(item)"
            >
                mdi-file-chart
            </v-icon>
            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

    <!-- Dialogo Edit Invoice -->
    <v-dialog
      v-model="editInvoiceDialog"
      width="400"
      scrollable
      eager
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar Factura </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>

          <v-row>
            <v-col cols="12" class="pb-0">
               <v-select
                v-model="statusInvoice"
                :items="invoicesStatus"
                label="Estado de la factura"
                outlined
                item-text="name"
                item-value="id"
                hide-details
              ></v-select>
            </v-col>

            <v-col cols="12" class="pb-0">
              <v-file-input
                v-model="attachMethodPaymentFile"
                color="primary accent-4"
                label="Comprobante de pago"
                placeholder="Clic aquí para adjuntar"
                outlined
                prepend-icon
                prepend-inner-icon="mdi-paperclip"
                hide-details
                :show-size="1000"
                @change="fileChanged"
              >
                <template v-slot:selection="{ index, text }">
                  <v-chip
                    v-if="index < 2"
                    color="primary accent-4"
                    dark
                    label
                    small
                  >
                    {{ text }}
                  </v-chip>
                </template>
              </v-file-input>
            </v-col>

            <v-col cols="12" class="pb-0">
              <v-textarea
                v-model="comments"
                outlined
                name="input-7-4"
                hide-details
                label="Comentarios"
                value=""
                auto-grow
                rows="1"
              ></v-textarea>
            </v-col>

          </v-row>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="editInvoiceDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="success"
            outlined
            @click="editInvoiceStatus()"
          >
           <v-icon left>mdi-send</v-icon> Editar
          </v-btn>
          
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Invoice -->

    <!-- Dialogo filter invoices -->
    <v-dialog v-model="dialogFilterInvoices" width="700" persistent scrollable>
      <v-form ref="formFilter" v-model="validFilter">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar facturas</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row>
              <v-col cols="12" sm="6">
                <v-date-picker v-model="dates" range @change="checkDates()" locale="es"></v-date-picker>
              </v-col>
              <v-col cols="12" sm="6">
                
                <v-text-field v-model="dateRangeText" label="Rango de fechas" prepend-inner-icon="mdi-calendar" readonly outlined hide-details></v-text-field>
                
                <h3
                  ref="radio"
                  class="mt-3"
                >
                  Status de facturas
                </h3>
                <v-radio-group v-model="statusOption" class="mt-1">
                  <v-radio
                    label="Todos"
                    value="all"
                  ></v-radio>
                  <v-radio
                    label="Pagadas"
                    value="paid"
                  ></v-radio>
                  <v-radio
                    label="Sin pagar"
                    value="created"
                  ></v-radio>
                </v-radio-group>
                
                <v-autocomplete
                  v-model="cities"
                  :items="zones"
                  outlined
                  chips
                  multiple
                  item-text="attributes.name"
                  item-value="attributes.name"
                  label="Seleccione las ciudades"
                  persistent-hint
                ></v-autocomplete>

              </v-col>
            </v-row>

            
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="red" outlined @click="dialogFilterInvoices = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            
            <v-btn color="primary" dark outlined @click="initialize()">
              <v-icon left>mdi-autorenew</v-icon>Limpiar
            </v-btn>
            <v-btn color="success" dark outlined @click="filterInvoice()">
              <v-icon left>mdi-filter</v-icon>Filtrar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo filter invoices -->

  </v-container>
</template>

<script>
import Parse from 'parse'
import JsonExcel from 'vue-json-excel'

export default {
    components: {
        'download-excel': JsonExcel
    },
    data() {
        return {
            companie: {
                attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            loading: true,
            loading_invoices: true,
            search: '',
            headers: [
              { text: 'Comercio', align: 'left', value: 'attributes.store.attributes.name' },
              { text: 'Ciudad', align: 'left', value: 'attributes.store.attributes.city' },
              { text: 'Celular', align: 'left', value: 'attributes.store.attributes.phone' },
              { text: 'Fecha de inicio', align: 'left', value: 'attributes.startDate' },
              { text: 'Fecha de corte', align: 'left', value: 'attributes.endDate' },
              { text: 'Subtotal', align: 'left', value: 'attributes.subTotal' },
              { text: 'Descuento',align: 'left',  value: 'attributes.discount' },
              { text: 'Total', align: 'left', value: 'attributes.total' },
              //{ text: 'Método', align: 'left', value: 'attributes.payment' },
              { text: 'Estado', align: 'left', value: 'attributes.status' },
              { text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            invoices: [],
            invoice: {
                attributes: {
                    store: {},
                    discount: 0,
                    subTotal: 0,
                    total: 0,
                    payment: 0,
                    endDate: '',
                    startDate: '',
                    status: ''
                }
            },
           editInvoiceDialog: false,
           statusInvoice: '',
           invoicesStatus: [
             {
               id: 'created',
               name: 'SIN PAGAR'
             },
             {
               id: 'paid',
               name: 'PAGADA'
             },
           ],
           comments: '',
           attachMethodPaymentFile: [],
           attachMethodPayment: '',
           pagination: {
              'items-per-page-options' : [20, 30, 50, 100, -1]
           },
           headers_export: {
                'ID': 'id',
                'Comercio': 'attributes.store.attributes.name',
                'Ciudad': 'attributes.store.attributes.city',
                'Celular': 'attributes.store.attributes.phone',
                'Fecha de inicio': {
                    field: 'attributes.startDate',
                    callback: (value) => {
                        let startDate = value.toLocaleString()
                        return `${startDate}`;
                    }
                },
                'Fecha de corte': {
                    field: 'attributes.endDate',
                    callback: (value) => {
                        let endDate = value.toLocaleString()
                        return `${endDate}`;
                    }
                },

                'Subtotal': 'attributes.subTotal',
                'Descuento': 'attributes.discount',
                'Total': 'attributes.total',
                'Estado': {
                    field: 'attributes.status',
                    callback: (value) => {
                        return this.traslateStatus(value)
                    }
                }
            },

            dialogFilterInvoices: false,
            validFilter: false,
            dates: [],
            statusOption: 'all',
            cities: [],
            zones: []
        }
    },

    mounted() {
        this.initialize();
        this.getZones();
    },

    computed: {
      dateRangeText () {
        return this.dates.join(' ~ ')
      },
    },

    methods: {
        async initialize(){
            try {
              let invoces = await Parse.Cloud.run("getInvocesNotPaid");
              this.invoices = invoces
              //eslint-disable-next-line
              //console.log(this.invoices);
              this.loading_invoices = false
              this.dialogFilterInvoices = false
            } catch (error) {
                this.$snotify.error(`${error}` , 'Facturas', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        async getZones(){
          try {
              let zones = await Parse.Cloud.run("getAppConfigWhitoutLocation");
              this.zones = zones;
          } catch (error) {
                  this.$snotify.error(`${error}`, "Ciudades", {
                  timeout: 4000,
                  preventDuplicates: true
              });
          }
        },

        async filterInvoice(){
          try {
            let params = {
              init: this.dates[0],
              end: this.dates[1],
              status: this.statusOption,
              cities: this.cities
            }
            let invoces = await Parse.Cloud.run("getInvocesNotPaidFilter", params);
            this.invoices = invoces
            //eslint-disable-next-line
            //console.log(this.invoices);
            this.loading_invoices = false
            this.dialogFilterInvoices = false
            } catch (error) {
                this.$snotify.error(`${error}` , 'Facturas', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        sendInvoice(invoice){
            this.$snotify.info(`Muy pronto habilitaremos esta opción, contacte a soporte para más información. ${invoice.id}` , 'Facturas', {
              timeout: 4000,
              preventDuplicates: true
            });
        },

        goInvoice(invoice){
          this.$router.push('/invoice/' + invoice.id)
        },

        goInvoicePayments(invoice){
          this.$router.push('/invoice-payments/' + invoice.id)
        },

        dialogEditInvoice(invoice){
          this.invoice = invoice
          this.editInvoiceDialog = true
        },

        async editInvoiceStatus(){
          if (!this.statusInvoice || !this.comments) {
            this.$snotify.info(`Debes seleccionar el estado y escribir un comentario` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });
            return;
          }

          if (this.attachMethodPaymentFile && this.attachMethodPaymentFile.length > 0 && this.attachMethodPaymentFile.type) {
            switch (this.attachMethodPaymentFile.type) {
              case 'image/png':
                  break;
              case 'image/jpeg':
                  break;
              case 'image/jpg':
                  break;
              default:
                  this.$snotify.info(`El archivo adjunto tiene un formato no válido ${this.attachMethodPaymentFile.type}` , 'Formato', {
                      timeout: 6000,
                      preventDuplicates: true
                  });
                  return;
            }
          }
          
          let params = {
            id : this.invoice.id,
            status: this.statusInvoice,
            comments: this.comments,
            attachUrl: this.attachMethodPaymentFile ? this.attachMethodPaymentFile.length == 0 ? '' : this.attachMethodPaymentFile.type ? await this.uploadAttachPaymentMethod() : '' : ''
          }

          try {
            await Parse.Cloud.run("editStatusInvoiceBO", params);
            
            this.statusInvoice = ''
            this.comments = ''
            this.editInvoiceDialog = false
            this.attachMethodPaymentFile = []
            this.attachMethodPayment = ''

            this.initialize();

            this.$snotify.success(`Factura editada correctamente.` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });   
                  
          } catch (error) {
            this.$snotify.error(`${error}` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });
          }
          
        },

      async uploadAttachPaymentMethod(){
        let simge = this.attachMethodPayment.split(",");
        simge = simge[1];
        var parseFile = new Parse.File(
          "paymentInvoice",
          { base64: simge },
          this.attachMethodPaymentFile.type
        );
        let file = await parseFile.save(null);
        return file._url
      },

      fileChanged(file) {
      if (file) {
          const fr = new FileReader();
          if (file) {
            fr.readAsDataURL(file);
            fr.addEventListener("load", () => {
              //eslint-disable-next-line
              //console.log(fr.result);
              this.attachMethodPayment = fr.result;
            });
          }
        }
      },

    traslateStatus(status) {
        switch (status) {
            case "created":
            return "Creado";

            case "paid":
            return "Pagada";

            default:
            return "Si estado";
        }
    },

    checkDates(){
      this.dates.sort(function(a, b) {
          var c = new Date(a);
          var d = new Date(b);
          return c-d;
      });
    },
        
  },
}
</script>