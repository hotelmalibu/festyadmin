<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card
        class="mx-auto"
        max-width="1300"
        style="margin-top: -64px"
        :loading="loading"
        v-if="dataZones"
      >
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Zonas</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-btn
            color="black"
            class="mr-2 white--text"
            @click="openModalSaveOrEdit()"
          >
            <v-icon left>mdi-plus</v-icon> Nueva zona</v-btn
          >
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="dataZones"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por',
            }"
            class="elevation-1"
          >
            <template v-slot:top>
              <v-toolbar flat color="white">
                <v-spacer></v-spacer>
                <v-text-field
                  v-model="search"
                  append-icon="mdi-magnify"
                  label="Buscar.."
                  single-line
                  hide-details
                  class="d-print-none mr-2"
                ></v-text-field>
              </v-toolbar>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
              {{ $moment(item.attributes.createdAt).format("lll") }}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
              {{ $moment(item.attributes.updatedAt).format("lll") }}
            </template>

            <template v-slot:item.attributes.image._url="{ item }">
              <v-img
                v-if="item.attributes.image"
                :src="item.attributes.image._url"
                aspect-ratio="1.7"
                class="grey darken-4"
                @click="openImageUrl(item)"
                v-ripple
              ></v-img>
            </template>

            <!--<template v-slot:item.attributes.type="{ item }">
                <v-chip :color="item.attributes.type === 'value' ? 'primary' : 'warning'" text-color="white" class="ml-0" small>
                      {{item.attributes.type ? item.attributes.type.toUpperCase() : ''}}
                </v-chip>
            </template>-->

            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                v-model="item.attributes.status"
                color="success"
                inset
                @click.native="changeStatusBanner(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
              <!--<v-icon
                    class="mr-2"
                    @click="detailBanner(item)"
                >
                    mdi-eye
                </v-icon>-->

              <v-icon class="mr-2" @click="openModalSaveOrEdit(true, item)">
                mdi-pencil
              </v-icon>
            </template>
            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <v-dialog v-model="saveOrEditZonesDialog" width="600" scrollable persistent>
      <v-form ref="formsaveoreditbanner" v-model="validEditPromo">
        <v-card>
          <v-card-title class="title grey lighten-3" primary-title>
            <span class="text-capitalize">
              {{ isEdit ? "Editar " : "Nuevo" }} Zona
            </span>
            <v-spacer></v-spacer>
          </v-card-title>

          <v-img
            max-height="210"
            v-if="zonesData.url"
            :src="zonesData.url"
            aspect-ratio="1.7"
            contain
          ></v-img>

          <v-card-text>
            <v-divider class="mb-2"></v-divider>
            <v-row dense>
              <v-col cols="12" md="12">
                <v-file-input
                  v-model="attachBannerImage"
                  color="primary accent-4"
                  label="Imagen de la zona"
                  placeholder="Clic aquí para adjuntar"
                  outlined
                  prepend-icon
                  prepend-inner-icon="mdi-paperclip"
                  hide-details
                  :show-size="1000"
                  @change="fileChanged"
                >
                  <template v-slot:selection="{ index, text }">
                    <v-chip
                      v-if="index < 2"
                      color="primary accent-4"
                      dark
                      label
                      small
                    >
                      {{ text }}
                    </v-chip>
                  </template>
                </v-file-input>
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="zonesData.name"
                  :rules="nameRules"
                  counter
                  maxlength="40"
                  outlined
                  label="Nombre"
                  prepend-inner-icon="mdi-rename-box"
                  hide-details
                ></v-text-field>
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="zonesData.newBadgeHours"
                  :rules="newBadgeHoursRules"
                  outlined
                  label="Badge Hours"
                  prepend-inner-icon="mdi-store-clock-outline"
                  hide-details
                  type="number"
                ></v-text-field>
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="zonesData.radius"
                  :rules="radiusRules"
                  outlined
                  label="Radio"
                  prepend-inner-icon="mdi-radiobox-marked"
                  hide-details
                  type="number"
                ></v-text-field>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  v-model="zonesData.options"
                  outlined
                  name="input-7-4"
                  label="Opciones de la zona (JSON)"
                  hide-details
                  auto-grow
                  rows="1"
                ></v-textarea>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  v-model="zonesData.config"
                  outlined
                  name="input-7-4"
                  label="Configuración de la zona (JSON)"
                  hide-details
                  auto-grow
                  rows="1"
                ></v-textarea>
              </v-col>

              <v-col cols="12" md="12">
                <v-switch
                  v-model="zonesData.status"
                  inset
                  color="success"
                  :label="`Activo`"
                  hide-details
                ></v-switch>
              </v-col>
            </v-row>
          </v-card-text>

          <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
              color="secondary"
              outlined
              @click="openModalMarkCoordinate()"
            >
              <v-icon left>mdi-map-marker</v-icon>
              {{ isEdit ? "Editar " : "Marcar" }} coordenadas:
              {{ this.marker.position.lat }}, {{ this.marker.position.lng }}
            </v-btn>
          </v-card-actions>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="close()">
              <v-icon left>mdi-close</v-icon> Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="success" outlined @click="saveOrEditZones()">
              <v-icon left>mdi-content-save-outline</v-icon> Guardar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>

    <v-dialog
      v-model="markCoordinateDialog"
      fullscreen
      hide-overlay
      transition="dialog-bottom-transition"
    >
      <v-card style="width: 100%; height: 100%">
        <v-toolbar dark color="primary">
          <v-toolbar-title>Seleccione con click una dirección</v-toolbar-title>
          <v-spacer></v-spacer>
          <v-toolbar-items>
            <v-btn dark text @click="closeModalMarkCoordinate()">
              Cerrar
            </v-btn>
          </v-toolbar-items>
        </v-toolbar>
        <GmapMap
          :center="center"
          :zoom="10"
          map-style-id="roadmap"
          :options="mapOptions"
          style="width: 100%; height: 100%"
          ref="mapRef"
          @click="handleMapClick"
        >
          <GmapMarker
            :position="marker.position"
            :clickable="true"
            :draggable="true"
            @drag="handleMarkerDrag"
            @click="panToMarker"
          />
        </GmapMap>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit appBanner -->
  </v-container>
</template>

<script>
import Parse from "parse";

export default {
  components: {},

  data() {
    return {
      marker: { position: { lat: 0, lng: 0 } },
      center: { lng: -72.32352599455174, lat: 3.5796305086574405 },
      mapOptions: {
        disableDefaultUI: true,
      },

      dataZones: [],
      loading: true,
      search: "",
      datenow: "",
      zonesData: {
        id: "",
        name: "",
        newBadgeHours: null,
        radius: null,
        latitude: "",
        longitude: "",
        image: "",
        imageType: "",
        status: "true",
        config: "{}",
        options: "{}",
      },
      saveOrEditZonesDialog: false,
      markCoordinateDialog: false,
      isEdit: false,
      menu: false,
      validEditPromo: true,

      nameRules: [(v) => !!v || "Nombre es requerido"],
      radiusRules: [(v) => !!v || "Radio es requerido"],
      newBadgeHoursRules: [(v) => !!v || "Badge Hours es requerido"],

      headers: [
        //{ text: 'ID', align: 'left', value: 'id' },

        { text: "Imagen", align: "left", value: "attributes.image._url" },
        { text: "Nombre", align: "left", value: "attributes.name" },
        { text: "Radio", align: "left", value: "attributes.radius" },
        {
          text: "Badge Hours",
          align: "left",
          value: "attributes.newBadgeHours",
        },
        { text: "Estado", align: "left", value: "attributes.status" },
        { text: "Fecha", align: "left", value: "attributes.createdAt" },
        { text: "Acciones", align: "left", value: "action", sortable: false },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1],
        "items-per-page-text": "Items por página",
      },
      dialogFilterOrders: false,
      validFilter: false,
      sourceOption: "all",
      dates: [],
      zones: [],
      attachBannerImage: [],
      frResultAttachBanner: "",
    };
  },

  mounted() {
    this.interval = setInterval(this.time, 1000);
    this.initialize();
  },

  destroyed() {
    clearInterval(this.interval);
  },

  computed: {},

  methods: {
    async initialize() {
      try {
        let dataZones = await Parse.Cloud.run("getZonesBO");
        this.dataZones = dataZones;
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Zonas", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    //detects location from browser
    geolocate() {
      navigator.geolocation.getCurrentPosition((position) => {
        this.marker.position = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        this.panToMarker();
      });
    },

    //sets the position of marker when dragged
    handleMarkerDrag(e) {
      this.marker.position = { lat: e.latLng.lat(), lng: e.latLng.lng() };
    },

    //Moves the map view port to marker
    panToMarker() {
      this.$refs.mapRef.panTo(this.marker.position);
    },

    //Moves the marker to click position on the map
    handleMapClick(e) {
      this.marker.position = { lat: e.latLng.lat(), lng: e.latLng.lng() };
    },

    markerPositionClean() {
      this.marker.position = { lat: 0, lng: 0 };
    },

    time() {
      this.datenow = this.$moment();
    },

    async changeStatusBanner(item) {
      try {
        let params = {
          id: item.id,
          status: !item.attributes.status,
        };

        this.loading = true;
        await Parse.Cloud.run("changeStatusZoneBO", params);

        this.loading = false;

        this.$snotify.success(
          `Se ha cambiado el estado de la zona`,
          "Cambio de estado",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
      } catch (error) {
        this.$snotify.error(`${error}`, "Zonas", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    openModalSaveOrEdit(edit = false, item = "") {
      this.isEdit = edit;

      if (item) {
        this.zonesData = {
          id: item.id,
          name: item.attributes.name,
          newBadgeHours: item.attributes.newBadgeHours,
          radius: item.attributes.radius,
          status: item.attributes.status,
          latitude: item.attributes.center._latitude,
          longitude: item.attributes.center._longitude,
          url: item.attributes.image._url,
          image: item.attributes.image,
          config: JSON.stringify(item.attributes.config),
          options: JSON.stringify(item.attributes.options),
        };
        this.marker.position = {
          lat: item.attributes.center._latitude,
          lng: item.attributes.center._longitude,
        };
      }

      this.attachBannerImage = [];
      this.frResultAttachBanner = "";
      this.saveOrEditZonesDialog = true;
    },

    openModalMarkCoordinate() {
      this.markCoordinateDialog = true;

      if (this.marker.position.lat == 0 && this.marker.position.lng == 0) {
        setTimeout(function () {}, 2000);
        this.geolocate();
      } else {
        setTimeout(() => {
          this.panToMarker();
        }, 1000);
      }
    },

    closeModalMarkCoordinate() {
      this.markCoordinateDialog = false;
    },

    close() {
      this.saveOrEditZonesDialog = false;
      this.isEdit = false;

      this.zonesData = {
        id: "",
        name: "",
        newBadgeHours: null,
        radius: null,
        latitude: "",
        longitude: "",
        image: "",
        imageType: "",
        status: "true",
        config: "{}",
        options: "{}",
      };

      this.markerPositionClean();
    },

    async saveOrEditZones() {
      if (!this.$refs.formsaveoreditbanner.validate()) {
        this.$snotify.error(`Todos los campos son requeridos.`, "Zonas", {
          timeout: 4000,
          preventDuplicates: true,
        });
        return;
      }

      if (this.marker.position.lat === 0 || this.marker.position.lng === 0) {
        this.$snotify.error(`Marque las coordenadas en el mapa`, "Zonas", {
          timeout: 4000,
          preventDuplicates: true,
        });
        return;
      }

      let params = {
        id: this.zonesData.id,
        name: this.zonesData.name,
        newBadgeHours: parseInt(this.zonesData.newBadgeHours),
        radius: parseInt(this.zonesData.radius),
        status: Boolean(this.zonesData.status),
        latitude: this.marker.position.lat,
        longitude: this.marker.position.lng,
        image: this.attachBannerImage
          ? this.attachBannerImage.length == 0
            ? this.zonesData.image
              ? this.zonesData.image
              : ""
            : this.attachBannerImage.type
            ? await this.uploadAttachBannerImage()
            : ""
          : "",
        imageType: this.attachBannerImage.type,
        config: this.zonesData.config ? JSON.parse(this.zonesData.config) : "",
        options: this.zonesData.options
          ? JSON.parse(this.zonesData.options)
          : "",
      };

      //eslint-disable-next-line
      console.log(params);
      if (!params.image._url) {
        this.$snotify.error(
          `La imagen de la zona no se ha adjuntado por favor verifica y vuelve a intentarlo`,
          "Zonas",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
        return;
      }

      try {
        if (this.isEdit) {
          await Parse.Cloud.run("editZoneBO", params);
        } else {
          await Parse.Cloud.run("newZoneBO", params);
        }

        //eslint-disable-next-line
        //console.log(params);
        this.$snotify.success(
          `Se ha ${this.isEdit ? "editado" : "guardado"} correctamente.`,
          "Zonas",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
        this.close();
        this.initialize();
      } catch (error) {
        this.$snotify.error(`${error}`, "Zonas", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    openImageUrl(item) {
      window.open(item.attributes.rider.attributes.photoUrl, "_blank");
    },

    async uploadAttachBannerImage() {
      let simge = this.frResultAttachBanner.split(",");
      simge = simge[1];
      var parseFile = new Parse.File(
        "zones",
        { base64: simge },
        this.attachBannerImage.type
      );
      let file = await parseFile.save(null);
      return file;
    },

    fileChanged(file) {
      if (file) {
        const fr = new FileReader();
        if (file) {
          fr.readAsDataURL(file);
          fr.addEventListener("load", () => {
            //eslint-disable-next-line
            //console.log(fr.result);
            this.frResultAttachBanner = fr.result;
          });
        }
      }
    },
  },
};
</script>