<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1200" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Descuentos</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
            class="mr-2"
          ></v-text-field>

            <v-btn
              class="mr-1 ml-2 white--text d-print-none"
              color="black"
              @click="createDiscountDialog = true"
              target="_blank"
            >
              <v-icon left>mdi-plus</v-icon>Crear descuento
            </v-btn>

            <!--<v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn icon v-on="on" class="d-print-none">
                <v-icon>mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="openSmsDialogStoreClients()">
                <v-list-item-title> <v-icon left>mdi-forum</v-icon>Enviar SMS a Descuentos</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>-->

        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="discounts"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >
          
            <template v-slot:item.attributes.createdAt="{ item }">
                {{ $moment(item.attributes.createdAt).format('lll') }}
            </template>


            <template v-slot:item.attributes.lastUsed="{ item }">
                {{ $moment(item.attributes.lastUsed).format('lll') }}
            </template>

             <template v-slot:item.attributes.type="{ item }">
                <v-chip
                    class="ml-0"
                    label
                    small
                  >
                    {{ types.find(x => x.id === item.attributes.type).name }}
                </v-chip>
            </template>

            <template v-slot:item.attributes.typeValue="{ item }">
                <v-chip
                    class="ml-0"
                    label
                    small
                  >
                    {{ typevalues.find(x => x.id === item.attributes.typeValue).name }}
                </v-chip>
            </template>

             <template v-slot:item.attributes.value="{ item }">
                <span v-if="item.attributes.typeValue == 'porcent'">{{ item.attributes.value }}%</span>
                <span v-else-if="item.attributes.typeValue == 'value'">{{ item.attributes.value | currency }}</span>
            </template>

             <template v-slot:item.attributes.elements="{ item }">
                {{ item.attributes.elements ? item.attributes.elements.length > 0 ? item.attributes.elements.length : `-` : '' }}
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="active"
                color="success"
                inset
                @click.native="changeStatusDiscount(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
              <v-icon
                class="mr-2"
                @click="showDialogDiscountDetails(item)"
              >
                mdi-eye-outline
              </v-icon>
               <v-icon
                class="mr-2"
                @click="deleteDiscount(item)"
              >
                mdi-delete
              </v-icon>
            </template>

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo Dialogo show info discount -->
    <v-dialog
      v-model="modalDiscount"
      width="500"
      scrollable
      v-if="discount"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Detalle Descuento </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12">
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Fecha:</strong> {{ $moment(discount.attributes.createdAt).format('lll') }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Nombre:</strong> {{ discount.attributes.name }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Tipo de calculo:</strong> {{ typevalues.find(x => x.id === discount.attributes.typeValue).name }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Valor:</strong> {{ discount.attributes.value }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Tipo de descuento:</strong> {{ types.find(x => x.id === discount.attributes.type).name }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-check</v-icon> Elementos:</strong> <br>
                <div v-if="discount.attributes.type != 'all' && discount.attributes.elements && discount.attributes.elements.length > 0" class="pa-3">
                  <ul v-if="discount.attributes.type === 'products'">
                      <li v-for="(item, index) in discount.attributes.elements" :key="index">
                        {{ products.find(prod => prod.id == item).attributes.name }} - (<strong>{{products.find(prod => prod.id == item).attributes.newPrice | currency}}</strong> - <span class="text-decoration-line-through">{{products.find(prod => prod.id == item).attributes.price | currency}}</span>)
                      </li>
                  </ul>
                  <ul v-else-if="discount.attributes.type === 'categories'">
                      <li v-for="(item, index) in discount.attributes.elements" :key="index">
                        {{ productCategories.find(prod => prod.id == item).attributes.name }}
                      </li>
                  </ul>
                </div>
                </div>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo show info customer -->


    <!-- Dialogo create discount -->
    <v-dialog v-model="createDiscountDialog" v-if="$route.params.store_id" width="600" persistent scrollable>
      <v-form ref="formcreate" v-model="validDiscount">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Crear descuento</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
                
                <v-col cols="12">
                    <v-text-field
                        outlined
                        v-model="discountModel.name"
                        :rules="nameRules"
                        label="Nombre"
                        placeholder="Escriba el nombre del descuento"
                        required
                        hide-details
                    ></v-text-field>
                </v-col>

                <v-col cols="12">
                    <v-select
                        v-model="discountModel.typeValue"
                        :items="typevalues"
                        label="Tipo de calculo"
                        outlined
                        item-text="name"
                        item-value="id"
                        :rules="typeValueRules"
                        hide-details
                    ></v-select>
                </v-col>

                <v-col cols="12">
                    <v-text-field
                        outlined
                        v-model="discountModel.value"
                        :rules="valueRules"
                        type="number"
                        min="1"
                        label="Valor de descuento"
                        placeholder="Escriba el valor del descuento"
                        required
                        hide-details
                    ></v-text-field>
                </v-col>
                

                <v-col cols="12">
                    <v-select
                        v-model="discountModel.type"
                        :items="types"
                        label="Tipo de descuento"
                        outlined
                        item-text="name"
                        item-value="id"
                        :rules="typeRules"
                        hide-details
                    ></v-select>
                </v-col>

                <v-col cols="12" v-if="discountModel.type == 'categories'">
                    <v-autocomplete
                        label="Categorías"
                        v-model="discountModel.elements"
                        :items="productCategories"
                        outlined
                        item-text="attributes.name"
                        item-value="id"
                        :rules="categoriesRules"
                        multiple
                        hide-details
                    ></v-autocomplete>
                </v-col>

                <v-col cols="12" v-if="discountModel.type == 'products'">
                    <v-autocomplete
                        label="Productos"
                        v-model="discountModel.elements"
                        :items="products"
                        outlined
                        item-text="attributes.name"
                        item-value="id"
                        :rules="productsRules"
                        multiple
                        hide-details
                    ></v-autocomplete>
                </v-col>

            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="close()">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="createDiscount()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo create discount -->

  </v-container>
</template>

<script>
import Parse from "parse";

export default {

    components: {
    },

  data() {
    return {
      discounts: [],
      discount: '',
      productCategories: [],
      products: [],
      search: "",
      loading: true,
      headers: [
        {
          text: "Nombre",
          align: "left",
          value: "attributes.name"
        },
        { text: "Tipo de descuento", value: "attributes.type" },
        { text: "Tipo de valor", value: "attributes.typeValue" },
        { text: "Valor", value: "attributes.value" },
        { text: "No. Elementos", value: "attributes.elements" },
        { text: "Último uso", value: "attributes.lastUsed" },
        { text: "Creación", value: "attributes.createdAt" },
        { text: "Estado", value: "attributes.status" },
        
        { text: 'Acciones', value: 'action', sortable: false, align: "center", },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      },
      modalDiscount: '',
      createDiscountDialog: false,
      validDiscount: true,
      templates: [],
      template: "",
      discountModel: {
        name: '',
        type: 'all',
        elements: [],
        typeValue: 'porcent',
        value: ''
      },
      nameRules: [v => !!v || "Nombre es requerido"],
      typeRules: [v => !!v || "Tipo de descuento es requerido"],
      categoriesRules: [v => v.length > 0 || "Sebe seleccionar al menos una categoría"],
      productsRules: [v => v.length > 0 || "Sebe seleccionar al menos un producto"],
      typeValueRules: [v => !!v || "Tipo de descuento es requerido"],
      valueRules: [v => !!v || "Valor de descuento es requerido"],
      bodyRules: [v => !!v || "Mensaje es requerido"],

      typevalues: [
        {id: 'porcent', name: 'Porcentaje de descuento'},
        {id: 'value', name: 'Valor fijo a descontar'}
      ],
      types: [
        {id: 'all', name: 'Todos los productos'},
        {id: 'categories', name: 'Por Categorías'},
        {id: 'products', name: 'Por productos específicos'}
      ]
    };
  },

  mounted() {
    this.initialize();
    this.getCategories();
    this.getProducts();
  },

  methods: {
    async initialize() {
      try {

        if (!this.$route.params.store_id) {
            this.$snotify.error(`La identificación del comercio es nula, por favor verificar.`, "Descuentos", {
                timeout: 4000,
                preventDuplicates: true
            });
            return;
        }
        
        let params = {
            id: this.$route.params.store_id
        }
        let discounts = await Parse.Cloud.run("getProductDiscountBO", params);
        this.discounts = discounts;
        //eslint-disable-next-line
        //console.log(this.discounts);
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Descuentos", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    async getCategories () {
          const params = {
              id: this.$route.params.store_id
          }
        try {
          let productCategories = await Parse.Cloud.run("getCategoriesBO", params);
          this.productCategories = productCategories
          //eslint-disable-next-line
          //console.log(this.products);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Categorías', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
    },

    async getProducts() {
          const params = {
              id: this.$route.params.store_id
          }
        try {
          let products = await Parse.Cloud.run("getProductsBO", params);
          this.products = products
          //eslint-disable-next-line
          //console.log(this.products);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
    },

    showDialogDiscountDetails(item){
      this.discount = item
      this.modalDiscount = true
    },

    close() {
        this.discountModel = {
            name: '',
            type: 'all',
            elements: [],
            typeValue: 'porcent',
            value: ''
        }
        this.modalDiscount = false
        this.createDiscountDialog = false
    },

    async createDiscount(){
        if (!this.$refs.formcreate.validate()) {
            this.$snotify.error(`Todos los campos son requeridos.` , 'Descuento', {
                timeout: 4000,
                preventDuplicates: true
            });
            return;
        }
        
        try {
            let params = {
                id: this.$route.params.store_id,
                name: this.discountModel.name,
                type: this.discountModel.type,
                elements: this.discountModel.elements,
                typeValue: this.discountModel.typeValue,
                value: this.discountModel.value,
            }
            
            await Parse.Cloud.run("saveDiscountBO", params)
            //eslint-disable-next-line
            //console.log(result);
            this.initialize()
            this.close()

            this.$snotify.success(`Descuento creado satisfactoriamente` , 'Creado', {
                timeout: 4000,
                preventDuplicates: true
            });

        } catch (error) {
            this.$snotify.error(`${error}` , 'Descuento', {
                timeout: 4000,
                preventDuplicates: true
            });
        }
    },

    async changeStatusDiscount(item){
        try {
            let params = {
                id: item.id,
                isDelete: false
            }
            
            await Parse.Cloud.run("changeStatusDiscountBO", params)
            this.initialize()

            this.$snotify.success(`Se cambio de estado satisfactoriamente` , 'Status', {
                timeout: 4000,
                preventDuplicates: true
            });

        } catch (error) {
            this.$snotify.error(`${error}` , 'Descuento', {
                timeout: 4000,
                preventDuplicates: true
            });
        }
    },

    async deleteDiscount(item){
        this.$swal({
            title: "Eliminar descuento",
            text: "¿Estás seguro de que deseas eliminar el descuento?",
            icon: "warning",
            buttons: ["NO cancelar", 'Eliminar'],
            dangerMode: true,
          })
          .then(async (willDelivered) => {
            if (willDelivered) {
                try {
                    let params = {
                        id: item.id,
                        isDelete: true
                    }
                    
                    await Parse.Cloud.run("changeStatusDiscountBO", params)
                    this.initialize()
        
                    this.$snotify.success(`Descuento eliminado satisfactoriamente` , 'Eliminado', {
                        timeout: 4000,
                        preventDuplicates: true
                    });
        
                } catch (error) {
                    this.$snotify.error(`${error}` , 'Descuento', {
                        timeout: 4000,
                        preventDuplicates: true
                    });
                }
            }
          });
    }

  }
};
</script>