<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1300"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="promoCodes"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Códigos promocionales</v-toolbar-title>

        <v-spacer></v-spacer>

        <v-btn color="black" class="mr-2 white--text" to="/promo-code-uses"> <v-icon left>mdi-tag</v-icon> Promos aplicadas</v-btn>
        <v-btn color="black" class="mr-2 white--text" @click="openModalSaveOrEdit()"> <v-icon left>mdi-plus</v-icon> Nueva promo</v-btn>
        
        <!--<download-excel
            class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
            :data = "promoCodes"
            :fields = "headers_export"
            worksheet = "Promos Repost"
            name = "PromosReport.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
        </download-excel>-->

      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="promoCodes"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por'
            }"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <!--<v-toolbar-title>PAGOS</v-toolbar-title>-->
                <v-spacer></v-spacer>
                 <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                ></v-text-field>
                <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
            </v-toolbar>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
                {{$moment(item.attributes.createdAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
                {{$moment(item.attributes.updatedAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.validUntil="{ item }">
                <span v-if="datenow" :style="datenow.diff($moment(item.attributes.validUntil), 'days') >= 1 ? 'color: brown;' : 'color: darkgreen;'">
                    {{$moment(item.attributes.validUntil).format('lll')}}
                </span>
            </template>

            <template v-slot:item.attributes.value="{ item }">
                <span v-if="item.attributes.type === 'value'">
                    {{ item.attributes.value | currency }}
                </span>
                <span v-else>
                    {{ item.attributes.value }}%
                </span>
            </template>

            <template v-slot:item.attributes.minOrderAmount="{ item }">
                {{ item.attributes.minOrderAmount | currency }}
            </template>

            <template v-slot:item.attributes.type="{ item }">
                <v-chip :color="item.attributes.type === 'value' ? 'primary' : 'warning'" text-color="white" class="ml-0" small>
                      {{item.attributes.type ? item.attributes.type.toUpperCase() : ''}}
                </v-chip>
            </template>


            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                v-if="item.attributes.status == 'deleted'"
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="deleted"
                color="error"
                inset
                @click.native="changeStatusPromo(item)"
              ></v-switch>
              <v-switch
                v-else
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="active"
                color="success"
                inset
                @click.native="changeStatusPromo(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
                <!--<v-icon
                    class="mr-2"
                    @click="detailPromoCode(item)"
                >
                    mdi-eye
                </v-icon>-->

                <v-icon
                    class="mr-2"
                    @click="openModalSaveOrEdit(true, item)"
                >
                    mdi-pencil
                </v-icon>
            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  <!-- Dialogo Edit promoCode -->
    <v-dialog
      v-model="saveOrEditPromoCodeDialog"
      width="600"
      scrollable
      persistent
    >
    <v-form ref="formeditpromo" v-model="validEditPromo">
      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{ isEdit ? 'Editar ': 'Nuevo' }} código promocional </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-card-text>
          <v-divider class="mb-2"></v-divider>
            <v-row dense>
                <v-col cols="12" md="12">
                    <v-text-field
                      v-model="promoCode.code"
                      :rules="codeRules"
                      outlined
                      label="Código"
                      prepend-inner-icon="mdi-tag"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                   <v-text-field
                      v-model.number="promoCode.maxUses"
                      :rules="maxUsesRules"
                      type="number"
                      min="1"
                      outlined
                      label="Usos máximos"
                      prepend-inner-icon="mdi-numeric-1-box-multiple-outline"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                   <v-text-field
                      v-model.number="promoCode.maxUsesXUser"
                      :rules="maxUsesXUserRules"
                      type="number"
                      min="1"
                      outlined
                      label="Usos máximos por usuario"
                      prepend-inner-icon="mdi-counter"
                      hide-details
                    ></v-text-field>
                </v-col>

                <v-col cols="12" md="6">
                   <v-text-field
                      v-model.number="promoCode.value"
                      :rules="valueRules"
                      type="number"
                      min="1"
                      outlined
                      label="Monto o valor"
                      prepend-inner-icon="mdi-currency-usd"
                    ></v-text-field>
                </v-col>

                <v-col cols="12" md="6">
                   <v-text-field
                      v-model.number="promoCode.minOrderAmount"
                      :rules="minOrderAmountRules"
                      type="number"
                      min="1"
                      outlined
                      label="Monto mínimo"
                      prepend-inner-icon="mdi-currency-usd"
                      hint="El cupón será aplicado solo si la orden supera este monto"
                    ></v-text-field>
                </v-col>

                <v-col cols="12" md="6">
                    <v-select
                      v-model="promoCode.type"
                      :rules="typeRules"
                      :items="[{id: 'value', name: 'Valor'}, {id: 'percent', name: 'Porcentaje'}]"
                      label="Tipo"
                      item-text="name"
                      item-value="id"
                      outlined
                      hide-details
                      prepend-inner-icon="mdi-sale"
                    ></v-select>
                </v-col>

                 <v-col cols="12" md="6">
                     <v-menu
                        ref="menu"
                        v-model="menu"
                        :close-on-content-click="false"
                        :return-value.sync="promoCode.validUntil"
                        transition="scale-transition"
                        offset-y
                        min-width="auto"
                    >
                        <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                            v-model="promoCode.validUntil"
                            label="Válido hasta"
                            :rules="validUntilRules"
                            prepend-inner-icon="mdi-calendar"
                            readonly
                            outlined
                            v-bind="attrs"
                            v-on="on"
                        ></v-text-field>
                        </template>
                        <v-date-picker
                        v-model="promoCode.validUntil"
                        no-title
                        scrollable
                        >
                        <v-spacer></v-spacer>
                        <v-btn
                            text
                            color="primary"
                            @click="menu = false"
                        >
                            Cancel
                        </v-btn>
                        <v-btn
                            text
                            color="primary"
                            @click="$refs.menu.save(promoCode.validUntil)"
                        >
                            OK
                        </v-btn>
                        </v-date-picker>
                    </v-menu>
                </v-col>

                <v-col cols="12" md="12">
                    <v-textarea
                      v-model="promoCode.description"
                      outlined
                      name="input-7-4"
                      label="Descripción"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>

                <v-col cols="12" md="12">
                    <v-autocomplete
                        v-model="promoCode.stores"
                        :items="stores"
                        outlined
                        chips
                        multiple
                        item-text="attributes.name"
                        item-value="id"
                        label="Seleccione los comercios al cual se aplicara el código"
                        hide-details
                    ></v-autocomplete>
                </v-col>

                <v-col cols="12" md="12">
                    <v-switch v-model="promoCode.byDelivery" inset color="success" :label="`¿El código promocional sólo se aplicará al valor o monto del domicilio?`" hide-details></v-switch>
                </v-col>

                <v-col cols="12" md="12">
                    <v-switch v-model="promoCode.status" inset color="success" false-value="inactive" true-value="active" :label="`Activo`" hide-details></v-switch>
                </v-col>

            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
           <v-btn
            color="success"
            outlined
            @click="saveOrEditPromoCode()"
          >
           <v-icon left>mdi-content-save-outline</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Edit PromoCode -->

  </v-container>
</template>

<script>
import Parse from 'parse'
//import JsonExcel from 'vue-json-excel'

export default {
    
    components: {
        //'download-excel': JsonExcel,
    },

    data() {
        return {
            promoCodes: [],
            loading: true,
            search: '',
            datenow: '',
            promoCode: {
                id: '',
                code: '',
                maxUses: '',
                maxUsesXUser: '',
                value: '',
                minOrderAmount: '',
                type: 'value',
                validUntil: '',
                stores: [],
                description: '',
                byDelivery: false,
                status: 'active',
            },
            stores: [],
            saveOrEditPromoCodeDialog: false,
            isEdit: false,
            menu: false,
            validEditPromo: true,
            codeRules: [v => !!v || "Código es requerido"],
            maxUsesRules: [v => !!v || "Usos máximos es requerido"],
            maxUsesXUserRules: [v => !!v || "Máximos usos por usuario es requerido"],
            valueRules: [v => !!v || "Valor o monto es requerido"],
            minOrderAmountRules: [v => !!v || "Monto mínimo es requerido"],
            typeRules: [v => !!v || "Tipo de código es requerido"],
            validUntilRules: [v => !!v || "Válido hasta es requerido"],
            headers: [
                //{ text: 'ID', align: 'left', value: 'id' },

                { text: 'Código', align: 'left', value: 'attributes.code' },
                { text: 'Usos', align: 'left', value: 'attributes.uses' },
                { text: 'Max usos', align: 'left', value: 'attributes.maxUses' },
                { text: 'Usos x usuario', align: 'left', value: 'attributes.maxUsesXUser' },
                { text: 'Monto', align: 'left', value: 'attributes.value' },
                { text: 'Monto mínimo', align: 'left', value: 'attributes.minOrderAmount' },
                { text: 'Tipo', align: 'left', value: 'attributes.type' },

                { text: 'Válido_Hasta', align: 'left', value: 'attributes.validUntil' },
                { text: 'Fecha creación', align: 'left', value: 'attributes.createdAt' },
                { text: 'Fecha modificación', align: 'left', value: 'attributes.updatedAt' },

                { text: 'Status', align: 'left', value: 'attributes.status' },

                //{ text: 'Comercios', align: 'left', value: 'attributes.stores' },
                { text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            dialogFilterOrders: false,
            validFilter: false,
            sourceOption: "all",
            dates: [],
            headers_export: {
                'ID': 'id',
                'Código': 'attributes.code',
                'Válido hasta': 'attributes.validUntil',
                'Usos': 'attributes.uses',
                'Max usos': 'attributes.maxUses',
                'Usos x usuario': 'attributes.maxUsesXUser',
                'Monto': 'attributes.value',
                'Monto mínimo': 'attributes.minOrderAmount',
                'Tipo': 'attributes.type',
                'Comercios': 'attributes.stores',
                'Status': 'attributes.status',

                'Fecha modificación': {
                    field: 'attributes.updatedAt',
                    callback: (value) => {
                        let startDate = value.toLocaleString()
                        return `${startDate}`;
                    }
                },
               
                'Fecha creación': {
                    field: 'attributes.createdAt',
                    callback: (value) => {
                        let startDate = value.toLocaleString()
                        return `${startDate}`;
                    }
                }
            },
        }
    },

    mounted() {
        this.interval = setInterval(this.time, 1000);
        this.initialize();
        this.getStores();
    },

    destroyed() {
        clearInterval(this.interval);
    },

    computed: {
    },

    methods: {

        async initialize(){
            let params = {}
            try {
                let promoCodes = await Parse.Cloud.run("getPromoCodesBO", params);
                this.promoCodes = promoCodes;
                //eslint-disable-next-line
                //console.log(this.promoCodes);
                this.loading = false;
            } catch (error) {
                this.$snotify.error(`${error}`, "Cupones", {
                timeout: 4000,
                preventDuplicates: true
                });
            }
        },

        time(){
            this.datenow = this.$moment()
        },

        async changeStatusPromo(item){
            
            try {
                let params = {
                    id: item.id
                }

                this.loading = true
                await Parse.Cloud.run("changeStatusPromoCodeBO", params);
                
                this.loading = false

                this.$snotify.success(`Se ha cambiado el estado del promo code ${item.attributes.code}` , 'Cambio de estado', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Promo code', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        detailPromoCode(item){
            //eslint-disable-next-line
            console.log(item);
        },

        editPromoCode(item){
            //eslint-disable-next-line
            console.log(item);
        },

        openModalSaveOrEdit(edit = false, item = ''){
            this.isEdit = edit
            if (item) {
                let stores = []
                if (item.attributes.stores && item.attributes.stores.length > 0) {
                    for (let index = 0; index < item.attributes.stores.length; index++) {
                        const element = item.attributes.stores[index];
                        let store = this.stores.find(a => a.id === element);
                        stores.push(store.id);
                    }
                }
                this.promoCode = {
                    id: item.id,
                    code: item.attributes.code,
                    maxUses: item.attributes.maxUses,
                    maxUsesXUser: item.attributes.maxUsesXUser,
                    value: item.attributes.value,
                    minOrderAmount: item.attributes.minOrderAmount,
                    type: item.attributes.type,
                    validUntil: item.attributes.validUntil ? this.$moment(item.attributes.validUntil).format('YYYY-MM-DD') : '',
                    stores: stores,
                    description: item.attributes.description,
                    byDelivery: item.attributes.byDelivery,
                    status: item.attributes.status,
                }
            }
            this.saveOrEditPromoCodeDialog = true
        },

        close(){
            this.saveOrEditPromoCodeDialog = false
            this.isEdit = false
            this.promoCode = {
                id: '',
                code: '',
                maxUses: '',
                maxUsesXUser: '',
                value: '',
                minOrderAmount: '',
                type: 'value',
                validUntil: '',
                stores: [],
                description: '',
                byDelivery: false,
                status: 'active',
            }
        },

        async saveOrEditPromoCode(){
            if (!this.$refs.formeditpromo.validate()) {
                this.$snotify.error(`Todos los campos son requeridos.` , 'Promo code', {
                    timeout: 4000,
                    preventDuplicates: true
                });
                return;
            }
            let params = {
                id: this.promoCode.id,
                code: this.promoCode.code,
                maxUses: this.promoCode.maxUses,
                maxUsesXUser: this.promoCode.maxUsesXUser,
                value: this.promoCode.value,
                minOrderAmount: this.promoCode.minOrderAmount,
                type: this.promoCode.type,
                validUntil: this.promoCode.validUntil,
                stores: this.promoCode.stores,
                description: this.promoCode.description,
                byDelivery: this.promoCode.byDelivery,
                status: this.promoCode.status,
            }
            try {
                if (this.isEdit) {
                    await Parse.Cloud.run("editPromoCodeBO", params);
                }else{
                    await Parse.Cloud.run("newPromoCodeBO", params);
                }
                
                //eslint-disable-next-line
                //console.log(this.promoCodes);
                this.$snotify.success(`Se ha ${this.isEdit ? 'editado' : 'guardado'} correctamente.` , 'Promo code', {
                    timeout: 4000,
                    preventDuplicates: true
                });
                this.close();
                this.initialize();
            } catch (error) {
                this.$snotify.error(`${error}`, "Promo code", {
                timeout: 4000,
                preventDuplicates: true
                });
            }
        },

        async getStores(){
            try {
            let stores = await Parse.Cloud.run("getStoresBO");
            this.stores = stores
            //eslint-disable-next-line
            //console.log(this.stores);
            this.loading = false
            
            } catch (error) {
            this.$snotify.error(`${error}` , 'Comercios', {
                timeout: 4000,
                preventDuplicates: true
            });
            }
            
        },
    },
}
</script>