<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1200"
      style="margin-top: -64px;"
    >
        <v-system-bar
         color="primary"
         dark
         class="d-none d-sm-flex"
        >
          <v-icon>mdi-store-outline</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'active').length }} comercios abiertos</span>
          <span class="mr-2">|</span>
          <v-icon>mdi-sleep</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'inactive').length }} comercios cerrados</span>
          <span class="mr-2">|</span>
          <v-icon>mdi-alert-octagram-outline</v-icon>
          <span class="mr-2">{{ companies.filter(store => store.attributes.status === 'created').length }} comercios inactivos</span>
          <v-spacer></v-spacer>
          <!--<v-icon>mdi-wifi-strength-4</v-icon>
          <v-icon>mdi-signal-cellular-outline</v-icon>
          <v-icon>mdi-battery</v-icon>
          <span>12:30</span>-->
        </v-system-bar>
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Comercios</v-toolbar-title>

        <v-spacer></v-spacer>

        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Buscar.."
          single-line
          hide-details
        ></v-text-field>

        <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn
                icon
                v-on="on"
              >
                <v-icon >mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="dialogInvoice = true">
                <v-list-item-title><v-icon left>mdi-receipt</v-icon> Generar facturas</v-list-item-title>
              </v-list-item>
              <v-list-item to="/invoices-payment-due">
                <v-list-item-title><v-icon left>mdi-calendar-clock</v-icon> Reporte de facturas</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

  
      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="companies"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <!--<v-toolbar-title>COMERCIOS</v-toolbar-title>-->
                <v-spacer></v-spacer>

                <!--<v-btn color="black" class="mb-2 mr-2 white--text d-none d-sm-flex" @click="pruebaCustomerNew()"> <v-icon left>mdi-android</v-icon> Generar Customers POS</v-btn>-->
                <v-btn color="black" class="mb-2 mr-2 white--text" to="/stores-maps"> <v-icon left>mdi-google-maps</v-icon> Ver mapa</v-btn>
                <v-btn color="black" class="mb-2 white--text d-none d-sm-flex" :loading="loading_invoice" :disabled="loading_invoice" @click="dialogInvoice = true"> <v-icon left>mdi-receipt</v-icon> Generar facturas</v-btn>
            </v-toolbar>
            </template>
            
            <template v-slot:item.attributes.logoUrl="{ item }">
              <v-avatar
                  size="36px"
                  color="teal"
                >
                  <img
                    v-if="item.attributes.logoUrl"
                    alt="Avatar"
                    :src="item.attributes.logoUrl"
                  >
                  <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.plan.attributes.display_name="{ item }">
              <v-chip
                class="text-center justify-center"
                style="width: 100%;"
                :color="item.attributes.plan.attributes.hexColor ? item.attributes.plan.attributes.hexColor : 'success'"
                small
                outlined
                v-if="item.attributes.plan"
              >
                {{item.attributes.plan.attributes.display_name}}
              </v-chip>

              <v-chip
                class="text-center justify-center"
                style="width: 100%;"
                small
                outlined
                v-else
              >
                No asignado
              </v-chip>
              
            </template>

            <template v-slot:item.attributes.acceptBankTransfer="{ item }">
              <v-icon v-if="item.attributes.acceptBankTransfer">mdi-check</v-icon>
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="active"
                color="success"
                inset
                @click.native="item.attributes.status == 'active' ? changeStatusStore(item, false) : item.attributes.status == 'inactive' ? changeStatusStore(item, false) : showDialogConfirmChange(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="detailStore(item)"
            >
                mdi-eye
            </v-icon>
            <v-icon
                class="mr-2"
                @click="editStore(item)"
            >
                mdi-pencil
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goProducts(item)"
            >
              mdi-package-variant
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goBillings(item)"
            >
                mdi-receipt
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goCustomers(item)"
            >
                mdi-account-group
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goReports(item)"
            >
                mdi-chart-bar
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goCategories(item)"
            >
                mdi-tag-multiple
            </v-icon>
             <v-icon
              class="mr-2"
              @click="goSchedule(item)"
            >
                mdi-calendar-arrow-right
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goGeoCoverage(item)"
            >
                mdi-map-plus
            </v-icon>
            <v-icon
              class="mr-2"
              @click="goLogStore(item)"
            >
                mdi-restore-alert
            </v-icon>
            <v-icon class="mr-2" @click="goStoreBanners(item)">
              mdi-folder-multiple-image
            </v-icon>
            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">Recargar</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  

    <!-- Dialogo Detail Store -->
    <v-dialog
      v-model="detailStoreDialog"
      width="450"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{store.attributes.name}}  </span>
          <v-spacer></v-spacer>
          <span class="text-capitalize"> 
            <v-icon>mdi-thumb-up-outline</v-icon> {{ store.attributes.likes }}
          </span>
        </v-card-title>
        <v-img
          max-height="210"
          v-if="store.attributes.logoUrl"
          :src="store.attributes.logoUrl"
          
        ></v-img>

        <v-card-text>
          <div class="pt-2 subtitle-1 black--text">
            <v-icon>mdi-home-city-outline</v-icon>
            {{ store.attributes.city }}
          </div>

          <div class="pt-2 black--text">
            <v-icon>mdi-cellphone-iphone</v-icon>
            {{ store.attributes.phone }}
          </div>

          <div class="pt-2 pb-2 black--text">
            <v-icon>mdi-file-eye-outline</v-icon>
            Vistas: {{ store.attributes.views }}
          </div>

          <v-divider class=""></v-divider>

          <div class="pt-2 black--text">
            {{store.attributes.description}}
          </div>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            :href="`https://stores.festyapp.com/me/${store.attributes.slug ? store.attributes.slug : store.id}`"
            target="_blank"
          >
           <v-icon left>mdi-open-in-new</v-icon> Ver perfil público
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="danger"
            outlined
            @click="detailStoreDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Detail Store -->

    <!-- Dialogo Confirm change -->
    <v-dialog
      v-model="dialogConfirmChange"
      width="450"
      v-if="store"
      scrollable
    >

        <v-form
          ref="form"
          v-model="valid"
        >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Comprobación  </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-text-field
            outlined
            :value="cityCheck"
            @change="v => cityCheck = v"
            :rules="cityCheckRules"
            label="Ciudad"
            placeholder="Escriba la ciudad del comercio"
            required
            hide-details
          ></v-text-field>
          
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          
          <v-btn
            color="primary"
            outlined
            @click="dialogConfirmChange = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="changeStatusStore(store, true)"
          >
           <v-icon left>mdi-content-save</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Confirm change -->


    <!-- Dialogo Confirm change -->
    <v-dialog
      v-model="dialogInvoice"
      width="500"
      scrollable
    >

        <v-form
          ref="form"
          v-model="valid"
        >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Generar facturas  </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          
          <v-select
            v-model="month_invoice"
            :items="[{id: '', text: 'Mes actual'}, {id: -12, text: `Enero ${new Date().getFullYear()-1} (año anterior)`}, {id: -11, text: `Febrero ${new Date().getFullYear()-1} (año anterior)`}, {id: -10, text: `Marzo ${new Date().getFullYear()-1} (año anterior)`}, {id: -9, text: `Abril ${new Date().getFullYear()-1} (año anterior)`}, {id: -8, text: `Mayo ${new Date().getFullYear()-1} (año anterior)`}, {id: -7, text: `Junio ${new Date().getFullYear()-1} (año anterior)`}, {id: -6, text: `Julio ${new Date().getFullYear()-1} (año anterior)`}, {id: -5, text: `Agosto ${new Date().getFullYear()-1} (año anterior)`}, {id: -4, text: `Septiembre ${new Date().getFullYear()-1} (año anterior)`}, {id: -3, text: `Octubre ${new Date().getFullYear()-1} (año anterior)`}, {id: -2, text: `Noviembre ${new Date().getFullYear()-1} (año anterior)`}, {id: -1, text: `Diciembre ${new Date().getFullYear()-1} (año anterior)`}, {id: 0, text: 'Enero'}, {id: 1, text: 'Febrero'}, {id: 2, text: 'Marzo'}, {id: 3, text: 'Abril'}, {id: 4, text: 'Mayo'}, {id: 5, text: 'Junio'}, {id: 6, text: 'Julio'}, {id: 7, text: 'Agosto'}, {id: 8, text: 'Septiembre'}, {id: 9, text: 'Octubre'}, {id: 10, text: 'Noviembre'}, {id: 11, text: 'Diciembre'}]"
            label="Mes de facturación"
            item-text="text"
            item-value="id"
            outlined
            hide-details
            class="mb-2"
          ></v-select>

          <v-autocomplete
            v-model="stores_invoice"
            :items="companies"
            outlined
            chips
            multiple
            
            item-text="attributes.name"
            item-value="id"
            label="Seleccione los comercios"
            hint="Deje este campo vacio si desea generar las facturas de todos los comercios."
            persistent-hint
          ></v-autocomplete>

          <v-checkbox
            class="mt-0"
            v-model="noDiscountApplies"
            label="¿Desea NO aplicar descuento para esta/estas facturas?"
            hide-details
          ></v-checkbox>
          
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          
          <v-btn
            color="primary"
            outlined
            @click="dialogInvoice = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="generateMonthlyInvoices()"
          >
           <v-icon left>mdi-content-save</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Confirm change -->

    <!-- Dialogo Edit Store -->
    <v-dialog
      v-model="editStoreDialog"
      width="600"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Editar producto </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

         <v-img
          max-height="210"
          v-if="store.attributes.logoUrl"
          :src="store.attributes.logoUrl"
          
        ></v-img>

        <v-card-text>
          <v-divider class="mb-2"></v-divider>
            <v-row dense>
                <v-col cols="12">
                  <!-- editedItem.attributes.logoUrl -->
                  <v-file-input
                    v-model="attachStoreLogoFile"
                    color="primary accent-4"
                    label="Logo"
                    placeholder="Adjunta la imagen del producto"
                    outlined
                    hide-details
                    :show-size="1000"
                    @change="fileChanged"
                    prepend-icon
                    prepend-inner-icon="mdi-image"
                  >
                    <template v-slot:selection="{ index, text }">
                      <v-chip
                        v-if="index < 2"
                        color="primary accent-4"
                        dark
                        label
                        small
                      >
                        {{ text }}
                      </v-chip>
                    </template>
                  </v-file-input>
                </v-col>
                <v-col cols="12" md="6">
                    <v-text-field
                      v-model="editedItem.attributes.name"
                      outlined
                      label="Nombre"
                      prepend-inner-icon="mdi-store"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                   <v-text-field
                      v-model="editedItem.attributes.category"
                      outlined
                      label="Categoría"
                      prepend-inner-icon="mdi-tag"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12">
                     <v-text-field
                      v-model="editedItem.attributes.address"
                      outlined
                      label="Dirección"
                      prepend-inner-icon="mdi-map-marker"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                      v-model="editedItem.attributes.city"
                      outlined
                      label="Ciudad"
                      prepend-inner-icon="mdi-city"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.slug"
                      outlined
                      label="Slug"
                      prepend-inner-icon="mdi-google-chrome"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.phone"
                      outlined
                      label="Teléfono principal"
                      prepend-inner-icon="mdi-phone"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.phoneSMSAlert"
                      outlined
                      label="Teléfono SMS"
                      prepend-inner-icon="mdi-message-alert"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                    <v-select
                      v-model="editedItem.attributes.storeCategory"
                      :items="categoriesStores"
                      label="Categoría del comercio"
                      item-text="attributes.name"
                      return-object
                      outlined
                      hide-details
                      prepend-inner-icon="mdi-tag-arrow-up"
                    ></v-select>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                     v-model.number="editedItem.attributes.minAmount"
                      outlined
                      label="Monto mínimo de una orden"
                      prepend-inner-icon="mdi-cash-multiple"
                      hide-details
                      type="number"
                      min="0"
                    ></v-text-field>
                </v-col>
                <v-col cols="12">
                    <v-textarea
                      v-model="editedItem.attributes.description"
                      outlined
                      name="input-7-4"
                      label="Descripción"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>
                <v-col cols="12" md="12">
                     <v-text-field
                     v-model="editedItem.attributes.subtitle"
                      outlined
                      label="Subtítulo"
                      prepend-inner-icon="mdi-subtitles"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12">
                    <v-textarea
                      v-model="editedItem.attributes.delivery"
                      outlined
                      name="input-7-4"
                      label="Configuración de envíos (JSON)"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>
                <v-col cols="12" class="mb-2">
                    <v-switch v-model="editedItem.attributes.acceptBankTransfer" inset color="success" :label="`¿Acepta transferencias bancarias?`" hide-details></v-switch>
                </v-col>
                <v-col cols="12" v-if="editedItem.attributes.acceptBankTransfer">
                    <v-textarea
                      v-model="editedItem.attributes.transfersMethods"
                      outlined
                      name="input-7-4"
                      label="Métodos aceptados (JSON)"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>

                <v-col cols="12">
                    <v-switch v-model="editedItem.attributes.hasCardReader" inset color="success" :label="`¿Envía y acepta pagos con datafono?`" hide-details></v-switch>
                </v-col>

                <v-col cols="12">
                    <v-switch v-model="editedItem.attributes.posEnabled" inset color="yellow darken-2" :label="`¿Activar función miniPOS?`" hide-details></v-switch>
                </v-col>

                <v-col cols="12">
                    <v-switch v-model="editedItem.attributes.riderService" inset color="success" :label="`¿Activar servicio de Festy Riders?`" hide-details></v-switch>
                </v-col>

                <v-col cols="12">
                    <v-switch v-model="editedItem.attributes.fee.status" inset color="success" :label="`¿Establecer comisión para ordenes o pedidos?`" hide-details></v-switch>
                </v-col>

                 <v-col cols="12" v-if="editedItem.attributes.fee.status">
                    <v-select
                      v-model="editedItem.attributes.fee.type"
                      :items="[{id: 'porcent', name: 'Porcentaje'}, {id: 'value', name: 'Valor fijo'}]"
                      label="Tipo de comisión"
                      item-value="id"
                      item-text="name"
                      outlined
                      hide-details
                      prepend-inner-icon="mdi-stairs-up"
                    ></v-select>
                </v-col>

                 <v-col cols="12" v-if="editedItem.attributes.fee.status">
                    <v-text-field
                      v-model="editedItem.attributes.fee.value"
                      type="number"
                      min="1"
                      outlined
                      label="Valor de la comisión"
                      prepend-inner-icon="mdi-counter"
                      hide-details
                    ></v-text-field>
                </v-col>

            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
           <v-btn
            color="success"
            outlined
            @click="saveEditStore()"
          >
           <v-icon left>mdi-content-save-outline</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Store -->
    
  </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    data() {
        return {
            month_invoice: '',
            stores_invoice: [],
            dialogInvoice: false,
            loading_invoice: false,
            cityCheck: '',
            cityCheckRules: [
              v => !!v || 'Ciudad es requerida'
            ],
            valid: false,
            store: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            detailStoreDialog: false,
            search: '',
            loading: true,
            dialog: false,
            headers: [
              { text: 'Logo', align: 'left', value: 'attributes.logoUrl', sortable: false },
              { text: 'Nombre', align: 'left', value: 'attributes.name' },
              { text: 'Ciudad', value: 'attributes.city' },
              { text: 'Celular', value: 'attributes.phone' },
              { text: 'Plan', value: 'attributes.plan.attributes.display_name' },
              { text: 'Vistas', value: 'attributes.views' },
              { text: 'T. Banco', value: 'attributes.acceptBankTransfer' },
              { text: 'Estado', value: 'attributes.status' },
              { text: 'Acciones', value: 'action', sortable: false },
            ],
            pagination: {
              'items-per-page-options' : [50, 60, 70, 100, -1]
            },
            companies: [],
            editedIndex: -1,
            editedItem: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: '',
                slug: '',
                phoneSMSAlert: '',
                acceptBankTransfer: false,
                transfersMethods: '',
                description: '',
                address: '',
                category: '',
                posEnabled: false,
                riderService: false,
                storeCategory: '',
                hasCardReader: false,
                delivery: '',
                fee: {
                  type: 'porcent',
                  value: 0,
                  status: false
                },
                subtitle: '',
                minAmount: '',
              }
            },
            defaultItem: {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: '',
                slug: '',
                phoneSMSAlert: '',
                acceptBankTransfer: false,
                transfersMethods: '',
                description: '',
                address: '',
                category: '',
                posEnabled: false,
                riderService: false,
                storeCategory: '',
                hasCardReader: false,
                delivery: '',
                fee: {
                  type: 'porcent',
                  value: 0,
                  status: false
                },
                subtitle: '',
                minAmount: ''
              }
            },
            dialogConfirmChange: false,
            editStoreDialog: false,
            noDiscountApplies: false,
            attachStoreLogo: '',
            attachStoreLogoFile: [],
            categoriesStores: []
        }
    },
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Nuevo Comercio' : 'Editar Comercio'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    created () {
      this.initialize()
      this.getCageriesStore()
    },

    methods: {
      async initialize () {
        try {
          let companies = await Parse.Cloud.run("getStoresBO");
          this.companies = companies
          //eslint-disable-next-line
          //console.log(this.companies);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

       async getCageriesStore() {
        try {
          let categoriesStores = await Parse.Cloud.run("getStoreCategoryBO");
          this.categoriesStores = categoriesStores
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Categorías', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      async pruebaCustomerNew () {
        try {
          let test = await Parse.Cloud.run("newPosOrderCustomerMethodForStoreBO");
          //let test = await Parse.Cloud.run("newPosOrderCustomerMethodForHunterAndButcherBO");
          //eslint-disable-next-line
          console.log(test);
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Prueba Customers', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      editItem (item) {
        this.editedIndex = this.companies.indexOf(item)
        this.editedItem = item
        this.dialog = true
      },

      deleteItem (item) {
        const index = this.companies.indexOf(item)
        confirm('Are you sure you want to delete this item?') && this.companies.splice(index, 1)
      },

      /*close () {
        this.dialog = false
        setTimeout(() => {
          this.editedItem = Object.assign({}, this.defaultItem)
          this.editedIndex = -1
        }, 300)
      },*/

      save () {
        if (this.editedIndex > -1) {
          Object.assign(this.companies[this.editedIndex], this.editedItem)
        } else {
          this.companies.push(this.editedItem)
        }
        this.close()
      },

      detailStore(store){
        let routeData = this.$router.resolve('/store-info/' + store.id);
        window.open(routeData.href, '_blank');
        //this.store = store
        //this.detailStoreDialog = true
      },

      goBillings(store){
        let routeData = this.$router.resolve('/store/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goCustomers(store){
        let routeData = this.$router.resolve('/customers/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goProducts(store){
        let routeData = this.$router.resolve('/products/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goReports(store){
        let routeData = this.$router.resolve('/reports/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goCategories(store){
        let routeData = this.$router.resolve('/categories/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goSchedule(store){
        let routeData = this.$router.resolve('/config/schedule/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goGeoCoverage(store){
        let routeData = this.$router.resolve('/geo-coverage/' + store.id);
        window.open(routeData.href, '_blank');
      },

      goLogStore(store){
        let routeData = this.$router.resolve('/logs-store/' + store.id);
        window.open(routeData.href, '_blank');
      },
      
      async generateMonthlyInvoices(){
        try {
          this.loading_invoice = true
          
          let params = {
            month: this.month_invoice,
            store_ids: this.stores_invoice ? this.stores_invoice.length > 0 ? this.stores_invoice : '' : '',
            noDiscountApplies: this.noDiscountApplies
          }
          let check_invoice = await Parse.Cloud.run("generateMonthlyInvoicesBO", params);
          //eslint-disable-next-line
          //console.log(check_invoice)

          if (!check_invoice) {
            this.$snotify.error(`Hubo un problema al generar la factura.` , 'Facturas', {
              timeout: 4000,
              preventDuplicates: true
            });
            this.loading_invoice = false
            this.dialogInvoice = false
            return;
          }

          this.$snotify.info(`Facturas generadas` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.loading_invoice = false
          this.dialogInvoice = false

        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.loading_invoice = false
          this.dialogInvoice = false
        }
      },

      async changeStatusStore(store, confirm=false){
        try {

          if (confirm) {
            //eslint-disable-next-line
            //console.log('Confirmación en progreso...');
            
            if (!this.$refs.form.validate()) {
              this.$snotify.error(`Escriba la ciudad antes de guardar los cambios.` , 'Cambio de estado', {
                timeout: 4000,
                preventDuplicates: true
              });
              return;
            }
            
            this.dialogConfirmChange = false

            let params = {
              id: store.id,
              city: this.cityCheck
            }

            this.loading = true
            await Parse.Cloud.run("activeStoreBO", params);
          
            this.loading = false

            this.$snotify.success(`Se ha activado el comercio ${store.attributes.name}` , 'Activación de comercio', {
              timeout: 4000,
              preventDuplicates: true
            });

            return;
          }

          this.dialogConfirmChange = false

            let params = {
              id: store.id
            }

            this.loading = true
            await Parse.Cloud.run("changeStatusStoreBO", params);
          
            this.loading = false

          this.$snotify.success(`Se ha cambiado el estado del comercio ${store.attributes.name}` , 'Cambio de estado', {
              timeout: 4000,
              preventDuplicates: true
            });

          
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      showDialogConfirmChange(store){
        this.store = store
        this.dialogConfirmChange = true
      },

      editStore(item){
        this.store = item
        this.editedIndex = this.companies.indexOf(item)
        this.editedItem = {
          attributes: {
            name: item.attributes.name,
            city: item.attributes.city,
            phone: item.attributes.phone,
            status: item.attributes.status,
            logoUrl: item.attributes.logoUrl,
            slug: item.attributes.slug,
            phoneSMSAlert: item.attributes.phoneSMSAlert,
            acceptBankTransfer: item.attributes.acceptBankTransfer,
            transfersMethods: JSON.stringify(item.attributes.transfersMethods),
            description: item.attributes.description,
            address: item.attributes.address,
            category: item.attributes.category,
            posEnabled: item.attributes.posEnabled,
            riderService: item.attributes.riderService,
            storeCategory: item.attributes.storeCategory,
            hasCardReader: item.attributes.hasCardReader,
            delivery: JSON.stringify(item.attributes.delivery),
            fee: {
              type: item.attributes.fee ? item.attributes.fee.type : 'porcent',
              value: item.attributes.fee ? item.attributes.fee.value : 0,
              status: item.attributes.fee ? item.attributes.fee.status : false
            },
            subtitle: item.attributes.subtitle,
            minAmount: item.attributes.minAmount,
          }
        }
        this.editStoreDialog = true
      },

      close(){
        this.editStoreDialog = false
        this.attachStoreLogo = '',
        this.attachStoreLogoFile = [],
        setTimeout(() => {
          this.editedItem = {
              attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: '',
                slug: '',
                phoneSMSAlert: '',
                acceptBankTransfer: false,
                transfersMethods: '',
                description: '',
                address: '',
                category: '',
                posEnabled: false,
                riderService: false,
                storeCategory: '',
                hasCardReader: false,
                delivery: '',
                fee: {
                  type: 'porcent',
                  value: 0,
                  status: false
                },
                subtitle: '',
                minAmount: ''
              }
          }
          this.editedIndex = -1
        }, 300)
      },

      goStoreBanners(store) {
        let routeData = this.$router.resolve("/stores/banners/" + store.id);
       window.open(routeData.href, "_blank");
      },
      
      async saveEditStore () {

        if (this.editedItem.attributes.fee && this.editedItem.attributes.fee.status && (!this.editedItem.attributes.fee.type || !this.editedItem.attributes.fee.value)) {
          this.$snotify.error(`Los campos de la comisión son requeridios (Tipo y valor)` , 'Comercio', {
            timeout: 4000,
            preventDuplicates: true
          });
          return
        }
        
        const params = {
            id: this.store.id,
            name: this.editedItem.attributes.name,
            city: this.editedItem.attributes.city,
            phone: this.editedItem.attributes.phone,
            status: this.editedItem.attributes.status,
            logoUrl: this.attachStoreLogoFile ? this.attachStoreLogoFile.length == 0 ? '' : this.attachStoreLogoFile.type ? await this.uploadAttachStoreLogoFile() : '' : this.editedItem.attributes.logoUrl,
            slug: this.editedItem.attributes.slug,
            phoneSMSAlert: this.editedItem.attributes.phoneSMSAlert,
            acceptBankTransfer: this.editedItem.attributes.acceptBankTransfer,
            transfersMethods: this.editedItem.attributes.acceptBankTransfer ? JSON.parse(this.editedItem.attributes.transfersMethods) : '',
            description: this.editedItem.attributes.description,
            address: this.editedItem.attributes.address,
            category: this.editedItem.attributes.category,
            posEnabled: this.editedItem.attributes.posEnabled,
            riderService: this.editedItem.attributes.riderService,
            storeCategory: this.editedItem.attributes.storeCategory ? this.editedItem.attributes.storeCategory.id : '',
            hasCardReader: this.editedItem.attributes.hasCardReader,
            delivery: this.editedItem.attributes.delivery ? JSON.parse(this.editedItem.attributes.delivery) : '',
            fee: this.editedItem.attributes.fee,
            subtitle: this.editedItem.attributes.subtitle,
            minAmount: this.editedItem.attributes.minAmount
        }

        try {
          await Parse.Cloud.run("editStoreBO", params)
          this.initialize()

          this.$snotify.success(`Comercio editado satisfactoriamente` , 'Editar comercio', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercio', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        this.close()
      },

      async uploadAttachStoreLogoFile(){
        let simge = this.attachStoreLogo.split(",");
        simge = simge[1];
        var parseFile = new Parse.File(
          "payment",
          { base64: simge },
          this.attachStoreLogoFile.type
        );
        let file = await parseFile.save(null);
        return file._url
      },

      fileChanged(file) {
        if (file) {
          const fr = new FileReader();
          if (file) {
            fr.readAsDataURL(file);
            fr.addEventListener("load", () => {
              //eslint-disable-next-line
              //console.log(fr.result);
              this.attachStoreLogo = fr.result;
            });
          }
        }
      },

    },
}
</script>