<template>
  <v-container fluid class="myFont">
    <section class="card" v-if="$store.state.statusDelivered">
      <div class="card--content" v-for="(state, i) in $store.state.statusDelivered" :key="i">
        <v-card>
          <v-toolbar :color="state.color" dark>
            <v-btn icon @click="dialogFilter = true"><v-icon>mdi-filter</v-icon></v-btn>
            <v-toolbar-title class="text-capitalize">
              <strong>{{ state.title }} ({{  state.name == 'pre-created' ? $store.state.orders_pre_created.length : state.name == 'created' ? $store.state.orders_created.length : state.name == 'preparing' ? $store.state.orders_preparing.length : state.name == 'delivering' ? $store.state.orders_delivering.length : state.name == 'delivered' ? $store.state.orders_delivered.length : $store.state.orders_nn.length}})</strong>
            </v-toolbar-title>
            <v-spacer></v-spacer>
          </v-toolbar>

          <v-list style="max-height: 69vh;" class="overflow-y-auto">
            <template>
              <v-list-item>
                <v-list-item-content>
                  <v-row dense v-if="$store.state.orders_delivered && state.name == 'delivered'">
                    <v-col cols="12" v-for="(order, j) in $store.state.orders_delivered" :key="j">
                      <v-card
                            class="mx-auto"
                            max-width="345"
                            outlined
                            @click="modalOrderDatail(order)"
                        >
                            <v-progress-linear
                              v-if="order.attributes.discount"
                              color="yellow darken-2"
                              value="100"
                             ></v-progress-linear>
                            <v-list-item>
                            <v-list-item-content>
                                <div class="overline mb-0">
                                  <span class="float-left ml-0 mr-2" style="vertical-align: middle; line-height: 38px">
                                    <v-img class="circle" v-if="order.attributes.store.attributes.logoUrl" :src="order.attributes.store.attributes.logoUrl"></v-img>
                                    <span v-else class="white--text">FT</span>
                                  </span>
                                  <span class="float-left" style="vertical-align: middle;" v-if="order.attributes.store.attributes.city"> <v-chip class="" x-small> {{ order.attributes.store.attributes.city }} </v-chip></span>
                                  <span class="float-left ml-1" style="vertical-align: middle;" v-if="order.attributes.source == 'pos'"><v-chip class="" x-small> POS </v-chip></span>
                                  <span class="float-right text-caption" style="vertical-align: middle; line-height: 38px; font-size: 0.64rem !important;" v-if="datenow">
                                    <v-tooltip bottom>
                                      <template v-slot:activator="{ on }">
                                        <span v-on="on">{{ order.createdAt | moment('from', datenow) }}</span>
                                      </template>
                                      <span>{{ $moment(order.createdAt).format('lll') }}</span>
                                    </v-tooltip>                       
                                  </span>
                                </div>
                                <v-list-item-subtitle class="caption text-wrap text-uppercase" v-if="order.id"> #{{ order.id }} </v-list-item-subtitle>
                                <v-list-item-title class="subtitle-1 font-weight-medium">{{ order.attributes.alias }}</v-list-item-title>
                                <v-list-item-subtitle class="caption text-wrap mb-1" v-if="order.attributes.items"> <v-icon color="info" v-if="checkIfModifiersOrder(order.attributes.items)" style="font-size:16px;">mdi-information</v-icon> {{ getPedidoText(order.attributes.items, true) }}  </v-list-item-subtitle>
                                <v-list-item-subtitle class="font-weight-medium text-wrap">
                                  <span class="float-left" style="vertical-align: middle;"> <v-icon v-if="order.attributes.payment.attributes.method == 'digitalTransfer'" class="blue--text">mdi-bank-transfer</v-icon> <v-icon v-else-if="order.attributes.payment.attributes.method == 'cardReader'" class="green--text">mdi-credit-card-wireless</v-icon> <v-icon v-else-if="order.attributes.payment.attributes.method == 'paymentGateway'" class="green--text">mdi-credit-card</v-icon> <v-icon v-else>mdi-cash-marker</v-icon> TOTAL: {{ order.attributes.total - order.attributes.discount | currency }} </span>
                                  <span class="float-right pr-2" style="vertical-align: middle;" v-if="order.attributes.rating">
                                    <v-rating
                                      :value="order.attributes.rating"
                                      background-color="grey lighten-2"
                                      color="yellow accent-4"
                                      dense
                                      hover
                                      size="18"
                                      readonly
                                    ></v-rating>
                                  </span>
                                  </v-list-item-subtitle>
                                  <v-list-item-subtitle class="font-weight-medium text-wrap" v-if="order.attributes.rider">
                                    <v-icon :color="order.attributes.riderStatus ? order.attributes.riderStatus == 'orderAccepted' ? 'success' : order.attributes.riderStatus == 'delivering' ? 'info' : 'success' : 'grey lighten-1' ">mdi-bike-fast</v-icon> <strong>{{ order.attributes.rider.attributes.name }} - ({{ order.attributes.rider.attributes.phone }})</strong>
                                  </v-list-item-subtitle>
                                  <v-list-item-subtitle class="font-weight-medium text-wrap" v-if="order.attributes.tags && order.attributes.tags.length > 0">
                                    <v-icon>mdi-map-marker-alert</v-icon> <v-chip class="overline mr-1" x-small v-for="(item, index) in order.attributes.tags" :key="index"> {{ item }}</v-chip>
                                </v-list-item-subtitle>
                            </v-list-item-content>

                            </v-list-item>

                            <!--<v-card-actions>
                            <v-btn text>Change status</v-btn>
                            </v-card-actions>-->
                        </v-card>
                    </v-col>

                  </v-row>

                  <v-row dense v-if="$store.state.orders_nn && $store.state.orders_nn != undefined && $store.state.orders_nn.length > 0 && state.name == 'other'">
                    <v-col cols="12" v-for="(order, j) in $store.state.orders_nn" :key="j">
                      <v-card
                            class="mx-auto"
                            max-width="345"
                            outlined
                            @click="modalOrderDatail(order)"

                        >
                            <v-progress-linear
                              v-if="order.attributes.discount"
                              color="yellow darken-2"
                              value="100"
                            ></v-progress-linear>
                            <v-list-item>
                            <v-list-item-content>
                                <div class="overline mb-0">
                                  <span class="float-left ml-0 mr-2" style="vertical-align: middle; line-height: 38px">
                                    <v-img class="circle" v-if="order.attributes.store.attributes.logoUrl" :src="order.attributes.store.attributes.logoUrl"></v-img>
                                    <span v-else class="white--text">FT</span>
                                  </span>
                                  <span class="float-left" style="vertical-align: middle;" v-if="order.attributes.store.attributes.city"> <v-chip class="" x-small> {{ order.attributes.store.attributes.city }} </v-chip></span>
                                  <span class="float-left ml-1" style="vertical-align: middle;" v-if="order.attributes.source == 'pos'"><v-chip class="" x-small> POS </v-chip></span>
                                  <span class="float-right text-caption" style="vertical-align: middle; line-height: 38px; font-size: 0.64rem !important;" v-if="datenow">
                                    <v-tooltip bottom>
                                      <template v-slot:activator="{ on }">
                                        <span v-on="on">{{ order.createdAt | moment('from', datenow) }}</span>
                                      </template>
                                      <span>{{ $moment(order.createdAt).format('lll') }}</span>
                                    </v-tooltip>
                                    
                                
                                  </span>
                                </div>
                                <v-list-item-subtitle class="caption text-wrap text-uppercase" v-if="order.id"> #{{ order.id }} </v-list-item-subtitle>
                                <v-list-item-title class="subtitle-1 font-weight-medium">{{ order.attributes.alias }}</v-list-item-title>
                                <v-list-item-subtitle class="caption text-wrap mb-1" v-if="order.attributes.items"> <v-icon color="info" v-if="checkIfModifiersOrder(order.attributes.items)" style="font-size:16px;">mdi-information</v-icon> {{ getPedidoText(order.attributes.items, true) }}  </v-list-item-subtitle>
                                <v-list-item-subtitle class="font-weight-medium text-wrap"><v-icon v-if="order.attributes.payment.attributes.method == 'digitalTransfer'" class="blue--text">mdi-bank-transfer</v-icon> <v-icon v-else-if="order.attributes.payment.attributes.method == 'cardReader'" class="green--text">mdi-credit-card-wireless</v-icon> <v-icon v-else-if="order.attributes.payment.attributes.method == 'paymentGateway'" class="green--text">mdi-credit-card</v-icon> <v-icon v-else>mdi-cash-marker</v-icon> TOTAL: {{ order.attributes.total - order.attributes.discount | currency }}  </v-list-item-subtitle>
                                <v-list-item-subtitle class="font-weight-medium text-wrap" v-if="order.attributes.rider">
                                  <v-icon :color="order.attributes.riderStatus ? order.attributes.riderStatus == 'orderAccepted' ? 'success' : order.attributes.riderStatus == 'delivering' ? 'info' : 'success' : 'grey lighten-1' ">mdi-bike-fast</v-icon> <strong>{{ order.attributes.rider.attributes.name }} - ({{ order.attributes.rider.attributes.phone }})</strong>
                                </v-list-item-subtitle>
                                <v-list-item-subtitle class="font-weight-medium text-wrap" v-if="order.attributes.tags && order.attributes.tags.length > 0">
                                    <v-icon>mdi-map-marker-alert</v-icon> <v-chip class="overline mr-1" x-small v-for="(item, index) in order.attributes.tags" :key="index"> {{ item }}</v-chip>
                                </v-list-item-subtitle>
                            </v-list-item-content>

                            </v-list-item>

                            <!--<v-card-actions>
                            <v-btn text>Change status</v-btn>
                            </v-card-actions>-->
                        </v-card>
                    </v-col>

                  </v-row>
                  
                </v-list-item-content>
              </v-list-item>
            </template>
          </v-list>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn text>TOTAL: ({{ state.name == 'pre-created' ? $store.state.orders_pre_created.length : state.name == 'created' ? $store.state.orders_created.length : state.name == 'preparing' ? $store.state.orders_preparing.length : state.name == 'delivering' ? $store.state.orders_delivering.length : state.name == 'delivered' ? $store.state.orders_delivered.length : $store.state.orders_nn.length}})</v-btn>
          </v-card-actions>
        </v-card>
      </div>
    </section>
    
    <!-- Dialogo Order Details -->
    <v-dialog
      v-model="modalOrder"
      v-if="order"
      width="600"
      scrollable
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize">{{ order.attributes.alias }}</span> &nbsp; <span class="title ma-1"> (#{{ order.id }}) </span>
          
          <v-spacer></v-spacer>
          
          <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn
                icon
                v-on="on"
              >
                <v-icon >mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="radioGroup = '2', modalCall(order)">
                <v-list-item-title> <v-icon>mdi-phone-forward</v-icon> Llamar al comercio</v-list-item-title>
              </v-list-item>
              <v-list-item @click="radioGroup = '1', modalCall(order)">
                <v-list-item-title> <v-icon>mdi-phone-forward-outline</v-icon> Llamar al cliente</v-list-item-title>
              </v-list-item>
              <v-list-item @click="openPushDialog(order)">
                <v-list-item-title> <v-icon>mdi-bell-ring</v-icon> Enviar Push</v-list-item-title>
              </v-list-item>
              <v-list-item @click="openSmsDialog(order)">
                <v-list-item-title> <v-icon>mdi-message-text</v-icon> Enviar SMS</v-list-item-title>
              </v-list-item>
              <v-list-item @click="openModalEditRider()">
                <v-list-item-title> <v-icon>mdi-bike-fast</v-icon> Asignar domiciliario</v-list-item-title>
              </v-list-item>
              <v-list-item @click="goStore(order)">
                <v-list-item-title> <v-icon>mdi-store</v-icon> Ver comercio</v-list-item-title>
              </v-list-item>
              <v-list-item @click="markAsDelivered(order)">
                <v-list-item-title> <v-icon>mdi-checkbox-marked-circle</v-icon> Marcar como entregada</v-list-item-title>
              </v-list-item>
              <v-list-item @click="cancelOrderModal(order)">
                  <v-list-item-title> <v-icon>mdi-cancel</v-icon> Cancelar orden</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <div class="mb-4" v-if="datenow">{{ $moment(order.createdAt).format('lll') }} - ({{ order.createdAt | moment('from', datenow) }})</div>

          <div class="body-1 text-wrap mb-3 " style="color: black;"> <strong><v-icon>mdi-storefront</v-icon> Tienda:</strong> {{ order.attributes.store.attributes.name }} </div>
          
          <div class="body-1 text-wrap mb-2" style="color: black;">
            <strong><v-icon>mdi-cart</v-icon> Pedido: </strong>
            <div v-for="(item, index) in getPedidoTextDatails(order.attributes.items, false)" :key="index">
              <div class="pl-4 pr-4 pt-1 pb-1">
                  <span class="font-weight-medium">{{ item.name }}</span>
                  <span class="caption">{{ item.modifiers }}</span>
              </div>
            </div>
          </div>
          
          <div class="body-1 text-wrap mb-3 font-weight-medium" style="color: black;" v-if="order.attributes.promoCode"> <strong><v-icon>mdi-tag-multiple-outline</v-icon> Promo:</strong> {{ order.attributes.discount | currency }} - ({{ order.attributes.promoCode.attributes.code }}) </div>
          
          <div class="body-1 text-wrap mb-3 font-weight-medium" style="color: black;"> <strong><v-icon> {{ order.attributes.payment.attributes.method == 'digitalTransfer' ? 'mdi-bank-transfer'  :  order.attributes.payment.attributes.method == 'cardReader' ? 'mdi-credit-card-wireless' : order.attributes.payment.attributes.method == 'paymentGateway' ? 'mdi-credit-card' : 'mdi-cash-marker' }} </v-icon> Total:</strong> {{ order.attributes.total - order.attributes.discount | currency }} <v-icon @click="modalPaymentMethod = true">mdi-magnify</v-icon> </div>

          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.source == 'pos' && order.attributes.comments"> <strong><v-icon>mdi-cellphone-iphone</v-icon> Teléfono:</strong> {{order.attributes.comments}} </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.address"> <strong><v-icon>mdi-map-marker</v-icon> Entregar en:</strong> {{ order.attributes.address.attributes.address }} <strong>{{ order.attributes.address.attributes.name ? ' - [' + order.attributes.address.attributes.name + ']' : '' }}</strong> <v-icon @click="modalEditAdress = true">mdi-file-document-edit-outline</v-icon> </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-else-if="order.attributes.source == 'pos'"> <strong><v-icon>mdi-map-marker</v-icon> Entregar en:</strong> {{ JSON.parse(order.attributes.notes).address }} <v-icon @click="modalEditNotes = true">mdi-file-document-edit-outline</v-icon> </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.rider"> <strong><v-icon :color="order.attributes.riderStatus ? order.attributes.riderStatus == 'orderAccepted' ? 'success' : order.attributes.riderStatus == 'delivering' ? 'info' : 'success' : 'grey lighten-1' ">mdi-bike-fast</v-icon> Domiciliario:</strong> {{ order.attributes.rider.attributes.name }}  - ({{ order.attributes.rider.attributes.phone }}) <v-icon @click="modalSendPushRider = true">mdi-android-messages</v-icon> <v-icon @click="openModalEditRider()">mdi-pencil</v-icon> </div>

          <div class="body-1 text-wrap mb-4 " style="color: black;"> <strong><v-icon>mdi-account-cash</v-icon> Valor del domicilio:</strong> {{ order.attributes.deliveryCost | currency }} </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;"> <strong><v-icon>mdi-note-text</v-icon> Notas:</strong> 
          <span  v-if="order.attributes.notes"> {{ order.attributes.source == 'client' ? order.attributes.notes : order.attributes.source == 'pos' ? JSON.parse(order.attributes.notes).notes : ''}} </span> 
          <v-icon @click="modalEditNotes = true">mdi-file-document-edit-outline</v-icon> </div>

          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.rating"> <strong><v-icon>mdi-star</v-icon> Calificación:</strong> ({{ order.attributes.rating }}) <span v-if="order.attributes.comments">: {{order.attributes.comments}} </span> </div>

          <v-row align="center" justify="center">
            <v-col cols="12" class="pa-0">
               <v-stepper v-model="status_stepper" alt-labels>
                <v-stepper-header>
                <v-stepper-step v-if="order.attributes.status == 'cancelled'" step="S6" :complete="order.attributes.status == 'cancelled' ? true : false" :rules="[() => false]">Cancelado</v-stepper-step>
                <v-divider v-if="order.attributes.status == 'cancelled'"></v-divider>
                
                <v-stepper-step v-if="order.attributes.status == 'pre-created'" step="S5" :complete="order.attributes.status == 'pre-created' ? true : false">Pre-creado</v-stepper-step>
                <v-divider v-if="order.attributes.status == 'pre-created'"></v-divider>
                <v-stepper-step step="S1" :complete="order.attributes.status == 'created' ? true : order.attributes.status == 'preparing' ? true : order.attributes.status == 'delivering' ? true : order.attributes.status == 'delivered' ? true : false" @click="changeStatusOrder(order, 'created')">Creado</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="S2" :complete="order.attributes.status == 'preparing' ? true : order.attributes.status == 'delivering' ? true : order.attributes.status == 'delivered' ? true : false" @click="changeStatusOrder(order, 'preparing')">Preparando</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="S3" :complete="order.attributes.status == 'delivering' ? true : order.attributes.status == 'delivered' ? true : false" @click="changeStatusOrder(order, 'delivering')">En camino</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="S4" :complete="order.attributes.status == 'delivered' ? true : false" @click="changeStatusOrder(order, 'delivered')">Entregado</v-stepper-step>
                </v-stepper-header>
              </v-stepper>
            </v-col>
            <v-col cols="12">
              <GmapMap
                v-if="order.attributes.address && order.attributes.address.attributes.location && order.attributes.store.attributes.location"
                :center="center"
                :zoom="zoom"
                map-type-id="terrain"
                style="width: 100%; height: 200px"
                :options="{
                  zoomControl: true,
                  mapTypeControl: false,
                  scaleControl: true,
                  streetViewControl: false,
                  rotateControl: false,
                  fullscreenControl: false,
                  disableDefaultUi: false
                }"
              >
                <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false"></GmapInfoWindow>

                <GmapMarker
                  :position="{lat: order.attributes.address.attributes.location.latitude, lng: order.attributes.address.attributes.location.longitude}"
                  :clickable="true"
                  :draggable="false"
                  @click="toggleInfoWindow({lat: order.attributes.address.attributes.location.latitude, lng: order.attributes.address.attributes.location.longitude}, `<strong>Cliente:</strong> ${order.attributes.alias}`)"
                />
                <GmapMarker
                  :position="{lat: order.attributes.store.attributes.location.latitude, lng: order.attributes.store.attributes.location.longitude}"
                  :clickable="true"
                  :draggable="false"
                  @click="toggleInfoWindow({lat: order.attributes.store.attributes.location.latitude, lng: order.attributes.store.attributes.location.longitude}, `<strong>Tienda</strong>: ${order.attributes.store.attributes.name}`)"
                  :icon="{ url: require('../assets/market-store.png')}"
                />
              </GmapMap>
            </v-col>
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="modalOrder = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Order Details -->

    <!-- Dialogo Send Push -->
    <v-dialog
      v-model="modalPush"
      v-if="order"
      width="600"
      persistent
      scrollable
    >
    <v-form
      ref="form"
      v-model="valid"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Enviar Push (#{{this.order.id}}) </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="pa-0 ma-0">
             <v-radio-group 
              v-model="radioGroup" 
              row 
              @change="changeDestination()"
              hide-details
              style="padding-left: 10px;">
              <v-radio
                label="Para usuario"
                value="1"
              ></v-radio>
              <v-radio
                label="Para tienda"
                value="2"
              ></v-radio>
            </v-radio-group>
            </v-col>

            <v-col cols="12" class="">
              <v-select
                v-model="template"
                :items="templates"
                label="Plantillas"
                outlined
                item-text="attributes.name"
                item-value="id"
                return-object
                @input="changeTemplate()"
                hide-details
              ></v-select>
            </v-col>

            <v-col cols="10">
              <v-text-field
                outlined
                :value="pushModel.title"
                @change="v => pushModel.title = v"
                :rules="titleRules"
                label="Título"
                placeholder="Escriba el título de la notificación"
                required
                hide-details
              ></v-text-field>
            </v-col>

            <v-col cols="2">
              <v-menu
                v-model="menu_emojis"
                :close-on-content-click="false"
                :nudge-width="200"
                offset-x
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    color="indigo"
                    fab x-small dark
                    v-on="on"
                  >
                  <v-icon>mdi-emoticon-cool-outline</v-icon>
                </v-btn>
                </template>

                <VEmojiPicker
                    v-show="menu_emojis"
                    labelSearch="Search"
                    style="{ width: 4px }"
                    @select="onSelectEmoji"
                  />
                
              </v-menu>

            </v-col>

            <v-col cols="12">
              <v-textarea
                outlined
                :value="pushModel.body"
                @change="v => pushModel.body = v"
                :rules="bodyRules"
                label="Mensaje"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>

             <v-col cols="12">
                <v-radio-group
                  v-model="radioGroupDeployed"
                  row
                  hide-details
                >
                  <v-radio label="Envío inmediato" value="1"></v-radio>
                  <v-radio label="Envío inteligente" value="2"></v-radio>
                </v-radio-group>
                
              </v-col>

              <v-col cols="12">
                <v-text-field
                  outlined
                  :value="app_url"
                  @change="v => app_url = v"
                  :rules="urlRules"
                  label="Link (opcional)"
                  placeholder="Escriba una url válida"
                  required
                  hide-details
                ></v-text-field>
              </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalPush = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="sendPush()"
          >
           <v-icon left>mdi-send</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send Push -->

    <!-- Dialogo Send SMS -->
    <v-dialog
      v-model="modalSms"
      v-if="order"
      width="600"
      persistent
      scrollable
    >
    <v-form
      ref="formsms"
      v-model="validSms"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Enviar SMS (#{{this.order.id}}) </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="pa-0 ma-0">
             <v-radio-group 
              v-model="radioGroup" 
              row 
              @change="changeDestination()"
              hide-details
              style="padding-left: 10px;">
              <v-radio
                label="Para usuario"
                value="1"
              ></v-radio>
              <v-radio
                label="Para tienda"
                value="2"
              ></v-radio>
            </v-radio-group>
            </v-col>

            <v-col cols="12" class="">
              <v-select
                v-model="template"
                :items="templates"
                label="Plantillas"
                outlined
                item-text="attributes.name"
                item-value="id"
                return-object
                @input="changeTemplate()"
                hide-details
              ></v-select>
            </v-col>

            <v-col cols="12">
              <v-textarea
                outlined
                :value="pushModel.body"
                @change="v => pushModel.body = v"
                :rules="bodyRules"
                label="Mensaje"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalSms = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="sendSms()"
          >
           <v-icon left>mdi-send</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send SMS -->

    <!-- Dialogo Filter -->
    <v-dialog
      v-model="dialogFilter"
      width="600"
      persistent
      scrollable
    >
    <v-form
      ref="form"
      v-model="valid"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Filtrar </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="pa-3 ma-2">
              <v-autocomplete
                label="Tiendas"
                :items="templates"
                outlined
                item-text="attributes.name"
                item-value="id"
                return-object
                hide-details
              ></v-autocomplete>
            </v-col>

            <v-col cols="12">
              <v-menu
                ref="menu"
                v-model="menuDatesFilters"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                min-width="290px"
              >
                <template v-slot:activator="{ on }">
                  <v-text-field
                    v-model="dateRangeText"
                    label="Rango de fechas"
                    append-icon="mdi-calendar-search"
                    outlined
                    readonly
                    v-on="on"
                  ></v-text-field>
                </template>

                <v-date-picker v-model="datesFilters" range></v-date-picker>
                
              </v-menu>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="dialogFilter = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="red"
            dark
            outlined
          >
           <v-icon left>mdi-autorenew</v-icon> Borrar filtros
          </v-btn>
          <v-btn
            color="green"
            dark
            outlined
            @click="dialogFilter = false"
          >
           <v-icon left>mdi-filter</v-icon> Filtar
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Filter -->

    <!-- Dialogo cancel order -->
    <v-dialog
      v-model="cancelOrderDialog"
      width="600"
      persistent
      v-if="cancelOrder"
      scrollable
    >
    <v-form
      ref="formCancel"
      v-model="validCancel"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Cancelar orden </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12" class="ma-0">
              <v-checkbox
                class="mt-0"
                v-model="silent_mode"
                label="¿Cancelar silenciosamente?"
                hide-details
              ></v-checkbox>
            </v-col>

            <v-col cols="12" class="pa-3 ma-2">
              <v-autocomplete
                label="Notas"
                v-model="noteCancelOrder"
                :items="notesCancelsOrders"
                outlined
                item-text="description"
                return-object
                hide-details
                required
              ></v-autocomplete>
            </v-col>

            <v-col cols="12" v-if="noteCancelOrder.name == 'otros'">
              <v-textarea
                outlined
                v-model="noteCancelOrderOther"
                label="Mensaje de la nota"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="cancelOrderDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="red"
            dark
            outlined
            @click="cancelOrderConfirm()"
          >
           <v-icon left>mdi-close-circle</v-icon> Cancelar orden
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo cancel order -->

    <!-- Dialogo edit notes of order -->
    <v-dialog
      v-model="modalEditNotes"
      width="600"
      scrollable
    >
    <v-form
      ref="formEditNote"
      v-model="validEditNote"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar nota </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12" v-if="order">
              <v-textarea
                outlined
                :value="order.attributes.notes"
                @change="v => newNoteOrder = v"
                label="Nota"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalEditNotes = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="success"
            dark
            outlined
            @click="editNote(order)"
          >
           <v-icon left>mdi-send</v-icon> Editar nota
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo edit notes of order -->

    <!-- Dialogo edit notes of order -->
    <v-dialog
      v-model="modalEditAdress"
      width="600"
      scrollable
    >
    <v-form
      ref="formEditNote"
      v-model="validEditAdress"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar dirección </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12" v-if="order">
              <v-textarea
                outlined
                v-if="order.attributes.address"
                :value="order.attributes.address.attributes.address"
                @change="v => newAddress = v"
                label="Dirección"
                placeholder="Escriba la dirección"
                hide-details
              ></v-textarea>
            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalEditAdress = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="success"
            dark
            outlined
            @click="editAdress(order)"
          >
           <v-icon left>mdi-send</v-icon> Editar nota
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo edit adress -->

    <!-- Dialogo show payment methods -->
    <v-dialog
      v-model="modalPaymentMethod"
      width="700"
      scrollable
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Método de pago </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12" v-if="order">
             
             <v-timeline dense>

              <v-timeline-item
                left
                color="yellow"
              >
                <v-card class="elevation-2">
                  <v-card-title class="headline">
                    {{ order.attributes.payment.attributes.method }}
                  </v-card-title>
                  <v-card-text> 
                     <p class="pa-0 ma-0">Creado: 
                    <v-tooltip bottom>
                      <template v-slot:activator="{ on }">
                        <span v-on="on"> {{ order.attributes.payment.createdAt  | moment('from', datenow) }} </span>
                      </template>
                          <span> {{ $moment(order.attributes.payment.createdAt ).format('lll') }} </span>
                    </v-tooltip>
                    </p>
                    
                    </v-card-text>
                </v-card>
              </v-timeline-item>

              <v-timeline-item
                left
                v-if="order.attributes.payment.attributes.method == 'digitalTransfer'"
                :color="order.attributes.payment.attributes.attachUrl ? 'green' : 'red'"
              >
                <v-card class="elevation-2">
                  <v-card-title class="headline">
                    <p class="pa-0 ma-0">Comprobante: 
                    <v-tooltip bottom v-if="order.attributes.payment.attributes.attachUrl">
                      <template v-slot:activator="{ on }">
                        <span v-on="on"> {{ order.attributes.payment.updatedAt  | moment('from', datenow) }}</span>
                      </template>
                          <span> {{ $moment(order.attributes.payment.updatedAt ).format('lll') }}</span>
                    </v-tooltip>
                    </p>
                  </v-card-title>
                  <v-card-text v-if="order.attributes.payment.attributes.attachUrl">
                    <v-img :src="order.attributes.payment.attributes.attachUrl" aspect-ratio="0.6" contain></v-img>
                  </v-card-text>
                </v-card>
              </v-timeline-item>

            </v-timeline>

            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="success"
            outlined
            @click="modalPaymentMethodEdit = true"
          >
           <v-icon left>mdi-close</v-icon> Editar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="modalPaymentMethod = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* show payment methods -->

    <!-- Dialogo edit payment methods -->
    <v-dialog
      v-model="modalPaymentMethodEdit"
      width="700"
      scrollable
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar método de pago </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center" v-if="order">

            <v-col cols="12">
              <v-select
                v-model="paymentsType"
                :items="paymentsTypes"
                label="Tipo de pago"
                outlined
                item-text="name"
                item-value="id"
                hide-details
                prepend-icon="mdi-cash"
              ></v-select>
            </v-col>

            <v-col cols="12" v-if="paymentsType == 'digitalTransfer' ">
             <v-file-input
              v-model="attachMethodPaymentFile"
              color="primary accent-4"
              label="Comprobante de pago"
              placeholder="Adjunta el comprobante de pago"
              outlined
              hide-details
              :show-size="1000"
              @change="fileChanged"
            >
              <template v-slot:selection="{ index, text }">
                <v-chip
                  v-if="index < 2"
                  color="primary accent-4"
                  dark
                  label
                  small
                >
                  {{ text }}
                </v-chip>
              </template>
            </v-file-input>
             
            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalPaymentMethodEdit = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="success"
            outlined
            @click="editPaymentMethod(order)"
          >
           <v-icon left>mdi-close</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* edit payment methods -->

    

    <!-- Dialogo Send Push Rider -->
    <v-dialog
      v-model="modalSendPushRider"
      v-if="order && order.attributes.rider"
      width="600"
      persistent
      scrollable
    >
    <v-form
      ref="formRider"
      v-model="validRider"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Enviar Push/SMS Domiciliario (#{{this.order.attributes.rider ? this.order.attributes.rider.id : 'objectId no enviado'}}) </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="pa-0 ma-0">
             <v-radio-group 
              v-model="radioGroupRider" 
              row 
              hide-details
              style="padding-left: 10px;">
              <v-radio
                label="Enviar Push"
                value="1"
              ></v-radio>
              <v-radio
                label="Enviar SMS"
                value="2"
              ></v-radio>
            </v-radio-group>
            </v-col>

            <!--<v-col cols="12" class="">
              <v-select
                v-model="template"
                :items="templates"
                label="Plantillas"
                outlined
                item-text="attributes.name"
                item-value="id"
                return-object
                @input="changeTemplate()"
                hide-details
              ></v-select>
            </v-col>-->

            <v-col cols="10" v-if="radioGroupRider == '1'">
              <v-text-field
                outlined
                :value="pushModel.title"
                @change="v => pushModel.title = v"
                :rules="titleRules"
                label="Título"
                placeholder="Escriba el título de la notificación"
                required
                hide-details
              ></v-text-field>
            </v-col>

            <v-col cols="2" v-if="radioGroupRider == '1'">
              <v-menu
                v-model="menu_emojis"
                :close-on-content-click="false"
                :nudge-width="200"
                offset-x
              >
                <template v-slot:activator="{ on }">
                  <v-btn
                    color="indigo"
                    fab x-small dark
                    v-on="on"
                  >
                  <v-icon>mdi-emoticon-cool-outline</v-icon>
                </v-btn>
                </template>

                <VEmojiPicker
                    v-show="menu_emojis"
                    labelSearch="Search"
                    style="{ width: 4px }"
                    @select="onSelectEmoji"
                  />
                
              </v-menu>

            </v-col>

            <v-col cols="12">
              <v-textarea
                outlined
                :value="pushModel.body"
                @change="v => pushModel.body = v"
                :rules="bodyRules"
                label="Mensaje"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalSendPushRider = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="sendPushRider()"
          >
           <v-icon left>mdi-send</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send Push Rider-->

    <!-- Dialogo Edit Rider -->
    <v-dialog
      v-model="modalEditRider"
      v-if="order"
      width="600"
      persistent
      scrollable
    >
    <v-form
      ref="formRider"
      v-model="validRider"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar Domiciliario (#{{this.order.attributes.rider ? this.order.attributes.rider.id : 'objectId no enviado'}}) </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="pa-0 ma-0">
              <v-switch v-model="offlineRiderCheck" class="ml-3" label="Ver domiciliarios inactivos" @change="openModalEditRider()"></v-switch>
            </v-col>

            <v-col cols="12" class="pa-0 ma-0">
              <v-switch v-model="defaultRiderCheck" class="ml-3 mt-0 pt-0" color="yellow darken-2" label="Ver Festy Riders" @change="openModalEditRider()"></v-switch>
            </v-col>

            <v-col cols="12">
              <v-select
                v-model="ridersSelect"
                :items="ridersItems"
                label="Lista de domiciliarios"
                item-text="attributes.rider.attributes.name"
                item-value="attributes.rider.id"
                outlined
              ></v-select>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalEditRider = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="changeRiderForOrder()"
          >
           <v-icon left>mdi-send</v-icon> Cambiar domiciliario
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send Push Rider-->

    <!-- Dialogo call store or client -->
    <v-dialog
      v-model="modalCallStoreOrClient"
      v-if="order"
      width="500"
      persistent
      scrollable
    >
    <v-form
      ref="formcall"
      v-model="validCall"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Llamar a la tienda / cliente </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12" class="pa-0 ma-0">
             <v-radio-group 
              v-model="radioGroup" 
              row 
              @change="changeDestination()"
              hide-details
              style="padding-left: 10px;">
              <v-radio
                label="Llamar al usuario"
                value="1"
              ></v-radio>
              <v-radio
                label="Llamar a la tienda"
                value="2"
              ></v-radio>
            </v-radio-group>
            </v-col>

            <v-col cols="12" class="" v-if="radioGroup == '2'">
              <div class="body-1 text-wrap mb-1" style="color: black;" v-if="order.attributes.store.attributes.owner.attributes.phone">
                <strong><v-icon>mdi-phone</v-icon> Teléfono:</strong> {{ order.attributes.store.attributes.owner.attributes.phone }}
                <v-btn
                  color="info"
                  dark
                  outlined
                  @click="pushModel.cellphone = order.attributes.store.attributes.owner.attributes.phone"
                  small
                >
                  <v-icon left>mdi-phone-in-talk</v-icon> Llamar
                </v-btn>
              </div>
              <div class="body-1 text-wrap mb-1 " style="color: black;" v-if="order.attributes.store.attributes.phoneSMSAlert">
                <strong><v-icon>mdi-message-alert</v-icon> Teléfono SMS:</strong> {{ order.attributes.store.attributes.phoneSMSAlert }}
                <v-btn
                  color="info"
                  dark
                  outlined
                  @click="pushModel.cellphone = order.attributes.store.attributes.phoneSMSAlert"
                  small
                >
                  <v-icon left>mdi-phone-in-talk</v-icon> Llamar
                </v-btn>
              </div>
            </v-col>

            <v-col cols="12" class="" v-if="radioGroup == '1'">
              <div class="body-1 text-wrap mb-1" style="color: black;" v-if="order.attributes.owner.attributes.phone||order.attributes.comments">
                <strong><v-icon>mdi-phone</v-icon> Teléfono:</strong> {{ order.attributes.source == 'pos' ? order.attributes.comments : order.attributes.owner.attributes.phone }}
                <v-btn
                  color="info"
                  dark
                  outlined
                  @click="pushModel.cellphone = order.attributes.source == 'pos' ? order.attributes.comments : order.attributes.owner.attributes.phone"
                  small
                >
                  <v-icon left>mdi-phone-in-talk</v-icon> Llamar
                </v-btn>
              </div>
            </v-col>

            <v-col cols="12" class="" v-if="pushModel.cellphone">
              <v-select
                v-model="template"
                :items="templates"
                label="Plantillas"
                outlined
                item-text="attributes.name"
                item-value="id"
                return-object
                @input="changeTemplate()"
                hide-details
              ></v-select>
            </v-col>

            <v-col cols="12" v-if="pushModel.cellphone">
              <v-text-field
                outlined
                :value="pushModel.cellphone"
                @change="v => pushModel.cellphone = v"
                :rules="titleRules"
                label="Teléfono"
                placeholder="Escriba el teléfono de la notificación"
                required
                hide-details
                disabled
              ></v-text-field>
            </v-col>

            <v-col cols="12" v-if="pushModel.cellphone">
              <v-textarea
                outlined
                :value="pushModel.body"
                @change="v => pushModel.body = v"
                :rules="bodyRules"
                label="Mensaje"
                placeholder="Escriba el mensaje"
                hide-details
              ></v-textarea>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="modalCallStoreOrClient = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="sendCall()"
            :disabled="pushModel.cellphone ? false : true"
          >
           <v-icon left>mdi-send</v-icon> Enviar
          </v-btn>
        </v-card-actions>
      </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Call store or client-->

  </v-container>
</template>

<script>
import Parse from "parse";
import VEmojiPicker from 'v-emoji-picker';

export default {

  components: {
    VEmojiPicker
  },

  data() {
    return {
      datenow: '',
      order: '',
      modalOrder: false,
      modalPush: false,
      menu_emojis: false,
      valid: true,
      validCancel: false,
      validEditNote: false,
      validRider: false,
      radioGroup: '2',
      radioGroupRider: '1',
      templates: [],
      template: '',
      pushModel: {
        title: '',
        body: '',
        cellphone: ''
      },
      status_stepper: 0,
      
      infoWindowPos: null,
      infoWinOpen: false,
      infoOptions: {
        content: '',
        //optional: offset infowindow so it visually sits nicely on top of our marker
        pixelOffset: {
          width: 0,
          height: -35
        }
      },
      zoom: 0,
      center: 0,

      titleRules: [
        v => !!v || 'Título es requerido'
      ],
      bodyRules: [
        v => !!v || 'Mensaje es requerido'
      ],
      urlRules: [v => !!this.validURL(v) || "Url no es válida"],
      dialogFilter: false,
      menuDatesFilters: false,
      datesFilters: [],
      cancelOrderDialog: false,
      cancelOrder: '',
      noteCancelOrder: '',
      noteCancelOrderOther: '',
      notesCancelsOrders: [
        {
          id: 1,
          name: 'Fuera de horario',
          description: 'Pedido hecho fuera de horarios de atención.'
        },
        {
          id: 2,
          name: 'No hay domiciliario',
          description: 'No hay domiciliario'
        },
        {
          id: 3,
          name: 'Error de pedido',
          description: 'Pedido realizado por error'
        },
        {
          id: 4,
          name: 'Atención sin cobertura',
          description: 'Aliado no atiende en dirección destino'
        },

        {
          id: 5,
          name: 'Problemas con el negocio',
          description: 'Negocio no puede realizar pedido'
        },
        {
          id: 6,
          name: 'otros',
          description: 'Otros'
        }
      ],
      modalSms: false,
      validSms: true,
      modalEditNotes: false,
      modalPaymentMethod: false,
      modalSendPushRider: false,
      newNoteOrder: '',
      modalEditAdress: false,
      validEditAdress: false,
      newAdress: '',
      app_url: '',
      radioGroupDeployed: '1',
      modalEditRider: false,
      offlineRiderCheck: false,
      defaultRiderCheck: false,
      ridersSelect: '',
      ridersItems: [],
      silent_mode: false,
      modalPaymentMethodEdit: false,
      attachMethodPayment: '',
      attachMethodPaymentFile: [],
      paymentsType: '',
      paymentsTypes: [
        {
          id: 'OnDelivery',
          name: 'Efectivo'
        },
        {
          id: 'digitalTransfer',
          name: 'Transferencia bancaria'
        }
      ],
      modalCallStoreOrClient: false,
      validCall: true
    };
  },

  computed: {
    dateRangeText () {
      return this.datesFilters.join(' - ')
    },
  },

  mounted() {      
      //this.liveQueryConnection();
      this.$store.dispatch('getStoreOrders')
      this.interval = setInterval(this.time, 1000);
  },

  destroyed() {
    clearInterval(this.interval)
    //Parse.LiveQuery.close();
  },
  
  methods: {

    time() {
				this.datenow = this.$moment()
			},

    liveQueryConnection() {
      let clientRequest = new Parse.LiveQueryClient({
        applicationId: process.env.VUE_APP_PARSE_SERVER_APPLICATION_ID,
        serverURL: process.env.VUE_APP_SERVER_URL_LIVE_QUERY,
        javascriptKey: process.env.VUE_APP_JS_KEY
      });

      clientRequest.open();

      let query = new Parse.Query("OrderUpdate");
      //query.equalTo("status", 'active');
      //query.descending("createdAt");
      //query.include('assistant');

      let subscription = clientRequest.subscribe(query);

      subscription.on('open', () => {
         //eslint-disable-next-line
        console.log('connection opened');
      });

      subscription.on('close', () => {
         //eslint-disable-next-line
        console.log('connection closed');
      });

      subscription.on('error', (error) => {
         //eslint-disable-next-line
        console.log(error);
      });

      subscription.on("create", async order => {
        //eslint-disable-next-line
        console.log('create ' + order.attributes.object);

        if (order.attributes.object) {
          let params = {
            id: order.attributes.object
          }

          let order_current = await Parse.Cloud.run("getOrderBO", params);
          this.removeOrderOfCards(order_current.id)

          switch (order_current.attributes.status) {
             case 'pre-created':
              this.$store.commit('addOrdersPreCreated', order_current)
              break;
            case 'created':
              this.$store.commit('addOrdersCreated', order_current)
              break;
            case 'preparing':
              this.$store.commit('addOrdersPreparing', order_current)
              break;
            case 'delivering':
              this.$store.commit('addOrdersDelivering', order_current)
              break;
            case 'delivered':
              this.$store.commit('addOrdersDelivered', order_current)
              break;
            default:
              this.$store.commit('addOrdersNn', order_current)
              break;
          }

          switch (order.attributes.update_type) {
            case 'rider_added': return;
            case 'rider_edited': return;
            case 'note_edited': return;
            case 'address_edited': return;
            case 'paymentEdit': return;
            case 'removeRider': return;
            default: break;
          }
         
          if (order_current.attributes.status === 'created' && order.attributes.update_type != 'orderAccepted') {
            this.play_new_order()
            this.$store.commit('removeLastElementOfOrdersDelivered')
          }else if(order_current.attributes.status === 'pre-created' && order.attributes.update_type != 'orderAccepted'){
            this.play_new_order()
            //this.play_alert_change_status()
          }

          if (order_current.attributes.status === 'preparing' && this.checkIfOrderNeedRider(order_current)) {
            this.play_new_order()
          }

          this.$snotify.info(`${order_current.attributes.status == 'created' ? `Nuevo pedido #${order_current.id}` : `Pedido #${order_current.id} se ha marcado como ${this.traslateStatus(order_current.attributes.status)}` }` , 'Orden', {
            timeout: 4000,
            preventDuplicates: true,
            buttons: [
              {
                text: 'Ver orden',
                action: () => this.modalOrderDatail(order_current),
                className: 'white--text font-weight-bold'
              }
						]
          });
          
        }

      });

      subscription.on("delete", async order => {
        //eslint-disable-next-line
        console.log('delete ' + order.id);
      });

      subscription.on("update", async order => {
        //eslint-disable-next-line
        console.log('updated ' + order.id);
      });
    },

    duplicateObject(){
        //eslint-disable-next-line
        console.log("Entro");
        this.$store.commit('setOrdersDelivered', [])
        //this.$store.state.orders_delivering = []
    },

    modalOrderDatail(order){
      this.order = order
      this.infoWinOpen = false
      this.zoom = 14
      this.center = {lat: order.attributes.address ? order.attributes.address.attributes.location.latitude : '', lng:  order.attributes.address ? order.attributes.store.attributes.location.longitude : ''}
      this.modalOrder = true
    },

    toggleInfoWindow(position, infoText) {
      this.infoWindowPos = position;
      this.infoOptions.content = infoText;
      this.infoWinOpen = !this.infoWinOpen;
    },

    modalCall(order){
      this.order = order
      this.changeDestination()
      this.modalCallStoreOrClient = true
      //this.$swal(`Contacto ${type == 'client' ? 'del cliente' : 'de la tienda' }`, type == 'client' ? `Teléfono: ${order.attributes.owner.attributes.phone}` :  `Teléfono SMS: ${order.attributes.store.attributes.phoneSMSAlert ? order.attributes.store.attributes.phoneSMSAlert : 'No suministrado.'} \n\n Teléfono principal: ${order.attributes.store.attributes.owner.attributes.phone ? order.attributes.store.attributes.owner.attributes.phone : 'No suministrado.'}`, "info")
    },

    openPushDialog(order){
      this.order = order
      this.changeDestination()
      this.modalPush = true
    },

    openSmsDialog(order){
      this.order = order
      this.changeDestination()
      this.modalSms = true
    },

    async changeDestination(){
      //eslint-disable-next-line
      //console.log('Cambio');
      
      this.template = ''
      this.pushModel.title = ''
      this.pushModel.cellphone = ''
      this.pushModel.body =  ''

      let params = {
        destination: this.radioGroup == '1' ? 'user': 'store'
      }
      let templates = await Parse.Cloud.run("getPushTemplates", params);
      this.templates = templates
    },

    changeTemplate(){
      //eslint-disable-next-line
      //console.log(this.template);
      if (this.template) {
        this.pushModel.title = this.template.attributes.title
        this.pushModel.body =  this.template.attributes.body
      }else{
        this.$snotify.error(`Seleccione una plantilla` , 'Plantilla', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async sendPush(){
      
      if (this.$refs.form.validate()) {

        try {
          let params = ''

          if (this.radioGroup == '1') {
               
            params = {
              title: this.pushModel.title,
              message: this.pushModel.body,
              recipient: this.order.attributes.owner.id,

              app_url: this.app_url ? this.app_url : '',
              delayed_option: this.radioGroupDeployed == '2' ? 'last-active' : ''
            }

            await Parse.Cloud.run("notifyUserBO", params);
                
          }else if(this.radioGroup == '2'){

           params = {
            title: this.pushModel.title,
            message: this.pushModel.body,
            recipient: this.order.attributes.store.attributes.owner.id,
            store_id: this.order.attributes.store.id,

            app_url: this.app_url ? this.app_url : '',  
            delayed_option: this.radioGroupDeployed == '2' ? 'last-active' : ''
           }

            await Parse.Cloud.run("notifyStoreBO", params);
         }
          
          this.$snotify.success(`Se ha enviado el push` , 'Envío push', {
                timeout: 4000,
                preventDuplicates: true
            });

          this.modalPush = false
              
        } catch (error) {
          this.$snotify.error(`${error}` , 'Notificación', {
            timeout: 4000,
            preventDuplicates: true
          });
        }

      }else{
        this.$snotify.error(`Compruebe todo los campos antes de enviar el formulario` , 'Notificación', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async sendPushRider(){
      
      if (this.$refs.formRider.validate()) {

        try {
          let params = ''
          //eslint-disable-next-line
          debugger;
          if (this.radioGroupRider == '1') {
               
            params = {
              title: this.pushModel.title,
              message: this.pushModel.body,
              recipient: this.order.attributes.rider.id
            }

            await Parse.Cloud.run("notifyRiderBO", params);
                
          }else if(this.radioGroup == '2'){

            params = {
              phone: this.order.attributes.rider.attributes.phone,
              message: this.pushModel.body
            }
            await Parse.Cloud.run("sendSMS", params);
         }
          
          this.$snotify.success(`Se ha enviado el push/SMS` , 'Envío push/SMS', {
                timeout: 4000,
                preventDuplicates: true
            });

          this.modalSendPushRider = false
              
        } catch (error) {
          this.$snotify.error(`${error}` , 'Notificación', {
            timeout: 4000,
            preventDuplicates: true
          });
        }

      }else{
        this.$snotify.error(`Compruebe todo los campos antes de enviar el formulario` , 'Notificación', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    onSelectEmoji(dataEmoji) {      
      this.pushModel.title += dataEmoji.data;
    },

    removeOrderOfCards(objectId){
       let index0 = this.$store.state.orders_pre_created.findIndex(function(order) {
        return order.id == objectId
      });

      let index1 = this.$store.state.orders_created.findIndex(function(order) {
        return order.id == objectId
      });

      let index2 = this.$store.state.orders_preparing.findIndex(function(order) {
        return order.id == objectId
      });

      let index3 = this.$store.state.orders_delivering.findIndex(function(order) {
        return order.id == objectId
      });

      let index4 = this.$store.state.orders_delivered.findIndex(function(order) {
          return order.id == objectId
      });

      let index5 = this.$store.state.orders_nn.findIndex(function(order) {
        return order.id == objectId
      });
      if (index0 >= 0) {
        this.$store.state.orders_pre_created.splice(index0, 1);
      }else if (index1 >= 0) {
        this.$store.state.orders_created.splice(index1, 1);
      }  else if (index2 >= 0) {
        this.$store.state.orders_preparing.splice(index2, 1);
      } else if (index3 >= 0) {
        this.$store.state.orders_delivering.splice(index3, 1);
      } else if (index4 >= 0) {
        this.$store.state.orders_delivered.splice(index4, 1);
      } else if (index5 >= 0) {
        this.$store.state.orders_nn.splice(index5, 1);
      }
    },
    
    /* Método para reproducir sonido */
		play_new_order(){
			document.getElementById("alert_change_status").play();
    },

    play_alert_change_status(){
			document.getElementById("alert_change_status").play();
    },
    

    cancelOrderModal(order){
      //this.play_alert_change_status()
      //eslint-disable-next-line
      console.log(order);
      this.cancelOrder = order
      this.noteCancelOrderOther = ''
      this.cancelOrderDialog = true
    },

    markAsDelivered(order){
      this.$swal({
            title: "Cambio de status (entregado)",
            text: "¿Estás seguro de que deseas cambiar el estado de la orden?",
            icon: "warning",
            buttons: ["NO cancelar", 'Cambiar status'],
            dangerMode: true,
          })
          .then(async (willDelivered) => {
            if (willDelivered) {
              try {
               
               let params = {
                  id: order.id,
                }
                
                await Parse.Cloud.run("markAsDeliveredBO", params)
                
                /*this.$snotify.success(`La orden #${order.id} fue modificada satisfactoriamente.` , 'Orden entregada', {
                  timeout: 4000,
                  preventDuplicates: true
                });*/
              
              } catch (error) {
                this.$snotify.error(`${error.message}` , 'Notificación', {
                  timeout: 4000,
                  preventDuplicates: true
                });
              }

            } else {
              //this.cancelOrderDialog = false
              //this.$swal("Orden no cancelada", 'la orden no se canceló', 'info');
            }
          });
    },

    cancelOrderConfirm(){
      //eslint-disable-next-line
      //console.log(this.cancelOrder.id);
      
      if (this.cancelOrder.id && this.noteCancelOrder.description) {

          let description = this.noteCancelOrder.name == 'otros' ? this.noteCancelOrderOther : this.noteCancelOrder.description;

          this.$swal({
            title: "Cancelar orden",
            text: "¿Estás seguro de que deseas cancelar orden?",
            icon: "warning",
            buttons: ["NO cancelar", 'Proceder a cancelar'],
            dangerMode: true,
          })
          .then(async (willDelete) => {
            if (willDelete) {
              try {
               
               let params = {
                  id: this.cancelOrder.id,
                  notes: description,
                  silent_mode: this.silent_mode
                }
                
                await Parse.Cloud.run("cancelOrderBO", params)

                this.cancelOrderDialog = false
                
                /*this.$snotify.success(`Se ha cancelado la orden #${this.cancelOrder.id}` , 'Orden cancelada', {
                  timeout: 4000,
                  preventDuplicates: true
                });*/
              
              } catch (error) {
                this.$snotify.error(`${error.message}` , 'Notificación', {
                  timeout: 4000,
                  preventDuplicates: true
                });
              }

            } else {
              this.cancelOrderDialog = false
              //this.$swal("Orden no cancelada", 'la orden no se canceló', 'info');
            }
          });
      }else{
        this.$snotify.error(`Compruebe todo los campos antes de enviar el formulario` , 'Cancelar orden', {
            timeout: 4000,
            preventDuplicates: true
          });
      }

    },

    traslateStatus(status){
      switch (status) {
        case 'pre-created':
          return 'Pendiente por transferencia';

        case 'created':
          return 'Creado';

        case 'preparing':
          return 'Preparando';

        case 'delivering':
          return 'En camino';

        case 'delivered':
          return 'Entregado';
      
        default:
          return 'Cancelado';
      }
    },

    goStore(order){
      if (order.attributes.store.id) {
        this.$router.push('/store-info/' + order.attributes.store.id)
      }else{
        this.$snotify.error(`La orden no posee un comercio.` , 'Ver comercio', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async sendSms(){

      if (this.$refs.formsms.validate()) {

        try {
          let params = ''
          let phone_order_owner = ''
          if (this.radioGroup == '1') {
               
            if (this.order.attributes.source == 'pos') {
               phone_order_owner = this.order.attributes.comments
            }else{
              phone_order_owner = this.order.attributes.owner.attributes.phone
            }

            params = {
              phone: phone_order_owner,
              message: this.pushModel.body
            };
                
          }else if(this.radioGroup == '2'){

           params = {
            phone: this.order.attributes.store.attributes.phoneSMSAlert ? this.order.attributes.store.attributes.phoneSMSAlert : this.order.attributes.store.attributes.owner.attributes.phone,
            message: this.pushModel.body
           }

         }

          await Parse.Cloud.run("sendSMS", params);
          
          this.$snotify.success(`Se ha enviado el SMS` , 'Envío SMS', {
                timeout: 4000,
                preventDuplicates: true
            });

          this.modalSms = false
              
        } catch (error) {
          this.$snotify.error(`${error}` , 'SMS', {
            timeout: 4000,
            preventDuplicates: true
          });
        }

      }else{
        this.$snotify.error(`Compruebe todo los campos antes de enviar el formulario` , 'SMS', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async sendCall(){

      if (this.$refs.formcall.validate()) {

        if (!this.pushModel.cellphone) {
          this.$snotify.error(`No se ha enviado el teléfono` , 'Llamada', {
            timeout: 4000,
            preventDuplicates: true
          });
        }

        try {
          let params = {
            phone: `57${this.pushModel.cellphone}`,
            message: this.pushModel.body
          };

          await Parse.Cloud.run("sendCall", params);
          
          this.$snotify.success(`Llamada enviada correctamente` , 'Envío Llamada', {
                timeout: 4000,
                preventDuplicates: true
            });

          this.modalCallStoreOrClient = false
              
        } catch (error) {
          this.$snotify.error(`${error}` , 'Llamada', {
            timeout: 4000,
            preventDuplicates: true
          });
        }

      }else{
        this.$snotify.error(`Compruebe todo los campos antes de enviar el formulario` , 'Llamada', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async editNote(order){
      if (this.newNoteOrder) {
        try {
               
          let params = {
            id: order.id,
            note: this.newNoteOrder
          }
                
          await Parse.Cloud.run("editNoteOrderBO", params)

          this.modalEditNotes = false
                
          this.$snotify.success(`Orden editada satisfactoriamente` , 'Editar nota', {
            timeout: 4000,
            preventDuplicates: true
          });
              
          } catch (error) {
              this.$snotify.error(`${error.message}` , 'Editar nota', {
              timeout: 4000,
              preventDuplicates: true
            });
          }
      } else {
        this.$snotify.error(`La nota esta vacia.` , 'Editar nota', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    async editAdress(order){
      if (this.newAddress) {
        try {
               
          let params = {
            id: order.id,
            address: this.newAddress
          }
                
          await Parse.Cloud.run("editAdressOrderBO", params)

          this.modalEditAdress = false
                
          this.$snotify.success(`Dirección editada satisfactoriamente` , 'Editar dirección', {
            timeout: 4000,
            preventDuplicates: true
          });
              
          } catch (error) {
              this.$snotify.error(`${error.message}` , 'Editar dirección', {
                timeout: 4000,
                preventDuplicates: true
              });
          }
      } else {
        this.$snotify.error(`La dirección esta vacia.` , 'Editar dirección', {
            timeout: 4000,
            preventDuplicates: true
          });
      }
    },

    getPedidoText(items, slice_text){
      let pedido_text = ''
      let pedido_text_temp = ''
      if (items) {
        items.forEach((item, index) => {
          pedido_text += `(${item.attributes.quantity}) - ${item.attributes.name} - (${this.$options.filters.currency(item.attributes.price)} c/u) ${item.attributes.comboOption ? ' + (' + this.$options.filters.currency(item.attributes.comboPrice) + ')' : ''}`
          if (index+1 < items.length) {            
            pedido_text += ', '
          }
        });

        pedido_text_temp = pedido_text

        if (slice_text) {
          pedido_text_temp = pedido_text.substring(0, 150)
          if (pedido_text.length > 150) {
            pedido_text_temp += '....'
          }
        }

        return pedido_text_temp
      }
    },

    getPedidoTextDatails(items, slice_text){
      let pedido_array = []
      if (items) {
        items.forEach((item, index) => {
          pedido_array.push({
            name: `(${item.attributes.quantity}) - ${item.attributes.name} - (${this.$options.filters.currency(item.attributes.price)} c/u) ${item.attributes.comboOption ? ' + (' + this.$options.filters.currency(item.attributes.comboPrice) + ')' : ''}`,
            modifiers: item.attributes.modifiers ? item.attributes.modifiers.length > 0 ? this.modifiersDetails(item.attributes.modifiers, slice_text) : '' : '',
            end: index+1 < items.length ? false : true
          })
        });
        return pedido_array
      }
    },

    modifiersDetails(modifiers, slice_text){
      let pedido_text = ''
      let pedido_text_temp = ''
      modifiers.forEach((item, indx) => {
        if (item.options) {
          item.options.forEach((option, index) => {
            pedido_text += `${option.label} ${option.price ? option.price > 0 ? '+'+this.$options.filters.currency(option.price) : '' : ''}`
            if (index+1 < item.options.length) {            
              pedido_text += ' | '
            }
          })

          if (indx+1 < modifiers.length) {            
              pedido_text += ' | '
            }
        }
      })

      pedido_text_temp = pedido_text

      if (slice_text) {
        pedido_text_temp = pedido_text.substring(0, 150)
        if (pedido_text.length > 150) {
          pedido_text_temp += '....'
        }
      }

      return pedido_text_temp
    },

    polygonCheck(point, vs) {
      // ray-casting algorithm based on
      // http://www.ecse.rpi.edu/Homepages/wrf/Research/Short_Notes/pnpoly.html
      
      var x = point[0], y = point[1];
      
      var inside = false;
      for (var i = 0, j = vs.length - 1; i < vs.length; j = i++) {
          var xi = vs[i][0], yi = vs[i][1];
          var xj = vs[j][0], yj = vs[j][1];
          
          var intersect = ((yi > y) != (yj > y))
              && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
          if (intersect) inside = !inside;
      }
      
      return inside;
    },

    validURL(str) {
      if (str) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
          '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
          '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
          '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
          '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
          '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
          return !!pattern.test(str);
      }
      return true;
    },
    
    async openModalEditRider(){
      try {

        let params = {
            id: this.order.attributes.store.id,
            offiline: this.offlineRiderCheck ? this.offlineRiderCheck : '',
            defaultRider: this.defaultRiderCheck ? this.defaultRiderCheck : ''
          }
                
          let riders = await Parse.Cloud.run("getRidersByStoreBO", params)
          this.ridersItems = riders

          this.ridersItems.unshift({
            attributes: {
              rider: {
                id: 'removeRider',
                attributes: {
                  name: 'Sin domiciliario'
                }
              }
            }
          })

          this.modalEditRider = true
        
      } catch (error) {
        this.$snotify.error(`${error.message}` , 'Editar domiciliario', {
            timeout: 4000,
            preventDuplicates: true
        });
      }


    },

    async changeRiderForOrder(){

      try {

        if (!this.ridersSelect) {
           this.$snotify.error(`Debe seleccionar una opcion para asignar o quitar el domiciliario.` , 'Asignar domiciliario', {
              timeout: 4000,
              preventDuplicates: true
          });
          return;
        }

        if (this.ridersSelect === 'removeRider') {
          if (this.order.attributes.rider && this.order.attributes.rider.id) {
            let params = {
              id: this.order.id
            }

            await Parse.Cloud.run("removeRiderToOrderBO", params)

            this.modalEditRider = false

            this.$snotify.info(`La orden ha quedado sin domiciliario.` , 'Asignar domiciliario', {
              timeout: 4000,
              preventDuplicates: true
            });
            location.reload();
            return;
          } else {
            this.$snotify.error(`La orden no tiene asignado un domiciliario.` , 'Asignar domiciliario', {
              timeout: 4000,
              preventDuplicates: true
            });
            return;
          }
        }

        let params = {
            id: this.order.id,
            rider_id: this.ridersSelect
          }

          await Parse.Cloud.run("assingRiderToOrderBO", params)

           this.modalEditRider = false

           this.$snotify.success(`Domiciliario reasignado existosamente` , 'Asignar domiciliario', {
            timeout: 4000,
            preventDuplicates: true
          });

      } catch (error) {
        this.$snotify.error(`${error.message}` , 'Asignar domiciliario', {
            timeout: 4000,
            preventDuplicates: true
        });
      }
    },

    async changeStatusOrder(order, status){

        if (order.attributes.status === status) {
          this.$snotify.info(`La orden ya esta asignada al estado ${status}` , 'Cambio de estado', {
            timeout: 4000,
            preventDuplicates: true
          });
          return;
        }

        this.$swal({
            title: "Modificar estado",
            text: `¿Estás seguro que deseas modificar el estado de la orden? \n\n Actual: ${this.traslateStatus(order.attributes.status)}, Modificación: ${this.traslateStatus(status)}`,
            icon: "info",
            buttons: ["Cancelar", 'Cambiar estado'],
            dangerMode: true,
          })
          .then(async (willDelete) => {
            if (willDelete) {
              try {
               
               let params = {
                  id: order.id,
                  status: status
                }

                await Parse.Cloud.run("updateOrderBO", params)
                this.modalOrder = false

              } catch (error) {
                this.$snotify.error(`${error.message}` , 'Notificación', {
                  timeout: 4000,
                  preventDuplicates: true
                });
              }

            } else {
              //this.modalOrder = false
              //this.$swal("Orden no cancelada", 'la orden no se canceló', 'info');
            }
        });
    },

    checkIfOrderNeedRider(order){
      if (order.attributes.source == 'pos') {
        let json = JSON.parse(order.attributes.notes)
        return json.requestRider
      }
      return false
    },

    async editPaymentMethod(order){

      if (!order.attributes.payment.id || !order.id || !this.paymentsType) {
        this.$snotify.error(`Los datos ingresados no son correctos` , 'Editar método de pago', {
            timeout: 4000,
            preventDuplicates: true
        });
        return;
      }

      this.$swal({
            title: "Editar método de pago",
            text: "¿Estás seguro que deseas editar el método de pago? \n\n Recuerde que si existe un comprobante adjunto, este será remplazado o eliminado.",
            icon: "warning",
            buttons: ["Cancelar", 'Editar'],
            dangerMode: true,
          })
          .then(async (willDelivered) => {
            if (willDelivered) {
              try {
               
               let params = {
                  id: order.attributes.payment.id,
                  order_id: order.id,
                  paymentsType: this.paymentsType,
                  attachMethodPayment: this.attachMethodPaymentFile ? this.attachMethodPaymentFile.length == 0 ? '' : this.attachMethodPaymentFile.type ? await this.uploadAttachPaymentMethod() : '' : ''
                }

                await Parse.Cloud.run("editPaymentMethodBO", params)
                this.modalPaymentMethodEdit = false
                
                this.paymentsType = ''
                this.attachMethodPaymentFile = []
                this.attachMethodPayment = ''

                this.$snotify.success(`Editado satisfactoriamente` , 'Método de pago', {
                  timeout: 4000,
                  preventDuplicates: true
                });
              
              } catch (error) {
               this.$snotify.error(`${error.message}` , 'Método de pago', {
                  timeout: 4000,
                  preventDuplicates: true
                });
              }

            } else {
              //this.cancelOrderDialog = false
              //this.$swal("Orden no cancelada", 'la orden no se canceló', 'info');
            }
          });
    },

    async uploadAttachPaymentMethod(){
      let simge = this.attachMethodPayment.split(",");
      simge = simge[1];
      var parseFile = new Parse.File(
        "payment",
        { base64: simge },
        this.attachMethodPaymentFile.type
      );
      let file = await parseFile.save(null);
      return file._url
    },

    fileChanged(file) {
			if (file) {
        const fr = new FileReader();
        if (file) {
          fr.readAsDataURL(file);
          fr.addEventListener("load", () => {
            //eslint-disable-next-line
            //console.log(fr.result);
            this.attachMethodPayment = fr.result;
          });
        }
      }
    },
    
    checkIfModifiersOrder(items){
      if (items) {
        //eslint-disable-next-line
        //console.log(items);
        let isModifier = false
        items.forEach((item) => { 
          if(item.attributes.modifiers && item.attributes.modifiers.length > 0){
            isModifier = true
          }
        })
        return isModifier
      }
      return false
    }
  }
};
</script>

<style lang="css" scope>

.card {
  display: flex;
  min-width: 100%;
  overflow: auto;
  padding-bottom: 10px;
}

/*.card::-webkit-scrollbar {
  display: none;
}*/

.card--content {
  min-width: 390px;
  max-width: 390px;
  margin: 5px;
  padding: 5px;
}

.circle {
	width: 38px;
	height: 38px;
	background: teal;
	-moz-border-radius: 50px;
	-webkit-border-radius: 50px;
	border-radius: 50px;
  border: 1px solid black;
}
</style>