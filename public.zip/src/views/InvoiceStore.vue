<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="900"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="companie"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Mi Comercio</v-toolbar-title>

        <v-spacer></v-spacer>
        
        <v-btn icon>
          <v-icon>mdi-magnify</v-icon>
        </v-btn>

        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>
      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

          <v-card
            class="mx-auto mb-5"
            max-width="100%"
            outlined
        >
            <v-list-item three-line>
            <v-list-item-content>
                <div class="overline mb-4">
                  <v-chip
                    v-if="companie.attributes.status === 'active'"
                    :color="`success`"
                    class="ml-0"
                    text-color="white"
                    label
                    small
                  >
                  <v-avatar left>
                        <v-icon>mdi-lock-open-outline</v-icon>
                    </v-avatar>
                    ABIERTO
                  </v-chip>

                <v-chip v-else text-color="black" class="ml-0" label small>
                     <v-avatar left>
                        <v-icon>mdi-lock-outline</v-icon>
                    </v-avatar>
                      CERRADO
                </v-chip>
                </div>
                <v-list-item-title class="headline mb-1">{{ companie.attributes.name }} </v-list-item-title>
                <v-list-item-subtitle class="mb-2"> 
                  <v-chip
                    class="text-center justify-center black--text"
                    :color="companie.attributes.plan.attributes.hexColor ? companie.attributes.plan.attributes.hexColor : 'success'"
                    small
                    outlined
                    v-if="companie.attributes.plan"
                  >
                    {{companie.attributes.plan.attributes.display_name}}
                  </v-chip>

                  <v-chip
                    class="text-center justify-center black--text"
                    small
                    outlined
                    v-else
                  >
                    No asignado
                  </v-chip>
              </v-list-item-subtitle>
              <v-list-item-subtitle v-if="companie.attributes.plan" style="display: block;">{{ companie.attributes.plan.attributes.description }}</v-list-item-subtitle>
            </v-list-item-content>

            <v-list-item-avatar
                size="80"
                color="teal"
            >
                <v-img v-if="companie.attributes.logoUrl" :src="companie.attributes.logoUrl"></v-img>
                <span v-else class="white--text">FT</span>
            </v-list-item-avatar>
            </v-list-item>

            <v-card-actions>
            
            </v-card-actions>
        </v-card>


        <v-data-table
            :loading="loading_invoices"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="invoices"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <v-toolbar-title>FACTURAS</v-toolbar-title>
                <v-spacer></v-spacer>
                <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
            </v-toolbar>
            </template>
            
            <template v-slot:item.attributes.logoUrl="{ item }">
              <v-avatar
                  size="36px"
                  color="teal"
                >
                  <img
                    v-if="item.attributes.logoUrl"
                    alt="Avatar"
                    :src="item.attributes.logoUrl"
                  >
                  <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.startDate="{ item }">
                {{$moment(item.attributes.startDate).format('ll')}}
            </template>

            <template v-slot:item.attributes.endDate="{ item }">
                {{$moment(item.attributes.endDate).format('ll')}}
            </template>

            <template v-slot:item.attributes.discount="{ item }">
                {{ !item.attributes.noDiscountApplies ? item.attributes.discount : 0 | currency }}
            </template>

            <template v-slot:item.attributes.subTotal="{ item }">
                {{ item.attributes.subTotal | currency }}
            </template>

            <template v-slot:item.attributes.total="{ item }">
                {{ item.attributes.total | currency }}
            </template>

            <template v-slot:item.attributes.status="{ item }">
                <v-chip
                    :color="item.attributes.status == 'paid' ? 'success' : 'warning' "
                    class="ml-0"
                    label
                    small
                >
                    {{ item.attributes.status == 'paid' ? 'PAGADA' : item.attributes.status == 'created' ? 'SIN PAGAR' : item.attributes.status.toUpperCase() }}
                </v-chip>
            </template>
            <template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="dialogEditInvoice(item)"
            >
                mdi-pencil
            </v-icon>
            <v-icon
                class="mr-2"
                @click="goInvoicePayments(item)"
            >
                mdi-credit-card
            </v-icon>
            <v-icon
                @click="goInvoice(item)"
            >
                mdi-file-chart
            </v-icon>
            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  <!-- Dialogo PDF -->
    <v-dialog
      v-model="dialogPdf"
      width="800"
      persistent
      scrollable
      eager
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Factura en PDF </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">
            
            <v-col cols="12" class="">
               <iframe id="pdf" width="100%" height="500" :src="iframe" frameborder="0" allowfullscreen></iframe>
            </v-col>

          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="dialogPdf = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo PDF -->

    <!-- Dialogo Edit Invoice -->
    <v-dialog
      v-model="editInvoiceDialog"
      width="400"
      scrollable
      eager
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Editar Factura </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>

          <v-row>
            <v-col cols="12" class="pb-0">
               <v-select
                v-model="statusInvoice"
                :items="invoicesStatus"
                label="Estado de la factura"
                outlined
                item-text="name"
                item-value="id"
                hide-details
              ></v-select>
            </v-col>

            <v-col cols="12" class="pb-0">
              <v-file-input
                v-model="attachMethodPaymentFile"
                color="primary accent-4"
                label="Comprobante de pago"
                placeholder="Clic aquí para adjuntar"
                outlined
                prepend-icon
                prepend-inner-icon="mdi-paperclip"
                hide-details
                :show-size="1000"
                @change="fileChanged"
              >
                <template v-slot:selection="{ index, text }">
                  <v-chip
                    v-if="index < 2"
                    color="primary accent-4"
                    dark
                    label
                    small
                  >
                    {{ text }}
                  </v-chip>
                </template>
              </v-file-input>
            </v-col>

            <v-col cols="12" class="pb-0">
              <v-textarea
                v-model="comments"
                outlined
                name="input-7-4"
                hide-details
                label="Comentarios"
                value=""
                auto-grow
                rows="1"
              ></v-textarea>
            </v-col>

          </v-row>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="editInvoiceDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="success"
            outlined
            @click="editInvoiceStatus()"
          >
           <v-icon left>mdi-send</v-icon> Editar
          </v-btn>
          
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Invoice -->

  </v-container>
</template>

<script>
import Parse from 'parse'
import fs from 'fs'
import Helvetica from '!!raw-loader!pdfkit/js/data/Helvetica.afm'
// use raw-loader explicitly
import Courier from '!!raw-loader!pdfkit/js/data/Courier.afm'
// use raw-loader implicitly (webpack is configured to load *.afm files using raw loader)
import CourierBold from 'pdfkit/js/data/Courier-Bold.afm'
//eslint-disable-next-line
var ace = require('brace');
require('brace/mode/javascript');
require('brace/theme/monokai');

export default {
    data() {
        return {
            companie: {
                attributes: {
                name: '',
                city: '',
                phone: '',
                status: '',
                logoUrl: ''
              }
            },
            loading: true,
            loading_invoices: true,
            search: '',
            headers: [
              //{ text: 'Comercio', align: 'left', value: 'attributes.store' },
              { text: 'Fecha de inicio', align: 'left', value: 'attributes.startDate' },
              { text: 'Fecha de corte', align: 'left', value: 'attributes.endDate' },
              { text: 'Subtotal', align: 'left', value: 'attributes.subTotal' },
              { text: 'Descuento',align: 'left',  value: 'attributes.discount' },
              { text: 'Total', align: 'left', value: 'attributes.total' },
              //{ text: 'Método', align: 'left', value: 'attributes.payment' },
              { text: 'Estado', align: 'left', value: 'attributes.status' },
              { text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
              "items-per-page-options": [50, 60, 70, 100, -1]
            },
            invoices: [],
            invoice: {
                attributes: {
                    store: {},
                    discount: 0,
                    subTotal: 0,
                    total: 0,
                    payment: 0,
                    endDate: '',
                    startDate: '',
                    status: ''
                }
            },
           dialogPdf: false,
           iframe: '',
           editInvoiceDialog: false,
           statusInvoice: '',
           invoicesStatus: [
             {
               id: 'created',
               name: 'SIN PAGAR'
             },
             {
               id: 'paid',
               name: 'PAGADA'
             },
           ],
           comments: '',
           attachMethodPaymentFile: [],
           attachMethodPayment: ''
        }
    },

    mounted() {
        this.initialize();

        fs.writeFileSync('data/Helvetica.afm', Helvetica)
        fs.writeFileSync('data/Courier.afm', Courier)
        fs.writeFileSync('data/Courier-Bold.afm', CourierBold)
        this.registerBinaryFiles(require.context('../assets/festy', true))
    },

    methods: {
        async initialize(){
            
            const params = {
                id: this.$route.params.store_id
            }

            try {
            let companie = await Parse.Cloud.run("getStoreBO", params);
            this.companie = companie
            //eslint-disable-next-line
            //console.log(this.companie);
            this.loading = false

            this.getIncoives(this.companie)
            
            } catch (error) {
                this.$swal({
                    title: "Comercio",
                    text: "Algo salío mal consultado el comercio.",
                    icon: "warning",
                    buttons: ['Salir', 'Entiendo'],
                    dangerMode: true,
                    })
                    .then((ok) => {
                    if (ok) {
                        this.$router.push('/stores')
                    }else{
                        this.$router.push('/stores')
                    }
                });
            }
            
        },

        async getIncoives(store){
            const params = {
                id: store.id
            }

            try {
            let invoces = await Parse.Cloud.run("getInvocesBO", params);
            this.invoices = invoces
            //eslint-disable-next-line
            //console.log(this.invoices);
            this.loading_invoices = false
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Facturas', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        generateInvocePdf(item){
            this.dialogPdf = true
            
            var PDFDocument = require('pdfkit').default;
            var blobStream = require('blob-stream');
            
            var doc = new PDFDocument();
            var stream = doc.pipe(blobStream());

           doc
            .image('logo-festy.PNG', 50, 45, { width: 70 })
            .fillColor("#444444")
            .fontSize(10)
            .text("Un festival de promociones todo el año!.", 200, 65, { align: "right" })
            .text("festtytech@gmail.com", 200, 80, { align: "right" })
            .moveDown();

            /**
            store
            discount
            subTotal
            total
            payment
            endDate
            startDate
            status
             */

            doc
            .text(`Factura ID: ${item.id}`, 50, 130)
            .text(`Total: ${this.$options.filters.currency(item.attributes.total)}`, 50, 200)
            .text(`Fecha: ${this.$moment(item.createdAt).format('lll')}`, 50, 215)
            .moveDown();

            // end and display the document in the iframe to the right
            var iframe = document.getElementById("pdf")

            doc.info['Title'] = `factura_${item.id}`;
            doc.info['Subject'] = `Factura generada por festy.`;
            doc.info['Author'] = `Festy`;
            doc.end();
            stream.on('finish', function() {
               iframe.src = stream.toBlobURL('application/pdf');
            });
        },

        registerBinaryFiles(ctx) {
            ctx.keys().forEach(key => {
                // extracts "./" from beginning of the key
                fs.writeFileSync(key.substring(2), ctx(key))
            });  
        },

        sendInvoice(invoice){
            this.$snotify.info(`Muy pronto habilitaremos esta opción, contacte a soporte para más información. ${invoice.id}` , 'Facturas', {
              timeout: 4000,
              preventDuplicates: true
            });
        },

        goInvoice(invoice){
          this.$router.push('/invoice/' + invoice.id)
        },

        goInvoicePayments(invoice){
          this.$router.push('/invoice-payments/' + invoice.id)
        },

        dialogEditInvoice(invoice){
          this.invoice = invoice
          this.editInvoiceDialog = true
        },

        async editInvoiceStatus(){
          if (!this.statusInvoice || !this.comments) {
            this.$snotify.info(`Debes seleccionar el estado y escribir un comentario` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });
            return;
          }

          if (this.attachMethodPaymentFile && this.attachMethodPaymentFile.length > 0 && this.attachMethodPaymentFile.type) {
            switch (this.attachMethodPaymentFile.type) {
              case 'image/png':
                  break;
              case 'image/jpeg':
                  break;
              case 'image/jpg':
                  break;
              default:
                  this.$snotify.info(`El archivo adjunto tiene un formato no válido ${this.attachMethodPaymentFile.type}` , 'Formato', {
                      timeout: 6000,
                      preventDuplicates: true
                  });
                  return;
            }
          }
          
          let params = {
            id : this.invoice.id,
            status: this.statusInvoice,
            comments: this.comments,
            attachUrl: this.attachMethodPaymentFile ? this.attachMethodPaymentFile.length == 0 ? '' : this.attachMethodPaymentFile.type ? await this.uploadAttachPaymentMethod() : '' : ''
          }

          try {
            await Parse.Cloud.run("editStatusInvoiceBO", params);
            
            this.statusInvoice = ''
            this.comments = ''
            this.editInvoiceDialog = false
            this.attachMethodPaymentFile = []
            this.attachMethodPayment = ''

            this.initialize();

            this.$snotify.success(`Factura editada correctamente.` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });   
                  
          } catch (error) {
            this.$snotify.error(`${error}` , 'Editar factura', {
              timeout: 4000,
              preventDuplicates: true
            });
          }
          
        },

      async uploadAttachPaymentMethod(){
        let simge = this.attachMethodPayment.split(",");
        simge = simge[1];
        var parseFile = new Parse.File(
          "paymentInvoice",
          { base64: simge },
          this.attachMethodPaymentFile.type
        );
        let file = await parseFile.save(null);
        return file._url
      },

      fileChanged(file) {
      if (file) {
          const fr = new FileReader();
          if (file) {
            fr.readAsDataURL(file);
            fr.addEventListener("load", () => {
              //eslint-disable-next-line
              //console.log(fr.result);
              this.attachMethodPayment = fr.result;
            });
          }
        }
      },
        
    },
}
</script>