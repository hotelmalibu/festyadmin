<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1400"
      style="margin-top: -64px;"
    >

      <v-toolbar flat>
        <v-toolbar-title class="black--text">Productos</v-toolbar-title>

        <v-spacer></v-spacer>

        <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
        ></v-text-field>

        <v-btn
            class="mr-1 ml-2 d-print-none"
            color="black"
            dark
            @click="massiveProductDialog = true"
            target="_blank"
          >
            <v-icon left>mdi-database-import</v-icon>Importar productos
          
        </v-btn>
          
        <v-btn class="mr-1"
          color="black"
          dark
          @click.stop="showAddProductModal()"
        >
          <v-icon left>mdi-plus</v-icon> Nuevo producto
        </v-btn>

        <v-btn class="mr-1"
          color="black"
          dark
          :to="`/products/discount/${$route.params.store_id}`"
          target="_blank"
        >
          <v-icon left>mdi-sale</v-icon> Ver decuentos
        </v-btn>  

        <!--<v-btn icon>
          <v-icon>mdi-magnify</v-icon>
        </v-btn>

        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>-->
        
      </v-toolbar>

      <v-divider></v-divider>
            
      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="products"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
        >
            <template v-slot:top>
              <v-toolbar flat color="white">
              </v-toolbar>
            </template>

            <template v-slot:item.attributes.name="{ item }">
              {{ item.attributes.name }} <v-chip v-if="item.attributes.status == 'deleted'" color="error" x-small>ELIMINADO</v-chip>
            </template>
            
            <template v-slot:item.attributes.imageUrl="{ item }">
              <v-avatar
                  size="36px"
                  color="teal"
                >
                  <img
                    v-if="item.attributes.imageUrl"
                    alt="Avatar"
                    :src="item.attributes.imageUrl"
                  >
                  <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                v-if="item.attributes.status == 'deleted'"
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="deleted"
                color="error"
                inset
                @click.native="changeStatusProduct(item)"
              ></v-switch>
              <v-switch
                v-else
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="active"
                color="success"
                inset
                @click.native="changeStatusProduct(item)"
              ></v-switch>
            </template>

            <template v-slot:item.attributes.featured="{ item }">
              <v-switch
                :input-value="item.attributes.featured"
                color="primary"
                inset
                @click.native="changeFectureProduct(item)"
              ></v-switch>
            </template>
            
            <template v-slot:item.attributes.price="{ item }">
                {{ item.attributes.price | currency }}
            </template>

            <template v-slot:item.attributes.newPrice="{ item }">
                {{ item.attributes.newPrice | currency }}
            </template>

            <template v-slot:item.attributes.deliveryCost="{ item }">
                {{ item.attributes.deliveryCost | currency }}
            </template>

            <template v-slot:item.attributes.comboOption="{ item }">
                <v-icon v-if="item.attributes.comboOption">mdi-check</v-icon>
            </template>

            <template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="detailProduct(item)"
            >
                mdi-eye
            </v-icon>

             <v-icon
                class="mr-2"
                @click="editProduct(item)"
            >
                mdi-pencil
            </v-icon>

            <v-icon
                class="mr-2"
                @click="copyUrlPromo(item)"
            >
                mdi-content-copy
            </v-icon>

            <a :href="item.attributes.imageUrl" download style="text-decoration:none" target="_blank">
                 <v-icon
                    class="mr-2"
                >
                    mdi-image-move
                </v-icon>
            </a>


            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">Reset</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

    <!-- Dialogo Detail product -->
    <v-dialog
      v-model="detailProductDialog"
      width="450"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{store.attributes.name}}  </span>
          <v-spacer></v-spacer>
          <span class="text-capitalize"> 
            <v-icon>mdi-thumb-up-outline</v-icon> {{ store.attributes.likes }}
          </span>
        </v-card-title>
        <v-img
          max-height="210"
          v-if="store.attributes.imageUrl"
          :src="store.attributes.imageUrl"
          
        ></v-img>

        <v-card-text>
            <v-row dense>
                <v-col cols="6">
                    <div class="pt-2 black--text">
                        <v-icon>mdi-bookmark-multiple</v-icon>
                        {{ store.attributes.superCategory }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 black--text">
                        <v-icon>mdi-bookmark-multiple-outline</v-icon>
                        {{ store.attributes.category }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-cash-usd</v-icon>
                        Precio: {{ store.attributes.price | currency }}
                    </div>
                </v-col>
                <v-col cols="6">
                     <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-cash-multiple</v-icon>
                        En Combo: {{ store.attributes.comboPrice | currency }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-file-eye-outline</v-icon>
                        Vistas: {{ store.attributes.views }}
                    </div>
                </v-col>
                <v-col cols="6">
                    <div class="pt-2 pb-2 black--text">
                        <v-icon>mdi-moped</v-icon>
                        Ordenes: {{ store.attributes.orders }}
                    </div>
                </v-col>
            </v-row>

          <v-divider class=""></v-divider>

          <div class="pt-2 black--text">
            {{store.attributes.description}}
          </div>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="detailProductDialog = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Detail product -->
  
  <!-- Dialogo Edit product -->
    <v-dialog
      v-model="editProductDialog"
      width="600"
      v-if="store"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Editar producto </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

         <v-img
          max-height="210"
          v-if="store.attributes.imageUrl"
          :src="store.attributes.imageUrl"
          
        ></v-img>

        <v-card-text>
          <v-divider class="mb-2"></v-divider>
            <v-row dense>
                <v-col cols="12">
                  <!-- editedItem.attributes.imageUrl -->
                  <v-file-input
                    v-model="attachProductImgFile"
                    color="primary accent-4"
                    label="Imagen"
                    placeholder="Adjunta la imagen del producto"
                    outlined
                    hide-details
                    :show-size="1000"
                    @change="fileChanged"
                    prepend-icon
                    prepend-inner-icon="mdi-image"
                  >
                    <template v-slot:selection="{ index, text }">
                      <v-chip
                        v-if="index < 2"
                        color="primary accent-4"
                        dark
                        label
                        small
                      >
                        {{ text }}
                      </v-chip>
                    </template>
                  </v-file-input>
                </v-col>
                <v-col cols="12" md="6">
                    <v-text-field
                      v-model="editedItem.attributes.name"
                      outlined
                      label="Nombre"
                      prepend-inner-icon="mdi-package-variant"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                      v-model="editedItem.attributes.superCategory"
                      outlined
                      label="Supercategoría"
                      prepend-inner-icon="mdi-tag-plus"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                   <v-text-field
                      v-model="editedItem.attributes.category"
                      outlined
                      label="Categoría"
                      prepend-inner-icon="mdi-tag"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" md="6">
                    <!-- <v-text-field
                      v-model="editedItem.attributes.subCategory"
                      outlined
                      label="Subcategoría"
                      prepend-inner-icon="mdi-tag-multiple"
                      hide-details
                    ></v-text-field>-->
                    <v-select
                      v-model="editedItem.attributes.productCategory"
                      :items="productCategories"
                      label="Nueva Categoría"
                      item-text="attributes.name"
                      return-object
                      outlined
                      hide-details
                      prepend-inner-icon="mdi-tag-arrow-up"
                    ></v-select>
                </v-col>
                <v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.price"
                      outlined
                      label="Precio"
                      prepend-inner-icon="mdi-cash-usd"
                      prefix="$"
                      hide-details
                    ></v-text-field>
                </v-col>
                 <v-col cols="12" md="6">
                     <v-text-field
                     v-model="editedItem.attributes.deliveryCost"
                      outlined
                      label="Valor del domicilio"
                      prepend-inner-icon="mdi-bike-fast"
                      prefix="$"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12">
                    <v-textarea
                      v-model="editedItem.attributes.description"
                      outlined
                      name="input-7-4"
                      label="Descripción"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>
                <v-col cols="12">
                    <v-textarea
                      v-model="editedItem.attributes.modifiers"
                      outlined
                      name="input-7-4"
                      label="Modificadores"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>
                <v-col cols="12" class="mb-2">
                    <v-switch v-model="editedItem.attributes.exclusive" inset color="success" :label="`¿Es un producto exclusivo?`" hide-details></v-switch>
                </v-col>
                <v-col cols="12" class="mb-2">
                    <v-switch v-model="editedItem.attributes.comboOption" inset color="success" :label="`¿Es un producto en combo?`" hide-details></v-switch>
                </v-col>
                <v-col cols="12" v-if="editedItem.attributes.comboOption">
                    <v-text-field
                     v-model="editedItem.attributes.comboPrice"
                      outlined
                      label="Precio del combo"
                      prepend-inner-icon="mdi-food"
                      prefix="$"
                      hide-details
                    ></v-text-field>
                </v-col>
                <v-col cols="12" v-if="editedItem.attributes.comboOption">
                    <v-textarea
                      v-model="editedItem.attributes.comboNotes"
                      outlined
                      name="input-7-4"
                      label="Notas del combo"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>
            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
           <v-btn
            color="success"
            outlined
            @click="saveEditProduct(store)"
          >
           <v-icon left>mdi-content-save-outline</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Product -->

    <!-- Dialogo load product massive -->
    <v-dialog
      v-model="massiveProductDialog"
      width="1200"
      v-if="store"
      scrollable
      persistent
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Importar productos CSV </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
            <v-row dense>
                <v-col cols="12">
                  <vue-csv-import
                    v-model="csv"
                    url="#"
                    :map-fields="['sku', 'name', 'description', 'price', 'deliveryCost', 'imageUrl', 'max', 'superCategory', 'subCategory', 'category', 'productCategory', 'featured', 'comboOption', 'comboNotes', 'status']"
                    tableClass="v-data-table theme--light"
                    tableSelectClass="v-input__control h100 display-select"
                    :headers="true"
                    :autoMatchFields="true"
                    :fileMimeTypes="['text/csv']"
                  >

                    <template slot="error">
                       <p class="red--text"><strong>El tipo de archivo es invalido. </strong></p>
                    </template>
                    
                    <template slot="thead">
                        <tr style="border: 1px solid black;">
                            <th style="border: 1px solid black;">Columnas del sistema</th>
                            <th style="border: 1px solid black;">Columnas del archivo CSV</th>
                        </tr>
                    </template>

                    <template slot="next" slot-scope="{load}">
                      <v-btn
                        class="mt-5 mb-5 white--text"
                        color="black"
                        @click.prevent="load"
                      >
                      <v-icon class="mr-1">mdi-cloud-upload</v-icon>
                       Cargar archivo CSV
                      </v-btn>
                      <v-icon>mdi-numeric-1-circle-outline</v-icon>

                    <p class="mt-3 mb-3"> <strong> En la siguiente tabla, compruebe que las columnas de su archivo CSV estén en concordancia con las columnas de la base de datos. </strong></p>
                    
                    </template>

                    <template slot="submit" slot-scope="{submit}">
                        <v-btn
                          class="mt-5 mb-5 white--text"
                          color="black"
                          @click.prevent="submit"
                        >
                        <v-icon class="mr-1">mdi-table-eye</v-icon>
                          Mostrar tabla de datos
                        </v-btn>
                        <v-icon>mdi-numeric-2-circle-outline</v-icon>
                    </template>
                </vue-csv-import>
                </v-col>

                <v-col cols="12" v-if="csv.length > 0"> 
                  <v-data-table
                    :headers="headersCsv"
                    :items="csv"
                    :footer-props="pagination"
                    class="elevation-1"
                  >
                    
                    <template v-slot:no-data>
                    <v-btn color="primary" @click="initialize">Reset</v-btn>
                    </template>
                </v-data-table>
                </v-col>
                
            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-icon>mdi-numeric-3-circle-outline</v-icon>
           <v-btn
            color="success"
            outlined
            @click="imporProducts()"
          >
           <v-icon left>mdi-database-import</v-icon> Importar productos
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Edit Product -->

    <!-- MODAL ADD PRODUCT -->
    <v-dialog v-model="showAddProduct"
      width="900"
      persistent
    >
      <v-card>
        <v-toolbar color="transparent">

          <v-btn icon
                 color="black"
                 @click="closeModalAddProduct()"
          >
            <v-icon>mdi-close</v-icon>
          </v-btn>

          <v-toolbar-title>Agregar Nuevo Producto</v-toolbar-title>
        </v-toolbar>

        <product-form :merchant-id="$route.params.store_id"
                      v-on:product:saved="closeModalAddProduct()"
                      v-on:product:canceled="closeModalAddProduct()"
                      :newCategories="productCategories"
        />
      </v-card>
    </v-dialog>

  </v-container>
</template>

<script>
import Parse from 'parse'
import { VueCsvImport } from 'vue-csv-import';
import ProductForm from "@/components/ProductForm"

export default {
  
  components:{
    VueCsvImport,
    ProductForm
  },
  
  data() {
        return {
            month_invoice: '',
            loading_invoice: false,
            valid: false,
            store: {
              attributes: {
                name: '',
                superCategory: '',
                category: '',
                subCategory: '',
                productCategory: '',
                price: '',
                deliveryCost: '',
                status: '',
                imageUrl: '',
                comboOption: false,
                comboPrice: 0,
                comboNotes: '',
                description: '',
                modifiers: ''
              }
            },
            detailProductDialog: false,
            search: '',
            loading: true,
            dialog: false,
            headers: [
              { text: 'Imagen', align: 'left', value: 'attributes.imageUrl', sortable: false },
              { text: 'Nombre', align: 'left', value: 'attributes.name' },
              { text: 'Super categoría', value: 'attributes.superCategory' },
              { text: 'Categoría', value: 'attributes.category' },
              //{ text: 'Subcategoría', value: 'attributes.subCategory' },
              { text: 'Nueva Categoría', value: 'attributes.productCategory.attributes.name' },
              { text: 'Precio', value: 'attributes.price' },
              { text: 'Rebajado', value: 'attributes.newPrice' },
              { text: '$ Envío', value: 'attributes.deliveryCost' },
              { text: 'Ordenes', value: 'attributes.orders' },
              { text: 'Vistas', value: 'attributes.views' },
              { text: 'Destacado', value: 'attributes.featured' },
              { text: 'Estado', value: 'attributes.status' },
              { text: 'Combo', value: 'attributes.comboOption' },
              { text: 'Acciones', value: 'action', sortable: false },
            ],
            headersCsv: [
              { text: 'sku', align: 'left', value: 'sku', sortable: false },
              { text: 'Nombre', align: 'left', value: 'name', sortable: false },
              { text: 'Descripción', value: 'description', sortable: false },
              { text: 'SuperCategoría', value: 'superCategory', sortable: false },
              { text: 'Categoría', value: 'category', sortable: false },
              { text: 'subcategoría', value: 'subCategory', sortable: false },
              { text: 'Nueva Categoría', value: 'productCategory', sortable: false },
              { text: 'Precio', value: 'price', sortable: false },
              { text: '$Envío', value: 'deliveryCost', sortable: false },
              { text: 'Combo', value: 'comboOption', sortable: false },
              { text: 'Notas', value: 'comboNotes', sortable: false },
              { text: 'Destacado', value: 'featured', sortable: false },
              { text: 'Imagen', value: 'imageUrl', sortable: false },
              { text: 'Estado', value: 'status', sortable: false },
            ],
            pagination: {
              'items-per-page-options' : [20, 30, 50, 100, -1]
            },
            products: [],
            editedIndex: -1,
            editedItem: {
              attributes: {
                name: '',
                superCategory: '',
                category: '',
                subCategory: '',
                productCategory: '',
                price: '',
                deliveryCost: '',
                status: '',
                imageUrl: '',
                comboOption: false,
                comboPrice: 0,
                comboNotes: '',
                description: '',
                modifiers: '',
                exclusive: false
              }
            },
            defaultItem: {
              attributes: {
                name: '',
                superCategory: '',
                category: '',
                subCategory: '',
                productCategory: '',
                price: '',
                deliveryCost: '',
                status: '',
                imageUrl: '',
                comboOption: false,
                comboPrice: 0,
                comboNotes: '',
                description: '',
                modifiers: ''
              }
            },
            editProductDialog: false,
            massiveProductDialog: false,
            csv: [],
            isHeaders: true,
            attachProductImg: '',
            attachProductImgFile: [],
            productCategories: [],
            showAddProduct: false
        }
    },
    computed: {
      formTitle () {
        return this.editedIndex === -1 ? 'Nuevo Comercio' : 'Editar Comercio'
      },
    },

    watch: {
      dialog (val) {
        val || this.close()
      },
    },

    created () {
      this.initialize()
      this.getCategories()
    },

    methods: {
      async initialize () {
          const params = {
              id: this.$route.params.store_id
          }
        try {
          let products = await Parse.Cloud.run("getProductsBO", params);
          this.products = products
          //eslint-disable-next-line
          //console.log(this.products);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      async getCategories () {
          const params = {
              id: this.$route.params.store_id
          }
        try {
          let productCategories = await Parse.Cloud.run("getCategoriesBO", params);
          this.productCategories = productCategories
          //eslint-disable-next-line
          //console.log(this.products);
          this.loading = false
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Categorías', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        
      },

      editProduct (item) {
        this.store = item
        this.editedIndex = this.products.indexOf(item)
        this.editedItem = {
          attributes: {
            name: item.attributes.name, 
            superCategory: item.attributes.superCategory,
            category: item.attributes.category,
            subCategory: item.attributes.subCategory,
            productCategory: item.attributes.productCategory,
            price: item.attributes.price,
            deliveryCost: item.attributes.deliveryCost,
            imageUrl: item.attributes.imageUrl,
            comboOption: item.attributes.comboOption,
            comboPrice: item.attributes.comboPrice,
            comboNotes: item.attributes.comboNotes,
            description: item.attributes.description,
            modifiers: JSON.stringify(item.attributes.modifiers),
            exclusive: item.attributes.exclusive
          }
        }
        this.editProductDialog = true
      },

      deleteItem (item) {
        const index = this.products.indexOf(item)
        confirm('Are you sure you want to delete this item?') && this.products.splice(index, 1)
      },

      close () {
        this.editProductDialog = false
        this.massiveProductDialog = false
        this.attachProductImg = '',
        this.attachProductImgFile = [],
        setTimeout(() => {
          this.editedItem = {
              attributes: {
                name: '',
                superCategory: '',
                category: '',
                subCategory: '',
                productCategory: '',
                price: '',
                deliveryCost: '',
                status: '',
                imageUrl: '',
                comboOption: false,
                comboPrice: 0,
                comboNotes: '',
                description: '',
                modifiers: '',
                exclusive: false
              }
          }
          this.editedIndex = -1
        }, 300)
      },

      async saveEditProduct (item) {

        if (this.editedItem.attributes.comboOption && (!this.editedItem.attributes.comboPrice || !this.editedItem.attributes.comboNotes)) {
          this.$snotify.error(`El precio del combo o las notas del combo son campos requeridos` , 'Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
          return;
        }
        //eslint-disable-next-line
        //console.log(this.editedItem.attributes.modifiers);
        const params = {
            id: item.id,
            name: this.editedItem.attributes.name, 
            superCategory: this.editedItem.attributes.superCategory,
            category: this.editedItem.attributes.category,
            subCategory: this.editedItem.attributes.subCategory,
            productCategory: this.editedItem.attributes.productCategory ? this.editedItem.attributes.productCategory.id : '',
            price: Number(this.editedItem.attributes.price),
            deliveryCost: Number(this.editedItem.attributes.deliveryCost),
            imageUrl: this.attachProductImgFile ? this.attachProductImgFile.length == 0 ? '' : this.attachProductImgFile.type ? await this.uploadAttachProductImgFile() : '' : this.editedItem.attributes.imageUrl,
            comboOption: this.editedItem.attributes.comboOption,
            comboPrice: Number(this.editedItem.attributes.comboPrice),
            comboNotes: this.editedItem.attributes.comboNotes,
            description: this.editedItem.attributes.description,
            modifiers: this.editedItem.attributes.modifiers ? JSON.parse(this.editedItem.attributes.modifiers): '',
            exclusive: this.editedItem.attributes.exclusive
        }

        try {
          await Parse.Cloud.run("editProductBO", params)
          this.initialize()

          this.$snotify.success(`Producto editado satisfactoriamente` , 'Editar producto', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
        this.close()
      },

      detailProduct(store){
        this.store = store
        this.detailProductDialog = true
      },

      goProducts(store){
        this.$router.push('/products/' + store.id)
      },

      async changeStatusProduct(store){
        try {
          let params = {
            id: store.id
          }

          this.loading = true
          await Parse.Cloud.run("changeStatusProduct", params);
        
          this.loading = false

          this.$snotify.success(`Se ha cambiado el estado del producto ${store.attributes.name}` , 'Cambio de estado', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      async changeFectureProduct(store){
        try {
          let params = {
            id: store.id
          }

          this.loading = true
          await Parse.Cloud.run("changeFectureProduct", params);
        
          this.loading = false

          this.$snotify.success(`Se ha cambiado el producto` , 'Cambio en destacado', {
            timeout: 4000,
            preventDuplicates: true
          });
          
        } catch (error) {
          this.$snotify.error(`${error}` , 'Comercios', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      copyUrlPromo(product){
        let texto = `https://promo.festyapp.com/${product.id}`;
        var textArea = document.createElement("textarea");
        //console.log(event.target.parentElement.childNodes[0].nodeValue.trim())
        textArea.value = texto;
        document.body.appendChild(textArea);
        textArea.select();
        try {
          var successful = document.execCommand('copy');
          if (successful) {
            this.$snotify.info('La URL de la promo fue copiada.', {
              timeout: 3000,
              preventDuplicates: true
            });
          }
        } catch (err) {
          this.$snotify.error(err, {
            timeout: 3000,
            preventDuplicates: true
          });
        }

        document.body.removeChild(textArea);
      },

      async imporProducts(){
        
        if (this.csv.length > 0) {
          let params = {
            id: this.$route.params.store_id,
            products: this.csv
          }
          await Parse.Cloud.run("importProductsBO", params);
          this.initialize()

          this.$snotify.success(`Se han importado los producto correctamente.` , 'Importar productos', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.close()

        }else{
          this.$snotify.error(`El archivo CSV no contiene datos.` , 'Importar Productos', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      async uploadAttachProductImgFile(){
        let simge = this.attachProductImg.split(",");
        simge = simge[1];
        var parseFile = new Parse.File(
          "payment",
          { base64: simge },
          this.attachProductImgFile.type
        );
        let file = await parseFile.save(null);
        return file._url
      },

      fileChanged(file) {
        if (file) {
          const fr = new FileReader();
          if (file) {
            fr.readAsDataURL(file);
            fr.addEventListener("load", () => {
              //eslint-disable-next-line
              //console.log(fr.result);
              this.attachProductImg = fr.result;
            });
          }
        }
      },

      showAddProductModal() {
        this.showAddProduct = true
      },

      closeModalAddProduct() {
        this.showAddProduct = false
        this.initialize()
      }

    },
}
</script>

<style lang="css">
  .csv-import-file{
    width: 100%;
    height: 70px;
    margin-top: 10px;
    background-color: white;
    outline: 2px dashed black;
  }

  .csv-import-file input{
    width: 100%;
    height: 70px;
    padding: 10px;
  }

  .vue-csv-mapping > table {
    width: 100%;
  }

  .h100{
    height: 100%;
    -webkit-appearance: auto !important;
  }

  .display-select{
    display: -webkit-box;
  }
</style>