<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Clientes</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
            class="mr-2"
          ></v-text-field>

           <download-excel
            class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
            :data = "customers"
            :fields = "headers_export"
            worksheet = "Clientes Festy POS"
            name = "customersPOS.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
            </download-excel>

            <v-btn
              class="mr-1 ml-2 white--text d-print-none"
              color="black"
              @click="massiveCustomerDialog = true"
              target="_blank"
            >
              <v-icon left>mdi-database-import</v-icon>Importar Clientes
            </v-btn>

            <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn icon v-on="on" class="d-print-none">
                <v-icon>mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="openSmsDialogStoreClients()">
                <v-list-item-title> <v-icon left>mdi-forum</v-icon>Enviar SMS a Clientes</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="customers"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >
          
            <template v-slot:item.attributes.createdAt="{ item }">
                {{ $moment(item.attributes.createdAt).format('lll') }}
            </template>
          
            <template v-slot:item.attributes.address="{ item }">
              {{ item.attributes.address.length >= 50 ? item.attributes.address.slice(0, 50)+'...' : item.attributes.address}}
            </template>

            <template v-slot:item.action="{ item }">
              <v-icon
                class="mr-2"
                @click="showDialogCustomer(item)"
              >
                mdi-eye-outline
              </v-icon>
            </template>

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo Dialogo show info customer -->
    <v-dialog
      v-model="modalCustomer"
      width="500"
      scrollable
      v-if="customer"
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize"> Detalle cliente </span>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <v-row align="center" justify="center">

            <v-col cols="12">
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-calendar</v-icon> Fecha:</strong> {{ $moment(customer.attributes.createdAt).format('lll') }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-account</v-icon> Nombre:</strong> {{ customer.attributes.name }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-map-marker</v-icon> Dirección:</strong> {{ customer.attributes.address }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-cellphone</v-icon> Teléfono:</strong> {{ customer.attributes.phone }} </div>
                <div class="body-1 text-wrap mb-3" style="color: black;"> <strong><v-icon>mdi-tag-text</v-icon> Tags:</strong> {{ customer.attributes.tags.join(', ') }} </div>
            </v-col>
           
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="modalCustomer = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo show info customer -->

    <!-- Dialogo import customers -->
    <v-dialog
      v-model="massiveCustomerDialog"
      width="1200"
      v-if="$route.params.store_id"
      scrollable
      persistent
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Importar clientes CSV </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
            <v-row dense>
                <v-col cols="12">
                  <vue-csv-import
                    v-model="csv"
                    url="#"
                    :map-fields="['name', 'phone', 'address']"
                    tableClass="v-data-table theme--light"
                    tableSelectClass="v-input__control h100 display-select"
                    :headers="true"
                    :autoMatchFields="true"
                    :fileMimeTypes="['text/csv']"
                  >

                    <template slot="error">
                       <p class="red--text"><strong>El tipo de archivo es invalido. </strong></p>
                    </template>
                    
                    <template slot="thead">
                        <tr style="border: 1px solid black;">
                            <th style="border: 1px solid black;">Columnas del sistema</th>
                            <th style="border: 1px solid black;">Columnas del archivo CSV</th>
                        </tr>
                    </template>

                    <template slot="next" slot-scope="{load}">
                      <v-btn
                        class="mt-5 mb-5 white--text"
                        color="black"
                        @click.prevent="load"
                      >
                      <v-icon class="mr-1">mdi-cloud-upload</v-icon>
                       Cargar archivo CSV
                      </v-btn>
                      <v-icon>mdi-numeric-1-circle-outline</v-icon>

                    <p class="mt-3 mb-3"> <strong> En la siguiente tabla, compruebe que las columnas de su archivo CSV estén en concordancia con las columnas de la base de datos. </strong></p>
                    
                    </template>

                    <template slot="submit" slot-scope="{submit}">
                        <v-btn
                          class="mt-5 mb-5 white--text"
                          color="black"
                          @click.prevent="submit"
                        >
                        <v-icon class="mr-1">mdi-table-eye</v-icon>
                          Mostrar tabla de datos
                        </v-btn>
                        <v-icon>mdi-numeric-2-circle-outline</v-icon>
                    </template>
                </vue-csv-import>
                </v-col>

                <v-col cols="12" v-if="csv.length > 0"> 
                  <v-data-table
                    :headers="headersCsv"
                    :items="csv"
                    :footer-props="pagination"
                    class="elevation-1"
                  >
                    
                    <template v-slot:no-data>
                    <v-btn color="primary" @click="initialize">Reset</v-btn>
                    </template>
                </v-data-table>
                </v-col>
                
            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-icon>mdi-numeric-3-circle-outline</v-icon>
           <v-btn
            color="success"
            outlined
            @click="importCustomers()"
          >
           <v-icon left>mdi-database-import</v-icon> Importar clientes
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo import customers -->

    <!-- Dialogo Send SMS Clients -->
    <v-dialog v-model="modalSmsClients" v-if="$route.params.store_id" width="600" persistent scrollable>
      <v-form ref="formsms" v-model="validSms">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Enviar SMS a Clientes (#{{$route.params.store_id}})</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">

              <v-col cols="12" class>
                <v-select
                  v-model="template"
                  :items="templates"
                  label="Plantillas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  @input="changeTemplate()"
                  hide-details
                ></v-select>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  outlined
                  :value="pushModel.body"
                  @change="v => pushModel.body = v"
                  :rules="bodyRules"
                  label="Mensaje"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalSmsClients = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="sendSmsClients()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send SMS Store -->

  </v-container>
</template>

<script>
import Parse from "parse";
import JsonExcel from 'vue-json-excel'
import { VueCsvImport } from 'vue-csv-import';

export default {

    components: {
        'download-excel': JsonExcel,
        VueCsvImport
    },

  data() {
    return {
      customers: [],
      customer: '',
      search: "",
      loading: true,
      headers: [
        {
          text: "Nombre",
          align: "left",
          value: "attributes.name"
        },
        { text: "Celular", value: "attributes.phone" },
        { text: "Dirección", value: "attributes.address" },
        { text: "Tags", value: "attributes.tags" },
        { text: "Fecha", value: "attributes.createdAt" },
        { text: 'Acciones', value: 'action', sortable: false, align: "center", },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      },
      headers_export: {
            'ID': 'id',
            'Nombre': 'attributes.name',
            'Celular': 'attributes.phone',
            'Dirección': 'attributes.address',
            'Tags': 'attributes.tags',
            'Fecha creación': {
                field: 'attributes.createdAt',
                callback: (value) => {
                    let startDate = value.toLocaleString()
                    return `${startDate}`;
                }
            }
      },
      headersCsv: [
         {
          text: "Nombre",
          align: "left",
          value: "name"
        },
        { text: "Celular", value: "phone", sortable: false },
        { text: "Dirección", value: "address", sortable: false },
        //{ text: "Tags", value: "attributes.tags", sortable: false },
        //{ text: "Fecha", value: "attributes.createdAt", sortable: false },
      ],
      modalCustomer: '',
      massiveCustomerDialog: false,
      csv: [],

      modalSmsClients: false,
      validSms: true,
      templates: [],
      template: "",
      pushModel: {
        title: "",
        body: ""
      },
      bodyRules: [v => !!v || "Mensaje es requerido"],
    };
  },

  mounted() {
    this.initialize();
  },

  methods: {
    async initialize() {
      try {

        if (!this.$route.params.store_id) {
            this.$snotify.error(`La identificación del comercio es nulo, por favor verificar.`, "Clientes", {
                timeout: 4000,
                preventDuplicates: true
            });
            return;
        }
        
        let params = {
            id: this.$route.params.store_id
        }
        let customers = await Parse.Cloud.run("getCustomersBO", params);
        this.customers = customers;
        //eslint-disable-next-line
        //console.log(this.customers);
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Clientes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    openImageUrl(item) {
      window.open(item.attributes.rider.attributes.photoUrl, "_blank");
    },

    showDialogCustomer(item){
      this.customer = item
      this.modalCustomer = true
    },

    async importCustomers(){
        
        if (this.csv.length > 0) {
          let params = {
            id: this.$route.params.store_id,
            customers: this.csv
          }
          
          await Parse.Cloud.run("importCustomersBO", params);
          this.initialize()

          this.$snotify.success(`Se han importado los clientes correctamente.` , 'Importar Clientes', {
            timeout: 4000,
            preventDuplicates: true
          });

          this.close()

        }else{
          this.$snotify.error(`El archivo CSV no contiene datos.` , 'Importar Clientes', {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },

      close () {
        this.massiveCustomerDialog = false
      },

      async sendSmsClients() {
        if (this.$refs.formsms.validate()) {
          try {
            if (this.customers.length < 0) {
              this.$snotify.error(
                `No hay clientes registrados.`,
                "Notificación",
                {
                  timeout: 4000,
                  preventDuplicates: true
                }
              );
              return;
            }

            let phones = this.customers.filter((item) => item.attributes.phone).map(obj => {
              return `57${obj.attributes.phone}`
              //return `${obj.attributes.phone}`
            });

            phones = Array.from(new Set(phones))
            phones = phones.filter(Boolean);
            
            let params = "";

            
            params = {
              title: this.pushModel.title,
              message: this.pushModel.body,
              phones: phones,
              label: `admin~${this.customers[0].attributes.store.id}~${this.customers[0].attributes.store.attributes.name}`
            };
            
            //eslint-disable-next-line
            //console.log(params)
            await Parse.Cloud.run("sendSMSMasive", params);

            this.$snotify.success(`Se ha enviado el SMS`, "Envío SMS", {
              timeout: 4000,
              preventDuplicates: true
            });

            this.modalSmsClients = false;
          } catch (error) {
            this.$snotify.error(`${error}`, "SMS", {
              timeout: 4000,
              preventDuplicates: true
            });
          }
        } else {
          this.$snotify.error(
            `Compruebe todo los campos antes de enviar el formulario`,
            "SMS",
            {
              timeout: 4000,
              preventDuplicates: true
            }
          );
        }
      },

      async changeDestination() {
        //eslint-disable-next-line
        //console.log('Cambio');

        this.template = "";
        this.pushModel.title = "";
        this.pushModel.body = "";

        let params = {
          destination:"user"
        };
        let templates = await Parse.Cloud.run("getPushTemplates", params);
        this.templates = templates;
      },

      changeTemplate() {
        //eslint-disable-next-line
        //console.log(this.template);
        if (this.template) {
          this.pushModel.title = this.template.attributes.title;
          this.pushModel.body = this.template.attributes.body;
        } else {
          this.$snotify.error(`Seleccione una plantilla`, "Plantilla", {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      },
      
      openSmsDialogStoreClients() {
        this.changeDestination();
        this.modalSmsClients = true;
      },
  }
};
</script>