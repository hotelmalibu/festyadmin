<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1000"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="payments"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Pagos</v-toolbar-title>

        <v-spacer></v-spacer>
        
        <!--<v-btn icon>
          <v-icon>mdi-magnify</v-icon>
        </v-btn>

        <v-btn icon>
          <v-icon>mdi-dots-vertical</v-icon>
        </v-btn>-->
      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="payments"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por'
            }"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <!--<v-toolbar-title>PAGOS</v-toolbar-title>-->
                <v-spacer></v-spacer>
                 <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                ></v-text-field>
                <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
            </v-toolbar>
            </template>
            
            <template v-slot:item.attributes.logoUrl="{ item }">
              <v-avatar
                  size="36px"
                  color="teal"
                >
                  <img
                    v-if="item.attributes.logoUrl"
                    alt="Avatar"
                    :src="item.attributes.logoUrl"
                  >
                  <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
                {{$moment(item.attributes.createdAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
                {{$moment(item.attributes.updatedAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.amount="{ item }">
                {{ item.attributes.amount | currency }}
            </template>

            <template v-slot:item.attributes.status="{ item }">
                <v-chip
                    :color="item.attributes.status == '1' ? 'success' : item.attributes.status == '3' ? 'warning' : 'error'"
                    class="ml-0"
                    label
                    small
                >
                    {{ item.attributes.status == '1' ? 'ACEPTADA' : item.attributes.status == '3' ? 'PENDIENTE' : item.attributes.response.toUpperCase() }}
                </v-chip>
            </template>
            <!--<template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="sendInvoice(item)"
            >
                mdi-email-send-outline
            </v-icon>
            </template>-->
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    data() {
        return {
            payments: [],
            payment: {
                attributes: {
                transactionId: '',
                amount: '',
                method: '',
                createdAt: '',
                updatedAt: '',
                response: '',
                status: ''
              }
            },
            loading: true,
            search: '',
            headers: [
              { text: 'Transacción', align: 'left', value: 'attributes.transactionId' },
              { text: 'Valor', align: 'left', value: 'attributes.amount' },
              { text: 'Método', align: 'left', value: 'attributes.method' },
              { text: 'Fecha creación', align: 'left', value: 'attributes.createdAt' },
              { text: 'Fecha modificación', align: 'left', value: 'attributes.updatedAt' },
              { text: 'Respuesta', align: 'left', value: 'attributes.response' },
              { text: 'Estado', align: 'left', value: 'attributes.status' },
              //{ text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
        }
    },

    mounted() {
        this.initialize();
    },

    methods: {
        async initialize(){
            
            const params = {
                id: this.$route.params.invoice_id
            }

            try {
            let payments = await Parse.Cloud.run("getPaymentsByStoreIdBO", params);
            this.payments = payments
            //eslint-disable-next-line
            //console.log(this.payments);
            this.loading = false
            
            } catch (error) {
                this.$swal({
                    title: "Pagos de factura",
                    text: "Algo salío mal consultado los pagos.",
                    icon: "warning",
                    buttons: ['Salir', 'Entiendo'],
                    dangerMode: true,
                    })
                    .then((ok) => {
                    if (ok) {
                        this.$router.push('/stores')
                    }else{
                        this.$router.push('/stores')
                    }
                });
            }
            
        },

        goInvoice(invoice){
          this.$router.push('/invoice/' + invoice.id)
        },

    },
}
</script>