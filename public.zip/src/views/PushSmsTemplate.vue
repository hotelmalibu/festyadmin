<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Plantillas Push / SMS</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
          ></v-text-field>

          <v-btn icon>
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="templates"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
          >
            <template v-slot:top>
              <v-toolbar flat color="white">
                <!--<v-toolbar-title>COMERCIOS</v-toolbar-title>-->
                <v-spacer></v-spacer>
                <!--<v-btn color="black" class="mb-2 mr-2 white--text" to="/stores-maps"> <v-icon left>mdi-google-maps</v-icon> Ver mapa</v-btn>-->
              </v-toolbar>
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <!--<v-switch
                :input-value="item.attributes.status"
                false-value="offline"
                true-value="online"
                color="success"
                inset
                @click.native="changeStatusStoreRider(item)"
              ></v-switch>-->
              {{ item.attributes.status }}
            </template>

            <!--<template v-slot:item.action="{ item }">
                        <v-icon
                            class="mr-2"
                            @click="detailStore(item)"
                        >
                            mdi-eye
                        </v-icon>
            </template>-->

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">Reset</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>
  </v-container>
</template>

<script>
import Parse from "parse";
export default {
  data() {
    return {
      templates: [],
      search: "",
      loading: true,
      headers: [
        {
          text: "Nombre",
          align: "left",
          value: "attributes.name",
          sortable: false
        },
        {
          text: "Título",
          align: "left",
          value: "attributes.title"
        },
        { text: "Body", value: "attributes.body" },
        { text: "Destino", value: "attributes.destination" },
        { text: "Estado", value: "attributes.status" }
        //{ text: 'Acciones', value: 'action', sortable: false },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      }
    };
  },

  mounted() {
    this.initialize();
    //this.timeTest();
  },

  methods: {
    async initialize() {
      try {

        let params = {
            destination: false
        }
        let templates = await Parse.Cloud.run("getPushTemplates", params);
        this.templates = templates;
        //eslint-disable-next-line
        //console.log(this.templates);
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Plantillas", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    /*async timeTest() {
      try {
        let params = {
          month: 5
        }
        let time = await Parse.Cloud.run("timeTest", params);
        //eslint-disable-next-line
        //console.log(time);

      } catch (error) {
        this.$snotify.error(`${error}`, "TimeTest", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    }*/
  }
};
</script>