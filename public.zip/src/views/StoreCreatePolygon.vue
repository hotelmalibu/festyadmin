<template>
    <v-container fluid class="ma-0 pa-0" style="height: 87%;">
        <div class="pa-2 ma-2">
            <!--<button @click="addPath()">Add Path</button>-->
           <v-alert
                dense
                type="info"
                dismissible
                max-width="600"
                class="float-left pa-1 pr-3 ma-0"
            >
                Haz clic derecho sobre el mapa para crear puntos al polígono
            </v-alert>
            <v-btn
                class="mr-1 ml-2 white--text d-print-none float-right"
                color="black"
                @click="removePath()"
                small
            >
                <v-icon left>mdi-map-marker-minus</v-icon>Eliminar vértices
            </v-btn>
            <v-btn
                class="mr-1 ml-2 white--text d-print-none float-right"
                color="black"
                @click="saveDialogPolygon = true"
                small
            >
                <v-icon left>mdi-content-save</v-icon>Guardar
            </v-btn>
        </div>

        <div class="text-center justify-center pt-1" style="width: 100%; height: 100%; display: flex;">
            <GmapMap :center="center" :zoom="zoom" ref="map" style="width: 100%; height: 100%" @rightclick="handleClickCheck">
                <GmapPolygon
                    v-if="paths.length > 0"
                    :path="paths"
                    :editable="true"
                    @path_changed="updateEdited($event)"
                    @rightclick="handleClickForDelete"
                    ref="polygon"
                >
                </GmapPolygon>
            </GmapMap>
        </div>

        <!-- Dialogo Detail product -->
    <v-dialog
      v-model="saveDialogPolygon"
      width="580"
      scrollable
    >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
            Guardar Polígono
        </v-card-title>

        <v-card-text class="pt-2">
            <v-textarea
                :value="getPathsText()"
                outlined
                name="input-7-4"
                label="Array Polígono"
                hide-details
                :editable="false"
            ></v-textarea>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="saveDialogPolygon = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
            <v-btn
                color="success"
                outlined
                @click="saveGeoCoverage()"
            >
            <v-icon left>mdi-content-save</v-icon> Guardar
            </v-btn>
          
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Detail product -->

    </v-container>
</template>

<script>
import { _ } from "vue-underscore";
import Parse from 'parse'

export default {
    data() {
        return {
            zoom: 8,
            center: { lng: -74.51927471938426, lat: 5.3136519075759825 },
            edited: null,
            paths: [],
            mvcPaths: null,
            errorMessage: null,
            polygonGeojson: '',
            saveDialogPolygon: false
        };
    },
    watch: {
          polygonPaths: _.throttle(function (paths) {
            if (paths) {
              this.paths = paths
              this.polygonGeojson = JSON.stringify({
                type: 'Polygon',
                coordinates: this.paths.map(path => {this.closeLoop(path)})
              }, null, 2)
            }
          }, 1000)
        },
        computed: {
          polygonPaths: function () {
            if (!this.mvcPaths) return null
            let paths = [];
            for (let j=0; j<this.mvcPaths.length; j++) {
                let point = this.mvcPaths.getAt(j);
                paths.push({ lat: point.lat(), lng: point.lng() });
            }
            return paths
          },
        },

    mounted() {
        this.initialize();
    },

    methods: {
        async initialize () {
            const params = {
                id: this.$route.params.store_id
            }
            try {
                let companie = await Parse.Cloud.run("getStoreBO", params);
                let coverage = companie.attributes.geoCoverage
                //eslint-disable-next-line
                //console.log(coverage.coordinates);
                if (coverage) {
                    this.center = { lng: coverage.coordinates[0][1], lat: coverage.coordinates[0][0] }
                    this.zoom = 9
                    const polygon = coverage.coordinates.map(([lat, lng]) => ({lat, lng}));
                    //eslint-disable-next-line
                    //console.log(polygon);
                    this.paths = polygon;
                }
                
                this.loading = false
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Covertura', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        closeLoop (path) {
            return path
        },
        updateEdited: function (mvcPaths) {
            //eslint-disable-next-line
            //console.log(mvcPaths);
            this.mvcPaths = mvcPaths
        },

        addPath: function () {
            // obtain the bounds, so we can guess how big the polygon should be
            var bounds = this.$refs.map.$mapObject.getBounds()
            var northEast = bounds.getNorthEast()
            var southWest = bounds.getSouthWest()
            var center = bounds.getCenter()
            var degree = this.paths.length + 1;
            var f = Math.pow(0.66, degree)

            // Draw a triangle. Use f to control the size of the triangle.
            // i.e., every time we add a path, we reduce the size of the triangle
            var path = [
              { lng: center.lng(), lat: (1-f) * center.lat() + (f) * northEast.lat() },
              { lng: (1-f) * center.lng() + (f) * southWest.lng(), lat: (1-f) * center.lat() + (f) * southWest.lat() },
              { lng: (1-f) * center.lng() + (f) * northEast.lng(), lat: (1-f) * center.lat() + (f) * southWest.lat() },
            ]

            this.paths.push(path)
        },
        removePath: function () {
            this.paths.splice(this.paths.length - 1, 1)
        },
        handleClickForDelete($event) {
            //eslint-disable-next-line
            //console.log($event);
            if ($event.vertex) {
              this.$refs.polygon.$polygonObject.getPaths()
                .getAt($event.path)
                .removeAt($event.vertex)
            }
        },

        readGeojson: function ($event) {
            try {
              this.polygonGeojson = $event.target.value

              var v = JSON.parse($event.target.value);

              this.paths = v.coordinates.map(linearRing =>
                linearRing.slice(0, linearRing.length - 1)
                .map(([lng, lat]) => ({lat, lng}))
              )

              this.errorMessage = null
            } catch (err) {
              this.errorMessage = err.message
            }
        },

        handleClickCheck($event){
            //eslint-disable-next-line
            //console.log($event);
            if ($event.latLng.lat() && $event.latLng.lng()) {
                this.paths.push({lng: $event.latLng.lng(), lat: $event.latLng.lat()})
            }
        },

        async saveGeoCoverage(){
            var outputData = this.paths.map(function(obj) {
                return Object.keys(obj).sort().map(function(key) { 
                    return obj[key];
                });
            });

            if (outputData.length > 2) {

                const params = {
                    id: this.$route.params.store_id,
                    geoCoverage: outputData
                }

                try {

                    await Parse.Cloud.run("saveGeoCoverageStoreBO", params);
                    this.initialize();
                    this.saveDialogPolygon = false

                    this.$snotify.success(`Se ha guardado la nueva covertura` , 'Covertura', {
                        timeout: 4000,
                        preventDuplicates: true
                    });

                } catch (error) {
                    this.$snotify.error(`${error}` , 'Covertura', {
                        timeout: 4000,
                        preventDuplicates: true
                    });
                }
            } else {
                this.$snotify.error(`El poligono debe contener más de 2 puntos` , 'Poligono', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        getPathsText(){
            var outputData = this.paths.map(function(obj) {
                return Object.keys(obj).sort().map(function(key) { 
                    return obj[key];
                });
            });
            return JSON.stringify(outputData)
        }
    }
};
</script>