<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1000"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="orders"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Promos aplicadas</v-toolbar-title>

        <v-spacer></v-spacer>
        
       <download-excel
            class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
            :data = "orders"
            :fields = "headers_export"
            worksheet = "Promos Festy"
            name = "PromosFesty.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
        </download-excel>

        <v-btn icon @click="dialogFilterOrders = true" class="pa-0 ma-0 d-print-none">
            <v-icon>mdi-filter</v-icon>
        </v-btn>
      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="orders"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por'
            }"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <!--<v-toolbar-title>PAGOS</v-toolbar-title>-->
                <v-spacer></v-spacer>
                 <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                ></v-text-field>
                <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
            </v-toolbar>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
                {{$moment(item.attributes.createdAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
                {{$moment(item.attributes.updatedAt).format('lll')}}
            </template>

            <!--<template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="sendInvoice(item)"
            >
                mdi-email-send-outline
            </v-icon>
            </template>-->
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  <!-- Dialogo filter orders -->
    <v-dialog v-model="dialogFilterOrders" width="700" persistent scrollable>
      <v-form ref="formFilter" v-model="validFilter">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar ordenes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row>
              <v-col cols="12" sm="6">
                <v-date-picker v-model="dates" range @change="checkDates()" locale="es"></v-date-picker>
              </v-col>
              <v-col cols="12" sm="6">
                <v-text-field v-model="dateRangeText" label="Rango de fechas" prepend-inner-icon="mdi-calendar" readonly outlined hide-details></v-text-field>
                <h3
                  ref="radio"
                  class="mt-3"
                >
                  Tipo de orden
                </h3>
                <v-radio-group v-model="sourceOption" class="mt-1">
                  <v-radio
                    label="Todos"
                    value="all"
                  ></v-radio>
                  <v-radio
                    label="POS"
                    value="pos"
                  ></v-radio>
                  <v-radio
                    label="Festy Ordenes"
                    value="client"
                  ></v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="red" outlined @click="dialogFilterOrders = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            
            <v-btn color="success" dark outlined @click="initialize()">
              <v-icon left>mdi-filter</v-icon>Filtrar ordenes
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo filter orders -->

  </v-container>
</template>

<script>
import Parse from 'parse'
import JsonExcel from 'vue-json-excel'

export default {
    
    components: {
        'download-excel': JsonExcel,
    },

    data() {
        return {
            orders: [],
            loading: true,
            search: '',
            headers: [
                { text: 'ID', align: 'left', value: 'id' },
                { text: 'Comercio', align: 'left', value: 'attributes.store.attributes.name' },
                { text: 'Cupón', align: 'left', value: 'attributes.promoCode.attributes.code' },
                { text: 'Cliente', align: 'left', value: 'attributes.alias' },
                { text: 'Fecha creación', align: 'left', value: 'attributes.createdAt' },
                //{ text: 'Fecha modificación', align: 'left', value: 'attributes.updatedAt' },
              //{ text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            dialogFilterOrders: false,
            validFilter: false,
            sourceOption: "all",
            dates: [],
            headers_export: {
                'ID': 'id',
                'Comercio': 'attributes.store.attributes.name',
                'Cupón': 'attributes.promoCode.attributes.code',
                'Cliente': 'attributes.alias',
                'Fecha creación': {
                    field: 'attributes.createdAt',
                    callback: (value) => {
                        let startDate = value.toLocaleString()
                        return `${startDate}`;
                    }
                }
            },
        }
    },

    mounted() {
        this.initialize();
        //this.test();
    },

    computed: {
        dateRangeText () {
        return this.dates.join(' ~ ')
        },
    },

    methods: {

        async initialize(){

            let params = {}

            if (!this.dates || this.dates.length <= 1) {
                params = {
                    source: this.sourceOption,
                    //status: this.statusOrder
                };
            }else{
                params = {
                    init: this.dates[0],
                    end: this.dates[1],
                    source: this.sourceOption,
                    //status: this.statusOrder
                };
            }

            //eslint-disable-next-line
            //console.log(params);

            try {
                let orders = await Parse.Cloud.run("getOrdersByStoreFilterWithPromoBO", params);
                this.orders = orders;
                //eslint-disable-next-line
                //console.log(this.invoices);

                this.dialogFilterOrders = false
                this.loading = false;

            } catch (error) {
                this.$snotify.error(`${error}`, "Cupones", {
                timeout: 4000,
                preventDuplicates: true
                });
            }

        },

        checkDates(){
            this.dates.sort(function(a, b) {
                var c = new Date(a);
                var d = new Date(b);
                return c-d;
            });
        },

        /*async test(){

          try {
                let result = await Parse.Cloud.run("openOrCloseStoresJob");
                //eslint-disable-next-line
                console.log(result);
            } catch (error) {
                this.$snotify.error(`${error}`, "MomentTest", {
                timeout: 4000,
                preventDuplicates: true
                });
            }
          
        }*/

    },
}
</script>