<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar class="d-print-none" color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>
      
      <div class="d-print-none" style="margin-top: -64px;"></div>

      <v-card
        class="mx-auto"
        max-width="1100"
        :loading="loading"
        v-if="owner"
      >
        <v-toolbar flat class="d-print-none">
          <v-toolbar-title class="black--text">Historial de ordenes</v-toolbar-title>

          <v-spacer></v-spacer>

          <download-excel
            class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
            :data = "orders"
            :fields = "headers_export"
            worksheet = "Festy Orders"
            name = "FestyOrders.xls">
            <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
          </download-excel>
         
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text v-if="owner">
          <v-card class="mx-auto mb-5" max-width="100%" outlined>
            <v-list-item three-line>
              <v-list-item-content>
                
                <v-list-item-title class="headline mb-1">
                    {{ owner.attributes.name }}
                </v-list-item-title>
                <v-list-item-subtitle class="mb-2" v-if="owner">
                  <v-icon>mdi-email</v-icon>
                  {{ owner.attributes.email ? owner.attributes.email : owner.attributes.gemail }}
                </v-list-item-subtitle>
                <v-list-item-subtitle class="mb-2" v-if="owner">
                  <v-icon>mdi-phone</v-icon>
                  {{ owner.attributes.phone }}
                </v-list-item-subtitle>
                <v-list-item-subtitle class="mb-2" v-if="owner">
                  <v-icon>mdi-store</v-icon>
                  {{ owner.attributes.store ? 'El usuario posee una tienda' : 'El usuario NO posee una tienda' }}
                </v-list-item-subtitle>
                <v-list-item-subtitle class="mb-2 text-uppercase" v-if="owner">
                  <v-icon>mdi-laptop</v-icon>
                  {{ owner.attributes.os }}
                </v-list-item-subtitle>
              </v-list-item-content>

              <v-list-item-avatar size="80" color="teal">
                <v-img v-if="owner.attributes.photoUrl" :src="owner.attributes.photoUrl"></v-img>
                <span v-else class="white--text">FT</span>
              </v-list-item-avatar>
            </v-list-item>

            <v-card-text>
              <v-row>
                <!--<v-col cols="6" sm="2" class="black--text">
                  <v-icon>mdi-cellphone-iphone</v-icon>
                  {{ companie.attributes.phoneSMSAlert ? companie.attributes.phoneSMSAlert : companie.attributes.owner ? companie.attributes.owner.attributes.phone : '' }}
                </v-col>-->

                <v-col cols="12" sm="3" class="black--text" v-if="countOrders">
                  <v-icon>mdi-clock-fast</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> ORDENES: <strong> ({{ countOrders }}) - {{ totalMoney | currency }}</strong></span>
                    </template>
                    <span>Número total de ordenes y el total del recaudo.</span>
                  </v-tooltip>
                </v-col>

                <v-col cols="12" sm="3" class="black--text" v-if="countOrders">
                  <v-icon>mdi-bike-fast</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> DOMICILIOS: <strong> {{ totalDelivery | currency }}</strong></span>
                    </template>
                    <span>Valor recaudado por concepto de domicilios.</span>
                  </v-tooltip>
                </v-col>

                <v-col cols="12" sm="3" class="black--text" v-if="cashOrderLength">
                  <v-icon>mdi-cash-multiple</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> EFECTIVO: <strong> ({{ cashOrderLength }}) - {{ totalCashOrders | currency }}</strong></span>
                    </template>
                    <span>Número de ordenes pagadas en efectivo y el total del recaudo.</span>
                  </v-tooltip>
                </v-col>

                <v-col cols="12" sm="3" class="black--text">
                  <v-icon>mdi-bank-transfer</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> TRANSFERENCIA: <strong>  ({{ transferOrderLength }}) - {{ totalTransferOrders | currency }}</strong></span>
                    </template>
                    <span>Número de ordenes pagadas por transferencia bancaria y el total del recaudo.</span>
                  </v-tooltip>
                </v-col>

                <!--<v-col cols="12" sm="3" class="black--text">
                  <v-icon>mdi-printer-pos</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> POS: <strong> ({{ posOrderLength }}) - {{ totalPosOrders | currency }}</strong></span>
                    </template>
                    <span>Número de ordenes por sistema POS y el total del recaudo.</span>
                  </v-tooltip>
                </v-col>-->

                <v-col cols="12" sm="3" class="black--text" v-if="countOrders">
                  <v-icon>mdi-tag-multiple</v-icon> 
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on"> CUPONES: <strong> ({{ couponslength }}) - {{ totalCoupons | currency }}</strong></span>
                    </template>
                    <span>Número de cupones aplicados y el valor total de los cupones.</span>
                  </v-tooltip>
                </v-col>

               

                <v-col cols="12" sm="3" class="black--text" v-if="datenow">
                  <v-icon>mdi-calendar-month</v-icon>
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on }">
                      <span v-on="on">REGISTRO: <strong>{{ owner.createdAt | moment('from', datenow) }}</strong></span>
                    </template>
                    <span>{{ $moment(owner.createdAt).format('lll') }}</span>
                  </v-tooltip>
                </v-col>

              </v-row>
            </v-card-text>

            <v-card-actions></v-card-actions>
          </v-card>

          <v-data-table
            :loading="loading_orders"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="orders"
            :search="search"
            :footer-props="pagination"
            class="elevation-1 d-print-table-row"
            @click:row="modalOrderDatail"
          >
            <template v-slot:top>
              <v-toolbar flat color="white">
                <v-toolbar-title>Ordenes</v-toolbar-title>
                <v-spacer></v-spacer>
                <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                    ></v-text-field>

                <!--<v-btn color="black" dark class="d-print-none mr-0 d-none d-sm-flex" @click="dialogStoreReview = true"> <v-icon class="mr-1">mdi-star-circle</v-icon> Opiniones de clientes ({{ reviewProm }})</v-btn>
                <v-btn color="black" dark class="d-print-none mr-0 d-flex d-sm-none" @click="dialogStoreReview = true"> <v-icon class="mr-1">mdi-star-circle</v-icon> ({{ reviewProm }})</v-btn>-->

              <v-btn icon @click="dialogFilterOrders = true" class="pa-0 ma-0 d-print-none">
                <v-icon>mdi-filter</v-icon>
              </v-btn>

              </v-toolbar>
            </template>

            <template v-slot:item.attributes.logoUrl="{ item }">
              <v-avatar size="36px" color="teal">
                <img v-if="item.attributes.logoUrl" alt="Avatar" :src="item.attributes.logoUrl" />
                <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.createdAt="{ item }">{{$moment(item.createdAt).format('lll')}}</template>

            <!--<template v-slot:item.id="{item }">{{ orders.indexOf(item)+1 }}</template>-->

            <template v-slot:item.attributes.alias="{ item }">
              {{ item.attributes.alias }} <span v-if="item.attributes.source == 'pos'"> <strong> - (pos)</strong></span>
            </template>

            <template
              v-slot:item.attributes.total="{ item }"
            >{{ item.attributes.total - item.attributes.discount | currency }}</template>

            <template v-slot:item.attributes.objectId="{ item }"> <span class="caption">{{ getPedidoText(item.attributes.items, false) }}</span>  </template>

            <template v-slot:item.attributes.promoCode.attributes.code="{ item }">
              <span
                v-if="item.attributes.promoCode"
              >{{ item.attributes.discount | currency }} - ({{ item.attributes.promoCode.attributes.code }})</span>
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-chip :color="colorStatus(item)" class="ml-0 white--text capitalize" label small>
                <strong>{{ traslateStatus(item.attributes.status) }}</strong>
              </v-chip>
            </template>
            <!--<template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="sendInvoice(item)"
            >
                mdi-email-send-outline
            </v-icon>
            <v-icon
                @click="goInvoice(item)"
            >
                mdi-file-chart
            </v-icon>
            </template>-->
            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">Recargar</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo Order Details -->
    <v-dialog
      v-model="modalOrder"
      v-if="order"
      width="600"
      scrollable
    >
      <v-card>
        <v-card-title
          class="title grey lighten-2"
          primary-title
        >
          <span class="text-capitalize">{{ order.attributes.alias }}</span> &nbsp; <span class="title ma-1"> (#{{ order.id }}) </span>
          
          <v-spacer></v-spacer>
          
          <v-menu bottom right>
            <template v-slot:activator="{ on }">
              <v-btn
                icon
                v-on="on"
              >
                <v-icon >mdi-dots-vertical</v-icon>
              </v-btn>
            </template>

            <v-list>
              <v-list-item @click="modalCall(order, 'store')">
                <v-list-item-title> <v-icon>mdi-phone-forward</v-icon> Llamar al comercio</v-list-item-title>
              </v-list-item>
              <v-list-item @click="modalCall(order, 'client')">
                <v-list-item-title> <v-icon>mdi-phone-forward-outline</v-icon> Llamar al cliente</v-list-item-title>
              </v-list-item>
              <!--<v-list-item @click="openPushDialog(order)">
                <v-list-item-title> <v-icon>mdi-bell-ring</v-icon> Enviar Push</v-list-item-title>
              </v-list-item>
              <v-list-item @click="openSmsDialog(order)">
                <v-list-item-title> <v-icon>mdi-message-text</v-icon> Enviar SMS</v-list-item-title>
              </v-list-item>
              <v-list-item @click="markAsDelivered(order)">
                <v-list-item-title> <v-icon>mdi-checkbox-marked-circle</v-icon> Marcar como entregada</v-list-item-title>
              </v-list-item>
              <v-list-item @click="cancelOrderModal(order)">
                  <v-list-item-title> <v-icon>mdi-cancel</v-icon> Cancelar orden</v-list-item-title>
              </v-list-item>-->
            </v-list>
          </v-menu>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <div class="mb-4" v-if="datenow">{{ $moment(order.createdAt).format('lll') }} - ({{ order.createdAt | moment('from', datenow) }})</div>

          <div class="body-1 text-wrap mb-3 " style="color: black;"> <strong><v-icon>mdi-storefront</v-icon> Tienda:</strong> {{ order.attributes.store.attributes.name }} </div>
          
          <div class="body-1 text-wrap mb-3 font-weight-medium" style="color: black;"> <strong><v-icon>mdi-cart</v-icon> Pedido:</strong> {{ getPedidoText(order.attributes.items, false) }}  </div>
          
          <div class="body-1 text-wrap mb-3 font-weight-medium" style="color: black;" v-if="order.attributes.promoCode"> <strong><v-icon>mdi-tag-multiple-outline</v-icon> Promo:</strong> {{ order.attributes.discount | currency }} - ({{ order.attributes.promoCode.attributes.code }}) </div>
          
          <div class="body-1 text-wrap mb-3 font-weight-medium" style="color: black;"> <strong><v-icon> {{ order.attributes.payment.attributes.method == 'digitalTransfer' ? 'mdi-bank-transfer'  : 'mdi-cash-marker' }} </v-icon> Total:</strong> {{ order.attributes.total - order.attributes.discount | currency }} <v-icon @click="modalPaymentMethod = true">mdi-magnify</v-icon> </div>

          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.source == 'pos' && order.attributes.comments"> <strong><v-icon>mdi-cellphone-iphone</v-icon> Teléfono:</strong> {{order.attributes.comments}} </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.address"> <strong><v-icon>mdi-map-marker</v-icon> Entregar en:</strong> {{ order.attributes.address.attributes.address }} {{ order.attributes.address.attributes.name ? ' - ' + order.attributes.address.attributes.name : '' }} <v-icon @click="modalEditAdress = true">mdi-file-document-edit-outline</v-icon> </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-else-if="order.attributes.source == 'pos'"> <strong><v-icon>mdi-map-marker</v-icon> Entregar en:</strong> {{ JSON.parse(order.attributes.notes).address }} <v-icon @click="modalEditNotes = true">mdi-file-document-edit-outline</v-icon> </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.rider"> <strong><v-icon>mdi-bike-fast</v-icon> Domiciliario:</strong> {{ order.attributes.rider.attributes.name }}  - ({{ order.attributes.rider.attributes.phone }})<v-icon @click="modalSendPushRider = true">mdi-android-messages</v-icon> </div>
          
          <div class="body-1 text-wrap mb-4 " style="color: black;"> <strong><v-icon>mdi-note-text</v-icon> Notas:</strong> 
          <span  v-if="order.attributes.notes"> {{ order.attributes.source == 'client' ? order.attributes.notes : order.attributes.source == 'pos' ? JSON.parse(order.attributes.notes).notes : ''}} </span> 
          <v-icon @click="modalEditNotes = true">mdi-file-document-edit-outline</v-icon> </div>

          <div class="body-1 text-wrap mb-4 " style="color: black;" v-if="order.attributes.rating"> <strong><v-icon>mdi-star</v-icon> Calificación:</strong> ({{ order.attributes.rating }}) <span v-if="order.attributes.comments">: {{order.attributes.comments}} </span> </div>

          <v-row align="center" justify="center">
            <v-col cols="12" class="pa-0">
               <v-stepper v-model="status_stepper" alt-labels>
                <v-stepper-header>
                <v-stepper-step step="1" :complete="true">Created</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="2" :complete="order.attributes.status == 'preparing' ? true : order.attributes.status == 'delivering' ? true : order.attributes.status == 'delivered' ? true : false">Preparing</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="3" :complete="order.attributes.status == 'delivering' ? true : order.attributes.status == 'delivered' ? true : false">Delivering</v-stepper-step>
                <v-divider></v-divider>
                <v-stepper-step step="4" :complete="order.attributes.status == 'delivered' ? true : false">Delivered</v-stepper-step>
                </v-stepper-header>
              </v-stepper>
            </v-col>
            <v-col cols="12">
              <GmapMap
                v-if="order.attributes.address && order.attributes.address.attributes.location && order.attributes.store.attributes.location"
                :center="center"
                :zoom="zoom"
                map-type-id="terrain"
                style="width: 100%; height: 200px"
                :options="{
                  zoomControl: true,
                  mapTypeControl: false,
                  scaleControl: true,
                  streetViewControl: false,
                  rotateControl: false,
                  fullscreenControl: false,
                  disableDefaultUi: false
                }"
              >
                <GmapInfoWindow :options="infoOptions" :position="infoWindowPos" :opened="infoWinOpen" @closeclick="infoWinOpen=false"></GmapInfoWindow>

                <GmapMarker
                  :position="{lat: order.attributes.address.attributes.location.latitude, lng: order.attributes.address.attributes.location.longitude}"
                  :clickable="true"
                  :draggable="false"
                  @click="toggleInfoWindow({lat: order.attributes.address.attributes.location.latitude, lng: order.attributes.address.attributes.location.longitude}, `<strong>Cliente:</strong> ${order.attributes.alias}`)"
                />
                <GmapMarker
                  :position="{lat: order.attributes.store.attributes.location.latitude, lng: order.attributes.store.attributes.location.longitude}"
                  :clickable="true"
                  :draggable="false"
                  @click="toggleInfoWindow({lat: order.attributes.store.attributes.location.latitude, lng: order.attributes.store.attributes.location.longitude}, `<strong>Tienda</strong>: ${order.attributes.store.attributes.name}`)"
                  :icon="{ url: require('../assets/market-store.png')}"
                />
              </GmapMap>
            </v-col>
          </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn
            color="primary"
            outlined
            @click="modalOrder = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- *End* Dialogo Order Details -->

    <!-- Dialogo Filter -->
    <v-dialog v-model="dialogFilter" width="600" persistent scrollable>
      <v-form ref="form" v-model="valid">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
              <v-col cols="12" class="pa-3 ma-2">
                <v-autocomplete
                  label="Tiendas"
                  :items="templates"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  hide-details
                ></v-autocomplete>
              </v-col>

              <v-col cols="12">
                <v-menu
                  ref="menu"
                  v-model="menuDatesFilters"
                  :close-on-content-click="false"
                  transition="scale-transition"
                  offset-y
                  min-width="290px"
                >
                  <template v-slot:activator="{ on }">
                    <v-text-field
                      v-model="dateRangeText"
                      label="Rango de fechas"
                      append-icon="mdi-calendar-search"
                      outlined
                      readonly
                      v-on="on"
                    ></v-text-field>
                  </template>

                  <v-date-picker v-model="datesFilters" range></v-date-picker>
                </v-menu>
              </v-col>

            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="dialogFilter = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="red" dark outlined>
              <v-icon left>mdi-autorenew</v-icon>Borrar filtros
            </v-btn>
            <v-btn color="green" dark outlined @click="dialogFilter = false">
              <v-icon left>mdi-filter</v-icon>Filtar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Filter -->

    <!-- Dialogo edit notes of order -->
    <v-dialog v-model="modalEditNotes" width="600" scrollable>
      <v-form ref="formEditNote" v-model="validEditNote">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Editar nota</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
              <v-col cols="12" v-if="order">
                <v-textarea
                  outlined
                  :value="order.attributes.notes"
                  @change="v => newNoteOrder = v"
                  label="Nota"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalEditNotes = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="success" dark outlined @click="editNote(order)">
              <v-icon left>mdi-send</v-icon>Editar nota
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo edit notes of order -->

    <!-- Dialogo filter orders -->
    <v-dialog v-model="dialogFilterOrders" width="700" persistent v-if="owner" scrollable>
      <v-form ref="formFilter" v-model="validFilter">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar ordenes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row>
              <v-col cols="12" sm="6">
                <v-date-picker v-model="dates" range @change="checkDates()" locale="es"></v-date-picker>
              </v-col>
              <v-col cols="12" sm="6">
                <v-text-field v-model="dateRangeText" label="Rango de fechas" prepend-inner-icon="mdi-calendar" readonly outlined hide-details></v-text-field>
                <!--<h3
                  ref="radio"
                  class="mt-3"
                >
                  Tipo de orden
                </h3>
                <v-radio-group v-model="sourceOption" class="mt-1">
                  <v-radio
                    label="Todos"
                    value="all"
                  ></v-radio>
                  <v-radio
                    label="POS"
                    value="pos"
                  ></v-radio>
                  <v-radio
                    label="Festy Ordenes"
                    value="client"
                  ></v-radio>
                </v-radio-group>-->

                 <h3
                  ref="radio"
                  class="mt-3"
                >
                  Ordenes canceladas
                </h3>
                <v-checkbox
                  v-model="ordersCancel"
                  label="Ver ordenes canceladas"
                  color="red"
                  hide-details
                ></v-checkbox>

              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="red" outlined @click="dialogFilterOrders = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            
            <v-btn color="primary" dark outlined @click="initialize()">
              <v-icon left>mdi-autorenew</v-icon>Limpiar
            </v-btn>
            <v-btn color="success" dark outlined @click="filterOrders()">
              <v-icon left>mdi-filter</v-icon>Filtrar ordenes
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo filter orders -->


    <!-- Dialogo Send Push -->
    <v-dialog v-model="modalPush" v-if="order" width="600" persistent scrollable>
      <v-form ref="form" v-model="valid">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Enviar Push (#{{this.order.id}})</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
              <v-col cols="12" class="pa-0 ma-0">
                <v-radio-group
                  v-model="radioGroup"
                  row
                  @change="changeDestination()"
                  hide-details
                  style="padding-left: 10px;"
                >
                  <v-radio label="Para usuario" value="1"></v-radio>
                  <v-radio label="Para tienda" value="2"></v-radio>
                </v-radio-group>
              </v-col>

              <v-col cols="12" class>
                <v-select
                  v-model="template"
                  :items="templates"
                  label="Plantillas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  @input="changeTemplate()"
                  hide-details
                ></v-select>
              </v-col>

              <v-col cols="10">
                <v-text-field
                  outlined
                  :value="pushModel.title"
                  @change="v => pushModel.title = v"
                  :rules="titleRules"
                  label="Título"
                  placeholder="Escriba el título de la notificación"
                  required
                  hide-details
                ></v-text-field>
              </v-col>

              <v-col cols="2">
                <v-menu
                  v-model="menu_emojis"
                  :close-on-content-click="false"
                  :nudge-width="200"
                  offset-x
                >
                  <template v-slot:activator="{ on }">
                    <v-btn color="indigo" fab x-small dark v-on="on">
                      <v-icon>mdi-emoticon-cool-outline</v-icon>
                    </v-btn>
                  </template>

                  <VEmojiPicker
                    v-show="menu_emojis"
                    labelSearch="Search"
                    style="{ width: 4px }"
                    @select="onSelectEmoji"
                  />
                </v-menu>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  outlined
                  :value="pushModel.body"
                  @change="v => pushModel.body = v"
                  :rules="bodyRules"
                  label="Mensaje"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>

              <v-col cols="12">
                <v-radio-group
                  v-model="radioGroupDeployed"
                  row
                  hide-details
                >
                  <v-radio label="Envío inmediato" value="1"></v-radio>
                  <v-radio label="Envío inteligente" value="2"></v-radio>
                </v-radio-group>
                
              </v-col>

              <v-col cols="12">
                <v-text-field
                  outlined
                  :value="app_url"
                  @change="v => app_url = v"
                  :rules="urlRules"
                  label="Link (opcional)"
                  placeholder="Escriba una url válida"
                  required
                  hide-details
                ></v-text-field>
              </v-col>

            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalPush = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="sendPush()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send Push -->

    <!-- Dialogo Send SMS -->
    <v-dialog v-model="modalSms" v-if="order" width="600" persistent scrollable>
      <v-form ref="formsms" v-model="validSms">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Enviar SMS (#{{this.order.id}})</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row align="center" justify="center">
              <v-col cols="12" class="pa-0 ma-0">
                <v-radio-group
                  v-model="radioGroup"
                  row
                  @change="changeDestination()"
                  hide-details
                  style="padding-left: 10px;"
                >
                  <v-radio label="Para usuario" value="1"></v-radio>
                  <v-radio label="Para tienda" value="2"></v-radio>
                </v-radio-group>
              </v-col>

              <v-col cols="12" class>
                <v-select
                  v-model="template"
                  :items="templates"
                  label="Plantillas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  return-object
                  @input="changeTemplate()"
                  hide-details
                ></v-select>
              </v-col>

              <v-col cols="12">
                <v-textarea
                  outlined
                  :value="pushModel.body"
                  @change="v => pushModel.body = v"
                  :rules="bodyRules"
                  label="Mensaje"
                  placeholder="Escriba el mensaje"
                  hide-details
                ></v-textarea>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="modalSms = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="green" dark outlined @click="sendSms()">
              <v-icon left>mdi-send</v-icon>Enviar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Send SMS -->


  </v-container>
</template>

<script>
import Parse from "parse";
import JsonExcel from 'vue-json-excel'
import VEmojiPicker from 'v-emoji-picker';

export default {

    components: {
        VEmojiPicker,
        'download-excel': JsonExcel
    },

  data() {
    return {
      sourceOption: "all",
      datenow: "",
      owner: {
        attributes: {
          name: "",
          city: "",
          phone: "",
          status: "",
          logoUrl: ""
        }
      },
      loading: true,
      loading_orders: true,
      search: "",
      headers: [
        //{ text: "ID", align: "left", value: "id" },
        {
          text: "Pedido",
          align: "left",
          value: "attributes.objectId",
          sortable: false
        },
        { text: "Total", align: "left", value: "attributes.total" },
        {
          text: "Cupón",
          align: "left",
          value: "attributes.promoCode.attributes.code"
        },
        { text: "Comercio", align: "left", value: "attributes.store.attributes.name" },
        { text: "Fecha", align: "left", value: "createdAt" },
        { text: "Estado", align: "left", value: "attributes.status" }
        //{ text: 'Acciones', align: 'left', value: 'action', sortable: false },
      ],
      orders: [],
      countOrders: "",
      storeCurrent: {},
      modalPushStore: false,
      modalSmsStore: false,
      modalPushStoreClient: false,
      modalSmsClients: false,
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      },
      order: "",
      modalOrder: false,
      modalPush: false,
      menu_emojis: false,
      valid: true,
      validClient: false,
      validCancel: false,
      validEditNote: false,
      radioGroup: "2",
      templates: [],
      template: "",
      pushModel: {
        title: "",
        body: ""
      },
      status_stepper: 0,

      infoWindowPos: null,
      infoWinOpen: false,
      infoOptions: {
        content: "",
        //optional: offset infowindow so it visually sits nicely on top of our marker
        pixelOffset: {
          width: 0,
          height: -35
        }
      },
      zoom: 0,
      center: 0,

      titleRules: [v => !!v || "Título es requerido"],
      bodyRules: [v => !!v || "Mensaje es requerido"],
      urlRules: [v => !!this.validURL(v) || "Url no es válida"],
      dialogFilter: false,
      menuDatesFilters: false,
      datesFilters: [],
      cancelOrderDialog: false,
      cancelOrder: "",
      noteCancelOrder: "",
      noteCancelOrderOther: "",
      notesCancelsOrders: [
        {
          id: 1,
          name: "Fuera de horario",
          description: "Pedido hecho fuera de horarios de atención."
        },
        {
          id: 2,
          name: "No hay domiciliario",
          description: "No hay domiciliario"
        },
        {
          id: 3,
          name: "Error de pedido",
          description: "Pedido realizado por error"
        },
        {
          id: 4,
          name: "Atención sin cobertura",
          description: "Aliado no atiende en dirección destino"
        },

        {
          id: 5,
          name: "Problemas con el negocio",
          description: "Negocio no puede realizar pedido"
        },
        {
          id: 6,
          name: "otros",
          description: "Otros"
        }
      ],
      modalSms: false,
      validSms: true,
      modalEditNotes: false,
      newNoteOrder: "",
      totalMoney: 0,
      totalDelivery: 0,
      dialogStoreReview: false,
      reviewProm: 0,
      dialogFilterOrders: false,
      validFilter: false,
      dates: [],
      withCancelled: false,
      totalCoupons: '',
      couponslength: '',
      app_url: '',
      radioGroupDeployed: '1',
      totalCashOrders: 0,
      cashOrderLength: 0,
      transferOrderLength: 0,
      totalTransferOrders: 0,
      posOrderLength: 0,
      totalPosOrders: 0,

      headers_export: {
        'ID': 'id',
        'Pedido': {
          field: 'attributes.items',
          callback: (value) => {
            return this.getPedidoText(value, false);
          }
        },
        'Total': 'attributes.total',
        'Domicilio': 'attributes.deliveryCost',
        'Promo': 'attributes.promoCode.attributes.code',
        'Comercio': 'attributes.store.attributes.name',
        'Fuente': 'attributes.source',
        'Fecha creación': {
          field: 'attributes.createdAt',
          callback: (value) => {
            let createdAt = value.toLocaleString()
            return `${createdAt}`;
          }
        },
        'Estado': {
          field: 'attributes.status',
          callback: (value) => {
            return this.traslateStatus(value)
          }
        }
      },
      ordersCancel: false
    };
  },

  mounted() {
    this.initialize();
    this.interval = setInterval(this.time, 1000);
  },

  computed: {
    dateRangeText () {
      return this.dates.join(' ~ ')
    },
  },

  methods: {
    time() {
      this.datenow = this.$moment();
    },

    async initialize() {
      const params = {
        id: this.$route.params.user_id
      };

      try {
        let owner = await Parse.Cloud.run("getUserBO", params);
        this.owner = owner;
        //eslint-disable-next-line
        //console.log(this.owner);
        this.loading = false;

        this.getOrders(this.owner);
      } catch (error) {
        this.$swal({
          title: "Comercio",
          text: "Algo salío mal consultado el usuario.",
          icon: "warning",
          buttons: ["Salir", "Entiendo"],
          dangerMode: true
        }).then(ok => {
          if (ok) {
            this.$router.push("/");
          } else {
            this.$router.push("/");
          }
        });
      }
    },

    async getOrders(owner) {
      const params = {
        id: owner.id,
        withCancelled: this.withCancelled
      };

      try {
        let orders = await Parse.Cloud.run("getOrdersByUserBO", params);
        this.orders = orders;
        this.countOrders = orders.filter(order => {
          if (order.attributes.status === 'delivered') {
            return order
          }
        }).length
        //eslint-disable-next-line
        //console.log(this.invoices);
        this.getTotalMoney(orders);
        this.getReviewProm(orders)
        this.getCouponsData(orders)
        this.getNumberCashOrdersAndValue(orders)
        this.getNumberTransferOrdersAndValue(orders)
        this.getNumberPosOrdersAndValue(orders)

        this.dialogFilterOrders = false

        this.loading_orders = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Ordenes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    async filterOrders(){

      if (!this.dates || this.dates.length <= 1) {
        this.$snotify.error(`Debe seleccionar un rango de fechas válido`, "Fechas", {
          timeout: 4000,
          preventDuplicates: true
        });
        return;
      }

      const params = {
        id:  this.owner.id,
        init: this.dates[0],
        end: this.dates[1],
        //source: this.sourceOption,
        status: this.ordersCancel ? 'cancelled' : '',
      };

      try {
        let orders = await Parse.Cloud.run("getOrdersByUserFilterBO", params);
        this.orders = orders;
        this.countOrders = orders.length;
        //eslint-disable-next-line
        //console.log(this.invoices);
        this.getTotalMoney(orders);
        this.getReviewProm(orders)
        this.getCouponsData(orders)
        this.getNumberCashOrdersAndValue(orders)
        this.getNumberTransferOrdersAndValue(orders)
        this.getNumberPosOrdersAndValue(orders)

        this.totalPerMonth(orders)

        this.dialogFilterOrders = false

        this.loading_orders = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Ordenes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }

    },

    checkDates(){
      this.dates.sort(function(a, b) {
          var c = new Date(a);
          var d = new Date(b);
          return c-d;
      });
    },

    traslateStatus(status) {
      switch (status) {
         case "pre-created":
          return "Pre-Creado";

        case "created":
          return "Creado";

        case "preparing":
          return "Preparando";

        case "delivering":
          return "En camino";

        case "delivered":
          return "Entregado";

        default:
          return "Cancelado";
      }
    },

    colorStatus(item) {
      let status = this.$store.state.status.filter(function(order) {
        return order.name === item.attributes.status;
      });
      return status[0] ? status[0].color : "red";
    },

    modalOrderDatail(order) {
      this.order = order
      this.infoWinOpen = false
      this.zoom = 14
      this.center = {lat: order.attributes.address ? order.attributes.address.attributes.location.latitude : '', lng:  order.attributes.address ? order.attributes.store.attributes.location.longitude : ''}
      this.modalOrder = true
    },

    toggleInfoWindow(position, infoText) {
      this.infoWindowPos = position;
      this.infoOptions.content = infoText;
      this.infoWinOpen = !this.infoWinOpen;
    },

    modalCall(order, type){
      this.$swal(`Contacto ${type == 'client' ? 'del cliente' : 'de la tienda' }`, type == 'client' ? `Teléfono: ${order.attributes.owner.attributes.phone}` :  `Teléfono SMS: ${order.attributes.store.attributes.phoneSMSAlert ? order.attributes.store.attributes.phoneSMSAlert : 'No suministrado.'} \n\n Teléfono principal: ${order.attributes.store.attributes.owner.attributes.phone ? order.attributes.store.attributes.owner.attributes.phone : 'No suministrado.'}`, "info")
    },

    openPushDialog(order) {
      this.order = order;
      this.changeDestination();
      this.modalPush = true;
    },

    openSmsDialog(order) {
      this.order = order;
      this.changeDestination();
      this.modalSms = true;
    },

    openPushDialogStore(store) {
      this.radioGroup = '2'
      this.storeCurrent = store;
      this.changeDestination();
      this.modalPushStore = true;
    },

    openSmsDialogStore(store) {
      this.storeCurrent = store;
      this.changeDestination();
      this.modalSmsStore = true;
    },

    openPushDialogStoreClients(store) {
      this.radioGroup = '1'
      this.storeCurrent = store;
      this.changeDestination();
      this.modalPushStoreClient = true;
    },

    openSmsDialogStoreClients(store) {
      this.radioGroup = '1'
      this.storeCurrent = store;
      this.changeDestination();
      this.modalSmsClients = true;
    },
    
    async changeDestination() {
      //eslint-disable-next-line
      //console.log('Cambio');

      this.template = "";
      this.pushModel.title = "";
      this.pushModel.body = "";

      this.radioGroupDeployed = '1'
      this.app_url = ''

      let params = {
        destination: this.radioGroup == "1" ? "user" : "store"
      };
      let templates = await Parse.Cloud.run("getPushTemplates", params);
      this.templates = templates;
    },

    changeTemplate() {
      //eslint-disable-next-line
      //console.log(this.template);
      if (this.template) {
        this.pushModel.title = this.template.attributes.title;
        this.pushModel.body = this.template.attributes.body;
      } else {
        this.$snotify.error(`Seleccione una plantilla`, "Plantilla", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    cancelOrderModal(order) {
      //eslint-disable-next-line
      console.log(order);
      this.cancelOrder = order;
      this.noteCancelOrderOther = "";
      this.cancelOrderDialog = true;
    },

    goStore(order) {
      if (order.attributes.store.id) {
        this.$router.push("/store/" + order.attributes.store.id);
      } else {
        this.$snotify.error(`La orden no posee un comercio.`, "Ver comercio", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    async editNote(order) {
      if (this.newNoteOrder) {
        try {
          let params = {
            id: order.id,
            note: this.newNoteOrder
          };

          await Parse.Cloud.run("editNoteOrderBO", params);

          this.modalEditNotes = false;

          this.$snotify.success(
            `Orden editada satisfactoriamente`,
            "Editar nota",
            {
              timeout: 4000,
              preventDuplicates: true
            }
          );
        } catch (error) {
          this.$snotify.error(`${error.message}`, "Editar nota", {
            timeout: 4000,
            preventDuplicates: true
          });
        }
      } else {
        this.$snotify.error(`La nota esta vacia.`, "Editar nota", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    getTotalMoney(orders){
        let total = orders.reduce((a, b) => { return b.attributes.status === 'delivered' ? a + b.attributes.total - b.attributes.deliveryCost : a }, 0);
        let delivery = orders.reduce((a, b) => { return b.attributes.status === 'delivered' ? a + b.attributes.deliveryCost : a }, 0);
        this.totalMoney = total
        this.totalDelivery = delivery
    },

    getReviewProm(orders){
        let rating = orders.reduce((a, b) => { return b.attributes.rating ? a + b.attributes.rating : a }, 0);
        let totalordersReview = orders.reduce((a, b) => { return b.attributes.rating ? a + 1 : a }, 0);
        this.reviewProm = rating != 0 ? Number(rating/totalordersReview, -1).toFixed(1) : 0;
    },

    getCouponsData(orders){
        let total_coupons = orders.reduce((a, b) => { 
          if (b.attributes.status === 'delivered' && b.attributes.discount) {
            return a + b.attributes.discount
          }
          return a
         }, 0);
        this.totalCoupons = total_coupons
        this.couponslength = orders.filter(order => {
          if (order.attributes.status === 'delivered' && order.attributes.discount) {
            return order
          }
        }).length
    },

    openDialogReviews(store){
        this.storeCurrent = store
        this.dialogStoreReview = true
    },

    getPedidoText(items, slice_text){
      let pedido_text = ''
      let pedido_text_temp = ''
      if (items) {
        items.forEach((item, index) => {
          pedido_text += `(${item.attributes.quantity}) - ${item.attributes.name} - (${this.$options.filters.currency(item.attributes.price)} c/u) ${item.attributes.comboOption ? ' + (' + this.$options.filters.currency(item.attributes.comboPrice) + ')' : ''}`
          if (index+1 < items.length) {            
            pedido_text += ', '
          }
        });

        pedido_text_temp = pedido_text

        if (slice_text) {
          pedido_text_temp = pedido_text.substring(0, 150)
          if (pedido_text.length > 150) {
            pedido_text_temp += '....'
          }
        }

        return pedido_text_temp
      }
    },

    validURL(str) {
      if (str) {
        var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
          '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
          '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
          '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
          '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
          '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
          return !!pattern.test(str);
      }
      return true;
    },

    getNumberCashOrdersAndValue(orders){
      let totalCashOrders = orders.reduce((a, b) => { 
          if (b.attributes.status === 'delivered' && b.attributes.payment.attributes.method === 'OnDelivery') {
            return a + (b.attributes.total - b.attributes.deliveryCost)
          }
          return a
         }, 0);
        
        this.totalCashOrders = totalCashOrders
        
        this.cashOrderLength = orders.filter(order => {
          if (order.attributes.status === 'delivered' && order.attributes.payment.attributes.method === 'OnDelivery') {
            return order
          }
        }).length
    },

    getNumberTransferOrdersAndValue(orders){
      let totalTransferOrders = orders.reduce((a, b) => { 
          if (b.attributes.status === 'delivered' && b.attributes.payment.attributes.method === 'digitalTransfer') {
            return a + (b.attributes.total - b.attributes.deliveryCost)
          }
          return a
         }, 0);
        
        this.totalTransferOrders = totalTransferOrders
        
        this.transferOrderLength = orders.filter(order => {
          if (order.attributes.status === 'delivered' && order.attributes.payment.attributes.method === 'digitalTransfer') {
            return order
          }
        }).length
    },

    getNumberPosOrdersAndValue(orders){
      let totalPosOrders = orders.reduce((a, b) => { 
          if (b.attributes.status === 'delivered' && b.attributes.source === 'pos') {
            return a + (b.attributes.total - b.attributes.deliveryCost)
          }
          return a
         }, 0);
        
        this.totalPosOrders = totalPosOrders
        
        this.posOrderLength = orders.filter(order => {
          if (order.attributes.status === 'delivered' && order.attributes.source === 'pos') {
            return order
          }
        }).length
    },

    totalPerMonth(orders){
      if (orders.length > 0) {
            let to = orders[0].attributes.createdAt
            let from = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();
            //eslint-disable-next-line
            //console.log(from.getMonth());
            //eslint-disable-next-line
            //console.log(diffYear);
            
            for (var i = from.getMonth(); i <= diffYear; i++) {
              let totalOrders = orders.reduce((a, b) => {
                  if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                    return a + (b.attributes.total - b.attributes.deliveryCost)
                  }
                  return a
              }, 0);

                arrMonths.push({
                    month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                    total: totalOrders
                });
            }

            //return arrMonths;
            //eslint-disable-next-line
            //console.log(arrMonths);
        }
    },

    onSelectEmoji(dataEmoji) {
      this.pushModel.title += dataEmoji.data;
    },

  }
};
</script>