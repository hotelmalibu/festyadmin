<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat> </v-toolbar>

      <v-card class="mx-auto" max-width="1000" style="margin-top: -64px">
        <v-toolbar flat>
          <v-toolbar-title class="black--text"
            >Categorías del App</v-toolbar-title
          >

          <v-spacer></v-spacer>

          <v-btn
            class="mr-1 ml-2 white--text d-print-none"
            color="black"
            @click="openModalSaveOrEdit()"
          >
            <v-icon left>mdi-plus</v-icon>Nueva Categoría
          </v-btn>
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="categories"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >
            <template v-slot:body="props">
              <draggable v-model="categories" tag="tbody" @change="changeIndex">
                <tr v-for="(item, index) in props.items" :key="index">
                  <td>
                    <v-icon small class="page__grab-icon">
                      mdi-arrow-all
                    </v-icon>
                  </td>
                  <td>{{ index }}</td>
                  <td>
                    <v-img
                      v-if="item.attributes.iconUrl"
                      :src="item.attributes.iconUrl"
                      aspect-ratio="1.4"
                      class="grey darken-4"
                      v-ripple
                    ></v-img>
                  </td>
                  <td>{{ item.attributes.name }}</td>
                  <td>{{ item.attributes.displayName }}</td>
                  <td>{{ item.attributes.zone.attributes.name }}</td>
                  <td>
                    <v-switch
                      :input-value="item.attributes.status"
                      false-value="inactive"
                      true-value="active"
                      color="success"
                      inset
                      @click.native="changeStatusCategory(item)"
                    ></v-switch>
                  </td>
                  <td>
                    <v-icon
                      class="mr-2"
                      @click="openModalSaveOrEdit(true, item)"
                    >
                      mdi-pencil
                    </v-icon>
                    <v-icon class="mr-2" @click="openModalDelete(item)">
                      mdi-delete
                    </v-icon>
                  </td>
                </tr>
              </draggable>
            </template>

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">Reset</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo Edit appCategory -->
    <v-dialog v-model="saveOrEditDialog" width="600" scrollable persistent>
      <v-form ref="formsaveoreditbanner" v-model="valid">
        <v-card>
          <v-card-title class="title grey lighten-3" primary-title>
            <span class="text-capitalize">
              {{ isEdit ? "Editar " : "Nueva" }} categoría
            </span>
            <v-spacer></v-spacer>
          </v-card-title>

          <v-img
            max-height="210"
            v-if="appCategory.iconUrl"
            :src="appCategory.iconUrl"
            aspect-ratio="1.7"
            contain
          ></v-img>

          <v-card-text>
            <v-divider class="mb-2"></v-divider>
            <v-row dense>
              <v-col cols="12" md="12">
                <v-file-input
                  v-model="attachappCategoryImage"
                  color="primary accent-4"
                  label="Imagen del banner"
                  placeholder="Clic aquí para adjuntar"
                  outlined
                  prepend-icon
                  prepend-inner-icon="mdi-paperclip"
                  hide-details
                  :show-size="1000"
                  @change="fileChanged"
                >
                  <template v-slot:selection="{ index, text }">
                    <v-chip
                      v-if="index < 2"
                      color="primary accent-4"
                      dark
                      label
                      small
                    >
                      {{ text }}
                    </v-chip>
                  </template>
                </v-file-input>
              </v-col>

              <v-col cols="12" md="12">
                <v-select
                  v-model="appCategory.zone"
                  :items="zones"
                  :rules="zoneRules"
                  label="Ciudades / Zonas"
                  outlined
                  item-text="attributes.name"
                  item-value="id"
                  hide-details
                ></v-select>
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="appCategory.name"
                  :rules="nameRules"
                  outlined
                  label="Nombre"
                  prepend-inner-icon="mdi-format-title"
                  hide-details
                ></v-text-field>
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="appCategory.displayName"
                  :rules="nameRules"
                  outlined
                  label="Nombre para mostrar"
                  prepend-inner-icon="mdi-monitor-screenshot"
                  hide-details
                ></v-text-field>
              </v-col>

              <v-col cols="12" md="12">
                <v-switch
                  v-model="appCategory.status"
                  inset
                  color="success"
                  false-value="inactive"
                  true-value="active"
                  :label="`Activo`"
                  hide-details
                ></v-switch>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="primary" outlined @click="close()">
              <v-icon left>mdi-close</v-icon> Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            <v-btn color="success" outlined @click="saveOrEditAppCategory()">
              <v-icon left>mdi-content-save-outline</v-icon> Guardar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo Edit appCategory -->
    <!-- Dialogo delete appCategory -->
    <v-dialog v-model="isOpenModalDelete" width="600" scrollable persistent>
      <v-card>
        <v-card-title class="title grey lighten-3" primary-title>
          <span class="text-capitalize"> Eliminar Categoría del App </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-img
          class="ma-3"
          ma-5
          max-height="210"
          v-if="appCategory.iconUrl"
          :src="appCategory.iconUrl"
          aspect-ratio="1.7"
          contain
        ></v-img>

        <v-card-text class="d-flex justify-center align-center pa-0 mb-3 mt-2">
          <span class="ma-0">
            ¿Estás seguro que deseas eliminar de tú lista de Categorias del App
            a <strong>{{ appCategory.name }}</strong
            >?
          </span>
        </v-card-text>
        <v-divider></v-divider>
        <v-card-actions>
          <v-btn color="primary" outlined @click="close()">
            <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn color="error" outlined @click="deleteappCategoriesApp()">
            <v-icon left>mdi-check-bold</v-icon> Confirmar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <!-- fin dialogo delete appCategory -->
  </v-container>
</template>

<script>
import Parse from "parse";
import draggable from "vuedraggable";

export default {
  components: {
    draggable,
  },

  data() {
    return {
      search: "",
      loading: true,
      valid: true,
      appCategory: {
        id: "",
        iconUrl: "",
        name: "",
        displayName: "",
        zone: "",
        status: "active",
      },
      categories: [],
      headers: [
        //{ text: 'Imagen', align: 'left', value: 'attributes.imageUrl', sortable: false },
        { text: "", sortable: false },
        { text: "Orden", value: "attributes.index" },
        { text: "Icono", value: "attributes.iconUrl" },
        { text: "Nombre", align: "left", value: "attributes.name" },
        {
          text: "Nombre para mostrar",
          align: "left",
          value: "attributes.displayName",
        },
        {
          text: "Zona",
          align: "left",
          value: "attributes.zone.attributes.name",
        },
        { text: "Status", value: "attributes.status" },
        { text: "Acciones", value: "action", sortable: false },
      ],

      pagination: {
        "items-per-page-options": [50, 100, -1],
        "items-per-page-text": "Items por página",
      },

      saveOrEditDialog: false,
      isEdit: false,
      zones: [],
      attachappCategoryImage: [],
      frResultAttach: "",
      isOpenModalDelete: false,

      urlRules: [(v) => !!v || "Url es requerido"],
      zoneRules: [(v) => !!v || "La ciudad es requerida"],
      nameRules: [(v) => !!v || "Nombre es requerido"],
    };
  },
  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "Nueva Categoría" : "Editar Categoría";
    },
  },

  watch: {
    dialog(val) {
      val || this.close();
    },
  },

  mounted() {
    this.initialize();
    this.getZones();
  },

  methods: {
    async initialize() {
      try {
        let categories = await Parse.Cloud.run("getAppCategoryBO");
        this.categories = categories;
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Categorías", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    async saveOrEditAppCategory() {
      if (!this.$refs.formsaveoreditbanner.validate()) {
        this.$snotify.error(`Todos los campos son requeridos.`, "Categorías", {
          timeout: 4000,
          preventDuplicates: true,
        });
        return;
      }
      let params = {
        id: this.appCategory.id,
        iconUrl: this.attachappCategoryImage
          ? this.attachappCategoryImage.length == 0
            ? this.appCategory.iconUrl
              ? this.appCategory.iconUrl
              : ""
            : this.attachappCategoryImage.type
            ? await this.uploadAttachAppCategoryImage()
            : ""
          : "",
        name: this.appCategory.name,
        displayName: this.appCategory.displayName,
        zone: this.appCategory.zone,
        status: this.appCategory.status,
        index: this.isEdit ? "" : this.categories.length,
      };

      if (!params.iconUrl) {
        this.$snotify.error(
          `La imagen del banner no se ha adjuntado por favor verifica y vuelve a intentarlo`,
          "Categorías",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
        return;
      }

      try {
        if (this.isEdit) {
          await Parse.Cloud.run("editAppCategoryBO", params);
        } else {
          await Parse.Cloud.run("newAppCategoryBO", params);
        }

        //eslint-disable-next-line
        //console.log(this.banners);
        this.$snotify.success(
          `Se ha ${this.isEdit ? "editado" : "guardado"} correctamente.`,
          "Categorías",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
        this.close();
        this.initialize();
      } catch (error) {
        this.$snotify.error(`${error}`, "Categorías", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    openModalDelete(item = {}) {
      if (item) {
        this.appCategory = {
          id: item.id,
          iconUrl: item.attributes.iconUrl,
          name: item.attributes.name,
          displayName: item.attributes.displayName,
          zone: item.attributes.zone ? item.attributes.zone.id : "",
          status: item.attributes.status,
        };
      }

      this.isOpenModalDelete = true;
    },

    async deleteappCategoriesApp() {
      let params = {
        id: this.appCategory.id,
      };

      try {
        if (params.id) {
          //eslint-disable-next-line
          // console.log(params);
          await Parse.Cloud.run("deleteAppCategoryBO", params);
          this.$snotify.success(
            `Se ha eliminado correctamente.`,
            "Categorías",
            {
              timeout: 4000,
              preventDuplicates: true,
            }
          );
        }
        this.close();
        this.initialize();
      } catch (error) {
        this.$snotify.error(`${error}`, "Categorías", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    async changeStatusCategory(item) {
      try {
        let params = {
          id: item.id,
        };
        this.loading = true;
        await Parse.Cloud.run("changeAppCategoryBO", params);
        this.loading = false;
        this.$snotify.success(
          `Se ha cambiado el estado de la categoría ${item.attributes.displayName}`,
          "Cambio de estado",
          {
            timeout: 4000,
            preventDuplicates: true,
          }
        );
      } catch (error) {
        this.$snotify.error(`${error}`, "Comercios", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    async changeIndex() {
      this.loading = true;
      if (this.categories && this.categories.length > 0) {
        for (let index = 0; index < this.categories.length; index++) {
          const element = this.categories[index];
          let params = {
            id: element.id,
            newIndex: index,
          };
          await Parse.Cloud.run("editIndexAppCategoryBO", params);
        }
      }
      this.loading = false;
    },

    openModalSaveOrEdit(edit = false, item = "") {
      this.isEdit = edit;
      if (item) {
        this.appCategory = {
          id: item.id,
          iconUrl: item.attributes.iconUrl,
          name: item.attributes.name,
          displayName: item.attributes.displayName,
          zone: item.attributes.zone ? item.attributes.zone.id : "",
          status: item.attributes.status,
        };
      }
      this.attachappCategoryImage = [];
      this.frResultAttach = "";
      this.saveOrEditDialog = true;
    },

    close() {
      this.isOpenModalDelete = false;
      this.saveOrEditDialog = false;
      this.isEdit = false;
      this.appCategory = {
        id: "",
        iconUrl: "",
        name: "",
        displayName: "",
        zone: "",
        status: "active",
      };
    },

    async getZones() {
      try {
        let zones = await Parse.Cloud.run("getAppConfigWhitoutLocation");
        this.zones = zones;
      } catch (error) {
        this.$snotify.error(`${error}`, "Ciudades", {
          timeout: 4000,
          preventDuplicates: true,
        });
      }
    },

    async uploadAttachAppCategoryImage() {
      let simge = this.frResultAttach.split(",");
      simge = simge[1];
      var parseFile = new Parse.File(
        "paymentOrder",
        { base64: simge },
        this.attachappCategoryImage.type
      );
      let file = await parseFile.save(null);
      return file._url;
    },

    fileChanged(file) {
      if (file) {
        const fr = new FileReader();
        if (file) {
          fr.readAsDataURL(file);
          fr.addEventListener("load", () => {
            //eslint-disable-next-line
            //console.log(fr.result);
            this.frResultAttach = fr.result;
          });
        }
      }
    },
  },
};
</script>
