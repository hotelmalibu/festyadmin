<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1100" style="margin-top: -64px;">
        <v-toolbar flat>
          <v-toolbar-title class="black--text">Domiciliarios</v-toolbar-title>

          <v-spacer></v-spacer>

          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="Buscar.."
            single-line
            hide-details
            class="mr-2"
          ></v-text-field>

          <v-btn color="black" class="mb-2 mr-2 white--text" to="/riders-map"> <v-icon left>mdi-google-maps</v-icon> Ver mapa</v-btn>

          <v-btn icon>
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="riders"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >
          
            <template v-slot:item.attributes.rider.attributes.photoUrl="{ item }">
              <v-avatar size="36px" color="teal" @click="openImageUrl(item)" v-ripple>
                <img
                  v-if="item.attributes.rider"
                  alt="Avatar"
                  :src="item.attributes.rider.attributes.photoUrl"
                />
                <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.store.attributes.name="{ item }">
              <v-avatar size="36px" color="teal" @click="openImageUrl(item)" v-ripple class="mr-2">
                <img
                  v-if="item.attributes.store"
                  alt="Avatar"
                  :src="item.attributes.store.attributes.logoUrl"
                />
                <span v-else class="white--text">FT</span>
              </v-avatar>
              {{item.attributes.store.attributes.name}}
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                :input-value="item.attributes.status"
                false-value="offline"
                true-value="online"
                color="success"
                inset
                @click.native="changeStatusStoreRider(item)"
              ></v-switch>
            </template>

            <template v-slot:item.attributes.default="{ item }">
              <v-switch
                :input-value="item.attributes.default"
                color="yellow darken-2"
                inset
                @click.native="changeDefaultStoreRider(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
              <v-icon
                class="mr-2"
                v-if="item.attributes.rider && item.attributes.rider.id"
                @click="goToRiderOrders(item.attributes.rider.id)"
               >
                mdi-eye
             </v-icon>
            </template>

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>
  </v-container>
</template>

<script>
import Parse from "parse";
export default {
  data() {
    return {
      riders: [],
      search: "",
      loading: true,
      headers: [
        {
          text: "Foto",
          align: "left",
          value: "attributes.rider.attributes.photoUrl",
          sortable: false
        },
        {
          text: "Nombre",
          align: "left",
          value: "attributes.rider.attributes.name"
        },
        { text: "Celular", value: "attributes.rider.attributes.phone" },
        { text: "Comercio", value: "attributes.store.attributes.name" },
        { text: "Festy Rider", value: "attributes.default" },
        { text: "Estado", value: "attributes.status" },
        { text: 'Acciones', value: 'action', sortable: false, align: "center", },
      ],
      pagination: {
        "items-per-page-options": [50, 60, 70, 100, -1]
      }
    };
  },

  mounted() {
    this.initialize();
  },

  methods: {
    async initialize() {
      try {
        let riders = await Parse.Cloud.run("getStoresAndRidersBO");
        this.riders = riders;
        //eslint-disable-next-line
        //console.log(this.riders);
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Domiciliarios", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },
    openImageUrl(item) {
      window.open(item.attributes.rider.attributes.photoUrl, "_blank");
    },

    async changeStatusStoreRider(item) {
      try {
        let params = {
          id: item.id
        };

        this.loading = true;
        await Parse.Cloud.run("changeStatusStoreRiderBO", params);

        this.loading = false;

        this.$snotify.success(
          `Se ha cambiado el estado del domiciliario ${item.attributes.rider.attributes.name}`,
          "Cambio de estado",
          {
            timeout: 4000,
            preventDuplicates: true
          }
        );
      } catch (error) {
        this.$snotify.error(`${error}`, "Domiciliarios", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    async changeDefaultStoreRider(item){
      try {
        let params = {
          id: item.id
        };

        this.loading = true;
        await Parse.Cloud.run("changeDefaultStoreRiderBO", params);

        this.loading = false;

        this.$snotify.success(
          `${item.attributes.rider.attributes.name} es un nuevo Festy Rider`,
          "Festy rider",
          {
            timeout: 4000,
            preventDuplicates: true
          }
        );
      } catch (error) {
        this.$snotify.error(`${error}`, "Domiciliarios", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    goToRiderOrders(id){
       this.$router.push('/rider-orders/' + id)
    }
  }
};
</script>