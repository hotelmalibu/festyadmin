<template>
  <v-container fluid>
    <v-card flat>
      <v-toolbar color="#f0e633" dark extended flat>
        <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
      </v-toolbar>

      <v-card class="mx-auto" max-width="1200" style="margin-top: -64px;">
        <v-toolbar flat>
            <v-toolbar-title class="black--text">Ordenes - <strong v-if="rider">({{ rider.attributes.name }})</strong></v-toolbar-title>

            <v-spacer></v-spacer>

            <v-text-field
                v-model="search"
                append-icon="mdi-magnify"
                label="Buscar.."
                single-line
                hide-details
                class="mr-2"
            ></v-text-field>

            <download-excel
                class = "mr-1 white--text d-print-none v-btn v-btn--contained theme--light v-size--default black"
                :data = "orders"
                :fields = "headers_export"
                worksheet = "Festy Orders Domiciliario"
                name = "FestyOrdersDomiciliario.xls">
                <v-icon left style="color:white;">mdi-microsoft-excel</v-icon> Descargar en Excel  
            </download-excel>

            <v-btn icon @click="dialogFilterOrders = true" class="pa-0 ma-0 d-print-none">
                <v-icon>mdi-filter</v-icon>
            </v-btn>

            <v-btn icon>
                <v-icon>mdi-dots-vertical</v-icon>
            </v-btn>
        </v-toolbar>

        <v-divider></v-divider>

        <v-card-text>
          <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="orders"
            :search="search"
            :footer-props="pagination"
            class="elevation-1"
            :header-props="{ sortIcon: null }"
          >

            <template v-slot:item.attributes.store.attributes.logoUrl="{ item }">
              <v-avatar size="36px" color="teal" @click="openImageUrl(item)" v-ripple>
                <img
                  v-if="item.attributes.store"
                  alt="Avatar"
                  :src="item.attributes.store.attributes.logoUrl"
                />
                <span v-else class="white--text">FT</span>
              </v-avatar>
            </template>

            <template v-slot:item.attributes.total="{ item }">
              {{ item.attributes.total | currency }}
            </template>

            <template v-slot:item.attributes.deliveryCost="{ item }">
              {{ item.attributes.deliveryCost | currency }}
            </template>

            <template v-slot:item.attributes.discount="{ item }">
              {{ item.attributes.discount | currency }}
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
              {{$moment(item.attributes.createdAt).format('ll')}}
            </template>

            <template v-slot:item.attributes.status="{ item }">
              <v-chip :color="colorStatus(item)" class="ml-0 white--text capitalize" label small>
                <strong>{{ traslateStatus(item.attributes.status) }}</strong>
              </v-chip>
            </template>

            <!--<template v-slot:item.action="{ item }">
              <v-icon
                class="mr-2"
                @click="detailStore(item)"
               >
                mdi-eye
             </v-icon>
            </template>-->

            <template v-slot:no-data>
              <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
          </v-data-table>
        </v-card-text>
      </v-card>
    </v-card>

    <!-- Dialogo filter orders -->
    <v-dialog v-model="dialogFilterOrders" width="700" persistent v-if="rider_id" scrollable>
      <v-form ref="formFilter" v-model="validFilter">
        <v-card>
          <v-card-title class="title grey lighten-2" primary-title>
            <span class="text-capitalize">Filtrar ordenes</span>
          </v-card-title>

          <v-card-text>
            <div class="mb-2"></div>
            <v-row>
              <v-col cols="12" sm="6">
                <v-date-picker v-model="dates" range @change="checkDates()" locale="es"></v-date-picker>
              </v-col>
              <v-col cols="12" sm="6">
                <v-text-field v-model="dateRangeText" label="Rango de fechas" prepend-inner-icon="mdi-calendar" readonly outlined hide-details></v-text-field>
                <h3
                  ref="radio"
                  class="mt-3"
                >
                  Tipo de orden
                </h3>
                <v-radio-group v-model="sourceOption" class="mt-1">
                  <v-radio
                    label="Todos"
                    value="all"
                  ></v-radio>
                  <v-radio
                    label="POS"
                    value="pos"
                  ></v-radio>
                  <v-radio
                    label="Festy Ordenes"
                    value="client"
                  ></v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
          </v-card-text>

          <v-divider></v-divider>

          <v-card-actions>
            <v-btn color="red" outlined @click="dialogFilterOrders = false">
              <v-icon left>mdi-close</v-icon>Cerrar
            </v-btn>
            <v-spacer></v-spacer>
            
            <v-btn color="primary" dark outlined @click="initialize()">
              <v-icon left>mdi-autorenew</v-icon>Limpiar
            </v-btn>
            <v-btn color="success" dark outlined @click="filterOrders()">
              <v-icon left>mdi-filter</v-icon>Filtrar ordenes
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-form>
    </v-dialog>
    <!-- *End* Dialogo filter orders -->

  </v-container>
</template>

<script>
import Parse from "parse";
import JsonExcel from 'vue-json-excel'

export default {

    components: {
        'download-excel': JsonExcel
    },

    data() {
        return {
            rider: '',
            rider_id: '',
            orders: [],
            search: "",
            loading: true,
            headers: [
                {
                text: "Logo",
                align: "left",
                value: "attributes.store.attributes.logoUrl",
                sortable: false
                },
                {
                text: "Comercio",
                align: "left",
                value: "attributes.store.attributes.name"
                },
                { text: "Total", value: "attributes.total" },
                { text: "Domicilio", value: "attributes.deliveryCost" },
                { text: "Descuento", value: "attributes.discount" },
                { text: "Promo", value: "attributes.promoCode.attributes.code" },
                { text: "Cliente", value: "attributes.alias" },
                //{ text: "Fuente", value: "attributes.source" },
                { text: "Fecha", value: "attributes.createdAt" },
                { text: "Estado", value: "attributes.status" },
                //{ text: 'Acciones', value: 'action', sortable: false, align: "center", },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1]
            },

            headers_export: {
                'ID': 'id',
                'Comercio': 'attributes.store.attributes.name',
                'Total': 'attributes.total',
                'Domicilio': 'attributes.deliveryCost',
                'Descuento': 'attributes.discount',
                'Promo': 'attributes.promoCode.attributes.code',
                'Cliente': 'attributes.alias',
                'Fuente': 'attributes.source',
                'Fecha creación': {
                field: 'attributes.createdAt',
                callback: (value) => {
                    let createdAt = value.toLocaleString()
                    return `${createdAt}`;
                }
                },
                'Estado': {
                field: 'attributes.status',
                callback: (value) => {
                    return this.traslateStatus(value)
                }
            }
        },
        dialogFilterOrders: false,
        validFilter: false,
        dates: [],
        sourceOption: "all",
    };
},

  mounted() {
    this.rider_id = this.$route.params.rider_id
    this.initialize();
  },

  computed: {
      dateRangeText () {
      return this.dates.join(' ~ ')
    },
  },

  methods: {
    async initialize() {
      try {
        let params = {
            id: this.rider_id
        }
        let orders = await Parse.Cloud.run("getOrderByRidersBO", params);
        this.orders = orders;
        this.rider = orders ? orders.length > 0 ? orders[0].attributes.rider : '' : ''
        //eslint-disable-next-line
        //console.log(this.orders);
        this.loading = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Ordenes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }
    },

    openImageUrl(item) {
      window.open(item.attributes.store.attributes.logoUrl, "_blank");
    },

    colorStatus(item) {
      let status = this.$store.state.status.filter(function(order) {
        return order.name === item.attributes.status;
      });
      return status[0] ? status[0].color : "red";
    },

    traslateStatus(status) {
      switch (status) {
         case "pre-created":
          return "Pre-Creado";

        case "created":
          return "Creado";

        case "preparing":
          return "Preparando";

        case "delivering":
          return "En camino";

        case "delivered":
          return "Entregado";

        default:
          return "Cancelado";
      }
    },

    checkDates(){
      this.dates.sort(function(a, b) {
          var c = new Date(a);
          var d = new Date(b);
          return c-d;
      });
    },

    async filterOrders(){

      if (!this.dates || this.dates.length <= 1) {
        this.$snotify.error(`Debe seleccionar un rango de fechas válido`, "Fechas", {
          timeout: 4000,
          preventDuplicates: true
        });
      }

      const params = {
        id:  this.rider_id,
        init: this.dates[0],
        end: this.dates[1],
        source: this.sourceOption,
        //status: this.statusOrder
      };

      try {
        let orders = await Parse.Cloud.run("getOrdersByRiderFilterBO", params);
        this.orders = orders;
        this.countOrders = orders.length;
        //eslint-disable-next-line
        //console.log(this.invoices);

        this.dialogFilterOrders = false

        this.loading_orders = false;
      } catch (error) {
        this.$snotify.error(`${error}`, "Ordenes", {
          timeout: 4000,
          preventDuplicates: true
        });
      }

    },
  }
};
</script>