<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1300"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="banners"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Banners de la aplicación</v-toolbar-title>

        <v-spacer></v-spacer>

        <v-btn color="black" class="mr-2 white--text" @click="openModalSaveOrEdit()"> <v-icon left>mdi-plus</v-icon> Nuevo banner</v-btn>

      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="banners"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por'
            }"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <v-spacer></v-spacer>
                 <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                ></v-text-field>
            </v-toolbar>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
                {{$moment(item.attributes.createdAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
                {{$moment(item.attributes.updatedAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.url="{ item }">
                <v-img
                    v-if="item.attributes.url"
                    :src="item.attributes.url"
                    aspect-ratio="1.7"
                    class="grey darken-4"
                    @click="openImageUrl(item)" v-ripple
                ></v-img>
            </template>

            <!--<template v-slot:item.attributes.type="{ item }">
                <v-chip :color="item.attributes.type === 'value' ? 'primary' : 'warning'" text-color="white" class="ml-0" small>
                      {{item.attributes.type ? item.attributes.type.toUpperCase() : ''}}
                </v-chip>
            </template>-->


            <template v-slot:item.attributes.status="{ item }">
              <v-switch
                v-if="item.attributes.status == 'deleted'"
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="deleted"
                color="error"
                inset
                @click.native="changeStatusBanner(item)"
              ></v-switch>
              <v-switch
                v-else
                :input-value="item.attributes.status"
                false-value="inactive"
                true-value="active"
                color="success"
                inset
                @click.native="changeStatusBanner(item)"
              ></v-switch>
            </template>

            <template v-slot:item.action="{ item }">
                <!--<v-icon
                    class="mr-2"
                    @click="detailBanner(item)"
                >
                    mdi-eye
                </v-icon>-->

                <v-icon
                    class="mr-2"
                    @click="openModalSaveOrEdit(true, item)"
                >
                    mdi-pencil
                </v-icon>
            </template>
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  <!-- Dialogo Edit appBanner -->
    <v-dialog
      v-model="saveOrEditBannerDialog"
      width="600"
      scrollable
      persistent
    >
    <v-form ref="formsaveoreditbanner" v-model="validEditPromo">
      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> {{ isEdit ? 'Editar ': 'Nuevo' }} banner </span>
          <v-spacer></v-spacer>
         
        </v-card-title>

        <v-img
          max-height="210"
          v-if="appBanner.url"
          :src="appBanner.url"
          aspect-ratio="1.7"
          contain
        ></v-img>

        <v-card-text>
          <v-divider class="mb-2"></v-divider>
            <v-row dense>
                <v-col cols="12" md="12">
                    <v-file-input
                        v-model="attachBannerImage"
                        color="primary accent-4"
                        label="Imagen del banner"
                        placeholder="Clic aquí para adjuntar"
                        outlined
                        prepend-icon
                        prepend-inner-icon="mdi-paperclip"
                        hide-details
                        :show-size="1000"
                        @change="fileChanged"
                    >
                        <template v-slot:selection="{ index, text }">
                            <v-chip
                            v-if="index < 2"
                            color="primary accent-4"
                            dark
                            label
                            small
                            >
                            {{ text }}
                            </v-chip>
                        </template>
                    </v-file-input>
                </v-col>

                <v-col cols="12" md="6">
                     <v-select
                        v-model="appBanner.zone"
                        :items="zones"
                        :rules="zoneRules"
                        label="Ciudades / Zonas"
                        outlined
                        item-text="attributes.name"
                        item-value="id"
                        hide-details
                    ></v-select>
                </v-col>

                <v-col cols="12" md="6">
                   <v-text-field
                      v-model="appBanner.title"
                      :rules="titleRules"
                      outlined
                      label="Título"
                      prepend-inner-icon="mdi-format-title"
                      hide-details
                    ></v-text-field>
                </v-col>

                <v-col cols="12" md="6">
                   <v-text-field
                      v-model="appBanner.superCategory"
                      :rules="superCatRules"
                      outlined
                      label="Super categoría"
                      prepend-inner-icon="mdi-tag-text"
                      hide-details
                    ></v-text-field>
                </v-col>

                <v-col cols="12" md="6">
                   <v-text-field
                      v-model="appBanner.type"
                      :rules="typeRules"
                      outlined
                      label="Tipo"
                      prepend-inner-icon="mdi-filter-check"
                      hide-details
                    ></v-text-field>
                </v-col>

                <v-col cols="12">
                     <v-textarea
                      v-model="appBanner.data"
                      outlined
                      name="input-7-4"
                      label="Configuración del banner (JSON)"
                      hide-details
                      auto-grow
                      rows="1"
                    ></v-textarea>
                </v-col>

                <v-col cols="12" md="12">
                    <v-switch v-model="appBanner.status" inset color="success" false-value="inactive" true-value="active" :label="`Activo`" hide-details></v-switch>
                </v-col>

            </v-row>

        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-btn
            color="primary"
            outlined
            @click="close()"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
           <v-btn
            color="success"
            outlined
            @click="saveOrEditAppBanner()"
          >
           <v-icon left>mdi-content-save-outline</v-icon> Guardar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Edit appBanner -->

  </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    
    components: {
    },

    data() {
        return {
            banners: [],
            loading: true,
            search: '',
            datenow: '',
            appBanner: {
                id: '',
                zone: '',
                title: '',
                url: '',
                superCategory: '',
                type: 'default',
                data: '',
                status: 'active',
            },
            saveOrEditBannerDialog: false,
            isEdit: false,
            menu: false,
            validEditPromo: true,
            urlRules: [v => !!v || "Url es requerido"],
            zoneRules: [v => !!v || "La ciudad es requerida"],
            titleRules: [v => !!v || "Título es requerido"],
            superCatRules: [v => !!v || "Super categoría es requerida"],
            typeRules: [v => !!v || "Tipo es requerido"],
            headers: [
                //{ text: 'ID', align: 'left', value: 'id' },

                { text: 'Imagen', align: 'left', value: 'attributes.url' },
                { text: 'Zona', align: 'left', value: 'attributes.zone.attributes.name' },
                { text: 'Título', align: 'left', value: 'attributes.title' },
                { text: 'Super categoría', align: 'left', value: 'attributes.superCategory' },
                { text: 'Tipo', align: 'left', value: 'attributes.type' },
                { text: 'Status', align: 'left', value: 'attributes.status' },
                { text: 'Fecha', align: 'left', value: 'attributes.createdAt' },

                { text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            dialogFilterOrders: false,
            validFilter: false,
            sourceOption: "all",
            dates: [],
            zones: [],
            attachBannerImage: [],
            frResultAttachBanner: ''
        }
    },

    mounted() {
        this.interval = setInterval(this.time, 1000);
        this.initialize();
        this.getZones()
    },

    destroyed() {
        clearInterval(this.interval);
    },

    computed: {
    },

    methods: {

        async initialize(){
            let params = {}
            try {
                let banners = await Parse.Cloud.run("getAppBannersBO", params);
                this.banners = banners;
                //eslint-disable-next-line
                //console.log(this.banners);
                this.loading = false;
            } catch (error) {
                this.$snotify.error(`${error}`, "Banners", {
                timeout: 4000,
                preventDuplicates: true
                });
            }
        },

        time(){
            this.datenow = this.$moment()
        },

        async changeStatusBanner(item){
            
            try {
                let params = {
                    id: item.id
                }

                this.loading = true
                await Parse.Cloud.run("changeStatusAppBannerBO", params);
                
                this.loading = false

                this.$snotify.success(`Se ha cambiado el estado del banner ${item.attributes.code}` , 'Cambio de estado', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            
            } catch (error) {
                this.$snotify.error(`${error}` , 'Banner', {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        detailBanner(item){
            //eslint-disable-next-line
            console.log(item);
        },

        openModalSaveOrEdit(edit = false, item = ''){
            this.isEdit = edit
            if (item) {
                this.appBanner = {
                    id           : item.id,
                    zone         : item.attributes.zone.id,
                    title        : item.attributes.title,
                    url          : item.attributes.url,
                    superCategory: item.attributes.superCategory,
                    type         : item.attributes.type,
                    data         : JSON.stringify(item.attributes.data),
                    status       : item.attributes.status
                }
            }
            this.attachBannerImage = []
            this.frResultAttachBanner = ''
            this.saveOrEditBannerDialog = true
        },

        close(){
            this.saveOrEditBannerDialog = false
            this.isEdit = false
            this.appBanner = {
                id: '',
                zone: '',
                title: '',
                url: '',
                superCategory: '',
                type: 'default',
                data: '',
                status: 'active'
            }
        },

        async saveOrEditAppBanner(){
            if (!this.$refs.formsaveoreditbanner.validate()) {
                this.$snotify.error(`Todos los campos son requeridos.` , 'Banner', {
                    timeout: 4000,
                    preventDuplicates: true
                });
                return;
            }
            let params = {
                id           : this.appBanner.id,
                zone         : this.appBanner.zone,
                title        : this.appBanner.title,
                url          : this.attachBannerImage ? this.attachBannerImage.length == 0 ? this.appBanner.url ?  this.appBanner.url : '' : this.attachBannerImage.type ? await this.uploadAttachBannerImage() : '' : '',
                superCategory: this.appBanner.superCategory,
                type         : this.appBanner.type,
                data         : this.appBanner.data ? JSON.parse(this.appBanner.data) : '',
                status       : this.appBanner.status
            }

            if (!params.url ) {
                this.$snotify.error(`La imagen del banner no se ha adjuntado por favor verifica y vuelve a intentarlo` , 'Banner', {
                  timeout: 4000,
                  preventDuplicates: true
                });
                return;
            }

            try {
                if (this.isEdit) {
                    await Parse.Cloud.run("editAppBannerBO", params);
                }else{
                    await Parse.Cloud.run("newAppBannerBO", params);
                }
                
                //eslint-disable-next-line
                //console.log(this.banners);
                this.$snotify.success(`Se ha ${this.isEdit ? 'editado' : 'guardado'} correctamente.` , 'Banner', {
                    timeout: 4000,
                    preventDuplicates: true
                });
                this.close();
                this.initialize();
            } catch (error) {
                this.$snotify.error(`${error}`, "Banner", {
                timeout: 4000,
                preventDuplicates: true
                });
            }
        },

        openImageUrl(item) {
            window.open(item.attributes.rider.attributes.photoUrl, "_blank");
        },

        async getZones(){
            try {
                let zones = await Parse.Cloud.run("getAppConfigWhitoutLocation");
                this.zones = zones;
            } catch (error) {
                    this.$snotify.error(`${error}`, "Ciudades", {
                    timeout: 4000,
                    preventDuplicates: true
                });
            }
        },

        async uploadAttachBannerImage(){
            let simge = this.frResultAttachBanner.split(",");
            simge = simge[1];
            var parseFile = new Parse.File(
                "paymentOrder",
                { base64: simge },
                this.attachBannerImage.type
            );
            let file = await parseFile.save(null);
            return file._url
        },

        fileChanged(file) {
            if (file) {
                const fr = new FileReader();
                if (file) {
                fr.readAsDataURL(file);
                fr.addEventListener("load", () => {
                    //eslint-disable-next-line
                    //console.log(fr.result);
                    this.frResultAttachBanner = fr.result;
                });
                }
            }
        },
    },
}
</script>