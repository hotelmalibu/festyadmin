<template>
 <v-container fluid>
   <v-card flat>
    <v-toolbar
      color="#f0e633"
      dark
      extended
      flat
    >
      <!--<v-app-bar-nav-icon></v-app-bar-nav-icon>-->
    </v-toolbar>

    <v-card
      class="mx-auto"
      max-width="1000"
      style="margin-top: -64px;"
      :loading="loading"
      v-if="logsStore"
    >
      <v-toolbar flat>
        <v-toolbar-title class="black--text">Logs <strong v-if="store"> ({{store.attributes.name}}) </strong></v-toolbar-title>

        <v-spacer></v-spacer>

        <v-btn color="black" class="mb-2 mr-2 white--text" @click="dialogSuspend = true"> <v-icon left>mdi-close-circle</v-icon> Suspender comercio</v-btn>

      </v-toolbar>

      <v-divider></v-divider>

      <v-card-text>

        <v-data-table
            :loading="loading"
            loading-text="Cargando... Por favor espere"
            :headers="headers"
            :items="logsStore"
            :search="search"
            :footer-props="pagination"
            :header-props="{
              sortByText: 'Ordenar por'
            }"
            class="elevation-1"
        >
            <template v-slot:top>
            <v-toolbar flat color="white">
                <!--<v-toolbar-title>PAGOS</v-toolbar-title>-->
                <v-spacer></v-spacer>
                 <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar.."
                    single-line
                    hide-details
                    class="d-print-none mr-2"
                ></v-text-field>
                <!--<v-btn color="black" dark class="mb-2" @click="createBillingForStores()">Generar facturas</v-btn>-->
            </v-toolbar>
            </template>

            <template v-slot:item.attributes.update_type="{ item }">
              <v-chip
                class="text-center justify-center"
                style="width: 100%;"
                v-if="item.attributes.update_type === 'status_to_confirmation'"
                color="success"
                small
                outlined
              >
                Confirmado
              </v-chip>
              <v-chip
                class="text-center justify-center"
                style="width: 100%;"
                v-else-if="item.attributes.update_type === 'status_to_suspended'"
                color="error"
                small
                outlined
              >
                Suspendido
              </v-chip>
              <v-chip
                class="text-center justify-center"
                style="width: 100%;"
                v-else
                color="info"
                small
                outlined
              >
                {{item.attributes.update_type}}
              </v-chip>
            </template>

            <template v-slot:item.attributes.createdAt="{ item }">
                {{$moment(item.attributes.createdAt).format('lll')}}
            </template>

            <template v-slot:item.attributes.updatedAt="{ item }">
                {{$moment(item.attributes.updatedAt).format('lll')}}
            </template>

            <!--<template v-slot:item.action="{ item }">
            <v-icon
                class="mr-2"
                @click="sendInvoice(item)"
            >
                mdi-email-send-outline
            </v-icon>
            </template>-->
            <template v-slot:no-data>
            <v-btn color="primary" @click="initialize">RECARGAR</v-btn>
            </template>
        </v-data-table>

      </v-card-text>
    </v-card>
  </v-card>

  <!-- Dialogo Confirm change -->
    <v-dialog
      v-model="dialogSuspend"
      width="450"
      scrollable
    >

        <v-form
          ref="form"
          v-model="valid"
        >

      <v-card>
        <v-card-title
          class="title grey lighten-3"
          primary-title
        >
          <span class="text-capitalize"> Suspender comercio  </span>
          <v-spacer></v-spacer>
        </v-card-title>

        <v-card-text>
          <div class="mb-2"></div>
          <h3 class="mb-2">¿Esta seguro que desea suspender el comercio?</h3>
          <v-textarea
            v-model="notes"
            outlined
            name="input-7-4"
            label="Motivo de suspención"
            placeholder="Escriba el motivo por el cual el comercio será suspendido"
            hide-details
            auto-grow
            rows="2"
         ></v-textarea>
          
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          
          <v-btn
            color="primary"
            outlined
            @click="dialogSuspend = false"
          >
           <v-icon left>mdi-close</v-icon> Cerrar
          </v-btn>
          <v-spacer></v-spacer>
          <v-btn
            color="green"
            dark
            outlined
            @click="suspendStore()"
          >
           <v-icon left>mdi-content-save</v-icon> Suspender
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
    </v-dialog>
    <!-- *End* Dialogo Confirm change -->


  </v-container>
</template>

<script>
import Parse from 'parse'

export default {
    
    components: {

    },

    data() {
        return {
            logsStore: [],
            loading: true,
            search: '',
            headers: [
                { text: 'ID', align: 'left', value: 'id' },
                { text: 'Status', align: 'left', value: 'attributes.update_type' },
                { text: 'Fecha creación', align: 'left', value: 'attributes.createdAt' },
                { text: 'Notas', align: 'left', value: 'attributes.notes' },
                //{ text: 'Fecha modificación', align: 'left', value: 'attributes.updatedAt' },
              //{ text: 'Acciones', align: 'left', value: 'action', sortable: false },
            ],
            pagination: {
                "items-per-page-options": [50, 60, 70, 100, -1],
                "items-per-page-text": 'Items por página'
            },
            store: '',
            dialogSuspend: false,
            valid: false,
            notes: ''
        }
    },

    mounted() {
        this.initialize();
    },

    computed: {

    },

    methods: {

        async initialize(){

            let params = {
              id: this.$route.params.store_id
            };

            try {
                let logsStore = await Parse.Cloud.run("getLogStore", params);
                this.logsStore = logsStore;
                //eslint-disable-next-line
                //console.log(logsStore);
                if (this.logsStore.length > 0) {
                  this.store = this.logsStore[0].attributes.store
                }

                this.loading = false;

            } catch (error) {
                this.$snotify.error(`${error}`, "Logs", {
                timeout: 4000,
                preventDuplicates: true
                });
            }

        },

        async suspendStore(){
          try {
            let params = {
              id: this.$route.params.store_id,
              notes: this.notes
            };
            await Parse.Cloud.run("suspendStoreBO", params);
            this.dialogSuspend = false
            this.initialize();
          } catch (error) {
            this.$snotify.error(`${error}`, "Suspender", {
                timeout: 4000,
                preventDuplicates: true
            });
          }
          
        }

    },
}
</script>