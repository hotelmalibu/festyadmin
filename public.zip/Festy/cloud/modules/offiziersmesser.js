
//stores
Parse.Cloud.define("getStoreOrders", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.storeId;
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("promoCode");
        query.equalTo("status", status);
        query.limit(300);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreReviews", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.storeId;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.greaterThanOrEqualTo("rating", 0);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("promoCode");
        query.limit(500);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStores", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        let stores = await query.find({ useMasterKey: true });
        return stores;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        return store;
    } else {
        return null;
    }
});

Parse.Cloud.define("updatePromo", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var name = request.params.name;
        var description = request.params.description;
        var price = request.params.price;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;

        var comboOption = request.params.comboOption;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;

        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("name", name);
        promotion.set("description", description);
        promotion.set("price", price);
        promotion.set("category", category);
        promotion.set("deliveryCost", deliveryCost);
        promotion.set("comboOption", comboOption);
        promotion.set("comboPrice", comboPrice);
        promotion.set("comboNotes", comboNotes);
        let result = promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updatePromoPhoto", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var imageUrl = request.params.imageUrl;
        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("imageUrl", imageUrl);
        let result = promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});



Parse.Cloud.define("newPromo", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.storeId;
        var name = request.params.name;
        var imageUrl = request.params.imageUrl;
        var description = request.params.description;
        var price = request.params.price;
        var status = request.params.status;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;
        var comboOption = request.params.comboOption;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;

        var PromotionClass = Parse.Object.extend("Product");
        var promotion = new PromotionClass()
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });
        if (store) {
            promotion.set("name", name);
            promotion.set("description", description);
            promotion.set("price", price);
            promotion.set("imageUrl", imageUrl);
            promotion.set("store", store);
            promotion.set("likes", 0);
            promotion.set("views", 0);
            promotion.set("orders", 0);
            promotion.set("status", status);
            promotion.set("category", category);
            promotion.set("location", store.get("location"));
            promotion.set("deliveryCost", deliveryCost);
            promotion.set("comboOption", comboOption);
            promotion.set("comboPrice", comboPrice);
            promotion.set("comboNotes", comboNotes);
            let result = promotion.save(null, { useMasterKey: true });
            if (result) {
                /*   //now we send a push
                  var jsonBody = {
                      app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                      small_icon: "ic_notification",
                      large_icon: "ic_big_icon",
                      android_accent_color: "f4e828",
                      big_picture: imageUrl,
                      contents: { en: name + " De: " + store.get("name") + ", entra y mira que hay de nuevo en Festy." },
                      headings: { en: "Nueva promoción disponible!" },
                      buttons: [{ "id": "viewPromo", "text": "VER PROMOCIÓN", "icon": "" }],
                      data: {},
                      priority: 10,
                      included_segments: ["All"],
                      delayed_option: "last-active"
                  };
  
                  Parse.Cloud.httpRequest({
                      method: "POST",
                      url: "https://onesignal.com/api/v1/notifications",
                      headers: {
                          "Content-Type": "application/json;charset=utf-8",
                          "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                      },
                      body: JSON.stringify(jsonBody)
                  }).then(function (httpResponse) {
                      console.log(httpResponse.text);
                  }, function (httpResponse) {
                      console.error('Request failed with response code ' + httpResponse.status);
                  }); */
            }
            return result;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("updatePromoStatus", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("status", status);
        let result = promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStorePhoto", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var logoUrl = request.params.logoUrl;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("logoUrl", logoUrl);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStoreStatus", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        var StoreClass = Parse.Object.extend("Store");
        var StoreUpdateClass = Parse.Object.extend("StoreUpdate");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("status", status);
        let result = store.save(null, { useMasterKey: true });
        var storeUpdateItem = new StoreUpdateClass();
        storeUpdateItem.set("store", store);
        storeUpdateItem.set("update_type", "status_to_" + status);
        storeUpdateItem.set("editor", currentUser.id);
        storeUpdateItem.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStoreLocation", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var latitude = request.params.latitude;
        var longitude = request.params.longitude;
        var geoPoint = new Parse.GeoPoint({ latitude: latitude, longitude: longitude });
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        if (store) {
            store.set("location", geoPoint);
            let result = store.save(null, { useMasterKey: true });
            return result;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var name = request.params.name;
        var description = request.params.description;
        var address = request.params.address;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("name", name);
        store.set("description", description);
        store.set("address", address);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("createStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var geoPoint = new Parse.GeoPoint({ latitude: request.params.latitude, longitude: request.params.longitude });
        var logoUrl = request.params.logoUrl;
        var name = request.params.name;
        var description = request.params.description;
        var address = request.params.address;
        var StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass()
        store.set("logoUrl", logoUrl);
        store.set("name", name);
        store.set("description", description);
        store.set("status", "created");
        store.set("owner", currentUser);
        store.set("likes", 0);
        store.set("views", 0);
        store.set("address", address);
        store.set("location", geoPoint);
        let result = store.save(null, { useMasterKey: true });
        if (result) {
            currentUser.set("store", true);
            currentUser.save(null, { useMasterKey: true });
        }
        return result;
    }
});
