var moment = require('moment');

//for BO
Parse.Cloud.define("getAllStoresOrdersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("store.owner");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoresOrdersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.equalTo("status", status);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        let order = await query.get(id, { useMasterKey: true });
        return order;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreOrdersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.storeId;
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.equalTo("status", status);
        query.limit(300);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});


Parse.Cloud.define("cancelOrderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var notes = request.params.notes;
        let silent_mode = request.params.silent_mode;

        var OrderClass = Parse.Object.extend("Order");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var query = new Parse.Query(OrderClass);
        query.include("store");
        let order = await query.get(id, { useMasterKey: true });
        order.set("status", "cancelled");
        let result = order.save(null, { useMasterKey: true });
        if (result) {
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", "cancelled");
            orderUpdateItem.set("notes", notes);
            orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
            orderUpdateItem.save(null, { useMasterKey: true });

            if (!silent_mode) {
                //now we send a push
                var jsonBody = {
                    app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                    small_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: "Su pedido no puede ser procesado y ha sido cancelado" },
                    headings: { en: order.get("store").get("name") },
                    priority: 10,
                    android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                    include_external_user_ids: [order.get("owner").id]
                };
    
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
                });
            }

            return true;
        }
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyNewOrderStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var order_id = request.params.order_id;
        var user_name = request.params.user_name;
        var user_id = request.params.user_id;
        var store_id = request.params.store_id;
        var orderResumeText = request.params.orderResumeText;
        try {
            let pushMessage = "De: " + user_name + " " + orderResumeText;
            //now we send a push
            var jsonBody = {
                app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                small_icon: "ic_notification",
                large_icon: "ic_big_icon",
                android_accent_color: "f4e828",
                contents: { en: pushMessage },
                headings: { en: "Nuevo pedido Recibido!" },
                android_sound: "bell_sound",
                android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                channel_for_external_user_ids: "push",
                data: { "newOrder": true, "identifier": order_id, "printIfCan": false },
                priority: 10,
                ttl: 900,
                include_external_user_ids: [store_id, user_id]
            };
            Parse.Cloud.httpRequest({
                method: "POST",
                url: "https://onesignal.com/api/v1/notifications",
                headers: {
                    "Content-Type": "application/json;charset=utf-8",
                    "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                },
                body: JSON.stringify(jsonBody)
            }).then(function (httpResponse) {
                console.log(httpResponse.text);
                //logToSlack2("orderv1-push result: " + httpResponse.text)
            }, function (httpResponse) {
                console.error('Request failed with response code ' + httpResponse.status);
                logToSlack2("orderv1-push error result: " + httpResponse.text)
            });
            //now we notify support team via slack
            //let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + total + " , descuento: " + discount;
            //logToSlack2(slackMessage)
        } catch (error) {

        }
        return true;
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyNewOrderRiderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var order_id = request.params.order_id;
        var store_name = request.params.store_name;
        var rider_id = request.params.rider_id;
        if (order_id && store_name && rider_id) {  
            try {
                var riderPushBody = {
                    app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
                    small_icon: "ic_notification",
                    android_accent_color: "f4e828",
                    contents: { en: "Nuevo pedido asignado para entrega" },
                    headings: { en: store_name },
                    data: { newAssignment: order_id },
                    buttons: [{ id: "view", text: "VER PEDIDO", icon: "" }],
                    priority: 10,
                    android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
                    include_external_user_ids: [rider_id]
                };
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        Authorization: "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
                    },
                    body: JSON.stringify(riderPushBody)
                }).then(
                    function (httpResponse) {
                        console.log(httpResponse.text);
                    },
                    function (httpResponse) {
                        console.error(
                            "Request failed with response code " +
                            httpResponse.status +
                            " : " +
                            httpResponse.text
                        );
                    }
                );
            } catch (error) {
                return error;
            }
        }
        return true;
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var title = request.params.title;
        var message = request.params.message;
        var recipient = request.params.recipient;
        var store_id = request.params.store_id;

        var app_url = request.params.app_url;
        var delayed_option = request.params.delayed_option;

        //now we send a push
        var jsonBody = {
            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
            small_icon: "ic_notification",
            large_icon: "ic_big_icon",
            android_accent_color: "f4e828",
            contents: { en: message },
            headings: { en: title },
            android_sound: "notification",
            android_channel_id: "962d9d5a-97fa-493b-a60d-4c37fa0c1c68",
            channel_for_external_user_ids: "push",
            priority: 10,
            include_external_user_ids: [recipient, store_id]
        };

        if (app_url) {
            jsonBody.app_url = app_url
        }

        if (delayed_option) {
            jsonBody.delayed_option = delayed_option
        }

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            logToSlack2(`PUSH -> Title: ["${title}"] - Message: ${message}`)
            logToSlack2(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status);
        });
        return true;
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyStoreClientBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var title = request.params.title;
        var message = request.params.message;
        var ids = request.params.ids;

        var app_url = request.params.app_url;
        var delayed_option = request.params.delayed_option;

        //now we send a push
        var jsonBody = {
            app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
            small_icon: "ic_notification",
            large_icon: "ic_big_icon",
            android_accent_color: "f4e828",
            contents: { en: message },
            headings: { en: title },
            android_sound: "notification",
            android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
            priority: 10,
            include_external_user_ids: ids
        };

        if (app_url) {
            jsonBody.app_url = app_url
        }

        if (delayed_option) {
            jsonBody.delayed_option = delayed_option
        }

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            //logToSlack2(`PUSH -> Title: ["${title}"] - Message: ${message}`)
            //logToSlack2(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status);
        });
        return true;
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyUserBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var title = request.params.title;
        var message = request.params.message;
        var recipient = request.params.recipient;

        var app_url = request.params.app_url;
        var delayed_option = request.params.delayed_option;

        //now we send a push
        var jsonBody = {
            app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
            small_icon: "ic_notification",            
            android_accent_color: "f4e828",
            contents: { en: message },
            headings: { en: title },            
            android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
            priority: 10,
            include_external_user_ids: [recipient]
        };

        if (app_url) {
            jsonBody.app_url = app_url
        }

        if (delayed_option) {
            jsonBody.delayed_option = delayed_option
        }

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            //logToSlack2(`PUSH -> Title: ["${title}"] - Message: ${message}`)
            //logToSlack2(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
        });

        return true;
    } else {
        return false;
    }
});

Parse.Cloud.define("notifyRiderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var title = request.params.title;
        var message = request.params.message;
        var recipient = request.params.recipient;
        //now we send a push
        var jsonBody = {
            app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
            small_icon: "ic_notification",            
            android_accent_color: "f4e828",
            contents: { en: message },
            headings: { en: title },            
            android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
            priority: 10,
            include_external_user_ids: [recipient]
        };

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            //logToSlack2(`PUSH -> Title: ["${title}"] - Message: ${message}`)
            //logToSlack2(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
        });

        return true;
    } else {
        return false;
    }
});

/**
 * For Backoffice
 */

Parse.Cloud.define("getStoresBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('plan');
        query.limit(5000)
        //query.equalTo("owner", currentUser);
        let stores = await query.find({ useMasterKey: true });
        return stores;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('owner')
        query.include('plan')
        //query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        return store;
    } else {
        return null;
    }
});

/*Parse.Cloud.define("getMyStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('owner')
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        return store;
    } else {
        return null;
    }
});*/

Parse.Cloud.define("getOrdersByStoreBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        
        let date = new Date();
        let initDate = new Date(date.getFullYear(), date.getMonth(), 1);
        let endDate = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        endDate.setHours(23,59,59,999);

        initDate.setHours(initDate.getHours() + 5);
        initDate = new Date(initDate);

        endDate.setHours(endDate.getHours() + 5);
        endDate = new Date(endDate);

        let withCancelled = request.params.withCancelled || false;
        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass()
        store.id = id
        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.equalTo("store", store);
        query.greaterThanOrEqualTo("createdAt", initDate)
        query.lessThanOrEqualTo("createdAt", endDate);
        query.descending("createdAt");
        if (!withCancelled) {
            query.notEqualTo("status", 'cancelled');
        }
        query.limit(500);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrdersByStoreFilterBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let init = new Date(request.params.init);
        let end = new Date(request.params.end);
        let status = request.params.status;
        let source = request.params.source;

        init.setHours(init.getHours() + 5);
        init = new Date(init);
        
        end.setHours(23,59,59,999);
        end.setHours(end.getHours() + 5);
        end = new Date(end);

        //logToSlack2('StartDate: ' + init.toString())
        //logToSlack2('EndDate: ' + end.toString())

        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass()
        store.id = id
        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.equalTo("store", store);
        
        query.greaterThanOrEqualTo("createdAt", init)
        query.lessThanOrEqualTo("createdAt", end);
        
        if (status) {
            query.equalTo("status", status);
        }else{
            query.notEqualTo("status", 'cancelled');
        }

        if (source && source != 'all') {
            query.equalTo("source", source);
        }
        query.descending("createdAt");
        query.limit(10000);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getInvocesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        //queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var InvoiceClass = Parse.Object.extend("Invoice");
        var query = new Parse.Query(InvoiceClass);
        query.equalTo("store", store);
        let invoices = await query.find({ useMasterKey: true });
        return invoices;
    } else {
        return null;
    }
});

Parse.Cloud.define("getInvoceBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var InvoiceClass = Parse.Object.extend("Invoice");
        var query = new Parse.Query(InvoiceClass);
        query.include(['store.plan'])
        let invoice = await query.get(id, { useMasterKey: true });
        return invoice;
    } else {
        return null;
    }
});

Parse.Cloud.define("getProductsBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        //queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(ProductClass);
        query.include('productCategory');
        query.equalTo("store", store);
        let products = await query.find({ useMasterKey: true });
        return products;
    } else {
        return null;
    }
});

Parse.Cloud.define("getCategoriesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        //queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        var query = new Parse.Query(ProductCategoryClass);
        query.equalTo("store", store);
        query.ascending('index');
        let categories = await query.find({ useMasterKey: true });
        return categories;
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyCategoriesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        var query = new Parse.Query(ProductCategoryClass);
        query.equalTo("store", store);
        query.ascending('index');
        let categories = await query.find({ useMasterKey: true });
        return categories;
    } else {
        return null;
    }
});

Parse.Cloud.define("newOrEditCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var storeId = request.params.storeId;
        var index = request.params.index;
        var name = request.params.name;
        var color = request.params.color;
        //var status = request.params.status;
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        var category = ''
        if (id) {
            var queryCategory = new Parse.Query(ProductCategoryClass);
            category = await queryCategory.get(id, { useMasterKey: true });
        }else{
            category = new ProductCategoryClass()
        }
        
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });

        if (store) {
            category.set("index", Number(index));
            category.set("name", name);
            category.set("color", color);
            category.set("status", id ? category.attributes.status : 'enabled');
            category.set("store", store);
            let result = category.save(null, { useMasterKey: true });
            return result;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getMyStoresBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        let stores = await query.find({ useMasterKey: true });
        return stores;
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('owner')
        query.include('plan')
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        return store;
    } else {
        return null;
    }
});

Parse.Cloud.define("getPublicStoreBO", async request => {
    var id = request.params.id;
    
    var queryByObjectId = new Parse.Query('Store');
    queryByObjectId.equalTo("objectId", id);

    var queryBySlug = new Parse.Query('Store');
    queryBySlug.equalTo("slug", id);
    
    let masterQuery = Parse.Query.or(queryByObjectId, queryBySlug);
    let store = await masterQuery.find({ useMasterKey: true });
    return store;
});

Parse.Cloud.define("getMyInvocesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var InvoiceClass = Parse.Object.extend("Invoice");
        var query = new Parse.Query(InvoiceClass);
        query.include('payment')
        query.equalTo("store", store);
        let invoices = await query.find({ useMasterKey: true });
        return invoices;
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyInvoceBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var store_id = request.params.store_id;
        
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(store_id, { useMasterKey: true });

        var InvoiceClass = Parse.Object.extend("Invoice");
        var query = new Parse.Query(InvoiceClass);
        query.include('payment')
        query.include(['store.plan'])
        query.equalTo("store", store);
        let invoice = await query.get(id, { useMasterKey: true });
        return invoice;
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyProductsBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(ProductClass);
        query.equalTo("store", store);
        if (status) {
            query.equalTo("status", status);
        }
        let produccts = await query.find({ useMasterKey: true });
        return produccts;
    } else {
        return null;
    }
});

Parse.Cloud.define("getPublicProductsBO", async request => {
    var id = request.params.id;
    
    var queryByObjectId = new Parse.Query('Store');
    queryByObjectId.equalTo("objectId", id);
    var queryBySlug = new Parse.Query('Store');
    queryBySlug.equalTo("slug", id);
    let masterQuery = Parse.Query.or(queryByObjectId, queryBySlug);
    let store = await masterQuery.find({ useMasterKey: true });
    
    var ProductClass = Parse.Object.extend("Product");
    var query = new Parse.Query(ProductClass);
    query.equalTo("store", store[0]);
    query.equalTo("status", 'active');
    query.descending('featured')
    let produccts = await query.find({ useMasterKey: true });
    return produccts;
});

Parse.Cloud.define("activeStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var city = request.params.city;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        //query.equalTo("owner", currentUser);
        query.include('owner');
        let store = await query.get(id, { useMasterKey: true });
        store.set('status', store.attributes.status === 'inactive' ? 'active' : 'inactive');
        store.set('city', store.attributes.city ? store.attributes.city : city);
        store.set('phone', store.attributes.phone ? store.attributes.phone : store.attributes.owner.attributes.phone);
        let store_update = store.save(null, { useMasterKey: true });
        return store_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("changeStatusStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        //query.equalTo("owner", currentUser);
        query.include('owner');
        let store = await query.get(id, { useMasterKey: true });
        store.set('status', store.attributes.status === 'inactive' ? 'active' : 'inactive');
        let status = store.attributes.status === 'active' ? true : false;
        let owner_id = store.get("owner").id
        let store_update = store.save(null, { useMasterKey: true });
        let store_id = store.id
        
        //now we send a push
        var jsonBody = {
            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
            small_icon: "ic_notification",
            large_icon: "ic_big_icon",
            android_accent_color: "f4e828",
            contents: { en: "Tu estado a cambiado" },
            headings: { en: "Para ver más , abre Fest y ve a INFO" },
            //android_sound: "bell_sound",
            android_channel_id: "962d9d5a-97fa-493b-a60d-4c37fa0c1c68",
            channel_for_external_user_ids: "push",
            data: {
                "store_status_changed": true,
                "open": status
            },
            priority: 10,
            include_external_user_ids: [owner_id, store_id]
        };
        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status);
        });

        return store_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("suspendStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var notes = request.params.notes;

        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        //query.equalTo("owner", currentUser);
        query.include('owner');
        let store = await query.get(id, { useMasterKey: true });
        store.set('status', 'created');
        let store_update = store.save(null, { useMasterKey: true });

        var StoreUpdateClass = Parse.Object.extend("StoreUpdate");
        var storeUpdateItem = new StoreUpdateClass();
        storeUpdateItem.set("store", store);
        storeUpdateItem.set("update_type", "status_to_suspended");
        storeUpdateItem.set("editor", currentUser.id);
        storeUpdateItem.set("notes", notes);
        await storeUpdateItem.save(null, { useMasterKey: true });

        return store_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("getLogStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            var id = request.params.id;
            var StoreClass = Parse.Object.extend("Store");
            var store = new StoreClass();
            store.id = id
            
            var StoreUpdateClass = Parse.Object.extend("StoreUpdate");
            var query = new Parse.Query(StoreUpdateClass);
            query.include('store')
            query.equalTo('store', store)
            //query.containedIn('update_type', ['status_to_confirmation', 'status_to_suspended'])
            query.descending('createdAt')
            let logs = await query.find({ useMasterKey: true });
            return logs;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("changeStatusProduct", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(ProductClass);
        //query.equalTo("owner", currentUser);
        let product = await query.get(id, { useMasterKey: true });
        product.set('status', product.attributes.status === 'inactive' ? 'active' : 'inactive')
        let product_update = product.save(null, { useMasterKey: true });
        return product_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("changeStatusCategory", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        var query = new Parse.Query(ProductCategoryClass);
        //query.equalTo("owner", currentUser);
        let category = await query.get(id, { useMasterKey: true });
        category.set('status', category.attributes.status === 'desabled' ? 'enabled' : 'desabled')
        let category_update = category.save(null, { useMasterKey: true });
        return category_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("editIndexCategory", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        let newIndex = request.params.newIndex
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        var query = new Parse.Query(ProductCategoryClass);
        //query.equalTo("owner", currentUser);
        let category = await query.get(id, { useMasterKey: true });
        category.set('index', newIndex)
        let category_update = category.save(null, { useMasterKey: true });
        return category_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("changeFectureProduct", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(ProductClass);
        //query.equalTo("owner", currentUser);
        let product = await query.get(id, { useMasterKey: true });
        product.set('featured', product.attributes.featured == false ? true : false)
        let product_update = product.save(null, { useMasterKey: true });
        return product_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("generateMonthlyInvoicesBO", async request => {

    let currentUser = request.user;
    if (currentUser) {
        /*
        1. get stores
        2. get order by store
        3 .calculate and generate invoice 
        - generar la factura por periodo
        - no generar doble facturación en un mes
        - tener en cuenta el valor del plan para sumarlo
        - Tener en cuenta el saldo a favor para restarselo en la factura del siguiente mes.
        
        Formula:
        ((numero de ordenes * comision por orden) + cargo básico) - descuento o promocode
        */

        var store_ids = request.params.store_ids;
        var noDiscountApplies = request.params.noDiscountApplies;

        let StoreClass = Parse.Object.extend("Store");
        let query = new Parse.Query(StoreClass);
        query.include('plan')
        if (store_ids && store_ids.length > 0) {
            query.containedIn("objectId", store_ids)
        }
        let stores = await query.find({ useMasterKey: true });
        
        if (stores) {

            for (let index = 0; index < stores.length; index++) {
                const store = stores[index];
                
                if (store.attributes.plan) {
                    let date = new Date();
                    let initDate = new Date(date.getFullYear(), Number.isInteger(request.params.month) ? request.params.month : date.getMonth(), 1);
                    let endDate = new Date(date.getFullYear(), (Number.isInteger(request.params.month) ? request.params.month : date.getMonth()) + 1, 0);
                    endDate.setHours(23,59,59,999);

                    initDate.setHours(initDate.getHours() + 5);
                    initDate = new Date(initDate);

                    endDate.setHours(endDate.getHours() + 5);
                    endDate = new Date(endDate);

                    let order_price = store.attributes.plan.attributes.order_price ? store.attributes.plan.attributes.order_price : 0
                    let base_cost = store.attributes.plan.attributes.base_cost ? store.attributes.plan.attributes.base_cost : 0
                    let total_orders_number = 0
                    let discount_or_promocodes_total = 0

                    let OrderClass = Parse.Object.extend("Order");
                    let queryOrders = new Parse.Query(OrderClass);
                    queryOrders.equalTo("store", store);
                    queryOrders.greaterThanOrEqualTo("createdAt", initDate)
                    queryOrders.lessThanOrEqualTo("createdAt", endDate);
                    queryOrders.notEqualTo("source", 'pos');
                    queryOrders.equalTo("status", 'delivered');
                    queryOrders.limit(10000)
                    try {
                        let orders = await queryOrders.find({ useMasterKey: true });
                        if (orders.length > 0) {
                            total_orders_number = orders.filter(order => (order.attributes.total -  order.attributes.deliveryCost) > 10000).length
                            discount_or_promocodes_total = orders.reduce((a, b) => a + b.attributes.discount, 0);
                        }

                        const subTotal = (total_orders_number * order_price)+base_cost
                        const total = noDiscountApplies ? subTotal : subTotal - discount_or_promocodes_total
                        const iva = (total * store.attributes.plan.attributes.tax)

                        let InvoiceClass = Parse.Object.extend("Invoice");
                        let invoice = new InvoiceClass();

                        /*initDate.setHours(initDate.getHours() + 10);
                        initDate = new Date(initDate);*/
                        
                        invoice.set("store", store);
                        invoice.set("discount", discount_or_promocodes_total);
                        invoice.set("subTotal", subTotal);
                        invoice.set("total", total > 0 ? total + iva : 0);
                        invoice.set("tax", iva > 0 ? iva : 0);
                        invoice.set("startDate", initDate);
                        invoice.set("endDate", endDate);
                        invoice.set("status", 'created');
                        invoice.set("positiveBalance", total < 0 ?  Math.abs(total) : 0);

                        invoice.set("orderPrice", order_price);
                        invoice.set("baseCost", base_cost);
                        invoice.set("totalOrders", total_orders_number);
                        invoice.set("planName", store.attributes.plan.attributes.display_name); 
                        invoice.set("noDiscountApplies", noDiscountApplies);

                        invoice.save(null, { useMasterKey: true });

                        //return invoice

                    } catch (error) {
                        throw error.message;
                    }
            
                }
            }

            return true

        }else{
            throw "Error: Stores empty";
        }
        
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrderByPeriodBO", async request => {
    
    let currentUser = request.user;
    if (currentUser) {
        
        let store_id = request.params.store_id
        let initDate = request.params.init
        let endDate = request.params.end
        
        let StoreClass = Parse.Object.extend("Store");
        let query = new Parse.Query(StoreClass);
        query.include('plan')
        let store = await query.get(store_id, { useMasterKey: true });
        
        if (store) {
            
            let OrderClass = Parse.Object.extend("Order");
            let queryOrders = new Parse.Query(OrderClass);
            queryOrders.include("payment");
            queryOrders.include("items");
            queryOrders.include("address");
            queryOrders.include("store");
            queryOrders.include("promoCode");
            queryOrders.include("owner");
            queryOrders.equalTo("store", store);
            queryOrders.greaterThanOrEqualTo("createdAt", initDate)
            queryOrders.lessThanOrEqualTo("createdAt", endDate);
            queryOrders.notEqualTo("source", 'pos');
            queryOrders.equalTo("status", 'delivered');
            queryOrders.limit(10000);
            
            try {
                let orders = await queryOrders.find({ useMasterKey: true });
                return orders
                
            } catch (error) {
                throw error.message;
            }
            
        }else{
            throw "Error: Stores empty";
        }
        
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyOrderByPeriodBO", async request => {
    
    let currentUser = request.user;
    if (currentUser) {
        
        let store_id = request.params.store_id
        let initDate = request.params.init
        let endDate = request.params.end
        
        let StoreClass = Parse.Object.extend("Store");
        let query = new Parse.Query(StoreClass);
        query.include('plan')
        query.equalTo("owner", currentUser);
        let store = await query.get(store_id, { useMasterKey: true });
        
        if (store) {
            
            let OrderClass = Parse.Object.extend("Order");
            let queryOrders = new Parse.Query(OrderClass);
            queryOrders.include("payment");
            queryOrders.include("items");
            queryOrders.include("address");
            queryOrders.include("store");
            queryOrders.include("promoCode");
            queryOrders.include("owner");
            queryOrders.equalTo("store", store);
            queryOrders.greaterThanOrEqualTo("createdAt", initDate)
            queryOrders.lessThanOrEqualTo("createdAt", endDate);
            queryOrders.notEqualTo("source", 'pos');
            queryOrders.equalTo("status", 'delivered');
            queryOrders.limit(10000);
            
            try {
                let orders = await queryOrders.find({ useMasterKey: true });
                return orders
                
            } catch (error) {
                throw error.message;
            }
            
        }else{
            throw "Error: Stores empty";
        }
        
    } else {
        return null;
    }
});

Parse.Cloud.define("checkIfRoleIsWell", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let roles_array = request.params.roles;
        const query = new Parse.Query(Parse.Role)
        query.equalTo('users', currentUser)
        const roles = await query.find({ useMasterKey: true });
        
        if (roles && roles_array.length > 0) {
            for (let index = 0; index < roles.length; index++) {
                for (let i = 0; i < roles_array.length; i++) {
                    if (roles[index].attributes.name === roles_array[i]) {
                        return true;
                    }
                }
            }
            return false;
        }else{
            return false;
        }

    } else {
        return null;
    }
});

Parse.Cloud.define("markAsDeliveredBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = 'delivered';
        let now = '';
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include("store");
        let order = await query.get(id, { useMasterKey: true });
        order.set("status", status);
        let result = order.save(null, { useMasterKey: true });
        if (result) {
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", status);
            orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
            orderUpdateItem.save(null, { useMasterKey: true });
        }
        var pushIcon = "ic_notification";
        var butText = "VER PEDIDO";
        var displayName = order.get("alias").split(" ")[0];
        if (status != "canceled") {
            var message = "";
            if (status == "preparing") {
                pushIcon = "ic_preparing";
                message = displayName + ", tu pedido ya se esta preparando!";
            }
            else if (status == "delivering") {
                pushIcon = "ic_delivering";
                message = "Tu pedido va en camino 🛵, preparate para disfrutar de los productos.";
                now = new Date();
                now.setMinutes(now.getMinutes() + 5);
                now = new Date(now);
            }
            else if (status == "delivered") {
                pushIcon = "ic_delivered";
                butText = "CALIFICAR PEDIDO"
                message = displayName + ", Tu pedido ha sido entregado. ¿cómo estuvo todo?, entra a Perfil->Historial de Pedidos.";
                now = new Date();
                now.setMinutes(now.getMinutes() + 30);
                now = new Date(now);
            }
            //now we send a push
            var jsonBody = {
                app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                large_icon: pushIcon,
                small_icon: "ic_big_icon",
                android_accent_color: "f4e828",
                contents: { en: message },
                headings: { en: order.get("store").get("name") },
                data: { order: order.id },
                buttons: [{ "id": "view", "text": butText, "icon": "" }],
                priority: 10,
                android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                android_group: order.id,
                app_url: "https://festyapp.com/order/" + order.id,
                include_external_user_ids: [order.get("owner").id]
            };

            if (status == "delivered") {
                jsonBody.app_url = "https://festyapp.com/order/"+order.id
            }

            if (now) {
                jsonBody.send_after = now.toString()
            }

            Parse.Cloud.httpRequest({
                method: "POST",
                url: "https://onesignal.com/api/v1/notifications",
                headers: {
                    "Content-Type": "application/json;charset=utf-8",
                    "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                },
                body: JSON.stringify(jsonBody)
            }).then(function (httpResponse) {
                console.log(httpResponse.text);
            }, function (httpResponse) {
                console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
            });
            //now we notify support team via slack
            //let slackMessage = "BO MarkAsDelivry -> Orden " + order.id + " marcada como :" + status + " : cliente: " + order.get("alias");
            //logToSlack2(slackMessage)
        }
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateOrderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        let now = '';
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include("store");
        query.include("owner");
        query.include("rider");
        let order = await query.get(id, { useMasterKey: true });
        order.set("status", status);
        let result = await order.save(null, { useMasterKey: true });
        if (result) {
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", status);
            orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
            var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });

            if (result.get("source") == "pos") {
                /*var clientPhone = result.get("comments");
                if (status == "delivering") {
                    
                    let storeName = order.get("store").get("name");
                    let smsFormat = `Tu pedido a ${storeName} va en camino, preparate para disfrutar tus productos. Califica tu experiencia aqui https://invoices.festyapp.com/pos/${result.id}`;
                    
                    if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
                        let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            headers: {
                                "f-apiKey": process.env.FALCON_KEY,
                                "f-secretKey": process.env.FALCON_SECRET,
                                "Content-Type": "application/json"
                            },
                            url: smsUrlFormat,
                            body: {
                                'message': smsFormat,
                                'destinationsList': [`57${clientPhone}`],
                                'label': `admin~${order.attributes.store.id}~${order.attributes.store.attributes.name}`
                            },
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                            logToSlack2(`SMS FROM FESTYAPP -> Mensaje "${smsFormat}" enviando a: ${clientPhone}`)
                            logToSlack2(`Respuesta: ${httpResponse.text}`)
                        }, function (httpResponse) {
                            console.error('Request failed with response code ' + httpResponse.status);
                            logToSlack2(`BO Send SMS FORM FESTYAPP Request failed: ${httpResponse.text}`)
                        });
                    }else{
                        let smsUrlFormat = `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${clientPhone};${smsFormat.replace(/&/gi, 'y').replace(/#/gi, '')}`
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            url: smsUrlFormat
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                        }, function (httpResponse) {
                            console.error('Request failed with response code ' + httpResponse.status);
                            logToSlack2(`BO UpdateOrder FROM FESTYAPP Send SMS Request failed: ${httpResponse.text}`)
                        });
                    }
                }*/
            }

            if (result.get("source") == "client") {
                var pushIcon = "ic_notification";
                var butText = "VER PEDIDO";
                var displayName = order.get("alias").split(" ")[0];
                if (status != "canceled") {
                    var message = "";
                    if (status == "preparing") {
                        pushIcon = "ic_preparing";
                        message = displayName + ", tu pedido se está preparando!, te avisaremos cuando el domiciliario se dirija a tu dirección.";
                    }
                    else if (status == "delivering") {
                        pushIcon = "ic_delivering";
                        message = "Tu pedido va en camino 🛵, preparate para disfrutar de los productos.";
                    }
                    else if (status == "delivered") {
                        pushIcon = "ic_delivered";
                        butText = "CALIFICAR PEDIDO"
                        message = displayName + ", Tu pedido ha sido entregado. ¿cómo estuvo todo?, entra a Perfil->Historial de Pedidos.";
        
                        now = new Date();
                        now.setMinutes(now.getMinutes() + 60);
                        now = new Date(now);
                    }
                    //now we send a push
                    var jsonBody = {
                        app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                        large_icon: pushIcon,
                        small_icon: "ic_big_icon",
                        android_accent_color: "f4e828",
                        contents: { en: message },
                        headings: { en: order.get("store").get("name") },
                        data: { order: order.id },
                        buttons: [{ "id": "view", "text": butText, "icon": "" }],
                        priority: 10,
                        android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                        android_group: order.id,
                        include_external_user_ids: [order.get("owner").id]
                    };
        
                    if (now) {
                        jsonBody.send_after = now.toString()
                    }
        
                    if (status == "delivered") {
                        jsonBody.app_url = "https://festyapp.com/order/" + order.id
                    }
        
                    Parse.Cloud.httpRequest({
                        method: "POST",
                        url: "https://onesignal.com/api/v1/notifications",
                        headers: {
                            "Content-Type": "application/json;charset=utf-8",
                            "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                        },
                        body: JSON.stringify(jsonBody)
                    }).then(function (httpResponse) {
                        console.log(httpResponse.text);
                    }, function (httpResponse) {
                        console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
                    });
        
                    //let slackMessage = "BO -> Orden " + order.id + " marcada como :" + status + " : cliente: " + order.get("alias");
                    //logToSlack2(slackMessage)
                }
            }
            
            //now we look for the rider to assing the order
            if (status == "preparing" && !order.get("rider")) {
                try {
                    var StoreRiderClass = Parse.Object.extend("StoreRider");
                    var queryRiders = new Parse.Query(StoreRiderClass);
                    queryRiders.equalTo("store", result.get("store"));
                    queryRiders.equalTo("status", "online");
                    let onlineRiders = await queryRiders.find({ useMasterKey: true });
                    if (onlineRiders.length > 0) {
                        if (onlineRiders.length == 1) {
                            let rider = onlineRiders[0].get("rider");
                            await assingRiderToOrder2(result, rider, currentUser);
                        } else {
                            //custom implementation
                            var OrderClass = Parse.Object.extend("Order");
                            var queryOrder = new Parse.Query(OrderClass);
                            queryOrder.equalTo("store", result.get("store"));
                            queryOrder.equalTo("status", 'preparing');
                            queryOrder.exists('rider');
                            queryOrder.include('rider');
                            let ordersWithRiders = await queryOrder.find({ useMasterKey: true });

                            let busyRiders = ordersWithRiders.map(o => o.get("rider"));
                            let realOnlineRiders = onlineRiders.map(o => o.get("rider"));

                            const freeRiders = realOnlineRiders.filter(({ id: id1 }) => !busyRiders.some(({ id: id2 }) => id2 === id1));

                            if (freeRiders.length > 0) {
                                if (freeRiders.length === 1) {
                                    let freeRider = freeRiders[0];
                                    await assingRiderToOrder2(result, freeRider, currentUser);
                                } else {

                                    try {

                                        let riderMoreCloseToStore = ''

                                        let freeRidersWithTotalDistance = freeRiders.map(async (r) => {
                                            let queryRiderLocation = new Parse.Query("RiderLocation");
                                            queryRiderLocation.equalTo('rider', r)
                                            queryRiderLocation.descending('createdAt')
                                            let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                            let distanceBetweenStoreAndRider = calcDistance2(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                            return { rider: r, totalDistance: distanceBetweenStoreAndRider }
                                        });

                                        if (freeRidersWithTotalDistance) {
                                            riderMoreCloseToStore = freeRidersWithTotalDistance.reduce(function (prev, curr) {
                                                return prev.totalDistance < curr.totalDistance ? prev : curr;
                                            });
                                        } else {
                                            let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                            await assingRiderToOrder2(result, ramdomFreeRider, currentUser);
                                        }

                                        await assingRiderToOrder2(result, riderMoreCloseToStore.rider, currentUser);

                                    } catch (error) {
                                        // Si ocurre algún error el radom salva el dia.
                                        let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                        await assingRiderToOrder2(result, ramdomFreeRider, currentUser);
                                    }
                                }
                            } else {

                                try {

                                    let riderMoreCloseToStore = ''

                                    let ridersWithTotalDistance = realOnlineRiders.map(async (r) => {
                                        let queryRiderLocation = new Parse.Query("RiderLocation");
                                        queryRiderLocation.equalTo('rider', r)
                                        queryRiderLocation.descending('createdAt')
                                        let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                        let distanceBetweenStoreAndRider = calcDistance2(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let distanceBetweenClientAndRider = calcDistance2(order.attributes.address.attributes.location.latitude, order.attributes.address.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let totalDistance = 20
                                        if (distanceBetweenStoreAndRider && distanceBetweenClientAndRider) {
                                            totalDistance = distanceBetweenStoreAndRider + distanceBetweenClientAndRider
                                        }
                                        return { rider: r, totalDistance: totalDistance }
                                    });

                                    if (ridersWithTotalDistance) {
                                        riderMoreCloseToStore = ridersWithTotalDistance.reduce(function (prev, curr) {
                                            return prev.totalDistance < curr.totalDistance ? prev : curr;
                                        });
                                    } else {
                                        let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                        await assingRiderToOrder2(result, randomOnlineRiders, currentUser);
                                    }

                                    await assingRiderToOrder2(result, riderMoreCloseToStore.rider, currentUser);

                                } catch (error) {
                                    // Si ocurre algún error el radom salva el dia.
                                    let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                    await assingRiderToOrder2(result, randomOnlineRiders, currentUser);
                                }
                            }
                        }
                    }
                } catch (error) {
                    console.log("error " + error)
                }
            }
        }
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("sendSMS", async request => {
    var currentUser = request.user;
    if (currentUser && request.params.phone) {
        let phone = request.params.phone;
        let message = request.params.message;
        let label = request.params.label;

        if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
            let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
            Parse.Cloud.httpRequest({
                method: "POST",
                headers: {
                    "f-apiKey": process.env.FALCON_KEY,
                    "f-secretKey": process.env.FALCON_SECRET,
                    "Content-Type": "application/json"
                },
                url: smsUrlFormat,
                body: {
                    'message': message,
                    'destinationsList': [`57${phone}`],
                    'label': label ? label : `semdSms~${currentUser.id}`
                },
            }).then(function (httpResponse) {
                console.log(httpResponse.text);
                logToSlack2(`SMS FROM FESTYAPP -> Mensaje "${message}" enviando a: ${phone}`)
                logToSlack2(`Respuesta: ${httpResponse.text}`)
            }, function (httpResponse) {
                console.error('Request failed with response code ' + httpResponse.status);
                logToSlack2(`BO Send SMS FORM FESTYAPP Request failed: ${httpResponse.text}`)
            });
        }else{
            let smsUrlFormat = `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${phone};${message.replace(/&/gi, 'y').replace(/#/gi, '')}`
            Parse.Cloud.httpRequest({
                method: "POST",
                url: smsUrlFormat
            }).then(function (httpResponse) {
                console.log(httpResponse.text);
                //logToSlack2(`SMS -> Mensaje "${message}" enviando a: ${phone}`)
                //logToSlack2(`Respuesta: ${httpResponse.text}`)
            }, function (httpResponse) {
                console.error('Request failed with response code ' + httpResponse.status);
                logToSlack2(`BO Send SMS Request failed: ${httpResponse.text}`)
            });    
        }

        return true;

    } else {
        return null;
    }
});

Parse.Cloud.define("sendSMSMasive", async request => {
    var currentUser = request.user;
    if (currentUser && request.params.phones) {
        let phones = request.params.phones;
        let message = request.params.message;
        let label = request.params.label;

        if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
            if (Array.isArray(phones)) {
                let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
                Parse.Cloud.httpRequest({
                    method: "POST",
                    headers: {
                        "f-apiKey": process.env.FALCON_KEY,
                        "f-secretKey": process.env.FALCON_SECRET,
                        "Content-Type": "application/json"
                    },
                    url: smsUrlFormat,
                    body: {
                        'message': message,
                        'destinationsList': phones,
                        'label': label
                    },
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                    logToSlack2(`SMS FROM FESTYAPP MASIVE -> Mensaje "${message}"`)
                    logToSlack2(`Respuesta: ${httpResponse.text}`)
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status);
                    logToSlack2(`BO Send SMS MASIVE FORM FESTYAPP Request failed: ${httpResponse.text}`)
                });
    
                logToSlack2(`SMS Masive FROM FESTYAPP -> Mensaje "${message}" - Cantidad de SMS/Numeros ${phones.length}`)
                return true;
            }

        }else{
            if (Array.isArray(phones)) {
                phones.forEach(phone => {
                    Parse.Cloud.httpRequest({
                        method: "POST",
                        url: `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${phone};${message.replace(/&/gi, 'y').replace(/#/gi, '')}`
                    }).then(function (httpResponse) {
                        console.log(httpResponse.text);
                        //logToSlack2(`SMS -> Mensaje "${message}" enviando a: ${phone}`)
                        //logToSlack2(`Respuesta: ${httpResponse.text}`)
                    }, function (httpResponse) {
                        console.error('Request failed with response code ' + httpResponse.status);
                        logToSlack2(`Masive SMS Request failed: ${httpResponse.text}`)
                    });
                });
                logToSlack2(`SMS Masive FROM FESTYAPP -> Mensaje "${message}" - Cantidad de SMS/Numeros ${phones.length}`)
                return true;
            }
        }
        return false;
    } else {
        return null;
    }
});

Parse.Cloud.define("editNoteOrderBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let note = request.params.note;
        let OrderClass = Parse.Object.extend("Order");
        let query = new Parse.Query(OrderClass);
        //query.equalTo("owner", currentUser);
        let order = await query.get(id, { useMasterKey: true });
        let note_old = order.attributes.notes;
        
        order.set('notes', note)
        let order_update = order.save(null, { useMasterKey: true });

        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var orderUpdateItem = new OrderUpdateClass();
        orderUpdateItem.set("object", order.id);
        orderUpdateItem.set("update_type", 'note_edited');
        orderUpdateItem.set("notes", note_old);
        orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
        var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });

        return order_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("editAdressOrderBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let addressId = request.params.addressId;
        let editAddress = request.params.editAddress

        let OrderClass = Parse.Object.extend("Order");
        let query = new Parse.Query(OrderClass);
        query.include('address')
        //query.equalTo("owner", currentUser);
        let order = await query.get(id, { useMasterKey: true });
        
        let AddressClass = Parse.Object.extend("Address");
        if (editAddress) {
            let query_address = new Parse.Query(AddressClass);
            let addressUpdate = await query_address.get(addressId, { useMasterKey: true });
            addressUpdate.set('address', editAddress)
            await addressUpdate.save(null, { useMasterKey: true });
        }
        
        let addressNew = new AddressClass();
        addressNew.id = addressId
        order.set('address', addressNew)
        let order_update = order.save(null, { useMasterKey: true });
        
        let address_old = `${order.attributes.address.attributes.address} - [${order.attributes.address.attributes.name}]`

        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var orderUpdateItem = new OrderUpdateClass();
        orderUpdateItem.set("object", order.id);
        orderUpdateItem.set("update_type", 'address_edited');
        orderUpdateItem.set("notes", address_old);
        orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
        var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
        
        return order_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("timeTest", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let date = new Date();
        let initDate = new Date(date.getFullYear(), Number.isInteger(request.params.month) ? request.params.month : date.getMonth(), 1);
        let endDate = new Date(date.getFullYear(), (Number.isInteger(request.params.month) ? request.params.month : date.getMonth()) + 1, 0);
        endDate.setHours(23,59,59,999);

        initDate.setHours(initDate.getHours() + 5);
        initDate = new Date(initDate);

        endDate.setHours(endDate.getHours() + 5);
        endDate = new Date(endDate);

        return {initDate : initDate.toString(), endDate: endDate.toString(), initDateObject: initDate, endDateObject: endDate};
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoresAndRidersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        query.include('store')
        query.include('rider')
        //query.equalTo("owner", currentUser);
        let storeRider = await query.find({ useMasterKey: true });
        return storeRider;
    } else {
        return null;
    }
});

Parse.Cloud.define("changeStatusStoreRiderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        //query.equalTo("owner", currentUser);
        query.include('store');
        query.include('rider');
        let storeRider = await query.get(id, { useMasterKey: true });
        storeRider.set('status', storeRider.attributes.status === 'offline' ? 'online' : 'offline');
        let storeRider_update = await storeRider.save(null, { useMasterKey: true });
        let storeRider_id = storeRider.attributes.rider.id
        //logToSlack2("RiderBO -> " + storeRider.attributes.rider.attributes.name + " : " + storeRider.attributes.status);
        
        //now we send a push
        var jsonBody = {
            app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
            small_icon: "ic_notification",            
            android_accent_color: "f4e828",
            contents: { en: "Tu estado a cambiado" },
            headings: { en: "Para ver más, abre Festy Rider" },      
            android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
            priority: 10,
            include_external_user_ids: [storeRider_id]
        };

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
        });
        

        return storeRider_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("changeDefaultStoreRiderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        //query.equalTo("owner", currentUser);
        query.include('store');
        query.include('rider');
        let storeRider = await query.get(id, { useMasterKey: true });
        storeRider.set('default', !storeRider.attributes.default ? true : false);
        let storeRider_update = await storeRider.save(null, { useMasterKey: true });
        //logToSlack2("RiderBO -> " + storeRider.attributes.rider.attributes.name + " es un nuvo Fesry Rider!"); 

        return storeRider_update;
    } else {
        return null;
    }
});

const logToSlack2 = async (slackMessage) => {
    var bodyParams = {
        text: slackMessage
    };
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://hooks.slack.com/services/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",
        headers: {
            "Content-Type": "application/json;charset=utf-8"
        },
        body: JSON.stringify(bodyParams)
    }).then(function (httpResponse) {

    }, function (httpResponse) {

    });
};

const notificationOpenCloseStore = async (owner_id, store_id, status) => {
    if (owner_id && store_id && status) {
        //now we send a push
        var jsonBody = {
            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
            small_icon: "ic_notification",
            large_icon: "ic_big_icon",
            android_accent_color: "f4e828",
            contents: { en: "Tu estado a cambiado" },
            headings: { en: "Para ver más , abre Fest y ve a INFO" },
            //android_sound: "bell_sound",
            android_channel_id: "962d9d5a-97fa-493b-a60d-4c37fa0c1c68",
            channel_for_external_user_ids: "push",
            data: {
                "store_status_changed": true,
                "open": status
            },
            priority: 10,
            include_external_user_ids: [owner_id, store_id]
        };
        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status);
        });
    }
};

Parse.Cloud.define("editProductBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let name = request.params.name;
        let superCategory = request.params.superCategory;
        let category = request.params.category;
        let subCategory = request.params.subCategory;
        let price = request.params.price;
        let deliveryCost = request.params.deliveryCost;
        let imageUrl = request.params.imageUrl;
        let comboOption = request.params.comboOption;
        let comboPrice = request.params.comboPrice;
        let comboNotes = request.params.comboNotes;
        let description = request.params.description;
        let modifiers = request.params.modifiers;
        let productCategory = request.params.productCategory
        let exclusive = request.params.exclusive

        let ProductClass = Parse.Object.extend("Product");
        let query = new Parse.Query(ProductClass);
        //query.equalTo("owner", currentUser);
        let product = await query.get(id, { useMasterKey: true });

        product.set('name', name ? name : product.attributes.name)
        product.set('superCategory', superCategory ? superCategory : product.attributes.superCategory)
        product.set('category', category ? category : product.attributes.category)
        product.set('subCategory', subCategory ? subCategory : product.attributes.subCategory)
        product.set('price', price ? price : price === 0 ? price : product.attributes.price)
        product.set('deliveryCost', deliveryCost ? deliveryCost : deliveryCost === 0 ? deliveryCost : product.attributes.deliveryCost)
        product.set('imageUrl', imageUrl ? imageUrl : product.attributes.imageUrl)
        product.set('comboOption', comboOption)
        product.set('comboPrice', comboPrice ? comboPrice : product.attributes.comboPrice)
        product.set('comboNotes', comboNotes ? comboNotes : product.attributes.comboNotes)
        product.set("description", description ? description : product.attributes.description);
        product.set('exclusive', exclusive)

        if (modifiers) {
            product.set("modifiers", modifiers);
        }
        
        if (productCategory) {
            var ProductCategoryClass = Parse.Object.extend("ProductCategory");
            let categoryNew = new ProductCategoryClass();
            categoryNew.id = productCategory;
            product.set("productCategory", categoryNew);
        }
        
        let product_update = product.save(null, { useMasterKey: true });
        return product_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("newPromoBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.storeId;
        var name = request.params.name;
        var imageUrl = request.params.imageUrl;
        var description = request.params.description;
        var price = request.params.price;
        var status = request.params.status;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;
        var comboOption = request.params.comboOption;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;
        var superCategory = request.params.superCategory;
        let productCategory = request.params.productCategory
        let exclusive = request.params.exclusive

        var PromotionClass = Parse.Object.extend("Product");
        var promotion = new PromotionClass()
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });
        if (store) {
            promotion.set("name", name);
            promotion.set("description", description);
            promotion.set("price", price);
            promotion.set("imageUrl", imageUrl);
            promotion.set("store", store);
            promotion.set("likes", 0);
            promotion.set("views", 0);
            promotion.set("orders", 0);
            promotion.set("status", status);
            promotion.set("category", category);
            promotion.set("location", store.get("location"));
            promotion.set("deliveryCost", deliveryCost);
            promotion.set("comboOption", comboOption);
            promotion.set("comboPrice", comboPrice);
            promotion.set("comboNotes", comboNotes);
            promotion.set('exclusive', exclusive)
            if (superCategory)
                promotion.set("superCategory", superCategory);

            if (productCategory) {
                var ProductCategoryClass = Parse.Object.extend("ProductCategory");
                let categoryNew = new ProductCategoryClass();
                categoryNew.id = productCategory;
                promotion.set("productCategory", categoryNew);
            }
            let result = promotion.save(null, { useMasterKey: true });
            logToSlack2("[BO] new promo added " + store.attributes.name + ' - ' + name + " - " + imageUrl);
            return result;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("importProductsBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let products = request.params.products;
        let productsReturnArray = [];

        if (products.length > 0) {

            var StoreClass = Parse.Object.extend("Store");
            var queryStore = new Parse.Query(StoreClass);
            //query.equalTo("owner", currentUser);
            let store = await queryStore.get(id, { useMasterKey: true });

            products.forEach(async (product) => {
                
                let ProductClass = Parse.Object.extend("Product");
                let newProduct = new ProductClass();

                var queryProduct = new Parse.Query(ProductClass);
                queryProduct.equalTo("store", store);
                queryProduct.equalTo("sku", product.sku);
                let productExist = await queryProduct.first({ useMasterKey: true });

                if (productExist) {
                    newProduct = productExist;
                }

                newProduct.set("sku", product.sku);
                newProduct.set("name", product.name);
                newProduct.set("description", product.description);
                newProduct.set("price", Number(product.price));
                newProduct.set("deliveryCost", Number(product.deliveryCost));
                newProduct.set("imageUrl", product.imageUrl);
                newProduct.set("max", Number(product.max));
                newProduct.set("category", product.category);
                newProduct.set("superCategory", product.superCategory);
                newProduct.set("subCategory", product.subCategory);
                newProduct.set("featured", Boolean(Number(product.featured))); // False 0, True 1....n+
                newProduct.set("comboOption", Boolean(Number(product.comboOption))); // False 0, True 1....n+
                newProduct.set("comboNotes", product.comboNotes);
                newProduct.set("status", product.status);

                newProduct.set("orders", newProduct.attributes.orders ? newProduct.attributes.orders : 0);
                newProduct.set("likes", newProduct.attributes.likes ? newProduct.attributes.likes : 0);
                newProduct.set("views", newProduct.attributes.views ? newProduct.attributes.views : 0);
                
                newProduct.set("location", store.attributes.location);
                newProduct.set("store", store);
                
                let newp = await newProduct.save(null, { useMasterKey: true })
                productsReturnArray.push(newp)
            });

            return productsReturnArray;
        }
        return null;
    } else {
        return null;
    }
});

Parse.Cloud.define("getRidersByStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let offiline = request.params.offiline;
        let defaultRider = request.params.defaultRider;
        var Store = Parse.Object.extend("Store");
        var store = new Store();
        store.id = id;

        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        query.include('store')
        query.include('rider')
        if (!offiline) {
            query.equalTo("status", 'online');
        }
        if (defaultRider) {
            query.equalTo('default', true);
        }else{
            query.equalTo("store", store);
        }
        let storeRider = await query.find({ useMasterKey: true });
        return storeRider;
    } else {
        return null;
    }
})

Parse.Cloud.define("assingRiderToOrderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let rider_id = request.params.rider_id;

        var rider = new Parse.User();
        rider.id = rider_id;

        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include('store')
        query.include('rider')
        query.include('owner')
        let order = await query.get(id, { useMasterKey: true });
        let rider_old = order.attributes.rider ? order.attributes.rider.id : ''

        await assingRiderToOrder2(order, rider, currentUser)

        if (rider_old) {
            var riderPushBody = {
                app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
                small_icon: "ic_notification",
                android_accent_color: "f4e828",
                contents: { en: "Domicilio cancelado, revise nuevamente su lista de domicilios. Para saber los motivos consulte ha soporte." },
                headings: { en: order.get("store").get("name") },
                buttons: [{ id: "view", text: "VER PEDIDO", icon: "" }],
                priority: 10,
                android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
                include_external_user_ids: [rider_old]
            };
            Parse.Cloud.httpRequest({
                method: "POST",
                url: "https://onesignal.com/api/v1/notifications",
                headers: {
                    "Content-Type": "application/json;charset=utf-8",
                    Authorization: "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
                },
                body: JSON.stringify(riderPushBody)
            }).then(
                function (httpResponse) {
                    console.log(httpResponse.text);
                },
                function (httpResponse) {
                    console.error(
                        "Request failed with response code " +
                        httpResponse.status +
                        " : " +
                        httpResponse.text
                    );
                }
            );
        }

        return order;
    } else {
        return null;
    }
});

Parse.Cloud.define("removeRiderToOrderBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;

        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include('store')
        query.include('rider')
        query.include('owner')
        let order = await query.get(id, { useMasterKey: true });
        let rider_old = order.attributes.rider ? order.attributes.rider.id : ''

        order.unset('rider')
        let orderWithOutRider = await order.save(null, { useMasterKey: true })

        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var orderUpdateItem = new OrderUpdateClass();
        orderUpdateItem.set("object", order.id);
        orderUpdateItem.set("update_type", 'removeRider');
        if (rider_old) {
            orderUpdateItem.set("notes", rider_old);
        }
        orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
        var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });

        if (rider_old) {
            var riderPushBody = {
                app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
                small_icon: "ic_notification",
                android_accent_color: "f4e828",
                contents: { en: "Domicilio cancelado, revise nuevamente su lista de domicilios. Para saber los motivos consulte ha soporte." },
                headings: { en: order.get("store").get("name") },
                data: { newAssignment: order.id },
                buttons: [{ id: "view", text: "VER PEDIDO", icon: "" }],
                priority: 10,
                android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
                include_external_user_ids: [rider_old]
            };
            Parse.Cloud.httpRequest({
                method: "POST",
                url: "https://onesignal.com/api/v1/notifications",
                headers: {
                    "Content-Type": "application/json;charset=utf-8",
                    Authorization: "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
                },
                body: JSON.stringify(riderPushBody)
            }).then(
                function (httpResponse) {
                    console.log(httpResponse.text);
                },
                function (httpResponse) {
                    console.error(
                        "Request failed with response code " +
                        httpResponse.status +
                        " : " +
                        httpResponse.text
                    );
                }
            );
        }

        return orderWithOutRider;
    } else {
        return null;
    }
});

// Assing rider to order and send push
const assingRiderToOrder2 = async (result, rider, currentUser) => {
    console.log("assingRiderToOrder function call with rider: " + rider.id)
    
    let statusOrderUpdate = result.attributes.rider ? 'rider_edited' : 'rider_added'
    let idOldRider = result.attributes.rider ? result.attributes.rider.id : false

    result.set("rider", rider);
    var orderUpdateResult = await result.save(null, { useMasterKey: true });
    
    //logToSlack2(`BO -> Rider: ${rider.attributes.name} asignado a la orden: ${orderUpdateResult.id} - ${orderUpdateResult.attributes.owner.name}`)

    var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
    var orderUpdateItem = new OrderUpdateClass();
    orderUpdateItem.set("object", result.id);
    orderUpdateItem.set("update_type", statusOrderUpdate);
    if (idOldRider) {
        orderUpdateItem.set("notes", idOldRider);
    }
    orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
    var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });

    var riderPushBody = {
        app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
        small_icon: "ic_notification",
        android_accent_color: "f4e828",
        contents: { en: "Nuevo pedido asignado para entrega" },
        headings: { en: result.get("store").get("name") },
        data: { newAssignment: result.id },
        buttons: [{ id: "view", text: "VER PEDIDO", icon: "" }],
        priority: 10,
        android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
        include_external_user_ids: [rider.id]
    };
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://onesignal.com/api/v1/notifications",
        headers: {
            "Content-Type": "application/json;charset=utf-8",
            Authorization: "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
        },
        body: JSON.stringify(riderPushBody)
    }).then(
        function (httpResponse) {
            console.log(httpResponse.text);
        },
        function (httpResponse) {
            console.error(
                "Request failed with response code " +
                httpResponse.status +
                " : " +
                httpResponse.text
            );
        }
    );
};

Parse.Cloud.define("getAppConfigWhitoutLocation", async request => {
    try {
        let country = request.params.country;
    
        const query = new Parse.Query('Zone')
        query.equalTo('status', true)
        if (country) {
            query.equalTo('country', country)
        }
        const zone = await query.find({ useMasterKey: true });
        return zone; 
    } catch (error) {
        throw error.message;
    }
});

// Distance between two points 
const calcDistance2 = async (lat1, lon1, lat2, lon2) => {
    var R = 6371; // km
    var dLat = toRad2(lat2 - lat1);
    var dLon = toRad2(lon2 - lon1);
    var lat1 = toRad2(lat1);
    var lat2 = toRad2(lat2);

    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c;
    return d;
}

// Converts numeric degrees to radians
const toRad2 = (Value) => {
    return Value * Math.PI / 180;
}

Parse.Cloud.define("getInfoTiketOrder", async request => {
    let order_id = request.params.order_id;
    let arrayItems = []
    let items = []
    if(!order_id){
        return null;
    }
    const query = new Parse.Query('Order')
    query.include('store')
    query.include("items");
    const order = await query.get(order_id, { useMasterKey: true });
    if (order.attributes.source != 'pos') {
        return null;
    }
    items = order.attributes.items;
    items.forEach((item, index) => {
        arrayItems.push({
            name: `(${item.attributes.quantity}) - ${item.attributes.name}`,
            total: item.attributes.price,
        })
    });

    return {name_store: order.attributes.store.attributes.name, logo: order.attributes.store.attributes.logoUrl, delivery: order.attributes.deliveryCost, subtotal: order.attributes.total - order.attributes.deliveryCost, total: order.attributes.total, store_id: order.attributes.store.id, rating: order.attributes.rating ? true : false,  items : arrayItems, status: order.attributes.status};
});

Parse.Cloud.define("rateOrderPos", async request => {
    let order_id = request.params.order_id;
    let rate = request.params.rate;
    let comments = request.params.comments;
    if(!order_id || !rate){
        return null;
    }
    const query = new Parse.Query('Order')
    const order = await query.get(order_id, { useMasterKey: true });
    
    order.set('rating', Number(rate))
    if (comments) {
        order.set('comments', comments)
    }
    await order.save(null, { useMasterKey: true });
    
    //let slackMessage = "[BO] Orden POS Calificada: " + order_id + ", " + rate + " Estrellas";
    //logToSlack2(slackMessage);

    return 'OK'
});

Parse.Cloud.define("editPaymentMethodBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        
        let id = request.params.id;
        let order_id = request.params.order_id
        let paymentsType = request.params.paymentsType;
        let attachMethodPayment = request.params.attachMethodPayment;
        let oldPaymentMethod = ''

        try {

            var Payment = Parse.Object.extend("Payment");
            var query = new Parse.Query(Payment);
            let payment = await query.get(id, { useMasterKey: true });
            oldPaymentMethod = payment.attributes.method

            payment.set('method', paymentsType)
            payment.set('status', paymentsType == 'digitalTransfer' ? attachMethodPayment ? 'paid' : 'pending' : 'approved')
            payment.set('attachUrl', attachMethodPayment ? attachMethodPayment : '')

            var paymentUpdate = await payment.save(null, { useMasterKey: true });

            var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order_id);
            orderUpdateItem.set("update_type", 'paymentEdit');
            if (oldPaymentMethod) {
                orderUpdateItem.set("notes", 'Método anterior: ' + oldPaymentMethod);
            }
            orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
            var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });

            return paymentUpdate;
            
        } catch (error) {
            throw error.message;
        }
       
    } else {
        return null;
    }
});

Parse.Cloud.define("editStoreBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            let id = request.params.id;
            let name = request.params.name;
            let city = request.params.city;
            let phone = request.params.phone;
            let status = request.params.status;
            let logoUrl = request.params.logoUrl;
            let slug = request.params.slug;
            let phoneSMSAlert = request.params.phoneSMSAlert;
            let acceptBankTransfer = request.params.acceptBankTransfer;
            let transfersMethods = request.params.transfersMethods;
            let description = request.params.description;
            let address = request.params.address;
            let category = request.params.category;
            let posEnabled = request.params.posEnabled;
            let riderService = request.params.riderService;
            let storeCategory = request.params.storeCategory
            let hasCardReader = request.params.hasCardReader
            let delivery = request.params.delivery
            let fee = request.params.fee
            let subtitle = request.params.subtitle
            let minAmount = request.params.minAmount
            
            let StoreClass = Parse.Object.extend("Store");
            let query = new Parse.Query(StoreClass);
            //query.equalTo("owner", currentUser);
            let store = await query.get(id, { useMasterKey: true });

            store.set('name', name ? name : store.attributes.name)
            store.set('city', city ? city : store.attributes.city)
            store.set('phone', phone ? phone : store.attributes.phone)
            store.set('logoUrl', logoUrl ? logoUrl : store.attributes.logoUrl)
            store.set('slug', slug ? slug : store.attributes.slug)
            store.set('phoneSMSAlert', phoneSMSAlert ? phoneSMSAlert : store.attributes.phoneSMSAlert)
            store.set('acceptBankTransfer', acceptBankTransfer)
            store.set('transfersMethods', transfersMethods ? transfersMethods : store.attributes.transfersMethods)
            store.set('description', description ? description : store.attributes.description)
            store.set('address', address ? address : store.attributes.address)
            store.set('category', category ? category : store.attributes.category)
            store.set('posEnabled', posEnabled)
            store.set('riderService', riderService)
            store.set('hasCardReader', hasCardReader)
            store.set('delivery', delivery ? delivery : store.attributes.delivery)
            store.set('fee', fee)
            store.set('subtitle', subtitle)
            store.set('minAmount', minAmount ? minAmount : 0)
            
            if (storeCategory) {
                var StoreCategoryClass = Parse.Object.extend("StoreCategory");
                let categoryNew = new StoreCategoryClass()
                categoryNew.id = storeCategory
                store.set('storeCategory', categoryNew)
            }
            
            let store_update = store.save(null, { useMasterKey: true });
            return store_update;
            
        } catch (error) {
            throw error.message;
        }
        
    } else {
        return null;
    }
});

Parse.Cloud.define("getRidersLocationBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            let riders = []
            var StoreRiderClass = Parse.Object.extend("StoreRider");
            var query = new Parse.Query(StoreRiderClass);
            query.include('rider');
            query.include('store');
            query.limit(1000)
            let ridersStore = await query.find({ useMasterKey: true });
    
            if (ridersStore) {

                for (let index = 0; index < ridersStore.length; index++) {
                    const element = ridersStore[index];
                    if (element && element.attributes.rider && element.attributes.rider.id) {
                        var queryRiderLocation = new Parse.Query('RiderLocation');
                        queryRiderLocation.equalTo('rider', element.attributes.rider)
                        queryRiderLocation.ascending('createdAt')
                        let riderLocation = await queryRiderLocation.first({ useMasterKey: true });
                        riders.push({
                            rider_store: element,
                            location: riderLocation
                        })
                    }
                }
                
                return riders;
            }

        } catch (error) {
            throw error.message;
        }

    } else {
        return null;
    }
});

Parse.Cloud.define("newPosOrderCustomerMethodForStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            /*var StoreClass = Parse.Object.extend("Store");
            let store = new StoreClass()
            store.id = 'qab9u94Qdz'*/ 
            var OrderClass = Parse.Object.extend("Order");
            var query = new Parse.Query(OrderClass);
            query.include('owner');
            query.include('store');
            //query.equalTo('store', store); // Festy Sincelejo
            query.equalTo('source', 'pos');
            query.limit(10000)
            let orders = await query.find({ useMasterKey: true });

            for (let index = 0; index < orders.length; index++) {
                const order = orders[index];

                var CustomerClass = Parse.Object.extend("Customer");
                var queryCustomer = new Parse.Query(CustomerClass);
                queryCustomer.equalTo('store', order.attributes.store);
                queryCustomer.equalTo('phone', order.attributes.comments);
                let customer = await queryCustomer.first({ useMasterKey: true });
                if (!customer) {
                    var newCustomer = new CustomerClass()
                    newCustomer.set('store', order.attributes.store)
                    newCustomer.set('name', order.attributes.alias)
                    newCustomer.set('phone', order.attributes.comments)
                    newCustomer.set('address', JSON.parse(order.attributes.notes).address)
                    //newCustomer.set('notes', JSON.parse(order.attributes.notes).notes)
                    newCustomer.set('status', 'active')
                    newCustomer.set('tags', [])
                    await newCustomer.save(null, { useMasterKey: true });
                }
                
            }    

        } catch (error) {
            throw error.message;
        }

    } else {
        return null;
    }
});

Parse.Cloud.define("newPosOrderCustomerMethodForHunterAndButcherBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            var StoreClass = Parse.Object.extend("Store");
            let store = new StoreClass()
            store.id = '5ucHEEmebF'
            let storeHunter = new StoreClass()
            storeHunter.id = 'NDVT6jMPVu'

            var OrderClass = Parse.Object.extend("Order");
            var query = new Parse.Query(OrderClass);
            query.include('owner');
            query.include('store');
            query.equalTo('store', store); // Festy Sincelejo
            query.equalTo('source', 'pos');
            query.limit(10000)
            let orders = await query.find({ useMasterKey: true });

            for (let index = 0; index < orders.length; index++) {
                const order = orders[index];

                var CustomerClass = Parse.Object.extend("Customer");
                var queryCustomer = new Parse.Query(CustomerClass);
                //queryCustomer.equalTo('store', order.attributes.store);
                queryCustomer.equalTo('store', storeHunter);
                queryCustomer.equalTo('phone', order.attributes.comments);
                let customer = await queryCustomer.first({ useMasterKey: true });
                if (!customer) {
                    var newCustomer = new CustomerClass()
                    //newCustomer.set('store', order.attributes.store)
                    newCustomer.set('store', storeHunter)
                    newCustomer.set('name', order.attributes.alias)
                    newCustomer.set('phone', order.attributes.comments)
                    newCustomer.set('address', JSON.parse(order.attributes.notes).address)
                    //newCustomer.set('notes', JSON.parse(order.attributes.notes).notes)
                    newCustomer.set('status', 'active')
                    newCustomer.set('tags', [])
                    await newCustomer.save(null, { useMasterKey: true });
                }
                
            }    

        } catch (error) {
            throw error.message;
        }

    } else {
        return null;
    }
});

Parse.Cloud.define("getPaymentsByStoreIdBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            var id = request.params.id; 
            var InvoicePaymentClass = Parse.Object.extend("InvoicePayment");
            var query = new Parse.Query(InvoicePaymentClass);
            query.equalTo("invoice", id);
            let payments = await query.find({ useMasterKey: true });
            
            return payments;        
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrderByRidersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        try {
            var rider = new Parse.User();
            rider.id = id;

            var OrderClass = Parse.Object.extend("Order");
            var query = new Parse.Query(OrderClass);
            query.descending("createdAt");
            query.include("payment");
            query.include("items");
            query.include("address");
            query.include("store");
            query.include("promoCode");
            query.include("owner");
            query.include("rider");
            query.equalTo("rider", rider);
            query.equalTo("status", 'delivered');
            let orders = await query.find({ useMasterKey: true });

            return orders;

        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrdersByRiderFilterBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let init = new Date(request.params.init);
        let end = new Date(request.params.end);
        let status = request.params.status;
        let source = request.params.source;

        init.setHours(init.getHours() + 5);
        init = new Date(init);
        
        end.setHours(23,59,59,999);
        end.setHours(end.getHours() + 5);
        end = new Date(end);

        var rider = new Parse.User();
        rider.id = id;

        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.equalTo("rider", rider);
        
        query.greaterThanOrEqualTo("createdAt", init)
        query.lessThanOrEqualTo("createdAt", end);
        
        if (status) {
            query.equalTo("status", status);
        }

        if (source && source != 'all') {
            query.equalTo("source", source);
        }
        query.notEqualTo("status", 'cancelled');
        query.descending("createdAt");
        query.limit(10000);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("editStatusInvoiceBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let status = request.params.status;
        let comments = request.params.comments;
        let attachUrl = request.params.attachUrl
        try {
            var InvoiceClass = Parse.Object.extend("Invoice");
            var query = new Parse.Query(InvoiceClass);
            let invoice = await query.get(id, { useMasterKey: true });
            invoice.set('status', status)
            invoice.set('comments', comments)
            if (attachUrl) {
                invoice.set('attachUrl', attachUrl)
            }
            let editInvoice = await invoice.save(null, { useMasterKey: true });
            if (editInvoice) {
                return editInvoice;
            }
            return null
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("getInvocesNotPaid", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            var InvoiceClass = Parse.Object.extend("Invoice");
            var query = new Parse.Query(InvoiceClass);
            query.include('store');
            query.greaterThan('total', 0);
            query.notEqualTo('status', 'paid');
            query.limit(10000);
            //query.ascending('store.name');
            let invoices = await query.find({ useMasterKey: true });
            return invoices;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("getInvocesNotPaidFilter", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {

            let init = request.params.init ? new Date(request.params.init) : '';
            let end = request.params.end ? new Date(request.params.end) : '';
            let status = request.params.status;
            let cities = request.params.cities;

            if (!init || !end) {
                let date = new Date();
                init = new Date(date.getFullYear(), date.getMonth(), 1);
                end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
                end.setHours(23,59,59,999);

                init.setHours(init.getHours() + 5);
                init = new Date(init);

                end.setHours(end.getHours() + 5);
                end = new Date(end);
            }else{
                init.setHours(init.getHours() + 5);
                init = new Date(init);
                
                end.setHours(23,59,59,999);
                end.setHours(end.getHours() + 5);
                end = new Date(end);
            }

            var StoreClass = Parse.Object.extend("Store");
            var innerQuery = new Parse.Query(StoreClass);
            
            var InvoiceClass = Parse.Object.extend("Invoice");
            var query = new Parse.Query(InvoiceClass);
            query.include('store');
            //query.greaterThan('total', 0);
            //query.ascending('store.name');
            query.greaterThanOrEqualTo("startDate", init)
            query.lessThanOrEqualTo("endDate", end);
            
            if (cities && cities.length > 0) {
                innerQuery.containedIn("city", cities);
                query.matchesQuery("store", innerQuery);
            }
            
            if (status && status != 'all') {
                query.equalTo("status", status);
            }
            query.limit(10000);
            let invoices = await query.find({ useMasterKey: true });
            return invoices;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

//for BO
Parse.Cloud.define("getAllMyStoreOrdersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;

        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('owner')
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });

        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("store.owner");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.equalTo("store", store);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("sendCall", async request => {
    var currentUser = request.user;
    if (currentUser && request.params.phone) {
        let phone = request.params.phone;
        let message = request.params.message;
        let label = request.params.label;
        let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/voice/call`
        Parse.Cloud.httpRequest({
            method: "POST",
            headers: {
                "f-apiKey": process.env.FALCON_KEY,
                "f-secretKey": process.env.FALCON_SECRET,
                "Content-Type": "application/json"
             },
            url: smsUrlFormat,
            body: {
                'message': message,
                'destinationsList': [phone],
                'label': label
            },
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            logToSlack2(`Call -> Mensaje "${message}" enviando a: ${phone}`)
            logToSlack2(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status);
            logToSlack2(`BO Send Call Request failed: ${httpResponse.text}`)
        });

        return true;

    } else {
        return null;
    }
});

Parse.Cloud.define("getCustomersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        //queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        
        var CustomerClass = Parse.Object.extend("Customer");
        var query = new Parse.Query(CustomerClass);
        query.include('store')
        query.equalTo("store", store);
        query.limit(5000);
        let customers = await query.find({ useMasterKey: true });
        return customers;
    } else {
        return null;
    }
});

Parse.Cloud.define("getMyCustomersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        
        var CustomerClass = Parse.Object.extend("Customer");
        var query = new Parse.Query(CustomerClass);
        query.include('store')
        query.equalTo("store", store);
        query.limit(5000);
        let customers = await query.find({ useMasterKey: true });
        return customers;
    } else {
        return null;
    }
});



Parse.Cloud.define("importCustomersBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let customers = request.params.customers;
        let customersReturnArray = [];

        if (customers.length > 0) {

            var StoreClass = Parse.Object.extend("Store");
            var queryStore = new Parse.Query(StoreClass);
            //query.equalTo("owner", currentUser);
            let store = await queryStore.get(id, { useMasterKey: true });

            customers.forEach(async (customer) => {
                
                let CustomerClass = Parse.Object.extend("Customer");
                var newCustomer = new CustomerClass()

                var queryCustomer = new Parse.Query(CustomerClass);
                queryCustomer.equalTo("store", store);
                queryCustomer.equalTo("phone", customer.phone);
                let customerExist = await queryCustomer.first({ useMasterKey: true });

                if (customerExist) {
                    newCustomer = customerExist;
                }
              
                newCustomer.set('store', store)
                newCustomer.set('name', customer.name)
                newCustomer.set('phone', customer.phone)
                newCustomer.set('address', customer.address)
                newCustomer.set('status', 'active')
                newCustomer.set('tags', [])

                let newp = await newCustomer.save(null, { useMasterKey: true })
                productsReturnArray.push(newp)
            });

            return customersReturnArray;
        }
        return null;
    } else {
        return null;
    }
});

Parse.Cloud.define("reportBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            var arrMonths = [];        
            let OrderClass = Parse.Object.extend("Order");
            let queryOrders = new Parse.Query(OrderClass);
            //queryOrders.include('payment');
            queryOrders.equalTo("status", 'delivered');
            //queryOrders.ascending('createdAt');
            await queryOrders.each( async order_init => {
                arrMonths.push(order_init)
                
                /*const query = new Parse.Query(OrderClass)
                query.include('payment');
                let order = await query.get(order_init.id, { useMasterKey: true });
                
                let index = arrMonths.findIndex((element) => element.month == order.attributes.createdAt.getMonth() && element.year == order.attributes.createdAt.getFullYear())
                if (index >= 0) {
    
                    arrMonths[index].total = arrMonths[index].total + (order.attributes.total - order.attributes.deliveryCost)
                    arrMonths[index].totalPOS = order.attributes.source == 'pos' ? arrMonths[index].totalPOS + (order.attributes.total - order.attributes.deliveryCost) : arrMonths[index].totalPOS
                    arrMonths[index].totalClient = order.attributes.source == 'client' ? arrMonths[index].totalClient + (order.attributes.total - order.attributes.deliveryCost) : arrMonths[index].totalClient
                    arrMonths[index].totalEfecty = order.attributes.payment.attributes.method == 'OnDelivery' ? arrMonths[index].totalEfecty + (order.attributes.total - order.attributes.deliveryCost) : arrMonths[index].totalEfecty
                    arrMonths[index].totalTransfer = order.attributes.payment.attributes.method == 'digitalTransfer' ? arrMonths[index].totalTransfer + (order.attributes.total - order.attributes.deliveryCost) : arrMonths[index].totalTransfer
                    arrMonths[index].length = arrMonths[index].length + 1
                    arrMonths[index].lengthPOS = order.attributes.source == 'pos' ? arrMonths[index].lengthPOS + 1 : arrMonths[index].lengthPOS
                    arrMonths[index].lengthClient = order.attributes.source == 'client' ? arrMonths[index].lengthClient + 1 : arrMonths[index].lengthClient
    
                }else{
                    arrMonths.push({
                        month: order.attributes.createdAt.getMonth(),
                        year: order.attributes.createdAt.getFullYear(),
                        total: (order.attributes.total - order.attributes.deliveryCost),
                        totalPOS: order.attributes.source == 'pos' ? (order.attributes.total - order.attributes.deliveryCost) : 0,
                        totalClient: order.attributes.source == 'client' ? (order.attributes.total - order.attributes.deliveryCost) : 0,
                        totalEfecty: order.attributes.payment.attributes.method == 'OnDelivery' ? (order.attributes.total - order.attributes.deliveryCost) : 0,
                        totalTransfer: order.attributes.payment.attributes.method == 'digitalTransfer' ? (order.attributes.total - order.attributes.deliveryCost) : 0,
                        length: 1,
                        lengthPOS: order.attributes.source == 'pos' ? 1 : 0,
                        lengthClient: order.attributes.source == 'client' ? 1 : 0,
                    });
                }*/
    
            }, {useMasterKey: true});
            
            //let orders = await queryOrders.find({ useMasterKey: true });

            let orders = arrMonths.sort(function(a,b){
                return a.createdAt - b.createdAt;
            });
            
            if (orders.length > 0) {
                let from = orders[0].attributes.createdAt
                let to = orders[orders.length - 1].attributes.createdAt
                var arrMonths = [];

                var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

                var fromYear =  from.getFullYear();
                var toYear =  to.getFullYear();
                var diffYear = (12 * (toYear - fromYear)) + to.getMonth();
                    
                    for (var i = from.getMonth(); i <= diffYear; i++) {
                        let totalOrders = orders.reduce((a, b) => {
                            if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                                return a + (b.attributes.total - b.attributes.deliveryCost)
                            }
                            return a
                        }, 0);
        
                        let ordersLength = orders.filter(order => {
                            if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                                return order
                            }
                        }).length
        
                        let ordersLengthPOS = orders.filter(order => {
                            if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                                return order
                            }
                        }).length
        
                        let ordersLengthClient = orders.filter(order => {
                            if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                                return order
                            }
                        }).length
        
                        let ordersLengthEfecty = orders.filter(order => {
                            if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                                return order
                            }
                        }).length
        
                        let ordersLengthTransfer = orders.filter(order => {
                            if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                                return order
                            }
                        }).length
        
                        let totalOrdersPOS = orders.reduce((a, b) => {
                            if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                                return a + (b.attributes.total - b.attributes.deliveryCost)
                            }
                            return a
                        }, 0);
        
                        let totalOrdersClient = orders.reduce((a, b) => {
                            if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                                return a + (b.attributes.total - b.attributes.deliveryCost)
                            }
                            return a
                        }, 0);
        
                        let totalOrdersEfecty = orders.reduce((a, b) => {
                            if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                                return a + (b.attributes.total - b.attributes.deliveryCost)
                            }
                            return a
                        }, 0);
        
                        let totalOrdersTransfers = orders.reduce((a, b) => {
                            if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                                return a + (b.attributes.total - b.attributes.deliveryCost)
                            }
                            return a
                        }, 0);
        
                        arrMonths.push({
                            month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                            total: totalOrders,
                            totalPOS: totalOrdersPOS,
                            totalClient: totalOrdersClient,
                            totalEfecty: totalOrdersEfecty,
                            totalTransfer: totalOrdersTransfers,
                            length: ordersLength,
                            lengthPOS: ordersLengthPOS,
                            lengthClient: ordersLengthClient,
                            //lengthEfecty: ordersLengthEfecty,
                            //lengthTransfer: ordersLengthTransfer
                        });
                    }
        
                return arrMonths;
                    
            }
        } catch (error) {
            throw error.message;
        }
        
        return null;

    } else {
        return null;
    }
});

Parse.Cloud.job("resportJobBO", async function (request) {
    resportJob()
});

Parse.Cloud.job("resportJobSincelejoBO", async function (request) {
    resportJobSincelejo()
});

Parse.Cloud.job("resportJobValleduparBO", async function (request) {
    resportJobValledupar()
});

const resportJob = async () => {
    try {
        var arrMonths = [];        
        let OrderClass = Parse.Object.extend("Order");
        let queryOrders = new Parse.Query(OrderClass);
        //queryOrders.include('payment');
        queryOrders.equalTo("status", 'delivered');
        //queryOrders.ascending('createdAt');
        await queryOrders.each( async order_init => {
            arrMonths.push(order_init)
        }, {useMasterKey: true});
        //let orders = await queryOrders.find({ useMasterKey: true });

        let orders = arrMonths.sort(function(a,b){
            return a.createdAt - b.createdAt;
        });
        
        if (orders.length > 0) {
            let from = orders[0].attributes.createdAt
            let to = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();
                
                for (var i = from.getMonth(); i <= diffYear; i++) {
                    let totalOrders = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let ordersLength = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return order
                        }
                    }).length
    
                    let ordersLengthPOS = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                            return order
                        }
                    }).length
    
                    let ordersLengthClient = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                            return order
                        }
                    }).length
    
                    let ordersLengthEfecty = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                            return order
                        }
                    }).length
    
                    let ordersLengthTransfer = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                            return order
                        }
                    }).length
    
                    let totalOrdersPOS = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersClient = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersEfecty = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersTransfers = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    arrMonths.push({
                        month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                        total: totalOrders,
                        totalPOS: totalOrdersPOS,
                        totalClient: totalOrdersClient,
                        totalEfecty: totalOrdersEfecty,
                        totalTransfer: totalOrdersTransfers,
                        length: ordersLength,
                        lengthPOS: ordersLengthPOS,
                        lengthClient: ordersLengthClient,
                        //lengthEfecty: ordersLengthEfecty,
                        //lengthTransfer: ordersLengthTransfer
                    });
                }
            
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            query.equalTo('code', 'RG1')
            let report = await query.first({ useMasterKey: true });
            if (!report) {
                report = new ReportClass();
                report.set('name', 'Reporte General')
                report.set('code', 'RG1')
                report.set('status', true)
                report.set('type', 'admin')
            }
            report.set("result", {
                result: arrMonths
            });
            await report.save(null, { useMasterKey: true });
            logToSlack2(`[BO] NEW GENERAL REPORT CREATED`);
        }
    } catch (error) {
        throw error.message;
    }
}

const resportJobValledupar = async () => {        
    try {
        var StoreClass = Parse.Object.extend("Store");
        var innerQuery = new Parse.Query(StoreClass);
        innerQuery.fullText("city", 'Valledupar');

        var arrMonths = [];        
        let OrderClass = Parse.Object.extend("Order");
        let queryOrders = new Parse.Query(OrderClass);
        //queryOrders.include('payment');
        queryOrders.matchesQuery("store", innerQuery);
        queryOrders.equalTo("status", 'delivered');
        //queryOrders.ascending('createdAt');
        await queryOrders.each( async order_init => {
            arrMonths.push(order_init)
        }, {useMasterKey: true});
        //let orders = await queryOrders.find({ useMasterKey: true });

        let orders = arrMonths.sort(function(a,b){
            return a.createdAt - b.createdAt;
        });
        
        if (orders.length > 0) {
            let from = orders[0].attributes.createdAt
            let to = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();
                
                for (var i = from.getMonth(); i <= diffYear; i++) {
                    let totalOrders = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let ordersLength = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return order
                        }
                    }).length
    
                    let ordersLengthPOS = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                            return order
                        }
                    }).length
    
                    let ordersLengthClient = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                            return order
                        }
                    }).length
    
                    let ordersLengthEfecty = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                            return order
                        }
                    }).length
    
                    let ordersLengthTransfer = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                            return order
                        }
                    }).length
    
                    let totalOrdersPOS = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersClient = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersEfecty = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersTransfers = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    arrMonths.push({
                        month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                        total: totalOrders,
                        totalPOS: totalOrdersPOS,
                        totalClient: totalOrdersClient,
                        totalEfecty: totalOrdersEfecty,
                        totalTransfer: totalOrdersTransfers,
                        length: ordersLength,
                        lengthPOS: ordersLengthPOS,
                        lengthClient: ordersLengthClient,
                        //lengthEfecty: ordersLengthEfecty,
                        //lengthTransfer: ordersLengthTransfer
                    });
                }
            
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            query.equalTo('code', 'RV1')
            let report = await query.first({ useMasterKey: true });
            if (!report) {
                report = new ReportClass();
                report.set('name', 'Reporte General de Valledupar')
                report.set('code', 'RV1')
                report.set('status', true)
                report.set('type', 'admin')
            }
            report.set("result", {
                result: arrMonths
            });
            await report.save(null, { useMasterKey: true });
            logToSlack2(`[BO] NEW VALLEDUPAR GENERAL REPORT CREATED`);
        }
    } catch (error) {
        throw error.message;
    }
}

const resportJobSincelejo = async () => {       
    try {
        var StoreClass = Parse.Object.extend("Store");
        var innerQuery = new Parse.Query(StoreClass);
        innerQuery.fullText("city", 'Sincelejo');
        //innerQuery.matches("city", 'Sincelejo', "i");

        var arrOrders = [];        
        let OrderClass = Parse.Object.extend("Order");
        let queryOrders = new Parse.Query(OrderClass);
        //queryOrders.include('payment');
        queryOrders.matchesQuery("store", innerQuery);
        queryOrders.equalTo("status", 'delivered');
        //queryOrders.ascending('createdAt');
        await queryOrders.each( async result => {
            arrOrders.push(result)
        }, {useMasterKey: true});
        //let orders = await queryOrders.find({ useMasterKey: true });

        let orders = arrOrders.sort(function(a,b){
            return a.createdAt - b.createdAt;
        });
        
        if (orders.length > 0) {
            let from = orders[0].attributes.createdAt
            let to = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();
                
                for (var i = from.getMonth(); i <= diffYear; i++) {
                    let totalOrders = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let ordersLength = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return order
                        }
                    }).length
    
                    let ordersLengthPOS = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                            return order
                        }
                    }).length
    
                    let ordersLengthClient = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                            return order
                        }
                    }).length
    
                    let ordersLengthEfecty = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                            return order
                        }
                    }).length
    
                    let ordersLengthTransfer = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                            return order
                        }
                    }).length
    
                    let totalOrdersPOS = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersClient = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersEfecty = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersTransfers = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    arrMonths.push({
                        month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                        total: totalOrders,
                        totalPOS: totalOrdersPOS,
                        totalClient: totalOrdersClient,
                        totalEfecty: totalOrdersEfecty,
                        totalTransfer: totalOrdersTransfers,
                        length: ordersLength,
                        lengthPOS: ordersLengthPOS,
                        lengthClient: ordersLengthClient,
                        //lengthEfecty: ordersLengthEfecty,
                        //lengthTransfer: ordersLengthTransfer
                    });
                }
            
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            query.equalTo('code', 'RS1')
            let report = await query.first({ useMasterKey: true });
            if (!report) {
                report = new ReportClass();
                report.set('name', 'Reporte General de Sincelejo')
                report.set('code', 'RS1')
                report.set('status', true)
                report.set('type', 'admin')
            }
            report.set("result", {
                result: arrMonths
            });
            await report.save(null, { useMasterKey: true });
            logToSlack2(`[BO] NEW SINCELEJO GENERAL REPORT CREATED`);
        }
    } catch (error) {
        console.log(`[FESTY][BO] REPORT ERROR: ${error.message}`);
        logToSlack2(`[FESTY][BO] REPORT ERROR: ${error.message}`);
        throw error.message;
    }
}

Parse.Cloud.define("getReportsBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            let reports = await query.find({ useMasterKey: true });
            return reports;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("getReportByIdBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            let id = request.params.id;
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            let reports = await query.get(id, { useMasterKey: true });
            return reports;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("updateReportsBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            let code = request.params.code;
            switch (code) {
                case 'RS1':
                    resportJobSincelejo()
                    break;
                
                case 'RV1':
                    resportJobValledupar()
                    break;
            
                default:
                    resportJob()
                    break;
            }
            //resportJobSincelejo()
            //resportJobValledupar()
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("newGeneralReportBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            var ReportClass = Parse.Object.extend("Report");
            var query = new Parse.Query(ReportClass);
            query.equalTo('code', 'RG1')
            let report = await query.first({ useMasterKey: true });
            return report;
        } catch (error) {
            throw error.message;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("reportByStoreBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        
        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass()
        store.id = id

        let OrderClass = Parse.Object.extend("Order");
        let queryOrders = new Parse.Query(OrderClass);
        queryOrders.include('payment');
        queryOrders.equalTo("store", store);
        queryOrders.equalTo("status", 'delivered');
        queryOrders.ascending('createdAt')
        queryOrders.limit(1000000)
        let orders = await queryOrders.find({ useMasterKey: true });
        
        if (orders.length > 0) {
            let from = orders[0].attributes.createdAt
            let to = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();

            try {
                
                for (var i = from.getMonth(); i <= diffYear; i++) {
                    let totalOrders = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let ordersLength = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return order
                        }
                    }).length
    
                    let ordersLengthPOS = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                            return order
                        }
                    }).length
    
                    let ordersLengthClient = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                            return order
                        }
                    }).length
    
                    /*let ordersLengthEfecty = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                            return order
                        }
                    }).length
    
                    let ordersLengthTransfer = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                            return order
                        }
                    }).length*/
    
                    let totalOrdersPOS = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersClient = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersEfecty = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersTransfers = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    arrMonths.push({
                        month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                        total: totalOrders,
                        totalPOS: totalOrdersPOS,
                        totalClient: totalOrdersClient,
                        totalEfecty: totalOrdersEfecty,
                        totalTransfer: totalOrdersTransfers,
                        length: ordersLength,
                        lengthPOS: ordersLengthPOS,
                        lengthClient: ordersLengthClient,
                        //lengthEfecty: ordersLengthEfecty,
                        //lengthTransfer: ordersLengthTransfer
                    });
                }
    
                return arrMonths;
                
            } catch (error) {
                throw error.message;
            }
            
        }

        return null;

    } else {
        return null;
    }
});

Parse.Cloud.define("reportMyStoreBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.include('owner')
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });

        let OrderClass = Parse.Object.extend("Order");
        let queryOrders = new Parse.Query(OrderClass);
        queryOrders.include('payment');
        queryOrders.equalTo("store", store);
        queryOrders.equalTo("status", 'delivered');
        queryOrders.ascending('createdAt')
        queryOrders.limit(1000000)
        let orders = await queryOrders.find({ useMasterKey: true });
        
        if (orders.length > 0) {
            let from = orders[0].attributes.createdAt
            let to = orders[orders.length - 1].attributes.createdAt
            var arrMonths = [];

            var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Novimebre", "Diciembre" ];

            var fromYear =  from.getFullYear();
            var toYear =  to.getFullYear();
            var diffYear = (12 * (toYear - fromYear)) + to.getMonth();

            try {
                
                for (var i = from.getMonth(); i <= diffYear; i++) {
                    let totalOrders = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let ordersLength = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12))) {
                            return order
                        }
                    }).length
    
                    let ordersLengthPOS = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'pos') {
                            return order
                        }
                    }).length
    
                    let ordersLengthClient = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.source == 'client') {
                            return order
                        }
                    }).length
    
                    /*let ordersLengthEfecty = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'OnDelivery') {
                            return order
                        }
                    }).length
    
                    let ordersLengthTransfer = orders.filter(order => {
                        if (order.attributes.createdAt.getMonth() === (i%12) && order.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && order.attributes.payment.attributes.method == 'digitalTransfer') {
                            return order
                        }
                    }).length*/
    
                    let totalOrdersPOS = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'pos') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersClient = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.source == 'client') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersEfecty = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'OnDelivery') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    let totalOrdersTransfers = orders.reduce((a, b) => {
                        if (b.attributes.createdAt.getMonth() === (i%12) && b.attributes.createdAt.getFullYear() === Math.floor(fromYear+(i/12)) && b.attributes.payment.attributes.method == 'digitalTransfer') {
                            return a + (b.attributes.total - b.attributes.deliveryCost)
                        }
                        return a
                    }, 0);
    
                    arrMonths.push({
                        month: monthNames[i%12] + " " + Math.floor(fromYear+(i/12)),
                        total: totalOrders,
                        totalPOS: totalOrdersPOS,
                        totalClient: totalOrdersClient,
                        totalEfecty: totalOrdersEfecty,
                        totalTransfer: totalOrdersTransfers,
                        length: ordersLength,
                        lengthPOS: ordersLengthPOS,
                        lengthClient: ordersLengthClient,
                        //lengthEfecty: ordersLengthEfecty,
                        //lengthTransfer: ordersLengthTransfer
                    });
                }
    
                return arrMonths;
                
            } catch (error) {
                throw error.message;
            }
            
        }

        return null;

    } else {
        return null;
    }
});


Parse.Cloud.define("getOrdersByStoreFilterWithPromoBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let init = request.params.init ? new Date(request.params.init) : '';
        let end = request.params.end ? new Date(request.params.end) : '';
        let status = request.params.status;
        let source = request.params.source;

        if (!init || !end) {
            let date = new Date();
            init = new Date(date.getFullYear(), date.getMonth(), 1);
            end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
            end.setHours(23,59,59,999);

            init.setHours(init.getHours() + 5);
            init = new Date(init);

            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }else{
            
            init.setHours(init.getHours() + 5);
            init = new Date(init);
            
            end.setHours(23,59,59,999);
            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }


        //logToSlack2('StartDate: ' + init.toString())
        //logToSlack2('EndDate: ' + end.toString())

        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.exists('promoCode')
        
        query.greaterThanOrEqualTo("createdAt", init)
        query.lessThanOrEqualTo("createdAt", end);
        
        if (status) {
            query.equalTo("status", status);
        }else{
            query.equalTo("status", 'delivered');
        }
        
        if (source && source != 'all') {
            query.equalTo("source", source);
        }
        query.notEqualTo("status", 'cancelled');
        query.descending("createdAt");
        query.limit(10000);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.job("newOpenCloseStores", async function (request) {
    
    let now = moment().subtract(5, 'hours');
    let day = now.day();
    let hour = now.hour();

    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    query.include('owner');
    query.equalTo('hours.status', 'active');
    query.notEqualTo("status", 'created');
    query.limit(5000)
    let stores = await query.find({ useMasterKey: true });

    let array_store_open = []
    let array_store_close = []
    if (stores && stores.length > 0) {
        for (let index = 0; index < stores.length; index++) {
            const element = stores[index];
            if (element.attributes.hours.status == 'active') {
                let weekday = element.attributes.hours.weekdays[day]
                if (weekday.status == 'active' && weekday.hours[hour] != undefined) {
                    switch (weekday.hours[hour]) {
                        case 1:
                            if (element.attributes.status != 'active') {
                                element.set('status', 'active')
                                element.save(null, { useMasterKey: true });
                                array_store_open.push(element.attributes.name)
                                notificationOpenCloseStore(element.attributes.owner.id, element.id, true);
                            }
                            break;
    
                        case 0:
                            if (element.attributes.status != 'inactive') {
                                element.set('status', 'inactive')
                                element.save(null, { useMasterKey: true });
                                array_store_close.push(element.attributes.name)
                                notificationOpenCloseStore(element.attributes.owner.id, element.id, false);
                            }
                            break;
                        
                        default:
                            break;
                    }
                }else if (element.attributes.status == 'active') {
                    element.set('status', 'inactive')
                    element.save(null, { useMasterKey: true });
                    array_store_close.push(element.attributes.name)
                    notificationOpenCloseStore(element.attributes.owner.id, element.id, false);
                }
            }
        }

        logToSlack2(`[JOB OPEN/CLOSE STORES] [${now.format('LLLL')}] => De ${stores.length} comercios, se abrieron ${array_store_open.length} y se cerraron ${array_store_close.length}`);
        if (array_store_open.length > 0)
            logToSlack2(`[LISTA DE COMERCIOS ABIERTOS] => ${array_store_open.join(', ')}`);
        if (array_store_close.length > 0)
            logToSlack2(`[LISTA DE COMERCIOS CERRADOS] => ${array_store_close.join(', ')}`);
    }

    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://hc-ping.com/960e5f93-6746-4032-976c-dac8f82693ce"
    }).then(function (httpResponse) {
        console.log(httpResponse.text);
    }, function (httpResponse) {
        console.error('Request failed with response code ' + httpResponse.status);
    });

});

Parse.Cloud.define("updateHours", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var hours = request.params.hours;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("hours", hours);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateMyHours", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var hours = request.params.hours;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("hours", hours);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("saveGeoCoverageStoreBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var geoCoverage = request.params.geoCoverage;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        //query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        store.set('geoCoverage', new Parse.Polygon(geoCoverage));
        let store_update = store.save(null, { useMasterKey: true });
        return store_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreCategoryClass = Parse.Object.extend("StoreCategory");
        var query = new Parse.Query(StoreCategoryClass);
        query.limit(5000);
        let categories = await query.find({ useMasterKey: true });
        return categories;
    } else {
        return null;
    }
});

Parse.Cloud.job("calculateRatingStores", async function (request) {
    try {
        var StoreClass = Parse.Object.extend("Store");
        var queryStores = new Parse.Query(StoreClass);
        queryStores.notEqualTo("status", 'created');
        queryStores.limit(5000)
        let stores = await queryStores.find({ useMasterKey: true });
        
        if (stores && stores.length > 0) {
            var date = new Date(new Date().setHours(-5,0,0,0));
            let initDate = date.setMonth(date.getMonth() - 6);
            initDate = new Date(initDate);
            
            for (let index = 0; index < stores.length; index++) {
                var arrOrders = [];  
                const store = stores[index];
                let OrderClass = Parse.Object.extend("Order");
                let queryOrders = new Parse.Query(OrderClass);
                queryOrders.equalTo("store", store);
                queryOrders.equalTo("status", 'delivered');
                queryOrders.exists('rating');
                queryOrders.greaterThanOrEqualTo("createdAt", initDate)
                await queryOrders.each( async order_init => {
                    arrOrders.push(order_init)
                }, {useMasterKey: true});

                if (arrOrders.length >= 5) {
                    let total = arrOrders.length;
                    let summation = arrOrders.reduce((a, b) => a + b.attributes.rating, 0);
                    let prom = Number(summation) / Number(total);
                    store.set('rating', Number(prom.toFixed(2)))
                    await store.save(null, { useMasterKey: true });
                    logToSlack2(`STORE: ${store.attributes.name} - RATING: ${Number(prom.toFixed(2))}`);
                }
            }
        }
        
    } catch (error) {
        throw error.message;
    }
});

Parse.Cloud.define("getUserBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var query = new Parse.Query(Parse.User);
        let user = await query.get(id, { useMasterKey: true });
        return user;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrdersByUserBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var withCancelled = request.params.withCancelled;
        var OrderClass = Parse.Object.extend("Order");
        var user = new Parse.User();
        user.set("id", id)
        var query = new Parse.Query(OrderClass);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.descending("createdAt");
        query.equalTo("owner", user)
        if (!withCancelled) {
            query.notEqualTo("status", 'cancelled');
        }
        query.limit(20000)
        let orders = await query.find({ useMasterKey: true });
       
        return orders;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrdersByUserFilterBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let init = new Date(request.params.init);
        let end = new Date(request.params.end);
        let status = request.params.status;

        init.setHours(init.getHours() + 5);
        init = new Date(init);
        
        end.setHours(23,59,59,999);
        end.setHours(end.getHours() + 5);
        end = new Date(end);

        var user = new Parse.User();
        user.set("id", id)
        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner");
        query.include("rider");
        query.exclude("User.authData");
        query.equalTo("owner", user);
        
        query.greaterThanOrEqualTo("createdAt", init)
        query.lessThanOrEqualTo("createdAt", end);
        
        if (status) {
            query.equalTo("status", status);
        }else{
            query.notEqualTo("status", 'cancelled');
        }

        query.descending("createdAt");
        query.limit(20000);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getOrdersByCityFilterBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let city = request.params.city;
        let source = request.params.source;
        let init = request.params.init ? new Date(request.params.init) : '';
        let end = request.params.end ? new Date(request.params.end) : '';
        let status = request.params.status;

        if (!init || !end) {
            let date = new Date();
            init = new Date(date.getFullYear(), date.getMonth(), 1);
            end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
            end.setHours(23,59,59,999);

            init.setHours(init.getHours() + 5);
            init = new Date(init);

            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }else{
            
            init.setHours(init.getHours() + 5);
            init = new Date(init);
            
            end.setHours(23,59,59,999);
            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }

        //logToSlack2('StartDate: ' + init.toString())
        //logToSlack2('EndDate: ' + end.toString())

        let StoreClass = Parse.Object.extend("Store");
        var innerQuery = new Parse.Query(StoreClass);
        //innerQuery.fullText("city", city);
        innerQuery.matches("city", city, "i");
        
        let Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.matchesQuery("store", innerQuery);

        query.greaterThanOrEqualTo("createdAt", init);
        query.lessThanOrEqualTo("createdAt", end);
        
        if (status && status.length > 0) {
            query.containedIn("status", status); 
        }
        query.include('owner');

        if (source && source != 'all') {
            query.equalTo("source", source);
        }

        let orders = [] //await query.find({ useMasterKey: true });

        await query.each( async order_init => {
            orders.push(order_init)
        }, {useMasterKey: true});


        let owners = []
        if (orders.length > 0) {
            owners = orders.filter((item) => item.attributes.owner.attributes.phone).map(obj => {
                if (obj.attributes.source == 'pos' && (source == 'all' || source == 'pos')) {
                   return { id: obj.attributes.comments, name: obj.attributes.alias, phone: obj.attributes.comments, source: obj.attributes.source }
                }else{
                  return { id: obj.attributes.owner.id, name: obj.attributes.alias, phone: obj.attributes.owner.attributes.phone, source: obj.attributes.source }
                }
            });
            owners = Array.from(new Set(owners))
            owners = owners.filter(Boolean);
        }

        let uniqueObjects = [...new Map(owners.map(item => [item.id, item])).values()]
        
        return uniqueObjects;
    } else {
        return null;
    }
});

Parse.Cloud.define("getUsersByCityFilterBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let withPhone = request.params.withPhone
        let init = request.params.init ? new Date(request.params.init) : '';
        let end = request.params.end ? new Date(request.params.end) : '';

        if (!init || !end) {
            let date = new Date();
            init = new Date(date.getFullYear(), date.getMonth(), 1);
            end = new Date(date.getFullYear(), date.getMonth() + 1, 0);
            end.setHours(23,59,59,999);

            init.setHours(init.getHours() + 5);
            init = new Date(init);

            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }else{
            
            init.setHours(init.getHours() + 5);
            init = new Date(init);
            
            end.setHours(23,59,59,999);
            end.setHours(end.getHours() + 5);
            end = new Date(end);
        }

        var query = new Parse.Query(Parse.User);
        if (withPhone) {
            query.exists('phone')
        }
        query.greaterThanOrEqualTo("createdAt", init);
        query.lessThanOrEqualTo("createdAt", end);
        
        let users = [] //await query.find({ useMasterKey: true });

        await query.each( async users_init => {
            users.push(users_init)
        }, {useMasterKey: true});


        let owners = []
        if (users.length > 0) {
            owners = users.map(obj => {
                return { id: obj.id, name: obj.attributes.name, phone: obj.attributes.phone }
            });
            owners = Array.from(new Set(owners))
            owners = owners.filter(Boolean);
        }

        let uniqueObjects = [...new Map(owners.map(item => [item.id, item])).values()]
        
        return uniqueObjects;
    } else {
        return null;
    }
});

Parse.Cloud.define("getAddressesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var user = new Parse.User();
        user.set("id", id)
        var AddressClass = Parse.Object.extend("Address");
        var query = new Parse.Query(AddressClass);
        query.equalTo("owner", user);
        query.notEqualTo("status", "deleted");
        query.ascending("updatedAt");
        let addresses = await query.find({ useMasterKey: true });
        return addresses;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getProductDiscountBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });

        var ProductDiscountClass = Parse.Object.extend("ProductDiscount");
        var queryProductDiscount = new Parse.Query(ProductDiscountClass);
        queryProductDiscount.equalTo('store', store)
        queryProductDiscount.notEqualTo('status', 'deleted')
        let results = await queryProductDiscount.find({ useMasterKey: true });
        
        return results;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getMyProductDiscountBO", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        queryStore.equalTo("objectId", id);
        queryStore.equalTo("owner", currentUser);
        let store = await queryStore.first({ useMasterKey: true });

        var ProductDiscountClass = Parse.Object.extend("ProductDiscount");
        var queryProductDiscount = new Parse.Query(ProductDiscountClass);
        queryProductDiscount.equalTo('store', store)
        queryProductDiscount.notEqualTo('status', 'deleted')
        let results = await queryProductDiscount.find({ useMasterKey: true });
        
        return results;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("saveDiscountBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var name = request.params.name;
        var type = request.params.type;
        var elements = request.params.elements;
        var typeValue = request.params.typeValue;
        var value = request.params.value;
        var currentTime = new Date();

        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });

        var ProductDiscountClass = Parse.Object.extend("ProductDiscount");
        var productDiscount = new ProductDiscountClass();
        
        productDiscount.set('name', name);
        productDiscount.set('type', type);
        productDiscount.set('elements', elements);
        productDiscount.set('typeValue', typeValue);
        productDiscount.set('value', value);
        productDiscount.set('lastUsed', currentTime);
        productDiscount.set('status', 'active');
        productDiscount.set('store', store);

        productDiscount.set('log',[{
            user: currentUser.id,
            type: 'created',
            date: currentTime
        }]);

        let newProductDiscount = await productDiscount.save(null, { useMasterKey: true });

        if (newProductDiscount) {
            var ProductClass = Parse.Object.extend("Product");
            var queryProducts = new Parse.Query(ProductClass);
            queryProducts.equalTo('store', store)
            
            if (newProductDiscount.attributes.type === 'categories') {
                queryProducts.containedIn('productCategory', newProductDiscount.attributes.elements)
            }else if(newProductDiscount.attributes.type === 'products'){
                queryProducts.containedIn('objectId', newProductDiscount.attributes.elements)
            }
            queryProducts.limit(5000)
            let products = await queryProducts.find({ useMasterKey: true });

            if (products && products.length > 0) {
                for (let index = 0; index < products.length; index++) {
                    let product = products[index];
                    
                    if (newProductDiscount.attributes.typeValue === 'value') {
                        product.set('newPrice', Number(product.attributes.price) - Number(newProductDiscount.attributes.value))
                    }else{
                        product.set('newPrice', Number(product.attributes.price) - Number(product.attributes.price)*(Number(newProductDiscount.attributes.value)/100))
                    }

                    await product.save(null, { useMasterKey: true });
                }
            }
            return newProductDiscount
        }
        return null
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusDiscountBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var isDelete = request.params.isDelete;
        var currentTime = new Date();
        var ProductDiscountClass = Parse.Object.extend("ProductDiscount");
        var queryProductDiscount = new Parse.Query(ProductDiscountClass);
        queryProductDiscount.include('store')
        let result = await queryProductDiscount.get(id, { useMasterKey: true });
        if (result) {
            let status = isDelete ? 'deleted' : result.attributes.status === 'inactive' ? 'active' : 'inactive'
            let arrayLog = result.attributes.log
            result.set('status', status)
            result.set('log', arrayLog.concat({
                user: currentUser.id,
                type: status,
                date: currentTime
            }));
            let editResult = await result.save(null, { useMasterKey: true });
            
            if (editResult) {
                var ProductClass = Parse.Object.extend("Product");
                var queryProducts = new Parse.Query(ProductClass);
                queryProducts.equalTo('store', result.attributes.store)
                
                if (editResult.attributes.type === 'categories') {
                    queryProducts.containedIn('productCategory', editResult.attributes.elements)
                }else if(editResult.attributes.type === 'products'){
                    queryProducts.containedIn('objectId', editResult.attributes.elements)
                }
                queryProducts.limit(5000)
                let products = await queryProducts.find({ useMasterKey: true });

                if (products && products.length > 0) {
                    for (let index = 0; index < products.length; index++) {
                        let product = products[index];
                        
                        if (status === 'active') {
                            if (editResult.attributes.typeValue === 'value') {
                                product.set('newPrice', Number(product.attributes.price) - Number(editResult.attributes.value))
                            }else{
                                product.set('newPrice', Number(product.attributes.price) - Number(product.attributes.price)*(Number(editResult.attributes.value)/100))
                            }
                        }else{
                            product.set('newPrice', null)
                        }

                        await product.save(null, { useMasterKey: true });
                    }
                }

                return editResult
            }
        }
        return null;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getPromoCodesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var query = new Parse.Query(PromoCodeClass);
        query.limit(5000);
        query.descending('createdAt')
        let promoCodes = await query.find({ useMasterKey: true });
        return promoCodes;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("newPromoCodeBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var code = request.params.code;
        var maxUses = request.params.maxUses;
        var maxUsesXUser = request.params.maxUsesXUser;
        var value = request.params.value;
        var minOrderAmount = request.params.minOrderAmount;
        var type = request.params.type;
        var validUntil = request.params.validUntil;
        var stores = request.params.stores;
        var description = request.params.description;
        var byDelivery = request.params.byDelivery;
        var status = request.params.status;

        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var promoCode = new PromoCodeClass();

        promoCode.set("code", code);
        promoCode.set("uses", 0);
        promoCode.set("maxUses", maxUses);
        promoCode.set("maxUsesXUser", maxUsesXUser);
        promoCode.set("value", value);
        promoCode.set("minOrderAmount", minOrderAmount);
        promoCode.set("type", type);
        promoCode.set("stores", stores);
        promoCode.set("description", description);
        promoCode.set("byDelivery", byDelivery);
        promoCode.set("status", status);
        if (validUntil) {
            let newDate = new Date(validUntil)
            newDate.setHours(23,59,59,999)
            newDate.setHours(newDate.getHours() + 5);
            newDate = new Date(newDate)
            promoCode.set("validUntil", newDate);
        }

        let result = await promoCode.save(null, { useMasterKey: true });
        logToSlack2("[BO] FESTY new promo code added " + code + ' - ' + type + " - " + value);
        return result;
        
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("editPromoCodeBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        var code = request.params.code;
        var maxUses = request.params.maxUses;
        var maxUsesXUser = request.params.maxUsesXUser;
        var value = request.params.value;
        var minOrderAmount = request.params.minOrderAmount;
        var type = request.params.type;
        var validUntil = request.params.validUntil;
        var stores = request.params.stores;
        var description = request.params.description;
        var byDelivery = request.params.byDelivery;

        var PromoCodeClass = Parse.Object.extend("PromoCode");
        let query = new Parse.Query(PromoCodeClass);
        let promoCode = await query.get(id, { useMasterKey: true });

        promoCode.set("code", code ? code : promoCode.attributes.code);
        promoCode.set("maxUses", maxUses ? maxUses : promoCode.attributes.maxUses);
        promoCode.set("maxUsesXUser", maxUsesXUser ? maxUsesXUser : promoCode.attributes.maxUsesXUser);
        promoCode.set("value", value ? value : promoCode.attributes.value);
        promoCode.set("minOrderAmount", minOrderAmount ? minOrderAmount : promoCode.attributes.minOrderAmount);
        promoCode.set("type", type ? type : promoCode.attributes.type);
        promoCode.set("stores", stores ? stores : promoCode.attributes.stores);
        promoCode.set("description", description);
        promoCode.set("byDelivery", byDelivery);
        if (validUntil) {
            let newDate = new Date(validUntil)
            newDate.setHours(23,59,59,999)
            newDate.setHours(newDate.getHours() + 5);
            newDate = new Date(newDate)
            promoCode.set("validUntil", newDate);
        }

        let result = await promoCode.save(null, { useMasterKey: true });
        logToSlack2("[BO] FESTY edit promo code " + code + ' - ' + type + " - " + value);
        return result;
        
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusPromoCodeBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var query = new Parse.Query(PromoCodeClass);
        let promoCode = await query.get(id, { useMasterKey: true });
        promoCode.set('status', promoCode.attributes.status === 'inactive' ? 'active' : 'inactive')
        let promoCodeUpdate = await promoCode.save(null, { useMasterKey: true });
        return promoCodeUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("getAppBannersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var AppBannerClass = Parse.Object.extend("AppBanner");
        var query = new Parse.Query(AppBannerClass);
        query.include('zone');
        query.limit(5000);
        query.descending('createdAt')
        let banners = await query.find({ useMasterKey: true });
        return banners;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusAppBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var AppBannerClass = Parse.Object.extend("AppBanner");
        var query = new Parse.Query(AppBannerClass);
        let appBanner = await query.get(id, { useMasterKey: true });
        appBanner.set('status', appBanner.attributes.status === 'inactive' ? 'active' : 'inactive')
        let appBannerUpdate = await appBanner.save(null, { useMasterKey: true });
        return appBannerUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("newAppBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let zoneId = request.params.zone;
        let title = request.params.title;
        let url = request.params.url;
        let superCategory = request.params.superCategory;
        let type = request.params.type;
        let data = request.params.data;
        let status = request.params.status;

        let AppBannerClass = Parse.Object.extend("AppBanner");
        let appBanner = new AppBannerClass();

        let ZoneClass = Parse.Object.extend("Zone");
        let zone = new ZoneClass();
        zone.id = zoneId;

        appBanner.set("zone", zone);
        appBanner.set("title", title);
        appBanner.set("url", url);
        appBanner.set("superCategory", superCategory);
        appBanner.set("type", type);
        appBanner.set("data", data ? data : {});
        appBanner.set("status", status);

        let result = await appBanner.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("editAppBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let zoneId = request.params.zone;
        let title = request.params.title;
        let url = request.params.url;
        let superCategory = request.params.superCategory;
        let type = request.params.type;
        let data = request.params.data;
        let status = request.params.status;

        let AppBannerClass = Parse.Object.extend("AppBanner");
        let query = new Parse.Query(AppBannerClass);
        let appBanner = await query.get(id, { useMasterKey: true });

        let ZoneClass = Parse.Object.extend("Zone");
        let zone = new ZoneClass();
        zone.id = zoneId;

        appBanner.set("zone", zone);
        appBanner.set("title", title);
        appBanner.set("url", url);
        appBanner.set("superCategory", superCategory);
        appBanner.set("type", type);
        appBanner.set("data", data ? data : {});
        appBanner.set("status", status);

        let result = await appBanner.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getStoreBannersBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var storeId = request.params.store;
        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass();
        store.id = storeId;

        var StoreBannerClass = Parse.Object.extend("StoreBanner");
        var query = new Parse.Query(StoreBannerClass);
        query.include('store');
        query.equalTo('store', store);
        query.notEqualTo('status', 'deleted');
        query.limit(5000);
        query.descending('createdAt')
        let banners = await query.find({ useMasterKey: true });
        return banners;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusStoreBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.store;
        var StoreBannerClass = Parse.Object.extend("StoreBanner");
        var query = new Parse.Query(StoreBannerClass);
        let storeBanner = await query.get(id, { useMasterKey: true });
        storeBanner.set('status', storeBanner.attributes.status === 'inactive' ? 'active' : 'inactive')
        let storeBannerUpdate = await storeBanner.save(null, { useMasterKey: true });
        return storeBannerUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("deleteStoreBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.banner;
        var StoreBannerClass = Parse.Object.extend("StoreBanner");
        var query = new Parse.Query(StoreBannerClass);
        let storeBanner = await query.get(id, { useMasterKey: true });
        storeBanner.set('status', 'deleted')
        let storeBannerUpdate = await storeBanner.save(null, { useMasterKey: true });
        return storeBannerUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("newStoreBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let storeId = request.params.store;
        let caption = request.params.caption;
        let url = request.params.url;
        let type = request.params.type;
        let data = request.params.data;
        let status = request.params.status;

        let StoreBannerClass = Parse.Object.extend("StoreBanner");
        let storeBanner = new StoreBannerClass();

        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass();
        store.id = storeId;

        storeBanner.set("store", store);
        storeBanner.set("caption", caption);
        storeBanner.set("url", url);
        storeBanner.set("type", type);
        storeBanner.set("data", data ? data : {});
        storeBanner.set("status", status);

        let result = await storeBanner.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("editStoreBannerBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let storeId = request.params.store;
        let caption = request.params.caption;
        let url = request.params.url;
        let type = request.params.type;
        let data = request.params.data;
        let status = request.params.status;

        let StoreBannerClass = Parse.Object.extend("StoreBanner");
        let query = new Parse.Query(StoreBannerClass);
        let storeBanner = await query.get(id, { useMasterKey: true });

        let StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass();
        store.id = storeId;

        storeBanner.set("store", store);
        storeBanner.set("caption", caption);
        storeBanner.set("url", url);
        storeBanner.set("type", type);
        storeBanner.set("data", data ? data : {});
        storeBanner.set("status", status);

        let result = await storeBanner.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var AppCategoryClass = Parse.Object.extend("AppCategory");
        var query = new Parse.Query(AppCategoryClass);
        query.include('zone');
        query.limit(5000);
        query.ascending('index');
        query.notEqualTo('status', 'deleted');
        let categories = await query.find({ useMasterKey: true });
        return categories;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var AppCategoryClass = Parse.Object.extend("AppCategory");
        var query = new Parse.Query(AppCategoryClass);
        let appCategory = await query.get(id, { useMasterKey: true });
        appCategory.set('status', appCategory.attributes.status === 'inactive' ? 'active' : 'inactive');
        let appCategoryUpdate = await appCategory.save(null, { useMasterKey: true });
        return appCategoryUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("deleteAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var AppCategoryClass = Parse.Object.extend("AppCategory");
        var query = new Parse.Query(AppCategoryClass);
        let appCategory = await query.get(id, { useMasterKey: true });
        appCategory.set('status', 'deleted');
        let appCategoryUpdate = await appCategory.save(null, { useMasterKey: true });
        return appCategoryUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("editIndexAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        let newIndex = request.params.newIndex
        var AppCategoryClass = Parse.Object.extend("AppCategory");
        var query = new Parse.Query(AppCategoryClass);
        let category = await query.get(id, { useMasterKey: true });
        category.set('index', newIndex)
        let category_update = category.save(null, { useMasterKey: true });
        return category_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("newAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let iconUrl = request.params.iconUrl;
        let name = request.params.name;
        let displayName = request.params.displayName;
        let zoneId = request.params.zone;
        let status = request.params.status;
        let index = request.params.index;

        let AppCategoryClass = Parse.Object.extend("AppCategory");
        let appCategory = new AppCategoryClass();

        let ZoneClass = Parse.Object.extend("Zone");
        let zone = new ZoneClass();
        zone.id = zoneId;

        appCategory.set("zone", zone);
        appCategory.set("name", name);
        appCategory.set("displayName", displayName);
        appCategory.set("iconUrl", iconUrl);
        appCategory.set("status", status);
        appCategory.set("index", index);

        let result = await appCategory.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("editAppCategoryBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let iconUrl = request.params.iconUrl;
        let name = request.params.name;
        let displayName = request.params.displayName;
        let zoneId = request.params.zone;
        let status = request.params.status;
        //let index       = request.params.index;

        let AppCategoryClass = Parse.Object.extend("AppCategory");
        let query = new Parse.Query(AppCategoryClass);
        let appCategory = await query.get(id, { useMasterKey: true });

        let ZoneClass = Parse.Object.extend("Zone");
        let zone = new ZoneClass();
        zone.id = zoneId;

        appCategory.set("zone", zone);
        appCategory.set("name", name);
        appCategory.set("displayName", displayName);
        appCategory.set("iconUrl", iconUrl);
        appCategory.set("status", status);
        //appCategory.set("index", index);

        let result = await appCategory.save(null, { useMasterKey: true });
        return result;

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getZonesBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            const query = new Parse.Query('Zone')
            query.ascending('name')
            const zones = await query.find({ useMasterKey: true });
            return zones;
        } catch (error) {
            throw error.message;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusZoneBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let status = request.params.status;
        let ZoneClass = Parse.Object.extend("Zone");
        let query = new Parse.Query(ZoneClass);
        let zone = await query.get(id, { useMasterKey: true });
        zone.set('status', status);
        let zoneUpdate = await zone.save(null, { useMasterKey: true });
        return zoneUpdate;
    } else {
        return null;
    }
});

Parse.Cloud.define("newZoneBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            let name = request.params.name;
            let newBadgeHours = request.params.newBadgeHours;
            let radius = request.params.radius;
            let status = request.params.status;
            let center = new Parse.GeoPoint(request.params.latitude, request.params.longitude);;
            let image = request.params.image;
            let config = request.params.config;
            let options = request.params.options;

            let ZoneClass = Parse.Object.extend("Zone");
            let zone = new ZoneClass();
            zone.set('name', name);
            zone.set('newBadgeHours', newBadgeHours);
            zone.set('radius', radius);
            zone.set('status', status);
            zone.set('center', center);
            zone.set('config', config ? config : {});
            zone.set('options', options ? options : {});

            if (image) {
                zone.set('image', image);
            }

            let newZone = await zone.save(null, { useMasterKey: true });
            return newZone;

        } catch (error) {
            throw error.message;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("editZoneBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            let id = request.params.id;
            let name = request.params.name;
            let newBadgeHours = request.params.newBadgeHours;
            let radius = request.params.radius;
            let status = request.params.status;
            let center = new Parse.GeoPoint(request.params.latitude, request.params.longitude);;
            let image = request.params.image;
            let config = request.params.config;
            let options = request.params.options;

            const query = new Parse.Query('Zone')
            let zone = await query.get(id, { useMasterKey: true });

            zone.set('name', name);
            zone.set('newBadgeHours', newBadgeHours);
            zone.set('radius', radius);
            zone.set('status', status);
            zone.set('center', center);
            zone.set('config', config ? config : {});
            zone.set('options', options ? options : {});

            if (image) {
                zone.set('image', image);
            } else {
                zone.unset('image')
            }

            let newZone = await zone.save(null, { useMasterKey: true });
            return newZone;

        } catch (error) {
            throw error.message;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updateStoreOnwerEmailBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            const id    = request.params.id;
            const email = request.params.email;
            
            var StoreClass = Parse.Object.extend("Store");
            var query = new Parse.Query(StoreClass);
            let store = await query.get(id, { useMasterKey: true });
            
            let user = store.get('owner');
            if (user.setEmail(email)) {
                await user.save(null, { useMasterKey: true });
                return true;
            }
            return false;

        } catch (error) {
            throw error.message;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("requestPasswordResetBO", async request => {
    var currentUser = request.user;
    if (currentUser) {
        try {
            const email = request.params.email;
            let result = await Parse.User.requestPasswordReset(email)
            return result;
        } catch (error) {
            throw error.message;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("applyCuponToOrderBO", async request => {
    let currentUser = request.user;
    if (currentUser) {
        let id = request.params.id;
        let code = request.params.code;

        let OrderClass = Parse.Object.extend("Order");
        let query = new Parse.Query(OrderClass);
        //query.equalTo("owner", currentUser);
        let order = await query.get(id, { useMasterKey: true });
        let promoOld = order.attributes.promoCode;

        let PromoCodeClass = Parse.Object.extend("PromoCode");
        let queryPromoCode = new Parse.Query(PromoCodeClass);
        queryPromoCode.equalTo('code', code);
        let promoCode = await queryPromoCode.first({ useMasterKey: true });

        if (promoCode) {
            let nowMillis = Date.now();
            if (promoCode.attributes.status != 'active' || nowMillis > promoCode.attributes.validUntil.getTime() || promoCode.attributes.maxUses <= 0 || promoCode.attributes.uses >= promoCode.attributes.maxUses || promoCode.attributes.minOrderAmount < 0 || order.attributes.total < promoCode.attributes.minOrderAmount) {
                throw new Error('Promo code not pass validation');
            }
    
            let discount = 0;
            switch (promoCode.attributes.type) {
              case 'percent': 
                discount = (order.attributes.total*(Number(promoCode.attributes.value)/100));
                break;
              case 'value': 
                discount = promoCode.attributes.value;
                break;
              default: break;
            }
            
            order.set('promoCode', promoCode)
            if (discount > order.attributes.total) {
                order.set('discount', order.attributes.total)
            }else{
                order.set('discount', Number(discount))
            }
            let orderUpdate = await order.save(null, { useMasterKey: true });
            
            promoCode.increment("uses");
            let promoCodeUpdate = await promoCode.save(null, { useMasterKey: true });
    
            var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", 'promo_code_edited');
            orderUpdateItem.set("notes", `${promoOld ? promoOld.id : ''} change to ${promoCode.id}`);
            orderUpdateItem.set("editor", "BACKOFFICE_" + currentUser.id);
            var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
    
            return orderUpdate;
        }

        throw new Error('Promo code not found');

    } else {
        return null;
    }
});