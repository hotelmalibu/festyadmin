require('./modules/BO.js')
const stripe = require('stripe')('sk_test_51ITEcAJ0TFVEumUTW9EZHAafqMZ2CrbbHhltrYnAjarp5CtNP1HqNX4XEEfyB3vJLEGTOiLhGkVonyVKYJHVZ1e600kvmuwBsQ');

Parse.Cloud.define("like", async request => {
    var currentUser = request.user;
    var promotion = request.params.promotion;
    var PromotionClass = Parse.Object.extend("Product");
    var query = new Parse.Query(PromotionClass);
    query.get(promotion)
        .then((promo) => {
            promo.increment("likes");
            promo.save(null, { useMasterKey: true });
            return true;
        }, (error) => {
            return false;
        });
    return true;
});
Parse.Cloud.define("view", async request => {
    var currentUser = request.user;
    var promotion = request.params.promotion;
    var PromotionClass = Parse.Object.extend("Product");
    var query = new Parse.Query(PromotionClass);
    query.get(promotion)
        .then((promo) => {
            promo.increment("views");
            promo.save(null, { useMasterKey: true });
            return true;
        }, (error) => {
            return false;
        });
    return true;
});

Parse.Cloud.define("getPromo", async request => {
    var id = request.params.id;
    var PromotionClass = Parse.Object.extend("Product");
    var queryPromo = new Parse.Query(PromotionClass);
    queryPromo.include("store");
    let promotion = await queryPromo.get(id, { useMasterKey: true });
    return promotion;
});

Parse.Cloud.define("getProductV2", async request => {
    var id = request.params.id;
    var PromotionClass = Parse.Object.extend("Product");
    var queryPromo = new Parse.Query(PromotionClass);
    queryPromo.include("store");
    let promotion = await queryPromo.get(id, { useMasterKey: true });

    let PRICE = {
        porcent: (value, price) => Number(price) + (Number(price)*(Number(value)/100)),
        value  : (value, price) => Number(price) + Number(value),
    }
    var promotionJSON = promotion.toJSON();
    promotionJSON.__type = "Object";
    promotionJSON.className = "Product";
    
    if (promotion.attributes.store && promotion.attributes.store.attributes.fee && promotion.attributes.store.attributes.fee.status && promotion.attributes.store.attributes.fee.type && promotion.attributes.store.attributes.fee.value) {
        promotionJSON.price = PRICE[promotion.attributes.store.attributes.fee.type](promotion.attributes.store.attributes.fee.value, promotion.attributes.price)
        if (promotion.attributes.newPrice) {
            promotionJSON.newPrice = PRICE[promotion.attributes.store.attributes.fee.type](promotion.attributes.store.attributes.fee.value, promotion.attributes.newPrice)
        }
    }
    if (promotionJSON.newPrice) {
        promotionJSON.discountRate = ((Number(promotionJSON.price) - Number(promotionJSON.newPrice)) / promotionJSON.price) * 100
    }
    return promotionJSON;
});

Parse.Cloud.define("orderV2", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var promoCodeId = request.params.promoCode;
        var promotion = request.params.promotion;
        var addressId = request.params.address;
        var quantity = request.params.quantity;
        var notes = request.params.notes;
        var paymentMethod = request.params.paymentMethod;
        var deliveryCost = request.params.deliveryCost;
        var total = request.params.total;
        var discount = request.params.discount;
        //combo
        var combo = request.params.withCombo;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;
        //
        var AddressClass = Parse.Object.extend("Address");
        var PromotionClass = Parse.Object.extend("Product");
        var OrderClass = Parse.Object.extend("Order");
        var OrderItemClass = Parse.Object.extend("OrderItem");
        var PaymentClass = Parse.Object.extend("Payment");
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");

        var address = new AddressClass();
        address.set("id", addressId)
        var payment = new PaymentClass();
        var newOrder = new OrderClass();
        var newOrderItem = new OrderItemClass();
        var orderItems = [];
        var queryPromo = new Parse.Query(PromotionClass);
        queryPromo.include("store");
        let promo = await queryPromo.get(promotion, { useMasterKey: true });
        if (promo.get("status") == "active" && promo.get("store").get("status") == "active") {

            if (paymentMethod == "cash") {
                payment.set("method", "OnDelivery");
                payment.set("status", "approved");
            } else if (paymentMethod == "transfer") {
                payment.set("method", "digitalTransfer");
                payment.set("status", "pending");
            }
            newOrderItem.set("product", promo);
            newOrderItem.set("name", promo.get("name"));
            newOrderItem.set("quantity", quantity);
            newOrderItem.set("price", promo.get("price"));
            newOrderItem.set("comboOption", combo);
            newOrderItem.set("comboPrice", comboPrice);
            newOrderItem.set("comboNotes", comboNotes);

            orderItems.push(newOrderItem);

            newOrder.set("address", address);
            newOrder.set("items", orderItems);
            newOrder.set("total", total);
            newOrder.set("discount", discount);
            newOrder.set("notes", notes);
            newOrder.set("deliveryCost", deliveryCost);
            newOrder.set("owner", currentUser);
            newOrder.set("store", promo.get("store"));
            newOrder.set("status", paymentMethod == "cash" ? "created" : "pre-created");
            newOrder.set("alias", currentUser.get("name"));
            newOrder.set("messages", []);
            newOrder.set("payment", payment);
            if (promoCodeId != "") {
                var queryPromoCode = new Parse.Query(PromoCodeClass);
                let promoCode = await queryPromoCode.get(promoCodeId, { useMasterKey: true });
                newOrder.set("promoCode", promoCode);
                promoCode.increment("uses")
            }
            let result = await newOrder.save(null, { useMasterKey: true });
            if (result) {
                //save new status
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", result.id);
                orderUpdateItem.set("update_type", "created");
                orderUpdateItem.set("editor", currentUser.id);
                var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
                //increment orders count
                promo.increment("orders");
                var savedPromo = await promo.save(null, { useMasterKey: true });
                if (paymentMethod == "cash") {
                    try {
                        let pushMessage = quantity + "-" + promo.get("name") + ", Por :" + currentUser.get("name");
                        //now we send a push
                        var jsonBody = {
                            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                            small_icon: "ic_notification",
                            large_icon: "ic_big_icon",
                            android_accent_color: "f4e828",
                            contents: { en: pushMessage },
                            headings: { en: "Nuevo pedido Recibido!" },
                            android_sound: "bell_sound",
                            android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                            data: { "newOrder": true, "identifier": result.id },
                            channel_for_external_user_ids: "push",
                            priority: 10,
                            ttl: 900,
                            include_external_user_ids: [promo.get("store").id, promo.get("store").get("owner").id]
                        };
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            url: "https://onesignal.com/api/v1/notifications",
                            headers: {
                                "Content-Type": "application/json;charset=utf-8",
                                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                            },
                            body: JSON.stringify(jsonBody)
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                            //logToSlack("orderv2-push result: " + httpResponse.text)
                        }, function (httpResponse) {
                            console.error('Request failed with response code ' + httpResponse.status);
                            logToSlack("orderv2-push error result: " + httpResponse.text)
                        });
                        //now we notify support team via slack
                        //let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + total + " , descuento: " + discount;
                        //logToSlack(slackMessage)
                    } catch (error) {

                    }
                }
            }
            return result;
        } else {
            return null;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("order", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var promoCodeId = request.params.promoCode;
        var promotion = request.params.promotion;
        var addressId = request.params.address;
        var quantity = request.params.quantity;
        var notes = request.params.notes;
        var deliveryCost = request.params.deliveryCost;
        var total = request.params.total;
        var discount = request.params.discount;
        //combo
        var combo = request.params.withCombo;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;
        //
        var AddressClass = Parse.Object.extend("Address");
        var PromotionClass = Parse.Object.extend("Product");
        var OrderClass = Parse.Object.extend("Order");
        var OrderItemClass = Parse.Object.extend("OrderItem");
        var PaymentClass = Parse.Object.extend("Payment");
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");

        var address = new AddressClass();
        address.set("id", addressId)
        var payment = new PaymentClass();
        var newOrder = new OrderClass();
        var newOrderItem = new OrderItemClass();
        var orderItems = [];
        var queryPromo = new Parse.Query(PromotionClass);
        queryPromo.include("store");
        let promo = await queryPromo.get(promotion, { useMasterKey: true });
        if (promo.get("status") == "active" && promo.get("store").get("status") == "active") {

            payment.set("method", "OnDelivery");
            payment.set("status", "approved");
            newOrderItem.set("product", promo);
            newOrderItem.set("name", promo.get("name"));
            newOrderItem.set("quantity", quantity);
            newOrderItem.set("price", promo.get("price"));
            newOrderItem.set("comboOption", combo);
            newOrderItem.set("comboPrice", comboPrice);
            newOrderItem.set("comboNotes", comboNotes);

            orderItems.push(newOrderItem);

            newOrder.set("address", address);
            newOrder.set("items", orderItems);
            newOrder.set("total", total);
            newOrder.set("discount", discount);
            newOrder.set("notes", notes);
            newOrder.set("deliveryCost", deliveryCost);
            newOrder.set("owner", currentUser);
            newOrder.set("store", promo.get("store"));
            newOrder.set("status", "created");
            newOrder.set("alias", currentUser.get("name"));
            newOrder.set("messages", []);
            newOrder.set("payment", payment);
            if (promoCodeId != "") {
                var queryPromoCode = new Parse.Query(PromoCodeClass);
                let promoCode = await queryPromoCode.get(promoCodeId, { useMasterKey: true });
                newOrder.set("promoCode", promoCode);
                promoCode.increment("uses")
            }
            let result = await newOrder.save(null, { useMasterKey: true });
            if (result) {
                //save new status
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", result.id);
                orderUpdateItem.set("update_type", "created");
                orderUpdateItem.set("editor", currentUser.id);
                var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
                //increment orders count
                promo.increment("orders");
                var savedPromo = await promo.save(null, { useMasterKey: true });
                try {
                    let pushMessage = quantity + "-" + promo.get("name") + ", Por :" + currentUser.get("name");
                    //now we send a push
                    var jsonBody = {
                        app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                        small_icon: "ic_notification",
                        large_icon: "ic_big_icon",
                        android_accent_color: "f4e828",
                        contents: { en: pushMessage },
                        headings: { en: "Nuevo pedido Recibido!" },
                        android_sound: "bell_sound",
                        android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                        channel_for_external_user_ids: "push",
                        data: { "newOrder": true, "identifier": result.id },
                        priority: 10,
                        ttl: 900,
                        include_external_user_ids: [promo.get("store").id, promo.get("store").get("owner").id]
                    };
                    Parse.Cloud.httpRequest({
                        method: "POST",
                        url: "https://onesignal.com/api/v1/notifications",
                        headers: {
                            "Content-Type": "application/json;charset=utf-8",
                            "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                        },
                        body: JSON.stringify(jsonBody)
                    }).then(function (httpResponse) {
                        console.log(httpResponse.text);
                        //logToSlack("orderv1-push result: " + httpResponse.text)
                    }, function (httpResponse) {
                        console.error('Request failed with response code ' + httpResponse.status);
                        logToSlack("orderv1-push error result: " + httpResponse.text)
                    });
                    //now we notify support team via slack
                    //let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + total + " , descuento: " + discount;
                    //logToSlack(slackMessage)
                } catch (error) {

                }
            }
            return result;
        } else {
            return null;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define('setUsersAcls', async request => {
    var currentUser = request.user;
    currentUser.setACL(new Parse.ACL(currentUser));
    let result = await currentUser.save(null, { useMasterKey: true });
    return result;
});

Parse.Cloud.define('updateGUser', async request => {
    var currentUser = request.user;
    if (currentUser) {
        var name = request.params.name;
        var email = request.params.email;
        currentUser.set("name", name);
        currentUser.set("gemail", email);
        let result = currentUser.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updatePhone", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var phone = request.params.phone;
        currentUser.set("phone", phone);
        let result = currentUser.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updateName", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var name = request.params.name;
        currentUser.set("name", name);
        let result = currentUser.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getAddresses", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var AddressClass = Parse.Object.extend("Address");
        var query = new Parse.Query(AddressClass);
        query.equalTo("owner", currentUser);
        query.notEqualTo("status", "deleted");
        query.ascending("updatedAt");
        let addresses = await query.find({ useMasterKey: true });
        return addresses;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("saveAddress", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var name = request.params.name;
        var city = request.params.city;
        var address = request.params.address;
        const location = new Parse.GeoPoint(request.params.latitude, request.params.longitude);
        var AddressClass = Parse.Object.extend("Address");
        var newAddress = new AddressClass();
        newAddress.set("owner", currentUser);
        newAddress.set("name", name);
        newAddress.set("address", address);
        newAddress.set("location", location);
        if (city) {
            newAddress.set("city", city);
        }
        let result = newAddress.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updateAddress", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.addressId;
        var name = request.params.name;
        var city = request.params.city;
        var address = request.params.address;
        var neighborhood = request.params.neighborhood;
        const location = new Parse.GeoPoint(request.params.latitude, request.params.longitude);
        var AddressClass = Parse.Object.extend("Address");
        var query = new Parse.Query(AddressClass);
        query.equalTo("owner", currentUser);
        let addressObject = await query.get(id, { useMasterKey: true });
        if (addressObject) {
            addressObject.set("owner", currentUser);
            addressObject.set("name", name);
            addressObject.set("address", address);
            addressObject.set("city", city);
            addressObject.set("neighborhood", neighborhood);
            addressObject.set("location", location);
            var result = await addressObject.save(null, { useMasterKey: true });
            return result;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrders", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.equalTo("status", status);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getActiveOrders", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.containedIn("status", ["pre-created", "created", "preparing", "delivering"]);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getAllOrders", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner.phone");
        let order = await query.get(id, { useMasterKey: true });
        return order;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrderForUser", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner.phone");
        let order = await query.get(id, { useMasterKey: true });
        return order;
    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("getOrderForRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("rider", currentUser);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("owner.phone");
        let order = await query.get(id, { useMasterKey: true });
        return order;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getOrderForStore", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var storeId = request.params.store;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("store");
        query.include("promoCode");
        query.include("rider");
        query.include("owner.phone");
        let order = await query.get(id, { useMasterKey: true });
        return order;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("verifyOwnerForRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var user = new Parse.User();
        user.set("id", id)
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", user)
        query.equalTo("status", "delivered")
        query.limit(10)
        let orders = await query.find({ useMasterKey: true });
        var textResult = "Ha realizado " + orders.length + " Pedidos";
        if (orders.length > 5) {
            textResult = "Ha realizado más de 5 pedidos.";
        }
        return textResult;
    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("rateOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var rating = request.params.rating;
        var comments = request.params.comments;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        let order = await query.get(id, { useMasterKey: true });
        order.set("rating", rating);
        order.set("comments", comments);
        let result = order.save(null, { useMasterKey: true });
        //now we notify support team via slack
        if (rating && rating <= 2) {
            notificationUser('Gracias por calificar su pedido', 'Hemos recibido sus comentarios e informaremos al comercio. Seguro le ira mejor en su próximo pedido', currentUser.id, '', '', 2);
            let slackMessage = "Orden Calificada: " + id + ", " + rating + " Estrellas - comentarios: " + comments;
            logToSlack(slackMessage);
        }
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("attachMessageOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var message = request.params.message;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        let order = await query.get(id, { useMasterKey: true });
        order.get("messages").push(message);
        let result = order.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updateOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        let now = '';
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include("store");
        let order = await query.get(id, { useMasterKey: true });
        order.set("status", status);
        let result = await order.save(null, { useMasterKey: true });
        if (result) {
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", status);
            orderUpdateItem.set("editor", currentUser.id);
            var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
            if (result.get("source") == "pos") {
                /*var clientPhone = result.get("comments");
                if (status == "delivering") {
                    let storeName = order.get("store").get("name");
                    let smsFormat = `Tu pedido a ${storeName} va en camino, preparate para disfrutar tus productos. Califica tu experiencia aqui https://invoices.festyapp.com/pos/${result.id}`;
                    if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
                        let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            headers: {
                                "f-apiKey": process.env.FALCON_KEY,
                                "f-secretKey": process.env.FALCON_SECRET,
                                "Content-Type": "application/json"
                            },
                            url: smsUrlFormat,
                            body: {
                                'message': smsFormat,
                                'destinationsList': [`57${clientPhone}`],
                                'label': `store~${order.attributes.store.id}~${order.attributes.store.attributes.name}`
                            },
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                        }, function (httpResponse) {
                            console.error('Request failed with response code ' + httpResponse.status);
                            logToSlack(`BO Send SMS FORM FESTYAPP Request failed: ${httpResponse.text}`)
                        });
                    } else {
                        let smsUrlFormat = `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${clientPhone};${smsFormat.replace(/&/gi, 'y').replace(/#/gi, '')}`
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            url: smsUrlFormat
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                        }, function (httpResponse) {
                            console.error('Request failed with response code ' + httpResponse.status);
                        });
                    }
                }*/
            }
            if (result.get("source") == "client") {
                var pushIcon = "ic_notification";
                var butText = "VER PEDIDO";
                var displayName = order.get("alias").split(" ")[0];
                if (status != "canceled") {
                    var message = "";
                    if (status == "preparing") {
                        pushIcon = "ic_preparing";
                        message = request.params.time ? `${displayName},  tu pedido se está preparando!, el tiempo estimado de preparación es ${request.params.time} minutos. Te avisaremos cuando el domiciliario se dirija a tu dirección` : `${displayName}, tu pedido se está preparando!, te avisaremos cuando el domiciliario se dirija a tu dirección`;
                    }
                    else if (status == "delivering") {
                        pushIcon = "ic_delivering";
                        message = "Tu pedido va en camino 🛵, preparate para disfrutar de los productos";
                    }
                    else if (status == "delivered") {
                        pushIcon = "ic_delivered";
                        butText = "CALIFICAR PEDIDO"
                        message = `${displayName}, Tu pedido ha sido entregado. ¿cómo estuvo todo?, entra a Perfil->Historial de Pedidos`;

                        now = new Date();
                        now.setMinutes(now.getMinutes() + 20);
                        now = new Date(now);
                    }
                    //now we send a push
                    var jsonBody = {
                        app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                        large_icon: pushIcon,
                        small_icon: "ic_big_icon",
                        android_accent_color: "f4e828",
                        contents: { en: message },
                        headings: { en: order.get("store").get("name") },
                        data: { order: order.id },
                        buttons: [{ "id": "view", "text": butText, "icon": "" }],
                        priority: 10,
                        ttl: 3600,
                        android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                        android_group: order.id,
                        include_external_user_ids: [order.get("owner").id]
                    };

                    if (now) {
                        jsonBody.send_after = now.toString()
                    }

                    if (status == "delivered") {
                        jsonBody.app_url = "https://festyapp.com/order/" + order.id
                    }

                    Parse.Cloud.httpRequest({
                        method: "POST",
                        url: "https://onesignal.com/api/v1/notifications",
                        headers: {
                            "Content-Type": "application/json;charset=utf-8",
                            "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                        },
                        body: JSON.stringify(jsonBody)
                    }).then(function (httpResponse) {
                        console.log(httpResponse.text);
                    }, function (httpResponse) {
                        console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
                    });
                }
            }
            if (status == "created" && !order.get("rider")) {
                // Assign rider in created status
                await storesAssignRidersInCreated(order, status);
            }
            //now we look for the rider to assing the order
            if (status == "preparing" && !order.get("rider")) {
                try {

                    var StoreRiderClass = Parse.Object.extend("StoreRider");
                    var queryRiders = new Parse.Query(StoreRiderClass);

                    if (order.get('source') == 'pos') {
                        let json = JSON.parse(order.get('notes'))
                        if (json.requestRider) {
                            //logToSlack("UpdateOrder: Festy rider requerido")
                            queryRiders.equalTo("default", true);
                            queryRiders.equalTo("status", "online");
                            queryRiders.notEqualTo("role", "waiter");
                        } else {
                            //logToSlack("UpdateOrder: Es POS pero festy rider NO es requerido")
                            queryRiders.equalTo("store", result.get("store"));
                            queryRiders.equalTo("status", "online");
                            queryRiders.notEqualTo("role", "waiter");
                        }
                    } else {
                        //logToSlack("UpdateOrder: NO es POS")
                        queryRiders.equalTo("store", result.get("store"));
                        queryRiders.equalTo("status", "online");
                        queryRiders.notEqualTo("role", "waiter");
                    }

                    let onlineRiders = await queryRiders.find({ useMasterKey: true });

                    if (onlineRiders.length > 0) {
                        if (onlineRiders.length == 1) {
                            let rider = onlineRiders[0].get("rider");
                            await assingRiderToOrder(result, rider);
                        } else {
                            //custom implementation
                            var OrderClass = Parse.Object.extend("Order");
                            var queryOrder = new Parse.Query(OrderClass);
                            queryOrder.equalTo("store", result.get("store"));
                            queryOrder.equalTo("status", 'preparing');
                            queryOrder.exists('rider');
                            queryOrder.include('rider');
                            let ordersWithRiders = await queryOrder.find({ useMasterKey: true });

                            let busyRiders = ordersWithRiders.map(o => o.get("rider"));
                            let realOnlineRiders = onlineRiders.map(o => o.get("rider"));

                            const freeRiders = realOnlineRiders.filter(({ id: id1 }) => !busyRiders.some(({ id: id2 }) => id2 === id1));

                            if (freeRiders.length > 0) {
                                if (freeRiders.length === 1) {
                                    let freeRider = freeRiders[0];
                                    await assingRiderToOrder(result, freeRider);
                                } else {

                                    try {

                                        let riderMoreCloseToStore = ''

                                        let freeRidersWithTotalDistance = freeRiders.map(async (r) => {
                                            let queryRiderLocation = new Parse.Query("RiderLocation");
                                            queryRiderLocation.equalTo('rider', r)
                                            queryRiderLocation.descending('createdAt')
                                            let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                            let distanceBetweenStoreAndRider = calcDistance(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                            return { rider: r, totalDistance: distanceBetweenStoreAndRider }
                                        });

                                        if (freeRidersWithTotalDistance) {
                                            riderMoreCloseToStore = freeRidersWithTotalDistance.reduce(function (prev, curr) {
                                                return prev.totalDistance < curr.totalDistance ? prev : curr;
                                            });
                                        } else {
                                            let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                            await assingRiderToOrder(result, ramdomFreeRider);
                                        }

                                        await assingRiderToOrder(result, riderMoreCloseToStore.rider);

                                    } catch (error) {
                                        // Si ocurre algún error el radom salva el dia.
                                        let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                        await assingRiderToOrder(result, ramdomFreeRider);
                                    }
                                }
                            } else {

                                try {

                                    let riderMoreCloseToStore = ''

                                    let ridersWithTotalDistance = realOnlineRiders.map(async (r) => {
                                        let queryRiderLocation = new Parse.Query("RiderLocation");
                                        queryRiderLocation.equalTo('rider', r)
                                        queryRiderLocation.descending('createdAt')
                                        let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                        let distanceBetweenStoreAndRider = calcDistance(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let distanceBetweenClientAndRider = calcDistance(order.attributes.address.attributes.location.latitude, order.attributes.address.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let totalDistance = 20
                                        if (distanceBetweenStoreAndRider && distanceBetweenClientAndRider) {
                                            totalDistance = distanceBetweenStoreAndRider + distanceBetweenClientAndRider
                                        }
                                        return { rider: r, totalDistance: totalDistance }
                                    });

                                    if (ridersWithTotalDistance) {
                                        riderMoreCloseToStore = ridersWithTotalDistance.reduce(function (prev, curr) {
                                            return prev.totalDistance < curr.totalDistance ? prev : curr;
                                        });
                                    } else {
                                        let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                        await assingRiderToOrder(result, randomOnlineRiders);
                                    }

                                    await assingRiderToOrder(result, riderMoreCloseToStore.rider);

                                } catch (error) {
                                    // Si ocurre algún error el radom salva el dia.
                                    let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                    await assingRiderToOrder(result, randomOnlineRiders);
                                }
                            }
                        }
                    }
                } catch (error) {
                    console.log("error " + error)
                }
            }
        }
        return result;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("validatePromoCode", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var code = request.params.code;
        var storeId = request.params.store;
        var orderAmount = request.params.orderAmount;
        var productId = request.params.product;
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(PromoCodeClass);
        query.equalTo("code", code);
        let promoCode = await query.first({ useMasterKey: true });
        //validaciones
        if (promoCode) {
            let nowMillis = Date.now();
            let maxUses = promoCode.get("maxUses")
            let uses = promoCode.get("uses")
            let minOrderAmount = promoCode.get("minOrderAmount")
            let maxUsesXUser = promoCode.get("maxUsesXUser")
            let validUntil = promoCode.get("validUntil")
            let stores = promoCode.get("stores")
            if (promoCode.get("status") == "active") {
                if (validUntil.getTime() > nowMillis) {
                    if (maxUses > 0 && uses < maxUses) {
                        if (minOrderAmount > 0 && orderAmount >= minOrderAmount) {
                            var OrderClass = Parse.Object.extend("Order");
                            var queryOrders = new Parse.Query(OrderClass);
                            queryOrders.equalTo("owner", currentUser);
                            queryOrders.descending("createdAt");
                            queryOrders.equalTo("promoCode", promoCode);
                            //just for new users 
                            let ordersCount = await queryOrders.count({ useMasterKey: true });
                            if (ordersCount < maxUsesXUser) {
                                if (productId) {
                                    var queryProduct = new Parse.Query(ProductClass);
                                    queryProduct.include('store')
                                    let product = await queryProduct.get(productId, { useMasterKey: true });
                                    let storeIdOfPrduct = product.attributes.store.id
                                    if (stores && stores.length > 0) {
                                        if (stores.includes(storeIdOfPrduct)) {
                                            console.log("validated productId: " + productId + ' storeID' + storeIdOfPrduct + " includes: " + stores.includes(storeIdOfPrduct));
                                            return promoCode;
                                        } else {
                                            return null;
                                        }
                                    } else {
                                        return promoCode;
                                    }

                                } else if (storeId) {
                                    if (stores && stores.length > 0) {
                                        if (stores.includes(storeId)) {
                                            console.log("validated storeId: " + storeId + " includes: " + stores.includes(storeId));
                                            return promoCode;
                                        } else {
                                            return null;
                                        }
                                    } else {
                                        return promoCode;
                                    }
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }
                        }
                        else {
                            console.log("min order value not valid [ " + code + " - " + orderAmount + " ]");
                            //min order value not valid
                            return null;
                        }
                    } else {
                        console.log("promo uses limit reached [ " + code + "]");
                        //promo limite reached
                        return null;
                    }
                } else {
                    console.log("promo code expired [ " + code + "]");
                    //promo code expired
                    return null;
                }
            } else {
                //promo inactive
                console.log("promo inactive");
                return null;
            }
        } else {
            console.log("promo code not found :" + code);
            return null;
        }
    } else {
        console.log("user not logged in :" + code);
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("validatePromoCodeV2", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var code = request.params.code;
        var storeId = request.params.store;
        var orderAmount = request.params.orderAmount;
        var productId = request.params.product;
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var ProductClass = Parse.Object.extend("Product");
        var query = new Parse.Query(PromoCodeClass);
        query.equalTo("code", code);
        let promoCode = await query.first({ useMasterKey: true });
        //validaciones
        if (promoCode) {
            let nowMillis = Date.now();
            let maxUses = promoCode.get("maxUses")
            let uses = promoCode.get("uses")
            let minOrderAmount = promoCode.get("minOrderAmount")
            let maxUsesXUser = promoCode.get("maxUsesXUser")
            let validUntil = promoCode.get("validUntil")
            let stores = promoCode.get("stores")
            if (promoCode.get("status") == "active") {
                if (validUntil.getTime() > nowMillis) {
                    if (maxUses > 0 && uses < maxUses) {
                        if (minOrderAmount > 0 && orderAmount >= minOrderAmount) {
                            var OrderClass = Parse.Object.extend("Order");
                            var queryOrders = new Parse.Query(OrderClass);
                            queryOrders.equalTo("owner", currentUser);
                            queryOrders.descending("createdAt");
                            queryOrders.equalTo("promoCode", promoCode);
                            //just for new users 
                            let ordersCount = await queryOrders.count({ useMasterKey: true });
                            if (ordersCount < maxUsesXUser) {
                                if (productId) {
                                    var queryProduct = new Parse.Query(ProductClass);
                                    queryProduct.include('store')
                                    let product = await queryProduct.get(productId, { useMasterKey: true });
                                    let storeIdOfPrduct = product.attributes.store.id
                                    if (stores && stores.length > 0) {
                                        if (stores.includes(storeIdOfPrduct)) {
                                            console.log("validated productId: " + productId + ' storeID' + storeIdOfPrduct + " includes: " + stores.includes(storeIdOfPrduct));
                                            return returnObjectValidation(promoCode.id, true, '', promoCode, orderAmount);
                                        } else {
                                            return returnObjectValidation(promoCode.id, false, `El cupón no válido para el comercio: ${code}`, 0);
                                        }
                                    } else {
                                        return returnObjectValidation(promoCode.id, true, '', promoCode, orderAmount);
                                    }

                                } else if (storeId) {
                                    if (stores && stores.length > 0) {
                                        if (stores.includes(storeId)) {
                                            console.log("validated storeId: " + storeId + " includes: " + stores.includes(storeId));
                                            return returnObjectValidation(promoCode.id, true, '', promoCode, orderAmount);
                                        } else {
                                            return returnObjectValidation(promoCode.id, false, `El cupón no válido para el comercio: ${code}`, 0);
                                        }
                                    } else {
                                        return returnObjectValidation(promoCode.id, true, '', promoCode, orderAmount);
                                    }
                                } else {
                                    return returnObjectValidation(promoCode.id, false, `El cupón no válido para producto o comercio: ${code}`, 0);
                                }
                            } else {
                                return returnObjectValidation(promoCode.id, false, `El cupón ha superado el limite de usos pora su usuario: ${code}`, 0);
                            }
                        }
                        else {
                            //min order value not valid
                            console.log("min order value not valid [ " + code + " - " + orderAmount + " ]");
                            return returnObjectValidation(promoCode.id, false, `El monto mínimo de la orden no es válido: ${code} - ${orderAmount}`, 0);
                        }
                    } else {
                        //promo limite reached
                        console.log("promo uses limit reached [ " + code + "]");
                        return returnObjectValidation(promoCode.id, false, `El cupón ha superado el limite de usos: ${code}`, 0);
                    }
                } else {
                    //promo code expired
                    console.log("promo code expired [ " + code + "]");
                    return returnObjectValidation(promoCode.id, false, `El cupón ha expirado: ${code}`, 0);
                }
            } else {
                //promo inactive
                console.log("promo inactive");
                return returnObjectValidation(promoCode.id, false, `El cupón está inactivo: ${code}`, 0);
            }
        } else {
            console.log("promo code not found :" + code);
            return returnObjectValidation('', false, `El cupón ingresado no existe: ${code}`, 0);
        }
    } else {
        console.log("user not logged in :" + code);
        throw new Error('Unathorized');
    }
});

const returnObjectValidation = (id = '', valid = false, message = '', promoCode = {}, orderAmount = 0) => {
    let discount = 0;
    let byDelivery = false;
    let CALCULATE_DISCOUNT = {
        percent: (value, price) => (Number(price) * (Number(value) / 100)),
        value: (value, price) => Number(value),
    }
    if (valid && promoCode.id && orderAmount) {
        discount = CALCULATE_DISCOUNT[promoCode.attributes.type](promoCode.attributes.value, orderAmount);
        byDelivery = promoCode.attributes.byDelivery ? promoCode.attributes.byDelivery : false;
    }
    if (discount > orderAmount) {
        valid = false;
        message = 'El código promocional exede el monto de la orden';
    }
    return {
        id: id,
        valid: valid,
        error: message,
        dicount_amount: discount,
        byDelivery: byDelivery
    };
};

Parse.Cloud.define("getHotPromos", async request => {
    let currentUser = request.user;
    let superCategory = request.params.superCategory;
    let distance = 7;
    let sorted = false;
    let StoreClass = Parse.Object.extend("Store");
    const ProductClass = Parse.Object.extend("Product");
    const innerQuery = new Parse.Query(StoreClass);
    innerQuery.equalTo("status", "active");
    const query = new Parse.Query(ProductClass);
    if (request.params.latitude) {
        const location = new Parse.GeoPoint(request.params.latitude, request.params.longitude);
        innerQuery.polygonContains("geoCoverage", location);
    }
    query.matchesQuery("store", innerQuery);
    query.descending("createdAt");
    query.select("store.name");
    query.select("store.city");
    query.select("store.logoUrl");
    query.select("store.address");
    query.select("store.transfersMethods");
    query.select("store.acceptBankTransfer");
    query.select("store.hasCardReader");
    query.select("store.status");
    query.select("store.description");
    query.select("status");
    query.select("name");
    query.select("deliveryCost");
    query.select("price");
    query.select("category");
    query.select("featured");
    query.select("imageUrl");
    query.select("description");
    query.select("modifiers");
    query.equalTo("status", "active");
    query.equalTo("featured", true);
    query.limit(100);
    if (superCategory) {
        query.equalTo("superCategory", superCategory);
    } else {
        query.equalTo("superCategory", "food");
    }
    const hotPromos = await query.find({ useMasterKey: true });
    var justActivePromos = hotPromos.filter(function (promo) {
        return promo.get("store").get("status") == "active";
    });
    if (justActivePromos.length > 0) {
        return justActivePromos;
    }
    return hotPromos;
});

Parse.Cloud.define("getAllPromos", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    var currentUser = request.user;
    let distance = 7.5;
    let sorted = true;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var innerQuery = new Parse.Query(StoreClass);
    innerQuery.equalTo("status", "active");
    var query = new Parse.Query(ProductClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        query.withinKilometers("location", location, distance, sorted);
    }
    query.matchesQuery("store", innerQuery);
    query.limit(500);
    query.descending("createdAt");
    query.select("store.name");
    query.select("store.city");
    query.select("store.logoUrl");
    query.select("store.address");
    query.select("store.transfersMethods");
    query.select("store.acceptBankTransfer");
    query.select("store.hasCardReader");
    query.select("store.status");
    query.select("store.description");
    query.select("status");
    query.select("name");
    query.select("deliveryCost");
    query.select("price");
    query.select("featured");
    query.select("imageUrl");
    query.select("description");
    query.select("category");
    query.select("modifiers");
    query.include("productCategory");
    query.equalTo("status", "active");
    if (superCategory)
        query.equalTo("superCategory", superCategory);
    else
        query.equalTo("superCategory", "food");

    let promos = await query.find({ useMasterKey: true });
    return promos;
});


Parse.Cloud.define("getNewPromos", async request => {
    var currentUser = request.user;
    const superCategory = request.params.superCategory;
    const distance = 7;
    const sorted = false;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var innerQuery = new Parse.Query(StoreClass);
    innerQuery.notEqualTo("status", "created");
    var query = new Parse.Query(ProductClass);
    if (request.params.latitude) {
        const location = new Parse.GeoPoint(request.params.latitude, request.params.longitude);
        query.withinKilometers("location", location, distance, sorted);
    }
    query.matchesQuery("store", innerQuery);
    query.descending("createdAt");
    query.include("store");
    query.equalTo("status", "active");
    query.limit(500);

    if (superCategory)
        query.equalTo("superCategory", superCategory);
    else
        query.equalTo("superCategory", "food");

    let hotPromos = await query.find({ useMasterKey: true });
    return hotPromos;
});


Parse.Cloud.define("getNearPromos", async request => {
    var currentUser = request.user;
    const superCategory = request.params.superCategory;
    const distance = 6;
    const sorted = true;
    var getLat = request.params.latitude;
    var geoLong = request.params.longitude;
    var geoPoint = new Parse.GeoPoint({ latitude: getLat, longitude: geoLong });
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var innerQuery = new Parse.Query(StoreClass);
    innerQuery.notEqualTo("status", "created");
    var query = new Parse.Query(ProductClass);
    query.withinKilometers("location", geoPoint, distance, sorted);
    query.include("store");
    query.limit(500);
    query.equalTo("status", "active");
    query.matchesQuery("store", innerQuery);
    if (superCategory)
        query.equalTo("superCategory", superCategory);
    else
        query.equalTo("superCategory", "food");
    let hotPromos = await query.find({ useMasterKey: true });
    return hotPromos;
});

Parse.Cloud.define("getStorePromos", async request => {
    var storeId = request.params.storeId;
    var status = request.params.status;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var queryProducts = new Parse.Query(ProductClass);
    queryProducts.equalTo("status", status);
    if (status) {
        queryProducts.equalTo("store", store);
    }
    queryProducts.descending("createdAt")
    queryProducts.select("store.name");
    queryProducts.select("store.city");
    queryProducts.select("store.logoUrl");
    queryProducts.select("store.address");
    queryProducts.select("store.transfersMethods");
    queryProducts.select("store.acceptBankTransfer");
    queryProducts.select("store.hasCardReader");
    queryProducts.select("store.status");
    queryProducts.select("store.description");
    queryProducts.select("store.delivery");
    queryProducts.select("status");
    queryProducts.select("name");
    queryProducts.select("deliveryCost");
    queryProducts.select("price");
    queryProducts.select("featured");
    queryProducts.select("imageUrl");
    queryProducts.select("description");
    queryProducts.select("category")
    queryProducts.select("modifiers");
    queryProducts.equalTo("status", "active");

    let promos = await queryProducts.find({ useMasterKey: true });
    return promos;
});

Parse.Cloud.define("getStoreProductsCategories", async request => {
    var storeId = request.params.storeId;
    var ProductCategoryClass = Parse.Object.extend("ProductCategory");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var query = new Parse.Query(ProductCategoryClass);
    query.equalTo("status", "enabled");
    query.equalTo("store", store);
    query.ascending("index");
    let categories = await query.find({ useMasterKey: true });
    return categories;
});

Parse.Cloud.define("getStoreProducts", async request => {
    var storeId = request.params.storeId;
    var status = request.params.status;
    var ProductClass = Parse.Object.extend("Product");
    var ProductCategoryClass = Parse.Object.extend("ProductCategory");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var query = new Parse.Query(ProductCategoryClass);
    query.equalTo("status", "enabled");
    query.equalTo("store", store);
    query.ascending("index");
    let categories = await query.find({ useMasterKey: true });
    var resultArray = [];
    let PRICE = {
        porcent: (value, price) => Number(price) + (Number(price) * (Number(value) / 100)),
        value: (value, price) => Number(price) + Number(value),
    }
    if (categories) {
        for (var i = 0; i < categories.length; i++) {
            let category = categories[i];
            var categoryCleaned = category.toJSON();
            categoryCleaned.__type = "Object";
            categoryCleaned.className = "ProductCategory";
            var queryProducts = new Parse.Query(ProductClass);
            queryProducts.select("store.name");
            queryProducts.select("store.city");
            queryProducts.select("store.logoUrl");
            queryProducts.select("store.address");
            queryProducts.select("store.transfersMethods");
            queryProducts.select("store.acceptBankTransfer");
            queryProducts.select("store.hasCardReader");
            queryProducts.select("store.status");
            queryProducts.select("store.description");
            queryProducts.select("store.delivery");
            queryProducts.select("store.views");
            queryProducts.select("store.fee");
            queryProducts.select("store.minAmount");
            queryProducts.select("store.payment");
            queryProducts.select("store.exclusive");
            queryProducts.select("status");
            queryProducts.select("name");
            queryProducts.select("deliveryCost");
            queryProducts.select("price");
            queryProducts.select("appliedDiscount");
            queryProducts.select("featured");
            queryProducts.select("imageUrl");
            queryProducts.select("category");
            queryProducts.select("description");
            queryProducts.select("modifiers");
            queryProducts.select("exclusive");
            queryProducts.select("newPrice");
            queryProducts.equalTo("status", "active");
            queryProducts.equalTo("productCategory", category);
            let products = await queryProducts.find({ useMasterKey: true });
            if (products && products.length > 0) {
                let productsWithFee = []
                for (let index = 0; index < products.length; index++) {
                    let product = products[index];
                    var productCleaned = product.toJSON();
                    productCleaned.__type = "Object";
                    productCleaned.className = "Product";
                    if (product.attributes.store && product.attributes.store.attributes.fee && product.attributes.store.attributes.fee.status && product.attributes.store.attributes.fee.type && product.attributes.store.attributes.fee.value) {
                        productCleaned.price = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.price)
                        if (product.attributes.newPrice) {
                            productCleaned.newPrice = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.newPrice)
                        }
                    }
                    productsWithFee.push(productCleaned)
                }
                categoryCleaned.products = productsWithFee
                resultArray.push(categoryCleaned);
            }
        }
    }
    return resultArray;
});

Parse.Cloud.define("getStoreProductsV2", async request => {
    var storeId = request.params.storeId;
    var status = request.params.status;
    var ProductClass = Parse.Object.extend("Product");
    var ProductCategoryClass = Parse.Object.extend("ProductCategory");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var query = new Parse.Query(ProductCategoryClass);
    query.equalTo("status", "enabled");
    query.equalTo("store", store);
    query.ascending("index");
    let categories = await query.find({ useMasterKey: true });
    var resultArray = [];
    let PRICE = {
        porcent : (value, price) => Number(price) + (Number(price)*(Number(value)/100)),
        value :  (value, price) => Number(price) + Number(value),
    }
    if (categories) {
        let productsWithDescount = [];
        for (var i = 0; i < categories.length; i++) {
            let category = categories[i];
            var categoryCleaned = category.toJSON();
            categoryCleaned.__type = "Object";
            categoryCleaned.className = "ProductCategory";
            var queryProducts = new Parse.Query(ProductClass);
            queryProducts.select("store.name");
            queryProducts.select("store.city");
            queryProducts.select("store.logoUrl");
            queryProducts.select("store.address");
            queryProducts.select("store.transfersMethods");
            queryProducts.select("store.acceptBankTransfer");
            queryProducts.select("store.hasCardReader");
            queryProducts.select("store.status");
            queryProducts.select("store.description");
            queryProducts.select("store.delivery");
            queryProducts.select("store.views");
            queryProducts.select("store.fee");
            queryProducts.select("store.minAmount");
            queryProducts.select("store.payment");
            queryProducts.select("store.exclusive");
            queryProducts.select("status");
            queryProducts.select("name");
            queryProducts.select("deliveryCost");
            queryProducts.select("price");
            queryProducts.select("featured");
            queryProducts.select("imageUrl");
            queryProducts.select("exclusive");
            queryProducts.select("description");
            queryProducts.select("modifiers");
            queryProducts.select("exclusive");
            queryProducts.select("newPrice");
            queryProducts.equalTo("status", "active");
            queryProducts.equalTo("productCategory", category);
            let products = await queryProducts.find({ useMasterKey: true });
            if (products && products.length > 0) {
                let productsWithFee = []
                for (let index = 0; index < products.length; index++) {
                    let product = products[index];
                    var productCleaned = product.toJSON();
                    productCleaned.__type = "Object";
                    productCleaned.className = "Product";
                    if (product.attributes.store && product.attributes.store.attributes.fee && product.attributes.store.attributes.fee.status && product.attributes.store.attributes.fee.type && product.attributes.store.attributes.fee.value) {
                        productCleaned.price = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.price)
                        if (product.attributes.newPrice) {
                            productCleaned.newPrice = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.newPrice)
                        }
                    }
                    if (productCleaned.newPrice) {
                        productCleaned.discountRate = ((Number(productCleaned.price) - Number(productCleaned.newPrice)) / productCleaned.price) * 100
                        productsWithDescount.push(productCleaned);
                    }
                    productsWithFee.push(productCleaned)
                }
                categoryCleaned.products = productsWithFee
                resultArray.push(categoryCleaned);
            }
        }
        if (productsWithDescount.length > 0) {
            let categoryOffers       = {};
            categoryOffers.__type    = "Object";
            categoryOffers.className = "ProductCategory";
            categoryOffers.name      = "Ofertas";
            categoryOffers.index     = 0;
            categoryOffers.status    = "enabled";
            categoryOffers.products  = productsWithDescount;
            resultArray.unshift(categoryOffers);
        }
    }
    return resultArray;
});

Parse.Cloud.define("getStoreProductsForStore", async request => {
    var storeId = request.params.storeId;
    var status = request.params.status;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var queryProducts = new Parse.Query(ProductClass);
    queryProducts.equalTo("store", store);
    queryProducts.notEqualTo("status", "deleted");
    queryProducts.descending("createdAt")
    queryProducts.select("store.name");
    queryProducts.select("status");
    queryProducts.select("name");
    queryProducts.select("deliveryCost");
    queryProducts.select("price");
    queryProducts.select("featured");
    queryProducts.select("imageUrl");
    queryProducts.select("description");
    queryProducts.select("category");
    queryProducts.select("productCategory");
    queryProducts.select("views");
    queryProducts.select("views");
    queryProducts.select("modifiers");
    queryProducts.select("comboNotes");
    queryProducts.select("comboPrice");
    queryProducts.select("max");
    queryProducts.addAscending("status");

    let promos = await queryProducts.find({ useMasterKey: true });
    return promos;
});

Parse.Cloud.define("viewStore", async request => {
    var currentUser = request.user;
    var storeId = request.params.storeId;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    query.get(storeId)
        .then((store) => {
            store.increment("views");
            store.save(null, { useMasterKey: true });
            return true;
        }, (error) => {
            return false;
        });
    return true;
});

Parse.Cloud.define("getStoreStats", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.storeId;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.include("promoCode");
        query.equalTo("status", "delivered");
        query.limit(1000);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    }
    return null;
});


Parse.Cloud.define("getPushTemplates", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var destination = request.params.destination;
        var PushTemplateClass = Parse.Object.extend("PushTemplate");
        var query = new Parse.Query(PushTemplateClass);
        if (destination) {
            query.equalTo("destination", destination);
        }
        query.descending("createdAt");
        let templates = await query.find({ useMasterKey: true });
        return templates;
    }
    return null;
});


//stores
Parse.Cloud.define("getStoreOrders", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.storeId;
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("promoCode");
        query.exclude("owner.authData");
        query.exclude("owner.email");
        query.exclude("owner.gemail");
        query.exclude("owner.ACL");
        query.include("owner.phone");
        query.include("owner.name");
        query.equalTo("status", status);
        query.limit(100);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreReviews", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.storeId;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId)
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.descending("createdAt");
        query.greaterThanOrEqualTo("rating", 0);
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("promoCode");
        query.limit(100);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStoreReviewsList", async request => {
    var currentUser = request.user;
    var resultArray = [];
    var storeId = request.params.storeId;
    var spaMonths = new Array("ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC");
    var OrderClass = Parse.Object.extend("Order");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var query = new Parse.Query(OrderClass);
    query.equalTo("store", store);
    query.descending("createdAt");
    query.greaterThanOrEqualTo("rating", 0);
    query.limit(50);
    let orders = await query.find({ useMasterKey: true });
    console.log("getStoreReviewsList " + orders.length)
    orders.forEach(order => {
        var comments = order.get("source") == "client" ? order.get("comments") : "";
        let date = order.get("createdAt")
        let reviewObject = {
            source: order.get("source"),
            comments: comments,
            rating: order.get("rating"),
            alias: `${order.get("alias").split(" ")[0]} (${date.getDate()} ${spaMonths[date.getMonth()]} ${date.getFullYear()})`
        }
        resultArray.push(reviewObject)
    });
    return resultArray;
});

Parse.Cloud.define("getStores", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        let stores = await query.find({ useMasterKey: true });
        return stores;
    } else {
        return null;
    }
});

Parse.Cloud.define("getStore", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        let store = await query.get(id, { useMasterKey: true });
        return store;
    } else {
        return null;
    }
});

Parse.Cloud.define("updatePromo", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var name = request.params.name;
        var description = request.params.description;
        var price = request.params.price;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;

        var comboOption = request.params.comboOption;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;
        var superCategory = request.params.superCategory;

        var imageUrl = request.params.imageUrl;

        let productCategory = request.params.productCategory

        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("name", name);
        promotion.set("description", description);
        promotion.set("price", price);
        promotion.set("category", category);
        promotion.set("deliveryCost", deliveryCost);
        promotion.set("comboOption", comboOption);
        promotion.set("comboPrice", comboPrice);
        promotion.set("comboNotes", comboNotes);
        if (imageUrl) {
            promotion.set("imageUrl", imageUrl);
        }
        if (superCategory)
            promotion.set("superCategory", superCategory);

        if (productCategory) {
            var ProductCategoryClass = Parse.Object.extend("ProductCategory");
            let categoryNew = new ProductCategoryClass();
            categoryNew.id = productCategory;
            promotion.set("productCategory", categoryNew);
        }
        let result = promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateProduct", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var name = request.params.name;
        var description = request.params.description;
        var price = request.params.price;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;
        var superCategory = request.params.superCategory;
        var imageUrl = request.params.imageUrl;

        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("name", name);
        promotion.set("description", description);
        promotion.set("price", price);
        promotion.set("deliveryCost", deliveryCost);
        if (imageUrl) {
            promotion.set("imageUrl", imageUrl);
        }
        if (superCategory)
            promotion.set("superCategory", superCategory);

        if (category) {
            var ProductCategoryClass = Parse.Object.extend("ProductCategory");
            let categoryNew = new ProductCategoryClass();
            categoryNew.id = category;
            promotion.set("productCategory", categoryNew);
            //logToSlack("[FESTYAPP] setting category : " + category)
        }
        let result = await promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updatePromoPhoto", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var imageUrl = request.params.imageUrl;
        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("imageUrl", imageUrl);
        let result = promotion.save(null, { useMasterKey: true });
        logToSlack("promo image updated : " + imageUrl)
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("newPromo", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.storeId;
        var name = request.params.name;
        var imageUrl = request.params.imageUrl;
        var description = request.params.description;
        var price = request.params.price;
        var status = request.params.status;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;
        var comboOption = request.params.comboOption;
        var comboPrice = request.params.comboPrice;
        var comboNotes = request.params.comboNotes;
        var superCategory = request.params.superCategory;
        let productCategory = request.params.productCategory

        var PromotionClass = Parse.Object.extend("Product");
        var promotion = new PromotionClass()
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });
        if (store) {
            promotion.set("name", name);
            promotion.set("description", description);
            promotion.set("price", price);
            promotion.set("imageUrl", imageUrl);
            promotion.set("store", store);
            promotion.set("likes", 0);
            promotion.set("views", 0);
            promotion.set("orders", 0);
            promotion.set("status", status);
            promotion.set("category", category);
            promotion.set("location", store.get("location"));
            promotion.set("deliveryCost", deliveryCost);
            promotion.set("comboOption", comboOption);
            promotion.set("comboPrice", comboPrice);
            promotion.set("comboNotes", comboNotes);
            if (superCategory)
                promotion.set("superCategory", superCategory);

            if (productCategory) {
                var ProductCategoryClass = Parse.Object.extend("ProductCategory");
                let categoryNew = new ProductCategoryClass();
                categoryNew.id = productCategory;
                promotion.set("productCategory", categoryNew);
            }
            let result = promotion.save(null, { useMasterKey: true });
            logToSlack("new promo added " + store.attributes.name + ' - ' + name + " - " + imageUrl);
            return result;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("publishProduct", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.storeId;
        var name = request.params.name;
        var imageUrl = request.params.imageUrl;
        var description = request.params.description;
        var price = request.params.price;
        var status = request.params.status;
        var category = request.params.category;
        var deliveryCost = request.params.deliveryCost;
        var superCategory = request.params.superCategory;

        var PromotionClass = Parse.Object.extend("Product");
        var promotion = new PromotionClass()
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });
        if (store) {
            promotion.set("name", name);
            promotion.set("description", description);
            promotion.set("price", price);
            promotion.set("imageUrl", imageUrl);
            promotion.set("store", store);
            promotion.set("likes", 0);
            promotion.set("views", 0);
            promotion.set("orders", 0);
            promotion.set("status", status);
            promotion.set("deliveryCost", deliveryCost);
            if (superCategory)
                promotion.set("superCategory", superCategory);

            if (category) {
                var ProductCategoryClass = Parse.Object.extend("ProductCategory");
                let categoryNew = new ProductCategoryClass();
                categoryNew.id = category;
                promotion.set("productCategory", categoryNew);
            }
            let result = await promotion.save(null, { useMasterKey: true });
            logToSlack("new promo added " + store.attributes.name + ' - ' + name + " - " + imageUrl + " delivery " + deliveryCost);
            return result;
        }
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updatePromoStatus", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var status = request.params.status;
        var PromotionClass = Parse.Object.extend("Product");
        var queryPromo = new Parse.Query(PromotionClass);
        let promotion = await queryPromo.get(id, { useMasterKey: true });
        promotion.set("status", status);
        let result = await promotion.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStorePhoto", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var logoUrl = request.params.logoUrl;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("logoUrl", logoUrl);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStoreStatus", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var status = request.params.status;
        var StoreClass = Parse.Object.extend("Store");
        var StoreUpdateClass = Parse.Object.extend("StoreUpdate");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("status", status);
        let result = store.save(null, { useMasterKey: true });
        var storeUpdateItem = new StoreUpdateClass();
        storeUpdateItem.set("store", store);
        storeUpdateItem.set("update_type", "status_to_" + status);
        storeUpdateItem.set("editor", currentUser.id);
        storeUpdateItem.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStoreLocation", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var latitude = request.params.latitude;
        var longitude = request.params.longitude;
        var geoPoint = new Parse.GeoPoint({ latitude: latitude, longitude: longitude });
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        if (store) {
            store.set("location", geoPoint);
            let result = store.save(null, { useMasterKey: true });
            return result;
        }
    } else {
        return null;
    }
});

Parse.Cloud.define("updateStore", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var name = request.params.name;
        var description = request.params.description;
        var address = request.params.address;
        var phoneSMSAlertEnabled = request.params.phoneSMSAlertEnabled;
        var phoneSMSAlert = request.params.phoneSMSAlert;
        var StoreClass = Parse.Object.extend("Store");
        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(id, { useMasterKey: true });
        store.set("name", name);
        store.set("description", description);
        store.set("address", address);
        store.set("newOrderSMS", phoneSMSAlertEnabled);
        store.set("phoneSMSAlert", phoneSMSAlert);
        let result = store.save(null, { useMasterKey: true });
        return result;
    } else {
        return null;
    }
});

Parse.Cloud.define("createStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var geoPoint = new Parse.GeoPoint({ latitude: request.params.latitude, longitude: request.params.longitude });
        var logoUrl = request.params.logoUrl;
        var name = request.params.name;
        var description = request.params.description;
        var address = request.params.address;
        var StoreClass = Parse.Object.extend("Store");
        let store = new StoreClass()
        store.set("logoUrl", logoUrl);
        store.set("name", name);
        store.set("description", description);
        store.set("status", "created");
        store.set("slug", name.toLowerCase().replace(/\s/g, '-'));
        store.set("owner", currentUser);
        store.set("likes", 0);
        store.set("views", 0);
        store.set("address", address);
        store.set("location", geoPoint);
        let result = store.save(null, { useMasterKey: true });
        if (result) {
            currentUser.set("store", true);
            currentUser.save(null, { useMasterKey: true });
            logToSlack("Nuevo comercio registrado. " + name)
        }
        return result;
    }
});
Parse.Cloud.define("createRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        let storeId = request.params.store;
        let name = request.params.name;
        let phone = request.params.phone;
        let pin = request.params.pin;
        let photoUrl = request.params.photoUrl;
        try {
            var user = ''
            var newUser = ''
            let usersQuery = new Parse.Query(Parse.User);
            usersQuery.equalTo('phone', phone)
            user = await usersQuery.first({ useMasterKey: true })
            if (!user) {
                user = new Parse.User();
                user.set("username", phone);
                user.set("name", name);
                user.set("password", pin);
                user.set("phone", phone);
                user.set("photoUrl", photoUrl);
                newUser = await user.signUp();
            } else {
                user.set("password", pin);
                user.set("photoUrl", photoUrl);
                newUser = await user.save(null, { useMasterKey: true });
            }
            if (newUser) {
                var store = new StoreClass();
                store.set("id", storeId);

                var queryRiders = new Parse.Query(StoreRiderClass);
                queryRiders.equalTo("rider", newUser);
                queryRiders.equalTo("store", store);
                let storeRiderCheck = await queryRiders.first({ useMasterKey: true })

                if (!storeRiderCheck) {
                    newUser.setACL(new Parse.ACL(newUser));
                    newUser = await newUser.save(null, { useMasterKey: true });
                    var roleQuery = new Parse.Query(Parse.Role);
                    roleQuery.equalTo("name", "rider");
                    var riderRole = await roleQuery.first({ useMasterKey: true });
                    if (riderRole) {
                        riderRole.getUsers().add(newUser)
                        riderRole = await riderRole.save(null, { useMasterKey: true });

                        var storeRider = new StoreRiderClass();
                        storeRider.set("store", store);
                        storeRider.set("rider", newUser);
                        storeRider = await storeRider.save(null, { useMasterKey: true })

                        let smsFormat = `Hola,${name} te han registrado como Domiciliario en Festy, para empezar presiona el enlace https://festyapp.app.link/NQ1znJsQJ5`;
                        if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
                            let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
                            Parse.Cloud.httpRequest({
                                method: "POST",
                                headers: {
                                    "f-apiKey": process.env.FALCON_KEY,
                                    "f-secretKey": process.env.FALCON_SECRET,
                                    "Content-Type": "application/json"
                                },
                                url: smsUrlFormat,
                                body: {
                                    'message': smsFormat,
                                    'destinationsList': [`57${phone}`],
                                    'label': `stores~${store.id}~rider~${storeRider.id}`
                                },
                            }).then(function (httpResponse) {
                                console.log(httpResponse.text);
                            }, function (httpResponse) {
                                console.error('Request failed with response code ' + httpResponse.status);
                                logToSlack(`BO Send SMS FORM FESTYAPP Request failed: ${httpResponse.text}`)
                            });
                        } else {
                            let smsUrlFormat = `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${phone};${smsFormat.replace(/&/gi, 'y').replace(/#/gi, '')}`
                            Parse.Cloud.httpRequest({
                                method: "GET",
                                url: smsUrlFormat
                            }).then(function (httpResponse) {
                                console.log(httpResponse.text);
                            }, function (httpResponse) {
                                console.error('Request failed with response code ' + httpResponse.status);
                                logToSlack('Request failed with response code ' + httpResponse.status + " " + httpResponse.text)
                            });
                        }
                        logToSlack("Nuevo domiciliario registrado.");
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false
            }
        } catch (error) {
            return false;
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("updateRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        let id       = request.params.id;
        let name     = request.params.name;
        let phone    = request.params.phone;
        //let pin      = request.params.pin;
        let photoUrl = request.params.photoUrl;

        let riderQuery = new Parse.Query(Parse.User);
        let rider = await riderQuery.get(id, { useMasterKey: true })

        if (rider) {
            rider.set("name", name);
            rider.set("phone", phone);
            //rider.set("password", pin);
            rider.set("photoUrl", photoUrl);
           
            let result = await rider.save(null, { useMasterKey: true });
            
            return result;
        }
        throw new Error('Rider not found');
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("updatePasswordRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        let id       = request.params.id;
        let pin      = request.params.pin;

        let riderQuery = new Parse.Query(Parse.User);
        let rider = await riderQuery.get(id, { useMasterKey: true })

        if (rider) {
            rider.set("password", pin);
            let result = await rider.save(null, { useMasterKey: true });
            return result;
        }
        throw new Error('Rider not found');
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("changeStatusStoreRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        //query.equalTo("owner", currentUser);
        query.include('store');
        query.include('rider');
        let storeRider = await query.get(id, { useMasterKey: true });
        storeRider.set('status', storeRider.attributes.status === 'offline' ? 'online' : 'offline');
        let storeRider_update = await storeRider.save(null, { useMasterKey: true });
        let storeRider_id = storeRider.attributes.rider.id
        //logToSlack2("RiderBO -> " + storeRider.attributes.rider.attributes.name + " : " + storeRider.attributes.status);
        
        //now we send a push
        var jsonBody = {
            app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
            small_icon: "ic_notification",            
            android_accent_color: "f4e828",
            contents: { en: "Tu estado a cambiado" },
            headings: { en: "Para ver más, abre Festy Rider" },      
            android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
            priority: 10,
            include_external_user_ids: [storeRider_id]
        };

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
        });
        

        return storeRider_update;
    } else {
        return null;
    }
});

Parse.Cloud.define("deleteStoreRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        //query.equalTo("owner", currentUser);
        let storeRider = await query.get(id, { useMasterKey: true });
        storeRider.set('status', 'deleted');
        let storeRider_update = await storeRider.save(null, { useMasterKey: true });   

        return storeRider_update;
    } else {
        return null;
    }
});


Parse.Cloud.define("createCustomerST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var CustomerClass = Parse.Object.extend("Customer");
        let storeId = request.params.store;
        var store = new StoreClass();
        store.set("id", storeId);
        let name = request.params.name;
        let phone = request.params.phone;
        let address = request.params.address;
        let notes = request.params.notes;
        let tags = JSON.parse(request.params.tags);
        var customer = new CustomerClass();
        customer.set("phone", phone);
        customer.set("name", name);
        customer.set("address", address);
        customer.set("notes", notes);
        customer.set("tags", tags);
        customer.set("store", store);
        customer.set("status", "active");
        var result = await customer.save(null, { useMasterKey: true });
        if (result) {
            return result;
        } else {
            throw new Error('Error saving customer')
        }
    } else {
        throw new Error('Unathorized')
    }
});
Parse.Cloud.define("listCustomersST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var CustomerClass = Parse.Object.extend("Customer");
        let storeId = request.params.store;
        let limit = request.params.limit;
        let skip = request.params.skip;
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(CustomerClass);
        query.limit(limit);
        query.skip(skip);
        query.equalTo("store", store);
        query.ascending("name");
        query.equalTo("status", "active");
        let customers = await query.find({ useMasterKey: true });
        return customers;
    } else {
        throw new Error('Unathorized')
    }
});
Parse.Cloud.define("listAllCustomersST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var CustomerClass = Parse.Object.extend("Customer");
        let storeId = request.params.store;
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(CustomerClass);
        query.equalTo("store", store);
        query.ascending("name");
        query.equalTo("status", "active");
        query.limit(20000);
        let customers = await query.find({ useMasterKey: true });
        return customers;
    } else {
        throw new Error('Unathorized')
    }
});
Parse.Cloud.define("deleteCustomerST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var CustomerClass = Parse.Object.extend("Customer");
        let storeId = request.params.store;
        let customerId = request.params.customer;
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(CustomerClass);
        query.equalTo("store", store);
        let customer = await query.get(customerId, { useMasterKey: true });
        if (customer) {
            await customer.destroy({ useMasterKey: true })
            return true;
        } else {
            throw new Error('error deleting customer')
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("updateCustomerST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var CustomerClass = Parse.Object.extend("Customer");
        let storeId = request.params.store;
        let customerId = request.params.customer;
        let name = request.params.name;
        let address = request.params.address;
        let notes = request.params.notes;
        let tags = request.params.tags;
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(CustomerClass);
        query.equalTo("store", store);
        let customer = await query.get(customerId, { useMasterKey: true });
        if (customer) {
            customer.set("name", name);
            customer.set("address", address);
            customer.set("notes", notes);
            if (tags && tags.length > 0) {
                customer.set("tags", tags);
            }
            var result = await customer.save(null, { useMasterKey: true });
            if (result) {
                return result;
            } else {
                throw new Error('Error saving customer')
            }
        } else {
            throw new Error('error deleting customer')
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("listStoreRidersST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        let storeId = request.params.store;
        var StoreClass = Parse.Object.extend("Store");
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(StoreRiderClass);
        query.equalTo("store", store);
        query.notEqualTo("status", 'deleted');
        query.include("rider");
        let ridersList = await query.find({ useMasterKey: true });
        return ridersList;
    } else {
        throw new Error('Unathorized')
    }
});


Parse.Cloud.define("listOrdersForRiderST", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var status = request.params.status;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("rider", currentUser);
        query.descending("createdAt");
        query.include("store");
        query.include("payment");
        query.include("items");
        query.include("address");
        query.include("owner");
        query.include("promoCode");
        if (status == "delivering") {
            query.containedIn("status", ["created", "preparing", "delivering"]);
        } else {
            query.equalTo("status", status);
        }
        query.limit(100);
        let orders = await query.find({ useMasterKey: true });
        return orders;
    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("updateStatusRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var status = request.params.status;
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        query.equalTo("rider", currentUser);
        let riderStores = await query.find({ useMasterKey: true });
        riderStores.forEach(async (item) => {
            item.set("status", status)
            await item.save(null, { useMasterKey: true })
        });

    } else {
        return false;
    }
});

Parse.Cloud.define("updatePhoneRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var phone = request.params.phone;
        currentUser.set("phone", phone);
        let result = currentUser.save(null, { useMasterKey: true });
        return result;
    } else {
        throw new Error('Unathorized');;
    }
});


Parse.Cloud.define("getRiderStore", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var query = new Parse.Query(StoreRiderClass);
        query.equalTo("rider", currentUser);
        query.equalTo("role", "waiter");
        let riderStore = await query.first({ useMasterKey: true });
        return riderStore.get("store").id;
    } else {
        throw new Error('Unathorized');;
    }
});

Parse.Cloud.define("updateLocationRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        const location = new Parse.GeoPoint(request.params.latitude, request.params.longitude);
        var LocationClass = Parse.Object.extend("RiderLocation");
        var query = new Parse.Query(LocationClass);
        query.equalTo("rider", currentUser);
        let lastLocation = await query.first({ useMasterKey: true });
        if (lastLocation) {
            lastLocation.set("location", location);
            lastLocation.set("accuracy", request.params.accuracy);
            lastLocation.save({ useMasterKey: true });
        } else {
            lastLocation = new LocationClass();
            lastLocation.set("rider", currentUser)
            lastLocation.set("location", location);
            lastLocation.set("accuracy", request.params.accuracy);
            lastLocation.save({ useMasterKey: true });
        }
        return lastLocation;
    }
});

Parse.Cloud.job("closeStores", async function (request) {
    //close oall open store at 11.50
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    query.equalTo("status", "active");
    let stores = await query.find({ useMasterKey: true });
    stores.forEach(async (item) => {
        item.set("status", "inactive")
        await item.save(null, { useMasterKey: true })
    });
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://hc-ping.com/0d13a12f-db2e-4ac0-a46c-ff878a7492de"
    }).then(function (httpResponse) {
        console.log(httpResponse.text);
    }, function (httpResponse) {
        console.error('Request failed with response code ' + httpResponse.status);
    });

});


Parse.Cloud.define("UpdateTestRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let message = '';
        var Store = Parse.Object.extend("Store");
        var store = new Store();
        store.id = "DLMlSypU2G";

        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var queryRiders = new Parse.Query(StoreRiderClass);
        queryRiders.equalTo("store", store);
        queryRiders.equalTo("status", "online");
        let onlineRiders = await queryRiders.find({ useMasterKey: true });

        if (onlineRiders.length > 0) {

            var OrderClass = Parse.Object.extend("Order");
            var queryOrder = new Parse.Query(OrderClass);
            queryOrder.equalTo("store", store);
            queryOrder.equalTo("status", 'delivering');
            queryOrder.exists('rider');
            queryOrder.include('rider');
            let ordersWithRiders = await queryOrder.find({ useMasterKey: true });

            let busyRiders = ordersWithRiders.map(o => o.get("rider"));
            let realOnlineRiders = onlineRiders.map(o => o.get("rider"));

            const freeRiders = realOnlineRiders.filter(({ id: id1 }) => !busyRiders.some(({ id: id2 }) => id2 === id1));

            if (freeRiders.length > 0) {
                if (freeRiders.length === 1) {
                    message = 'Solo hay un domiciliario libre'
                } else {
                    message = 'Hay mas de un domiciliario libre'
                }
            } else {
                message = 'No hay domiciliarios libres'
            }

            return {
                "message": message,
                "Ramdom de freeRiders": freeRiders[Math.floor(Math.random() * freeRiders.length)],
                "realOnlineRiders": realOnlineRiders,
                "busyRiders": busyRiders,
                "freeRiders": freeRiders,
                'ordersWithRiders': ordersWithRiders
            };
        }

    } else {
        return false;
    }
});


Parse.Cloud.define("updateOrderByRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var status = request.params.status;
        let now = '';
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("rider", currentUser);
        query.include("store");
        let order = await query.get(id, { useMasterKey: true });
        if (status == "orderAccepted") {
            order.set("riderStatus", status);
            let result = await order.save(null, { useMasterKey: true });
            if (result) {
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", order.id);
                orderUpdateItem.set("update_type", status);
                orderUpdateItem.set("editor", "RIDER_" + currentUser.id);
                var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
                return updateObject;
            }
        } else {
            order.set("riderStatus", status);
            order.set("status", status);
            let result = await order.save(null, { useMasterKey: true });
            if (result) {
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", order.id);
                orderUpdateItem.set("update_type", status);
                orderUpdateItem.set("editor", "RIDER_" + currentUser.id);
                var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
                var pushIcon = "ic_delivered";
                var butText = "CALIFICAR";
                var displayName = order.get("alias").split(" ")[0];
                message = displayName + ", Tu pedido ha sido entregado. ¿cómo estuvo todo?, entra a Perfil->Historial de Pedidos.";

                if (status == "delivering") {
                    pushIcon = "ic_delivering";
                    message = "Tu pedido va en camino 🛵, preparate para disfrutar de los productos.";
                    now = new Date();
                    now.setMinutes(now.getMinutes() + 5);
                    now = new Date(now);
                }
                else if (status == "delivered") {
                    pushIcon = "ic_delivered";
                    butText = "CALIFICAR PEDIDO"
                    message = displayName + ", Tu pedido ha sido entregado. ¿cómo estuvo todo?, entra a Perfil->Historial de Pedidos.";
                    now = new Date();
                    now.setMinutes(now.getMinutes() + 30);
                    now = new Date(now);
                }
                //now we send a push
                var jsonBody = {
                    app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                    large_icon: pushIcon,
                    small_icon: "ic_notification",
                    android_accent_color: "f4e828",
                    contents: { en: message },
                    headings: { en: order.get("store").get("name") },
                    data: { order: order.id },
                    buttons: [{ "id": "view", "text": butText, "icon": "" }],
                    priority: 10,
                    android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                    android_group: order.id,
                    include_external_user_ids: [order.get("owner").id]
                };

                if (now) {
                    jsonBody.send_after = now.toString()
                }

                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
                });
                return updateObject;
            }
        }

    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("checkInRider", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("rider", currentUser);
        query.include("store");
        let order = await query.get(id, { useMasterKey: true });
        if (order) {
            var pushIcon = "ic_delivered";
            var displayName = order.get("alias").split(" ")[0];
            message = displayName + ", El domiciliario está fuera, sal a recibir tu pedido.";

            //now we send a push
            var jsonBody = {
                app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                large_icon: pushIcon,
                small_icon: "ic_notification",
                android_accent_color: "f4e828",
                contents: { en: message },
                headings: { en: order.get("store").get("name") },
                data: { order: order.id },
                priority: 10,
                android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                include_external_user_ids: [order.get("owner").id]
            };

            Parse.Cloud.httpRequest({
                method: "POST",
                url: "https://onesignal.com/api/v1/notifications",
                headers: {
                    "Content-Type": "application/json;charset=utf-8",
                    "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                },
                body: JSON.stringify(jsonBody)
            }).then(function (httpResponse) {
                console.log(httpResponse.text);
            }, function (httpResponse) {
                console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
            });
        }
        return true;
    } else {
        throw new Error('Unathorized');
    }
});




// Assing rider to order and send push
const assingRiderToOrder = async (result, rider) => {
    console.log("assingRiderToOrder function call with rider: " + rider.id)
    result.set("rider", rider);
    var orderUpdateResult = await result.save(null, { useMasterKey: true });
    var riderPushBody = {
        app_id: "6b08311e-f2b9-47ad-bb23-bd770a50dc6f",
        small_icon: "ic_notification",
        android_accent_color: "f4e828",
        contents: { en: "Nuevo pedido asignado para entrega" },
        headings: { en: result.get("store").get("name") },
        data: { newAssignment: result.id },
        buttons: [{ id: "view", text: "VER PEDIDO", icon: "" }],
        priority: 10,
        android_channel_id: "ed97f22b-33ab-4c26-a9ab-f0aee30d1d48",
        include_external_user_ids: [rider.id]
    };
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://onesignal.com/api/v1/notifications",
        headers: {
            "Content-Type": "application/json;charset=utf-8",
            Authorization: "Basic ZGQxMGFjMzgtMmIxZi00YWQ1LTkwODMtNzEzYTFkMWM0MjNh"
        },
        body: JSON.stringify(riderPushBody)
    }).then(
        function (httpResponse) {
            console.log(httpResponse.text);
        },
        function (httpResponse) {
            console.error(
                "Request failed with response code " +
                httpResponse.status +
                " : " +
                httpResponse.text
            );
        }
    );
};

const storesAssignRidersInCreated = async (result, status) => {
    try {
        if (status != 'created') {
            return;
        }
        var B4aSettingClass = Parse.Object.extend("B4aSetting");
        var queryStores = new Parse.Query(B4aSettingClass);
        queryStores.equalTo("key", 'storesAssignRidersInCreated');
        queryStores.equalTo('valueArray', result.attributes.store.id);
        let stores = await queryStores.first({ useMasterKey: true });
        if (stores) {
            var queryRider = new Parse.Query(B4aSettingClass);
            queryRider.equalTo("key", 'defaultRiderAssign');
            let riderDefault = await queryRider.first({ useMasterKey: true });
            if (riderDefault && riderDefault.attributes.value) {
                var rider = new Parse.User();
                rider.set('id', riderDefault.attributes.value);

                var StoreRiderClass = Parse.Object.extend("StoreRider");
                var queryStoreRider = new Parse.Query(StoreRiderClass);
                queryStoreRider.include('rider');
                queryStoreRider.equalTo("rider", rider);
                queryStoreRider.equalTo("store", result.attributes.store);
                queryStoreRider.equalTo("status", "online");
                let storeRider = await queryStoreRider.first({ useMasterKey: true });
                if (storeRider) {
                    await assingRiderToOrder(result, storeRider.attributes.rider);
                    logToSlack(`[FESTYAPP][OK] storesAssignRidersInCreated RIDER ${rider.id} ASSIGNED TO ORDER ${result.id} - STORE ${result.attributes.store.attributes.name}`);
                } else {
                    logToSlack(`[FESTYAPP][BAD] storesAssignRidersInCreated -> RIDER ${rider.id} NOT ONLINE OR NOT ASSIGNED TO STORE ${result.attributes.store.attributes.name} - ORDER: ${result.id}`);
                }
            }
        }
    } catch (error) {
        console.log(error.message)
        logToSlack(`[FESTYAPP][ERROR] storesAssignRidersInCreated -> ${error.message}`);
    }
}

// Distance between two points 
const calcDistance = async (lat1, lon1, lat2, lon2) => {
    var R = 6371; // km
    var dLat = toRad(lat2 - lat1);
    var dLon = toRad(lon2 - lon1);
    var lat1 = toRad(lat1);
    var lat2 = toRad(lat2);

    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c;
    return d;
}

// Converts numeric degrees to radians
const toRad = (Value) => {
    return Value * Math.PI / 180;
}


// Assing rider to order and send push
const logToSlack = async (slackMessage) => {
    var bodyParams = {
        text: slackMessage
    };
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://hooks.slack.com/services/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",
        headers: {
            "Content-Type": "application/json;charset=utf-8"
        },
        body: JSON.stringify(bodyParams)
    }).then(function (httpResponse) {

    }, function (httpResponse) {

    });
};


Parse.Cloud.define("attachVoucherToOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var orderId = request.params.orderId;
        var attachUrl = request.params.attachUrl;
        var OrderClass = Parse.Object.extend("Order");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.include("payment");
        query.include("store");
        var order = await query.get(orderId, { useMasterKey: true });
        if (order) {
            let payment = order.get("payment");
            payment.set("attachUrl", attachUrl);
            payment.set("status", "paid");
            if (request.params.payload) {
                let payload = JSON.parse(request.params.payload);
                payment.set("payload", payload);
            }
            let resultPayment = await payment.save(null, { useMasterKey: true });
            if (resultPayment) {

                // Assign rider in created status
                await storesAssignRidersInCreated(order, 'created');

                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", orderId);
                orderUpdateItem.set("update_type", "created");
                orderUpdateItem.set("editor", currentUser.id);
                var updateObject = await orderUpdateItem.save(null, { useMasterKey: true });
                order.set("status", "created")
                let resultOrder = await order.save(null, { useMasterKey: true });
                let pushMessage = "Pagado por Transferencia. Por: " + order.get("alias");
                //now we send a push
                var jsonBody = {
                    app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                    small_icon: "ic_notification",
                    large_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: pushMessage },
                    headings: { en: "Nuevo pedido Recibido!" },
                    android_sound: "bell_sound",
                    android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                    channel_for_external_user_ids: "push",
                    data: { "newOrder": true, "identifier": orderId },
                    priority: 10,
                    ttl: 900,
                    include_external_user_ids: [order.get("store").id, order.get("store").get("owner").id]
                };
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status);
                });
                //now we notify support team via slack
                let slackMessage = `Nuevo Pedido Pago por Transferencia, pagado a ${order.get("store").get("name")} y realizado por: ${order.get("alias")} => ${attachUrl}`;
                logToSlack(slackMessage)
                return resultPayment;
            }
        } else {
            throw new Error('Unathorized');
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("attachVoucherInfoToOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var orderId = request.params.orderId;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.equalTo("owner", currentUser);
        query.include("payment");
        var order = await query.get(orderId, { useMasterKey: true });
        if (order) {
            let payment = order.get("payment");
            if (request.params.payload) {
                let payload = JSON.parse(request.params.payload);
                payment.set("payload", payload);
            }
            let resultPayment = await payment.save(null, { useMasterKey: true });
        } else {
            throw new Error('Unathorized');
        }
    } else {
        throw new Error('Unathorized')
    }
});


Parse.Cloud.define("orderV3", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var cartItems = JSON.parse(request.params.items)
        var promoCodeId = request.params.promoCode;
        var storeId = request.params.store;
        var addressId = request.params.address;
        var paymentMethod = request.params.paymentMethod;
        var notes = request.params.notes;
        var deliveryCost = request.params.deliveryCost;
        var total = request.params.total;
        var discount = request.params.discount;
        var userAgent = request.params.userAgent;
        var fee = request.params.fee;
        var tip = request.params.tip;

        var StoreClass = Parse.Object.extend("Store");
        var AddressClass = Parse.Object.extend("Address");
        var PromotionClass = Parse.Object.extend("Product");
        var OrderClass = Parse.Object.extend("Order");
        var OrderItemClass = Parse.Object.extend("OrderItem");
        var PaymentClass = Parse.Object.extend("Payment");
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");

        let date = new Date();
        var queryAddress = new Parse.Query(AddressClass);
        let address = await queryAddress.get(addressId, { useMasterKey: true });
        address.set('lastUse', date);
        address.save(null, { useMasterKey: true });

        var payment = new PaymentClass();
        var newOrder = new OrderClass();
        var orderItems = [];

        var queryStore = new Parse.Query(StoreClass);
        let store = await queryStore.get(storeId, { useMasterKey: true });
        if (store && store.get("status") == "active") {
            var orderResumeText = "";
            for (var i = 0; i < cartItems.length; i++) {
                var item = cartItems[i];
                var newOrderItem = new OrderItemClass();
                var productObject = new PromotionClass();
                productObject.set("id", item.product)
                newOrderItem.set("product", productObject);
                newOrderItem.set("name", item.name);
                newOrderItem.set("quantity", item.quantity);
                newOrderItem.set("price", item.price);
                newOrderItem.set("comboOption", item.withCombo);
                newOrderItem.set("comboPrice", item.comboPrice);
                newOrderItem.set("comboNotes", item.comboNotes);
                if (item.modifiers) {
                    newOrderItem.set("modifiers", item.modifiers);
                }
                orderResumeText = orderResumeText.concat(item.quantity + " - " + item.name + " , ")
                orderItems.push(newOrderItem);
            }
            if (paymentMethod == "cash") {
                payment.set("method", "OnDelivery");
                payment.set("status", "approved");
            }
            else if (paymentMethod == "cardReader") {
                payment.set("method", "cardReader");
                payment.set("status", "approved");
            }
            else if (paymentMethod == "transfer") {
                payment.set("method", "digitalTransfer");
                payment.set("status", "pending");
            }
            else if (paymentMethod == "paymentGateway") {
                let paymentGateway = store.attributes.payment.methods.find((element) => 'paymentGateway' === element.id);
                payment.set("method", "paymentGateway");
                payment.set("provider", paymentGateway.name);
                payment.set("status", "pending");
            }
            newOrder.set("address", address);
            newOrder.set("items", orderItems);
            newOrder.set("total", total);
            newOrder.set("discount", discount);
            newOrder.set("notes", notes);
            newOrder.set("deliveryCost", deliveryCost);
            newOrder.set("owner", currentUser);
            newOrder.set("store", store);
            newOrder.set("status", paymentMethod == "transfer" ? "pre-created" : paymentMethod == "paymentGateway" ? 'pre-created' : "created");
            newOrder.set("alias", currentUser.get("name"));
            newOrder.set("messages", []);
            newOrder.set("payment", payment);
            newOrder.set("fee", fee);
            newOrder.set("tip", tip);
            if (promoCodeId != "") {
                var queryPromoCode = new Parse.Query(PromoCodeClass);
                let promoCode = await queryPromoCode.get(promoCodeId, { useMasterKey: true });
                if (promoCode.get("status") == "active") {
                    newOrder.set("promoCode", promoCode);
                    promoCode.increment("uses")
                }
            }
            if (userAgent) {
                newOrder.set("userAgent", userAgent);
            }
            let orderResult = await newOrder.save(null, { useMasterKey: true });
            if (orderResult) {
                // Assign rider in created status
                let statusForAssignRider = paymentMethod == "transfer" ? "pre-created" : paymentMethod == "paymentGateway" ? 'pre-created' : "created";
                await storesAssignRidersInCreated(orderResult, statusForAssignRider);

                //save new status
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", orderResult.id);
                orderUpdateItem.set("update_type", "created");
                orderUpdateItem.set("editor", currentUser.id);
                var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
                if (paymentMethod == "cash" || paymentMethod == "cardReader") {
                    try {
                        let pushMessage = "De: " + currentUser.get("name") + " " + orderResumeText;
                        //now we send a push
                        var jsonBody = {
                            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                            small_icon: "ic_notification",
                            large_icon: "ic_big_icon",
                            android_accent_color: "f4e828",
                            contents: { en: pushMessage },
                            headings: { en: "Nuevo pedido Recibido!" },
                            android_sound: "bell_sound",
                            android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                            data: { "newOrder": true, "identifier": orderResult.id, "printIfCan": true },
                            priority: 10,
                            ttl: 900,
                            channel_for_external_user_ids: "push",
                            include_external_user_ids: [store.get("owner").id]
                        };
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            url: "https://onesignal.com/api/v1/notifications",
                            headers: {
                                "Content-Type": "application/json;charset=utf-8",
                                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                            },
                            body: JSON.stringify(jsonBody)
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                            //logToSlack("orderv3-push result: " + httpResponse.text)
                        }, function (httpResponse) {
                            logToSlack("orderv3-push error result: " + httpResponse.text)
                        });
                        //now we notify support team via slack
                        let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + total + " , descuento: " + discount;
                        logToSlack(slackMessage)
                    } catch (error) {

                    }
                } else {
                    //logToSlack("Nuevo Pedido : Pago pendiente por transferencia - " + currentUser.get("name"));
                }
                return updateobject;
            } else {
                throw new Error('Error creando pedido.');
            }
        } else {
            throw new Error('El comercio esta cerrado.');
        }
    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("getAllPromosV2", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    var currentUser = request.user;
    let distance = request.params.radius || 7;
    let sorted = true;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        query.withinKilometers("location", location, distance, sorted);
    }
    query.limit(100);
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.exclude("posEnabled");
    query.exclude("riderService");
    query.exclude("geoCoverage");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.equalTo("status", "active");
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");

    let stores = await query.find({ useMasterKey: true });
    if (stores) {
        var resultArray = [];
        for (var i = 0; i < stores.length; i++) {
            let store = stores[i];
            var storeCleaned = store.toJSON();
            storeCleaned.__type = "Object";
            storeCleaned.className = "Store";

            var queryProducts = new Parse.Query(ProductClass);
            queryProducts.equalTo("store", store)
            queryProducts.select("store.name");
            queryProducts.select("store.city");
            queryProducts.select("store.logoUrl");
            queryProducts.select("store.address");
            queryProducts.select("store.transfersMethods");
            queryProducts.select("store.acceptBankTransfer");
            queryProducts.select("store.hasCardReader");
            queryProducts.select("store.status");
            queryProducts.select("store.description");
            queryProducts.select("status");
            queryProducts.select("name");
            queryProducts.select("deliveryCost");
            queryProducts.select("price");
            queryProducts.select("featured");
            queryProducts.select("imageUrl");
            queryProducts.select("description");
            queryProducts.select("category");
            queryProducts.include("productCategory");
            queryProducts.select("modifiers");
            queryProducts.equalTo("status", "active");
            queryProducts.descending("featured")
            queryProducts.limit(4);
            if (superCategory)
                queryProducts.equalTo("superCategory", superCategory);
            else
                queryProducts.equalTo("superCategory", "food");

            let topPromos = await queryProducts.find({ useMasterKey: true });
            if (topPromos && topPromos.length > 0) {
                storeCleaned.topProducts = topPromos
                resultArray.push(storeCleaned);
            }
        }
        return resultArray;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("getStoresList", async request => {
    const superCategory = request.params.superCategory;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        query.polygonContains("geoCoverage", location);
    }
    query.limit(100);
    query.include("storeCategory");
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("posEnabled");
    query.exclude("riderService");
    query.exclude("geoCoverage");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.equalTo("status", "active");
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");
    stores = await query.find({ useMasterKey: true });
    if (stores) {
        var resultArray = [];
        let PRICE = {
            porcent: (value, price) => Number(price) + (Number(price) * (Number(value) / 100)),
            value: (value, price) => Number(price) + Number(value),
        }
        for (var i = 0; i < stores.length; i++) {
            let store = stores[i];
            var storeCleaned = store.toJSON();
            storeCleaned.__type = "Object";
            storeCleaned.className = "Store";
            var queryProducts = new Parse.Query(ProductClass);
            queryProducts.equalTo("store", store)
            queryProducts.select("store.name");
            queryProducts.select("store.city");
            queryProducts.select("store.logoUrl");
            queryProducts.select("store.address");
            queryProducts.select("store.transfersMethods");
            queryProducts.select("store.acceptBankTransfer");
            queryProducts.select("store.hasCardReader");
            queryProducts.select("store.status");
            queryProducts.select("store.delivery");
            queryProducts.select("store.description");
            queryProducts.select("store.storeCategory");
            queryProducts.select("store.views");
            queryProducts.select("store.fee");
            queryProducts.select("store.minAmount");
            queryProducts.select("store.payment");
            queryProducts.select("store.exclusive");
            queryProducts.select("status");
            queryProducts.select("name");
            queryProducts.select("deliveryCost");
            queryProducts.select("price");
            queryProducts.select("appliedDiscount");
            queryProducts.select("featured");
            queryProducts.select("category");
            queryProducts.select("imageUrl");
            queryProducts.select("description");
            queryProducts.select("exclusive");
            queryProducts.select("newPrice");
            queryProducts.include("productCategory");
            queryProducts.select("modifiers");
            queryProducts.descending("featured")
            queryProducts.limit(4);
            queryProducts.equalTo("status", "active");
            let topPromos = await queryProducts.find({ useMasterKey: true });
            if (topPromos && topPromos.length > 0) {
                let topPromosWithFee = []
                for (let index = 0; index < topPromos.length; index++) {
                    let product = topPromos[index];
                    var productCleaned = product.toJSON();
                    productCleaned.__type = "Object";
                    productCleaned.className = "Product";
                    if (product.attributes.store && product.attributes.store.attributes.fee && product.attributes.store.attributes.fee.status && product.attributes.store.attributes.fee.type && product.attributes.store.attributes.fee.value) {
                        productCleaned.price = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.price)
                        if (product.attributes.newPrice) {
                            productCleaned.newPrice = PRICE[product.attributes.store.attributes.fee.type](product.attributes.store.attributes.fee.value, product.attributes.newPrice)
                        }
                    }
                    topPromosWithFee.push(productCleaned)
                }
                storeCleaned.topProducts = topPromosWithFee
                resultArray.push(storeCleaned);
            }
        }
        return resultArray;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("getNewStores", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    var currentUser = request.user;
    let distance = request.params.radius || 7;;
    let sorted = false;
    const useGeoCoverage = request.params.useGeoCoverage;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        let date = new Date();
        let init = new Date(date.getFullYear(), date.getMonth() - 2, 1);
        init.setHours(init.getHours() + 5);
        init = new Date(init);
        query.greaterThanOrEqualTo("createdAt", init)
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        if (useGeoCoverage) {
            query.polygonContains("geoCoverage", location);
        } else {
            query.withinKilometers("location", location, distance, sorted);
        }
    }
    query.limit(50);
    query.include("storeCategory");
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("geoCoverage");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.descending("createdAt");
    query.notEqualTo("status", "created");
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");
    let stores = await query.find({ useMasterKey: true });
    if (stores) {
        return stores;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("getTopStores", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    const useGeoCoverage = request.params.useGeoCoverage;
    var currentUser = request.user;
    let distance = request.params.radius || 7;
    let sorted = false;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        if (useGeoCoverage) {
            query.polygonContains("geoCoverage", location);
        } else {
            query.withinKilometers("location", location, distance, sorted);
        }
    }
    query.limit(50);
    query.include("storeCategory");
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.exclude("geoCoverage");
    query.notEqualTo("status", "created");
    query.greaterThanOrEqualTo("rating", 4.5);
    query.descending("rating");
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");
    let stores = await query.find({ useMasterKey: true });
    if (stores) {
        return stores;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("getFreeDeliveryStores", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    const useGeoCoverage = request.params.useGeoCoverage;
    var currentUser = request.user;
    let distance = request.params.radius || 7;
    let sorted = false;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        if (useGeoCoverage) {
            query.polygonContains("geoCoverage", location);
        } else {
            query.withinKilometers("location", location, distance, sorted);
        }
    }
    query.limit(50);
    query.include("storeCategory");
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.exclude("geoCoverage");
    query.notEqualTo("status", "created");
    query.equalTo('delivery.default', 0);
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");
    let stores = await query.find({ useMasterKey: true });
    if (stores) {
        return stores;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("getNearStores", async request => {
    const FestyHQ = new Parse.GeoPoint(9.303227755, -75.38071431219);
    const superCategory = request.params.superCategory;
    var currentUser = request.user;
    let distance = request.params.distance;
    let sorted = true;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    if (request.params.latitude) {
        const latitude = request.params.latitude;
        const longitude = request.params.longitude;
        const location = new Parse.GeoPoint(latitude, longitude);
        query.withinKilometers("location", location, distance, sorted);
    }
    query.limit(50);
    query.include("storeCategory");
    query.exclude("owner");
    query.exclude("hours");
    query.exclude("plan");
    query.exclude("geoCoverage");
    query.exclude("newOrderSMS");
    query.exclude("phoneSMSAlert");
    query.notEqualTo("status", "created");
    if (superCategory)
        query.equalTo("category", superCategory);
    else
        query.equalTo("category", "food");
    let stores = await query.find({ useMasterKey: true });
    if (stores) {
        return stores;
    } else {
        throw new Error("error getting stores list")
    }
});

Parse.Cloud.define("registerPOSSale", async request => {
    var currentUser = request.user;
    var byWaiter = request.params.byWaiter;
    var store = null;
    if (currentUser && (currentUser.get("store") || byWaiter)) {
        var storeId = request.params.store;
        var StoreClass = Parse.Object.extend("Store");
        if (byWaiter) {
            var StoreRiderClass = Parse.Object.extend("StoreRider");
            var query = new Parse.Query(StoreRiderClass);
            query.equalTo("rider", currentUser);
            query.equalTo("role", "waiter");
            query.include("store");
            let riderStore = await query.first({ useMasterKey: true });
            if (riderStore && riderStore.get("store").id == storeId) {
                store = riderStore.get("store")
            } else {
                throw new Error('Unathorized');
            }
        }
        var cartItems = JSON.parse(request.params.items)
        var tags = []
        if (request.params.tags) {
            tags = JSON.parse(request.params.tags)
        }
        var promoCodeId = request.params.promoCode;
        var paymentMethod = request.params.paymentMethod;
        var address = request.params.address;
        var notes = request.params.notes;
        var phone = request.params.phone;
        var alias = request.params.alias;
        var storeName = request.params.storeName;
        var deliveryCost = request.params.deliveryCost;
        var total = request.params.total;
        var discount = request.params.discount;
        var requestRider = false;
        if (request.params.requestRider) {
            requestRider = request.params.requestRider
        }
        var PromotionClass = Parse.Object.extend("Product");
        var OrderClass = Parse.Object.extend("Order");
        var OrderItemClass = Parse.Object.extend("OrderItem");
        var PaymentClass = Parse.Object.extend("Payment");
        var PromoCodeClass = Parse.Object.extend("PromoCode");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");

        var payment = new PaymentClass();
        var newOrder = new OrderClass();
        var orderItems = [];
        if (!byWaiter) {
            store = new StoreClass();
            store.set("id", storeId);
        }
        for (var i = 0; i < cartItems.length; i++) {
            var item = cartItems[i];
            var newOrderItem = new OrderItemClass();
            var productObject = new PromotionClass();
            productObject.set("id", item.product)
            newOrderItem.set("product", productObject);
            newOrderItem.set("name", item.name);
            newOrderItem.set("quantity", item.quantity);
            newOrderItem.set("price", item.price);
            newOrderItem.set("comboOption", item.withCombo);
            newOrderItem.set("comboPrice", item.comboPrice);
            newOrderItem.set("comboNotes", item.comboNotes);
            if (item.modifiers) {
                newOrderItem.set("modifiers", item.modifiers);
            }
            orderItems.push(newOrderItem);
        }
        if (paymentMethod == "cash") {
            payment.set("method", "OnDelivery");
            payment.set("status", "approved");
        } else if (paymentMethod == "transfer") {
            payment.set("method", "digitalTransfer");
            payment.set("status", "pending");
        }
        var infoJson = {};
        infoJson.address = address;
        infoJson.notes = notes;
        infoJson.requestRider = requestRider;
        newOrder.set("items", orderItems);
        newOrder.set("total", total);
        newOrder.set("discount", discount);
        newOrder.set("notes", JSON.stringify(infoJson));
        newOrder.set("comments", phone);
        newOrder.set("deliveryCost", deliveryCost);
        newOrder.set("owner", currentUser);
        newOrder.set("store", store);
        if (byWaiter) {
            newOrder.set("status", "created");
            newOrder.set("rider", currentUser);
            storeName = store.get("name")
        } else {
            newOrder.set("status", "preparing");
        }
        newOrder.set("source", "pos");
        newOrder.set("alias", alias);
        newOrder.set("messages", []);
        newOrder.set("tags", tags);
        newOrder.set("payment", payment);
        if (promoCodeId != "") {
            var queryPromoCode = new Parse.Query(PromoCodeClass);
            let promoCode = await queryPromoCode.get(promoCodeId, { useMasterKey: true });
            if (promoCode.get("status") == "active") {
                newOrder.set("promoCode", promoCode);
                promoCode.increment("uses")
            }
        }
        let orderResult = await newOrder.save(null, { useMasterKey: true });
        if (orderResult) {
            //save new status
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", orderResult.id);
            orderUpdateItem.set("update_type", requestRider ? "delivering" : "delivered");
            orderUpdateItem.set("editor", currentUser.id);
            var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
            if (requestRider) {
                logToSlack("nueva venta registrada con mini-POS " + storeName + " -> total: " + total + " - requestRider = " + requestRider)
            }
            let clientName = alias.split(" ")[0];
            let smsFormat = `Hola ${clientName}, sigue el estado de tu pedido a ${storeName} aquí https://invoices.festyapp.com/pos/${orderResult.id}`;
            //let smsFormat = `Gracias ${clientName} por tu compra y apoyo a ${storeName}. Califica tu experiencia y conoce el estado de tu orden aqui https://invoices.festyapp.com/pos/${orderResult.id}`;
            if (process.env.SMS_PROVIDER && process.env.SMS_PROVIDER == 'FALCON') {
                let smsUrlFormat = `https://falconsignalapp.b4a.app/api/v1/sms/send`
                Parse.Cloud.httpRequest({
                    method: "POST",
                    headers: {
                        "f-apiKey": process.env.FALCON_KEY,
                        "f-secretKey": process.env.FALCON_SECRET,
                        "Content-Type": "application/json"
                    },
                    url: smsUrlFormat,
                    body: {
                        'message': smsFormat,
                        'destinationsList': [`57${phone}`],
                        'label': `stores~${store.id}~${storeName}`
                    },
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status);
                    logToSlack(`BO Send SMS FORM FESTYAPP Request failed: ${httpResponse.text}`)
                });
            } else {
                let smsUrlFormat = `http://ms.hablaip.com/api/servicio?=&data=K;ENVIO;SMS;10740115;19649918;1;57${phone};${smsFormat.replace(/&/gi, 'y').replace(/#/gi, '')}`
                Parse.Cloud.httpRequest({
                    method: "GET",
                    url: smsUrlFormat
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status);
                    logToSlack('Request failed with response code ' + httpResponse.status + " " + httpResponse.text)
                });
            }

            if (byWaiter) {
                let pushMessage = "Registrado por Mesero.";
                //now we send a push
                var jsonBody = {
                    app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                    small_icon: "ic_notification",
                    large_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: pushMessage },
                    headings: { en: "Nuevo pedido Recibido!" },
                    android_sound: "bell_sound",
                    android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                    data: { "newOrder": true, "identifier": orderResult.id },
                    channel_for_external_user_ids: "push",
                    priority: 10,
                    ttl: 900,
                    include_external_user_ids: [store.get("owner").id]
                };
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                    //logToSlack("register POS order push result: " + httpResponse.text)
                }, function (httpResponse) {
                    logToSlack("register POS order error result: " + httpResponse.text)
                });
            }

            if (infoJson.requestRider) {

                try {

                    var OrderClass = Parse.Object.extend("Order");
                    var query = new Parse.Query(OrderClass);
                    query.include("store");
                    let order = await query.get(orderResult.id, { useMasterKey: true });

                    var StoreRiderClass = Parse.Object.extend("StoreRider");
                    var queryRiders = new Parse.Query(StoreRiderClass);

                    if (order.get('source') == 'pos') {
                        let json = JSON.parse(order.get('notes'))
                        if (json.requestRider) {
                            //logToSlack("UpdateOrder: Festy rider requerido")
                            queryRiders.equalTo("default", true);
                            queryRiders.equalTo("status", "online");
                            queryRiders.notEqualTo("role", "waiter");
                        } else {
                            //logToSlack("UpdateOrder: Es POS pero festy rider NO es requerido")
                            queryRiders.equalTo("store", order.get("store"));
                            queryRiders.equalTo("status", "online");
                            queryRiders.notEqualTo("role", "waiter");
                        }
                    } else {
                        //logToSlack("UpdateOrder: NO es POS")
                        queryRiders.equalTo("store", order.get("store"));
                        queryRiders.equalTo("status", "online");
                        queryRiders.notEqualTo("role", "waiter");
                    }


                    let onlineRiders = await queryRiders.find({ useMasterKey: true });

                    if (onlineRiders.length > 0) {
                        if (onlineRiders.length == 1) {
                            let rider = onlineRiders[0].get("rider");
                            await assingRiderToOrder(order, rider);
                        } else {
                            //custom implementation
                            var OrderClass = Parse.Object.extend("Order");
                            var queryOrder = new Parse.Query(OrderClass);
                            queryOrder.equalTo("store", order.get("store"));
                            queryOrder.equalTo("status", 'preparing');
                            queryOrder.exists('rider');
                            queryOrder.include('rider');
                            let ordersWithRiders = await queryOrder.find({ useMasterKey: true });

                            let busyRiders = ordersWithRiders.map(o => o.get("rider"));
                            let realOnlineRiders = onlineRiders.map(o => o.get("rider"));

                            const freeRiders = realOnlineRiders.filter(({ id: id1 }) => !busyRiders.some(({ id: id2 }) => id2 === id1));

                            if (freeRiders.length > 0) {
                                if (freeRiders.length === 1) {
                                    let freeRider = freeRiders[0];
                                    await assingRiderToOrder(order, freeRider);
                                } else {

                                    try {

                                        let riderMoreCloseToStore = ''

                                        let freeRidersWithTotalDistance = freeRiders.map(async (r) => {
                                            let queryRiderLocation = new Parse.Query("RiderLocation");
                                            queryRiderLocation.equalTo('rider', r)
                                            queryRiderLocation.descending('createdAt')
                                            let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                            let distanceBetweenStoreAndRider = calcDistance(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                            return { rider: r, totalDistance: distanceBetweenStoreAndRider }
                                        });

                                        if (freeRidersWithTotalDistance) {
                                            riderMoreCloseToStore = freeRidersWithTotalDistance.reduce(function (prev, curr) {
                                                return prev.totalDistance < curr.totalDistance ? prev : curr;
                                            });
                                        } else {
                                            let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                            await assingRiderToOrder(order, ramdomFreeRider);
                                        }

                                        await assingRiderToOrder(order, riderMoreCloseToStore.rider);

                                    } catch (error) {
                                        // Si ocurre algún error el radom salva el dia.
                                        let ramdomFreeRider = freeRiders[Math.floor(Math.random() * freeRiders.length)]
                                        await assingRiderToOrder(order, ramdomFreeRider);
                                    }
                                }
                            } else {

                                try {

                                    let riderMoreCloseToStore = ''

                                    let ridersWithTotalDistance = realOnlineRiders.map(async (r) => {
                                        let queryRiderLocation = new Parse.Query("RiderLocation");
                                        queryRiderLocation.equalTo('rider', r)
                                        queryRiderLocation.descending('createdAt')
                                        let riderLocation = await queryRiderLocation.first({ useMasterKey: true });

                                        let distanceBetweenStoreAndRider = calcDistance(order.attributes.store.attributes.location.latitude, order.attributes.store.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let distanceBetweenClientAndRider = calcDistance(order.attributes.address.attributes.location.latitude, order.attributes.address.attributes.location.longitude, riderLocation.attributes.location.latitude, riderLocation.attributes.location.longitude);
                                        let totalDistance = 20
                                        if (distanceBetweenStoreAndRider && distanceBetweenClientAndRider) {
                                            totalDistance = distanceBetweenStoreAndRider + distanceBetweenClientAndRider
                                        }
                                        return { rider: r, totalDistance: totalDistance }
                                    });

                                    if (ridersWithTotalDistance) {
                                        riderMoreCloseToStore = ridersWithTotalDistance.reduce(function (prev, curr) {
                                            return prev.totalDistance < curr.totalDistance ? prev : curr;
                                        });
                                    } else {
                                        let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                        await assingRiderToOrder(order, randomOnlineRiders);
                                    }

                                    await assingRiderToOrder(order, riderMoreCloseToStore.rider);

                                } catch (error) {
                                    // Si ocurre algún error el radom salva el dia.
                                    let randomOnlineRiders = realOnlineRiders[Math.floor(Math.random() * realOnlineRiders.length)]
                                    await assingRiderToOrder(order, randomOnlineRiders);
                                }
                            }
                        }
                    }
                } catch (error) {
                    console.log("error " + error)
                }
            }

            return orderResult;

        } else {
            throw new Error('Error creando pedido.');
        }

    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getAppConfig", async request => {
    let latitude = request.params.latitude;
    let longitude = request.params.longitude;
    if (latitude && longitude) {
        const location = new Parse.GeoPoint(latitude, longitude);
        const query = new Parse.Query('Zone')
        query.near("center", location);
        const zone = await query.first({ useMasterKey: true });
        return zone;
    }
    throw new Error('Missing required params');;
});

Parse.Cloud.define("getStorePlan", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var id = request.params.id;
        var StoreClass = Parse.Object.extend("Store");
        var query = new Parse.Query(StoreClass);
        query.equalTo("owner", currentUser);
        query.include("plan")
        let store = await query.get(id, { useMasterKey: true });
        if (store)
            return store.get("plan");
        else
            return null;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.define("getStoreWithSlug", async request => {
    var slug = request.params.slug;
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    query.equalTo("slug", slug);
    let store = await query.first({ useMasterKey: true });
    return store;
});

Parse.Cloud.define("getStorePromosWithSlug", async request => {
    var slug = request.params.slug;
    var ProductClass = Parse.Object.extend("Product");
    var StoreClass = Parse.Object.extend("Store");
    var StoreClass = Parse.Object.extend("Store");
    var query = new Parse.Query(StoreClass);
    query.equalTo("slug", slug);
    let store = await query.first({ useMasterKey: true });
    if (store) {
        var query = new Parse.Query(ProductClass);
        query.equalTo("status", "active");
        query.equalTo("store", store);
        query.descending("featured")
        query.include("store");
        let promos = await query.find({ useMasterKey: true });
        return promos;
    } else {
        throw new Error('Not found');
    }
});

Parse.Cloud.define("deleteAddress", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var AddressClass = Parse.Object.extend("Address");
        var query = new Parse.Query(AddressClass);
        query.equalTo("owner", currentUser);
        query.ascending("updatedAt");
        let address = await query.get(id, { useMasterKey: true });
        address.set("status", "deleted");
        let result = await address.save(null, { useMasterKey: true });
        if (result) {
            var queryList = new Parse.Query(AddressClass);
            queryList.equalTo("owner", currentUser);
            queryList.notEqualTo("status", "deleted");
            queryList.ascending("updatedAt");
            let addresses = await queryList.find({ useMasterKey: true });
            return addresses;
        } else {
            throw new Error('Error removing address');
        }
    } else {
        throw new Error('Unathorized');
    }
});


Parse.Cloud.define("addVoucherToOrderByStore", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var orderId = request.params.orderId;
        var storeId = request.params.storeId;
        var attachUrl = request.params.attachUrl;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.include("payment");
        var order = await query.get(orderId, { useMasterKey: true });
        if (order) {
            let payment = order.get("payment");
            payment.set("attachUrl", attachUrl);
            payment.set("status", "paid");
            let resultPayment = await payment.save(null, { useMasterKey: true });
            if (resultPayment) {
                return resultPayment;
            }
        }
        throw new Error('Unathorized');
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("cancelOrderByStore", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var orderId = request.params.orderId;
        var storeId = request.params.storeId;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        var order = await query.get(orderId, { useMasterKey: true });
        if (order) {
            order.set("status", "cancelled");
            let resultOrder = await order.save(null, { useMasterKey: true });
            if (resultOrder) {
                var orderUpdateItem = new OrderUpdateClass();
                orderUpdateItem.set("object", order.id);
                orderUpdateItem.set("update_type", "cancelled");
                orderUpdateItem.set("editor", currentUser.id);
                var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
                return true;
            }
        }
        throw new Error('Unathorized');
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("hasPendingInvoices", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var storeId = request.params.store;
        var StoreClass = Parse.Object.extend("Store");
        var InvoiceClass = Parse.Object.extend("Invoice");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(InvoiceClass);
        query.equalTo("store", store);
        query.notEqualTo("status", "paid");
        var orders = await query.find({ useMasterKey: true });
        if (orders && orders.length > 0) {
            return true;
        }
        return false;
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("addVoucherToOrderByRider", async request => {
    var currentUser = request.user;
    var storeId = request.params.storeId;
    if (currentUser && storeId) {
        var orderId = request.params.orderId;
        var attachUrl = request.params.attachUrl;
        var OrderClass = Parse.Object.extend("Order");
        var StoreClass = Parse.Object.extend("Store");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(OrderClass);
        query.equalTo("store", store);
        query.equalTo("rider", currentUser);
        query.include("payment");
        var order = await query.get(orderId, { useMasterKey: true });
        if (order) {
            let payment = order.get("payment");
            payment.set("attachUrl", attachUrl);
            payment.set("status", "paid");
            let resultPayment = await payment.save(null, { useMasterKey: true });
            if (resultPayment) {
                return resultPayment;
            }
        }
        throw new Error('Unathorized');
    } else {
        throw new Error('Unathorized')
    }
});

const notificationUser = async (title, message, recipient, app_url, delayed_option, send_after) => {
    if (title && message && recipient) {
        //now we send a push
        var jsonBody = {
            app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
            small_icon: "ic_notification",
            android_accent_color: "f4e828",
            contents: { en: message },
            headings: { en: title },
            android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
            priority: 10,
            include_external_user_ids: [recipient]
        };

        if (app_url) {
            jsonBody.app_url = app_url
        }

        if (delayed_option) {
            jsonBody.delayed_option = delayed_option
        }

        if (send_after) {
            let now = new Date();
            now.setMinutes(now.getMinutes() + Number(send_after));
            now = new Date(now);
            jsonBody.send_after = now.toString()
        }

        Parse.Cloud.httpRequest({
            method: "POST",
            url: "https://onesignal.com/api/v1/notifications",
            headers: {
                "Content-Type": "application/json;charset=utf-8",
                "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
            },
            body: JSON.stringify(jsonBody)
        }).then(function (httpResponse) {
            console.log(httpResponse.text);
            //logToSlack(`PUSH -> Title: ["${title}"] - Message: ${message}`)
            //logToSlack(`Respuesta: ${httpResponse.text}`)
        }, function (httpResponse) {
            console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
        });
    }
};

Parse.Cloud.define("calculateDeliveryPrice", async request => {
    var currentUser = request.user;
    if (currentUser) {
        let storeId = request.params.storeId;
        let addressId = request.params.addressId;
        let deliveryDefault = request.params.deliveryDefault
        var StoreClass = Parse.Object.extend("Store");
        var AddressClass = Parse.Object.extend("Address");

        if (storeId && addressId) {
            var queryAddress = new Parse.Query(AddressClass);
            queryAddress.equalTo("owner", currentUser);
            let address = await queryAddress.get(addressId, { useMasterKey: true });

            var queryStore = new Parse.Query(StoreClass);
            let store = await queryStore.get(storeId, { useMasterKey: true });
            let delivery = store.attributes.delivery

            if (delivery && delivery.method == 'byDistance') {
                if (store.attributes.location.latitude && store.attributes.location.longitude && address.attributes.location.latitude && address.attributes.location.longitude) {
                    let unit = delivery.byDistance.unit ? delivery.byDistance.unit == 'kilometers' ? 'metric' : 'imperial' : 'imperial'
                    let distanceInKm = 0

                    let httpResponse = await Parse.Cloud.httpRequest({
                        method: "GET",
                        url: `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${`${store.attributes.location.latitude},${store.attributes.location.longitude}`}&destinations=${`${address.attributes.location.latitude},${address.attributes.location.longitude}`}&key=AIzaSyAQCXy1qnb-ZOdOlCzQ3SdfhUM-7ZO5nG8&mode=driving&units=${unit}`,
                        headers: {
                            "Content-Type": "application/json;charset=utf-8",
                        }
                    })
                    if (httpResponse && httpResponse.data && httpResponse.data.status === 'OK') {
                        let foundElement = httpResponse.data.rows[0].elements.find(element => element.status == 'OK');
                        if (foundElement) {
                            //logToSlack(`[calculateDeliveryPrice] Found Element: ${JSON.stringify(foundElement)}`)
                            let unitCalculate = unit == 'metric' ? 1000 : 1609.34
                            distanceInKm = (foundElement.distance.value / unitCalculate)
                        } else {
                            distanceInKm = calcDistance(address.attributes.location.latitude, address.attributes.location.longitude, store.attributes.location.latitude, store.attributes.location.longitude)
                            logToSlack(`[calculateDeliveryPrice] NOT Found Element: ${distanceInKm}`)
                        }

                        return resolveTotalAndDistance(delivery.method, delivery.byDistance.unit, delivery.byDistance.base, delivery.byDistance.max, distanceInKm, delivery.byDistance.baseDistance, delivery.byDistance.extraUnit, 0.5)

                    } else {
                        logToSlack(`[calculateDeliveryPrice] Error: ${httpResponse.status} : ${httpResponse.text}`)
                        distanceInKm = calcDistance(address.attributes.location.latitude, address.attributes.location.longitude, store.attributes.location.latitude, store.attributes.location.longitude)

                        return resolveTotalAndDistance(delivery.method, delivery.byDistance.unit, delivery.byDistance.base, delivery.byDistance.max, distanceInKm, delivery.byDistance.baseDistance, delivery.byDistance.extraUnit, 0.5)
                    }

                }

                //throw new Error('Not found location in store or address')
            }

            return { method: delivery ? delivery.method ? delivery.method : 'default' : 'default', total: delivery ? delivery.default ? delivery.default : deliveryDefault : deliveryDefault }

        }
        throw new Error('Invalid params')

    } else {
        throw new Error('Unathorized')
    }
});

// Resolve total and distance 
const resolveTotalAndDistance = async (method, unit, base, max = 0, distanceInKm, baseDistance, extraUnit, fit) => {
    let totalDelivery = Number(base)
    if (distanceInKm > baseDistance) {
        totalDelivery = base + ((distanceInKm - baseDistance) + fit) * extraUnit
    }
    return { method: method, total: totalDelivery > max ? max : totalDelivery, distance: distanceInKm, unit: unit }
}

Parse.Cloud.define("addTokenCardStripe", async request => {
    let currentUser = request.user;
    if (currentUser) {
        var number = request.params.number;
        var expMonth = request.params.expMonth;
        var expYear = request.params.expYear;
        var cvc = request.params.cvc;
        var holder = request.params.holder
        var name = request.params.name;
        var preferred = request.params.preferred;

        if (number && expMonth && expYear && cvc && holder) {

            const token = await stripe.tokens.create({
                card: {
                    number: number,
                    exp_month: expMonth,
                    exp_year: expYear,
                    cvc: cvc,
                    name: holder
                },
            });

            if (!token) {
                throw new Error('Error with create token')
            }

            let UserCardClass = Parse.Object.extend("UserCard");
            let userCard = new UserCardClass();
            userCard.set('user', currentUser);
            userCard.set('name', name);
            userCard.set('token', token.id);
            userCard.set('last4', token.card.last4);
            userCard.set('brand', token.card.brand);
            userCard.set('payload', token);
            userCard.set('status', 'active');
            if (preferred) {
                userCard.set('preferred', true);
            }
            let creditCard = await userCard.save(null, { useMasterKey: true });
            return creditCard

        } else {
            throw new Error('Invalid params')
        }
    }
});

Parse.Cloud.define("getTokensCardStripe", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            let UserCardClass = Parse.Object.extend("UserCard");
            var query = new Parse.Query(UserCardClass);
            query.equalTo("user", currentUser);
            query.notEqualTo("status", "inactive");
            query.descending('createdAt');
            query.ascending('preferred');
            query.exclude('token');
            query.exclude('payload');
            var cards = await query.find({ useMasterKey: true });

            return cards
        } catch (error) {
            throw error.message;
        }
    }
});

Parse.Cloud.define("payOrderStripe", async request => {
    let currentUser = request.user;
    if (currentUser) {

        try {
            var id = request.params.id;
            var cardId = request.params.cardId;

            if (id && cardId) {

                let UserCardClass = Parse.Object.extend("UserCard");
                var queryCard = new Parse.Query(UserCardClass);
                var card = await queryCard.get(cardId, { useMasterKey: true });

                let OrderClass = Parse.Object.extend("Order");
                var query = new Parse.Query(OrderClass);
                query.include('store')
                var order = await query.get(id, { useMasterKey: true });

                const charge = await stripe.charges.create({
                    amount: order.attributes.total,
                    currency: 'usd',
                    source: card.attributes.token,
                    description: `Payment for the order ${order.id}, made by the user (${order.attributes.owner.id}) alias ${order.attributes.alias} with the credit card ${card.id}`,
                });

                if (!charge) {
                    throw new Error('Error with create token')
                }

                if (charge.status === 'succeeded') {

                    order.set('status', 'created')
                    await order.save(null, { useMasterKey: true });

                    let payment = order.attributes.payment;
                    payment.set('status', 'approved');
                    payment.set('payload', charge);
                    await order.save(null, { useMasterKey: true });

                    //save new status
                    var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
                    var orderUpdateItem = new OrderUpdateClass();
                    orderUpdateItem.set("object", order.id);
                    orderUpdateItem.set("update_type", "created");
                    orderUpdateItem.set("editor", currentUser.id);
                    var updateobject = await orderUpdateItem.save(null, { useMasterKey: true });
                    try {
                        let pushMessage = "De: " + currentUser.get("name") + " "; //+ orderResumeText
                        //now we send a push
                        var jsonBody = {
                            app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                            small_icon: "ic_notification",
                            large_icon: "ic_big_icon",
                            android_accent_color: "f4e828",
                            contents: { en: pushMessage },
                            headings: { en: "Nuevo pedido Recibido!" },
                            android_sound: "bell_sound",
                            android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                            data: { "newOrder": true, "identifier": order.id, "printIfCan": true },
                            priority: 10,
                            ttl: 900,
                            channel_for_external_user_ids: "push",
                            include_external_user_ids: [order.attributes.store.get("owner").id]
                        };
                        Parse.Cloud.httpRequest({
                            method: "POST",
                            url: "https://onesignal.com/api/v1/notifications",
                            headers: {
                                "Content-Type": "application/json;charset=utf-8",
                                "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                            },
                            body: JSON.stringify(jsonBody)
                        }).then(function (httpResponse) {
                            console.log(httpResponse.text);
                            //logToSlack("orderv3-push result: " + httpResponse.text)
                        }, function (httpResponse) {
                            logToSlack("[CREDIT CARD] orderv3-push error result: " + httpResponse.text)
                        });
                        //now we notify support team via slack
                        let slackMessage = "[CREDIT CARD] Nuevo Pedido: " + pushMessage + " , total: " + order.attributes.total + " , descuento: " + order.attributes.discount;
                        logToSlack(slackMessage)

                    } catch (error) {
                        throw error.message;
                    }

                    return 'success'
                }


                throw new Error('Error in payment')


            } else {
                throw new Error('Invalid params')
            }

        } catch (error) {
            throw error.message;
        }
    }
});

Parse.Cloud.define("paymentSheet", async request => {
    let currentUser = request.user;
    if (currentUser) {
        try {
            var amount = request.params.amount;
            let currency = request.params.currency || 'usd';

            let UserCustomerClass = Parse.Object.extend("UserCustomer");
            var query = new Parse.Query(UserCustomerClass);
            query.equalTo("user", currentUser);
            var customer = await query.first({ useMasterKey: true });

            if (!customer) {

                const customerStripe = await stripe.customers.create({
                    name: currentUser.get("name"),
                    email: currentUser.get("email") ? currentUser.get("email") : currentUser.get("gemail"),
                    phone: currentUser.get("phone"),
                    description: `Customer created form festyapp ${currentUser.id}`
                });

                if (!customerStripe) {
                    throw new Error('Error creating customer')
                }

                customer = new UserCustomerClass();
                customer.set('customerId', customerStripe.id);
                customer.set('user', currentUser);
                customer.set('payload', customerStripe);
                customer = await customer.save(null, { useMasterKey: true });
            }

            const ephemeralKey = await stripe.ephemeralKeys.create(
                { customer: customer.attributes.customerId },
                { apiVersion: '2020-08-27' }
            );

            const paymentIntent = await stripe.paymentIntents.create({
                amount: normalizeAmountForStipe(amount),
                currency: currency,
                customer: customer.attributes.customerId,
            });

            return {
                paymentIntent: paymentIntent.client_secret,
                ephemeralKey: ephemeralKey.secret,
                customer: customer.attributes.customerId
            };

        } catch (error) {
            throw error.message;
        }
    }
});

// normalize amount for stripe 
const normalizeAmountForStipe = (amount) => {
    let num = Number(amount);
    let amountWithDecimals = num.toFixed(2);
    let splitNumber = `${amountWithDecimals}`.split(".")

    return Number(`${splitNumber[0]}${splitNumber[1]}`)
}

Parse.Cloud.define("cancelOrderByPaymentGateway", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var notes = request.params.notes;
        let silent_mode = request.params.silent_mode;

        var OrderClass = Parse.Object.extend("Order");
        var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
        var query = new Parse.Query(OrderClass);
        query.include("store");
        query.equalTo('owner', currentUser);
        let order = await query.get(id, { useMasterKey: true });
        order.set("status", "cancelled");
        let result = order.save(null, { useMasterKey: true });
        if (result) {
            var orderUpdateItem = new OrderUpdateClass();
            orderUpdateItem.set("object", order.id);
            orderUpdateItem.set("update_type", "cancelled");
            orderUpdateItem.set("notes", notes);
            orderUpdateItem.set("editor", currentUser.id);
            orderUpdateItem.save(null, { useMasterKey: true });

            if (!silent_mode) {
                //now we send a push
                var jsonBody = {
                    app_id: "90ea6fc6-b897-47ad-b5af-37d09a1ffd6d",
                    small_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: "Su pedido no puede ser procesado y ha sido cancelado" },
                    headings: { en: order.get("store").get("name") },
                    priority: 10,
                    android_channel_id: "455d7d37-de03-46d4-8d74-7825a8163a0a",
                    include_external_user_ids: [order.get("owner").id]
                };

                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic YzM5MjIzNmQtMTAzOC00MDFjLWI5NmItMzhkNzY3MjE1YjVj"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                }, function (httpResponse) {
                    console.error('Request failed with response code ' + httpResponse.status + ' : ' + httpResponse.text);
                });
            }

            return true;
        }
    } else {
        return false;
    }
});

Parse.Cloud.define("createCategoryST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        var StoreClass = Parse.Object.extend("Store");
        var ProductCategoryClass = Parse.Object.extend("ProductCategory");
        let storeId = request.params.store;
        var store = new StoreClass();
        store.set("id", storeId);
        let name = request.params.name;
        let index = request.params.index;

        var category = new ProductCategoryClass();
        category.set("name", name);
        category.set("index", index);
        category.set("store", store);
        category.set("status", "enabled");
        var result = await category.save(null, { useMasterKey: true });
        if (result) {
            return result;
        } else {
            throw new Error('Error saving category')
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define("getStoreProductsCategories", async request => {
    var storeId = request.params.storeId;
    var ProductCategoryClass = Parse.Object.extend("ProductCategory");
    var StoreClass = Parse.Object.extend("Store");
    var store = new StoreClass();
    store.set("id", storeId)
    var query = new Parse.Query(ProductCategoryClass);
    query.equalTo("status", "enabled");
    query.equalTo("store", store);
    query.ascending("index");
    let categories = await query.find({ useMasterKey: true });
    return categories;
});

Parse.Cloud.define("existOrder", async request => {
    var currentUser = request.user;
    if (currentUser) {
        var id = request.params.id;
        var OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        let order = await query.get(id, { useMasterKey: true });
        if (order) {
            return true
        }
        return false;
    } else {
        throw new Error('Unathorized');
    }
});

Parse.Cloud.afterSave("Payment", async request => {
    let payment = request.object;
    let payment_orig = request.original;

    var PaymentUpdateClass = Parse.Object.extend("PaymentUpdate");
    var paymentUpdate = new PaymentUpdateClass();

    if (!payment_orig) {
        paymentUpdate.set('update_type', 'new');
        paymentUpdate.set('payment', payment);
        paymentUpdate.set('status', payment.get("status"));
        paymentUpdate.set('payload', payment.get("payload"));
        paymentUpdate.set('method', payment.get("method"));
        paymentUpdate.set('provider', payment.get("provider"));
        paymentUpdate.set('notes', 'created');
    } else {
        paymentUpdate.set('notes', 'edited');
        paymentUpdate.set('payment', payment);
        paymentUpdate.set('update_type', `${payment_orig.get("status")}_to_${payment.get("status")}`);
        paymentUpdate.set('status', payment.get("status"));
        paymentUpdate.set('payload', payment.get("payload"));
        paymentUpdate.set('method', payment.get("method"));
        paymentUpdate.set('provider', payment.get("provider"));
    }

    await paymentUpdate.save(null, { useMasterKey: true });
});

Parse.Cloud.define("removeStoreRiderST", async request => {
    var currentUser = request.user;
    if (currentUser && currentUser.get("store")) {
        let storeRiderId = request.params.storeRiderId;
        let storeId = request.params.storeId;
        var StoreClass = Parse.Object.extend("Store");
        var StoreRiderClass = Parse.Object.extend("StoreRider");
        var store = new StoreClass();
        store.set("id", storeId);
        var query = new Parse.Query(StoreRiderClass);
        query.equalTo("store", store);
        let storeRiderObject = await query.get(storeRiderId, { useMasterKey: true });
        if (storeRiderObject) {
            await storeRiderObject.destroy({ useMasterKey: true })
            return true;
        } else {
            throw new Error('error deleting rider')
        }
    } else {
        throw new Error('Unathorized')
    }
});

Parse.Cloud.define('createOrUpdateGoogleUser', async (request) => {
    const { email, name, googleId, imageUrl } = request.params;

    if (!email || !googleId) {
        throw new Parse.Error(Parse.Error.INVALID_QUERY, 'Email y googleId son requeridos');
    }

    // Función auxiliar para generar password aleatorio
    function generateRandomPassword() {
        return Math.random().toString(36).slice(-12) + Date.now().toString(36);
    }

    // Buscar usuario existente por email
    const emailQuery = new Parse.Query(Parse.User);
    emailQuery.equalTo('email', email);
    let user = await emailQuery.first({ useMasterKey: true });

    // Si no se encuentra por email, buscar por authProviderId
    if (!user) {
        const providerQuery = new Parse.Query(Parse.User);
        providerQuery.equalTo('authProviderId', googleId);
        user = await providerQuery.first({ useMasterKey: true });
    }

    if (!user) {
        // Crear nuevo usuario
        user = new Parse.User();
        user.set('username', email);
        user.set('email', email);
        user.set('password', generateRandomPassword()); // Password aleatorio seguro
        
        // Campos personalizados - Asegúrate de que estos campos existan en tu esquema Parse
        // O usa el Dashboard de Parse para agregarlos automáticamente la primera vez
        if (name) {
            user.set('name', name);
        }
        user.set('authProvider', 'google');
        user.set('authProviderId', googleId);
        if (imageUrl) {
            user.set('photoUrl', imageUrl);
        }
        
        // signUp con useMasterKey para evitar problemas de permisos
        await user.signUp(null, { useMasterKey: true });
    } else {
        // Actualizar usuario existente
        // Solo actualizar campos si no existen o si hay nuevos valores
        if (!user.get('authProvider')) {
            user.set('authProvider', 'google');
        }
        if (!user.get('authProviderId')) {
            user.set('authProviderId', googleId);
        }
        if (name && !user.get('name')) {
            user.set('name', name);
        }
        if (imageUrl && !user.get('photoUrl')) {
            user.set('photoUrl', imageUrl);
        }
        
        // save con useMasterKey para evitar problemas de permisos
        await user.save(null, { useMasterKey: true });
    }

    // Obtener o crear sessionToken para el usuario
    // En Parse Server, después de signUp, el usuario puede tener un sessionToken
    // Si no, necesitamos crear una sesión manualmente
    let sessionToken = null;

    // Función auxiliar para generar ID único (similar a generateRandomPassword)
    function generateSessionToken() {
        const randomPart = Math.random().toString(36).substring(2, 15) + 
                            Math.random().toString(36).substring(2, 15) +
                            Date.now().toString(36);
        return `r:${randomPart}`;
    }

    // Intentar obtener el sessionToken del usuario (disponible después de signUp en algunas versiones)
    if (user.getSessionToken && typeof user.getSessionToken === 'function') {
        sessionToken = user.getSessionToken();
    }

    // Si no hay sessionToken, crear una sesión manualmente en la tabla _Session
    if (!sessionToken) {
        const Session = Parse.Object.extend('_Session');
        const session = new Session();
        session.set('user', user);
        session.set('sessionToken', generateSessionToken());
        session.set('createdWith', { action: 'create', authProvider: 'google' });
        session.set('restricted', false);
        await session.save(null, { useMasterKey: true });
        sessionToken = session.get('sessionToken');
    }

    return {
        sessionToken: sessionToken,
        user: {
            id: user.id,
            email: user.get('email'),
            name: user.get('name'),
            sessionToken: sessionToken
        }
    };
});