const crypto = require('crypto');
const stripe = require('stripe')('sk_test_51ITEcAJ0TFVEumUTW9EZHAafqMZ2CrbbHhltrYnAjarp5CtNP1HqNX4XEEfyB3vJLEGTOiLhGkVonyVKYJHVZ1e600kvmuwBsQ');

// ePayco Confirmation
app.post('/epco/confirmation', async (req, res) => {
    
    logToSlack2(`[SERVER] confirmación iniciada`)
    if (!req.body.x_signature || !req.body.x_transaction_id || !req.body.x_ref_payco || !req.body.x_amount || !req.body.x_currency_code) {
        res.status(403).send('Error con el envio de los datos.')
    }

    const p_cus = process.env.PEYCO_P_CUS
    const p_key = process.env.PEYCO_P_KEY
    let secret = `${p_cus}^${p_key}^${req.body.x_ref_payco}^${req.body.x_transaction_id}^${req.body.x_amount}^${req.body.x_currency_code}`;
    const hash_init = crypto.createHash('sha256')
    const hash = hash_init.update(secret).digest('hex')
    
    if (hash === req.body.x_signature) {

        try {

            let InvoicePaymentClass = Parse.Object.extend("InvoicePayment");
            let newInvoicePayment = new InvoicePaymentClass();

            var invoicePayment = new Parse.Query(InvoicePaymentClass);
            invoicePayment.equalTo("transactionId", req.body.x_transaction_id);
            let invoicePaymentExist = await invoicePayment.first({ useMasterKey: true });

            if (invoicePaymentExist) {
                newInvoicePayment = invoicePaymentExist
            }

            newInvoicePayment.set('status', req.body.x_cod_transaction_state)
            newInvoicePayment.set('method', req.body.x_franchise)
            newInvoicePayment.set('transactionId', req.body.x_transaction_id)
            newInvoicePayment.set('invoice', req.body.x_id_invoice)
            newInvoicePayment.set('response', req.body.x_transaction_state)
            newInvoicePayment.set('amount', Number(req.body.x_amount))
            newInvoicePayment.set('store', req.body.x_extra1)
            newInvoicePayment.set('plan', req.body.x_extra2)
            newInvoicePayment.set('storeOwner', req.body.x_extra3)
            newInvoicePayment.set('payload', req.body)
            newInvoicePayment.set('isTest', req.body.x_test_request == 'FALSE' ? false : true)
            
            let invoicePaymentNew = await newInvoicePayment.save(null, { useMasterKey: true })

            var queryInvoice = new Parse.Query('Invoice');
            queryInvoice.include('store')
            queryInvoice.include('store.owner')
            let invoice = await queryInvoice.get(req.body.x_id_invoice, { useMasterKey: true });
            
            if (req.body.x_cod_transaction_state == 1) {
            
                invoice.set('payment', invoicePaymentNew)
                invoice.set('status', 'paid')
                await invoice.save(null, { useMasterKey: true })
                
                sendPushNotification(invoice.attributes.store, req.body.x_cod_transaction_state, invoice.attributes.startDate)
                logToSlack2(`[SERVER] Factura pagada ID: ${invoice.id} - Pago ID: ${invoicePaymentNew.id} - Comercio: ${invoice.attributes.store.attributes.name}`)

            }else if (req.body.x_cod_transaction_state == 3) {
                sendPushNotification(invoice.attributes.store, req.body.x_cod_transaction_state, invoice.attributes.startDate)
                logToSlack2(`[SERVER][PENDING] Se ha intentado pagar la factura ID: ${req.body.x_id_invoice} - Comercio: ${invoice.attributes.store.attributes.name} - Pago ID: ${invoicePaymentNew.id} - STATUS PAYMENT: ${invoicePaymentNew.attributes.response}`)
            }else{
                sendPushNotification(invoice.attributes.store, req.body.x_cod_transaction_state, invoice.attributes.startDate)
                logToSlack2(`[SERVER][FAIL] Se ha intentado pagar la factura ID: ${req.body.x_id_invoice} - Comercio: ${invoice.attributes.store.attributes.name} - Pago ID: ${invoicePaymentNew.id} - STATUS PAYMENT: ${invoicePaymentNew.attributes.response}`)
            }

            res.status(200).send('Pago procesado y fue ' + req.body.x_transaction_state)
            
        } catch (error) {
            logToSlack2(error)
            res.status(403).send(error)
        }
    }

    res.status(403).send('Firma invalida.')
});


const logToSlack2 = async (slackMessage) => {
    var bodyParams = {
        text: slackMessage
    };
    Parse.Cloud.httpRequest({
        method: "POST",
        url: "https://hooks.slack.com/services/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",
        headers: {
            "Content-Type": "application/json;charset=utf-8"
        },
        body: JSON.stringify(bodyParams)
    }).then(function (httpResponse) {

    }, function (httpResponse) {

    });
};

app.post('/getPromo', async (req, res) => {
    if (req.body.id) {
        var product = new Parse.Query('Product');
        product.include('store')
        let promo = await product.get(req.body.id, { useMasterKey: true });
        res.json(promo)
    }
    res.status(403).send('Error con el envio de los datos.')
});

// ePayco Response POST
app.post('/epco/response', async (req, res) => {
    logToSlack2(`[SERVER] Redireccionando en POST`)
    if(req.query.ref_payco){
        res.redirect('https://stores.festyapp.com/epco/response?ref_payco='+req.query.ref_payco)
    }
    res.status(403).send('Datos invalidos.')
});

// ePayco Response GET
app.get('/epco/response', async (req, res) => {
    logToSlack2(`[SERVER] Redireccionando en GET`)
    if(req.query.ref_payco){
        res.redirect('https://stores.festyapp.com/epco/response?ref_payco='+req.query.ref_payco)
    }
    res.status(403).send('Datos invalidos.')
});

app.get('/testNotifications', async (req, res) => {
    if (req.query.invoice_id) {
        try {
            var invloice = new Parse.Query('Invoice');
            invloice.include('store')
            invloice.include('store.owner')
            let test = await invloice.get(req.query.invoice_id, { useMasterKey: true });
    
            sendPushNotification(test.attributes.store, '1', test.attributes.startDate)
            res.json(test.attributes.startDate.getMonth())
            
        } catch (error) {
            logToSlack2(error)
            res.status(500).send(error)
        }
    }
    res.status(403).send('Error con el envio de los datos.')
});

// Redirect stripe
app.post('/redirect/checkout', async (req, res) => {
    logToSlack2(`[SERVER PAYMENT] Redireccionando create-checkout-session ID: ${req.body.order}`)
    try {
        let order = req.body.order;
        let amount = normalizeAmountForStipe(req.body.amount);
        let user = req.body.user;
        let currency = req.body.currency || 'usd';

        var queryUser = new Parse.Query(Parse.User);
        let payer = await queryUser.get(user, { useMasterKey: true });

        let UserCustomerClass = Parse.Object.extend("UserCustomer");
        var query = new Parse.Query(UserCustomerClass);
        query.include('user');
        query.equalTo("user", payer);
        var customer = await query.first({ useMasterKey: true });
            
        if (!customer) {

            const customerStripe = await stripe.customers.create({
                name: payer.get("name"),
                email: payer.get("email") ? payer.get("email") : payer.get("gemail"),
                phone: payer.get("phone"),
                description: `Customer created form festyapp ${payer.id}`
            });

            if (!customerStripe) {
                throw new Error('Error creating customer')
            }

            customer = new UserCustomerClass();
            customer.set('customerId', customerStripe.id);
            customer.set('user', currentUser);
            customer.set('payload', customerStripe);
            customer = await customer.save(null, { useMasterKey: true });
        }

        const session = await stripe.checkout.sessions.create({
            payment_intent_data: {
                setup_future_usage: 'off_session',
            },
            payment_method_types: ['card'],
            line_items: [
                {
                price_data: {
                    currency: currency,
                    product_data: {
                    name: `FESTY ORDER: ${order}`,
                    },
                    unit_amount: amount,
                },
                quantity: 1,
                },
            ],
            mode: 'payment',
            client_reference_id: order,
            customer: customer.attributes.customerId,
            success_url: 'https://web.festyapp.com/stripe/success',
            cancel_url: 'https://web.festyapp.com/stripe/cancel',
        });

        if (session) {
            let OrderClass = Parse.Object.extend("Order");
            var queryOrder = new Parse.Query(OrderClass);
            queryOrder.include('payment');
            var orderNow = await queryOrder.get(order, { useMasterKey: true });
            
            let payment = orderNow.attributes.payment
            payment.set('customId', session.payment_intent);
            payment.set('payload', session);
            await payment.save(null, { useMasterKey: true });

            logToSlack2(`[SESSION OBJECT] Json: ${JSON.stringify(session)}`)
            return res.redirect(303, session.url);
        }
        
        logToSlack2('[ERROR REDIRECT PAYMENT] Session no existe');
        res.status(500).send('Error to redirect, session no exist');

    } catch (error) {
        logToSlack2(error)
        res.status(500).send(error)
    }
});

app.post('/webhook', async (req, res) => {
    const event = req.body;
    logToSlack2(`[WEBHOOK PAYMENT] REQUEST: ${JSON.stringify(event)}`);
    try {

        let PaymentClass = Parse.Object.extend("Payment");
        var query = new Parse.Query(PaymentClass);
        query.equalTo("customId", event.data.object.id);
        var payment = await query.first({ useMasterKey: true });

        if (payment && payment.attributes.status ==! 'approved') {
            let OrderClass = Parse.Object.extend("Order");
            var OrderUpdateClass = Parse.Object.extend("OrderUpdate");

            var queryOrder = new Parse.Query(OrderClass);
            queryOrder.include('store')
            queryOrder.include('owner')
            queryOrder.equalTo('payment', payment);
            var orderNow = await queryOrder.first({ useMasterKey: true });
            
            var orderUpdateItem = new OrderUpdateClass();

            switch (event.type) {
                case 'payment_intent.succeeded':
                    payment.set('status', 'approved');
                    payment.set('payload', event);

                    orderNow.set('status', 'created')
                    
                    orderUpdateItem.set("object", orderNow.id);
                    orderUpdateItem.set("update_type", "created");
                    orderUpdateItem.set("editor", 'webhook_stripe');
                    break;
                case 'payment_intent.canceled':
                    payment.set('status', 'canceled');
                    payment.set('payload', event);

                    orderNow.set('status', 'cancelled')

                    orderUpdateItem.set("object", orderNow.id);
                    orderUpdateItem.set("update_type", "cancelled");
                    orderUpdateItem.set("editor", 'webhook_stripe');
                    break;
                case 'payment_intent.created':
                    payment.set('payload', event);
                    break;
                default:
                  console.log(`Unhandled event type ${event.type}`);
            }
            
            let paymentSave = await payment.save(null, { useMasterKey: true });

            if (event.type === 'payment_intent.succeeded') {
                var orderSave = await orderNow.save(null, { useMasterKey: true });
                var orderUpdateSave = await orderUpdateItem.save(null, { useMasterKey: true });
                
                let pushMessage = "De: " + orderSave.get('owner').get("name");
                //now we send a push
                var jsonBody = {
                    app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                    small_icon: "ic_notification",
                    large_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: pushMessage },
                    headings: { en: "Nuevo pedido Recibido!" },
                    android_sound: "bell_sound",
                    android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                    data: { "newOrder": true, "identifier": orderSave.id, "printIfCan": true },
                    priority: 10,
                    ttl: 900,
                    channel_for_external_user_ids: "push",
                    include_external_user_ids: [orderSave.get('store').get("owner").id]
                };
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                    //logToSlack2("orderv3-push result: " + httpResponse.text)
                }, function (httpResponse) {
                    logToSlack2("orderv3-push error result: " + httpResponse.text)
                });
                //now we notify support team via slack
                let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + orderSave.attributes.total + " , descuento: " + orderSave.attributes.discount;
                logToSlack2(slackMessage)
            
            }else if(event.type === 'payment_intent.canceled'){
                var orderSave = await orderNow.save(null, { useMasterKey: true });
                var orderUpdateSave = await orderUpdateItem.save(null, { useMasterKey: true });
            }

            logToSlack2(`[WEBHOOK RESPONSE] Event Type: ${event.type}, Payment ID: ${paymentSave.id}`)
            return res.send();
        }

        logToSlack2(`[WEBHOOK PAYMENT] PAYMENT ID: ${payment ? payment.id : 'NOT FOUND'} `);
        logToSlack2(`[WEBHOOK PAYMENT] PAYMENT STATUS: ${payment ? payment.attributes.status : 'NOT FOUND'} `);
        return res.status(200).send('Payment problem?');
        
    } catch (error) {
        logToSlack2(error)
        res.status(500).send(error)
    }
  });

  /**
    {
        "transaction": {
            "status": 1,
            "order_description": "ORDER #1507155336536",
            "authorization_code": "113310",
            "status_detail": 3,
            "date": "04/10/2017 22:15:37",
            "message": "Operation Successful",
            "id": "CI-502",
            "dev_reference": "1507155336536",
            "carrier_code": "6",
            "amount": 10.5,
            "paid_date": "04/10/2017 19:15:00",
            "installments": 1,
            "stoken": "e03f67eba6d730d8468f328961ac9b2e",
            "application_code": "AndroidTest"
        },
        "user": {
            "id": "4",
            "email": "user@example.com"
        },
        "card": {
            "bin": "411111",
            "holder_name": "Martin Mucito",
            "type": "vi",
            "number": "1111",
            "origin": "ORIGIN"
        }
    }
   */
  app.post('/webhook/globalpay', async (req, res) => {
    const event = req.body;
    logToSlack2(`[WEBHOOK PAYMENT GLOBALPAY] REQUEST: ${JSON.stringify(event)}`);
    try {

        let OrderClass = Parse.Object.extend("Order");
        var query = new Parse.Query(OrderClass);
        query.include('payment')
        query.include('store')
        query.include('owner')
        var orderNow = await query.get(event.transaction.dev_reference, { useMasterKey: true });

        let paymentGateway = orderNow.attributes.store.attributes.payment.methods.find((element) => 'paymentGateway' === element.id);
        let token = `${event.transaction.id}_${event.transaction.application_code}_${event.user.id}_${paymentGateway ? paymentGateway.config.credentials.client_app_key : ''}`
        const hash_init = crypto.createHash('md5')
        const hash = hash_init.update(token).digest('hex')

        if (event.transaction.stoken !== hash) {
            logToSlack2(`[WEBHOOK PAYMENT GLOBALPAY] TOKEN INVALIDO!!! `);
            return res.status(500).send('Invalid Token')
        }

        var payment = orderNow.attributes.payment

        if (payment && payment.attributes.status != 'approved') {
            var OrderUpdateClass = Parse.Object.extend("OrderUpdate");
            var orderUpdateItem = new OrderUpdateClass();

            switch (event.transaction.status) {
                case '1':
                    payment.set('status', 'approved');
                    payment.set('payload', event);

                    orderNow.set('status', 'created')
                    
                    orderUpdateItem.set("object", orderNow.id);
                    orderUpdateItem.set("update_type", "created");
                    orderUpdateItem.set("editor", 'webhook_globalpay');
                    break;
                case '0':
                    payment.set('status', 'review');
                    payment.set('payload', event);

                    orderNow.set('status', 'pre-created')

                    orderUpdateItem.set("object", orderNow.id);
                    orderUpdateItem.set("update_type", "review");
                    orderUpdateItem.set("editor", 'webhook_globalpay');
                    break;
                default:
                    payment.set('status', 'cancelled');
                    payment.set('payload', event);

                    orderNow.set('status', 'cancelled')

                    orderUpdateItem.set("object", orderNow.id);
                    orderUpdateItem.set("update_type", "cancelled");
                    orderUpdateItem.set("editor", 'webhook_globalpay');
            }
            
            let paymentSave = await payment.save(null, { useMasterKey: true });

            if (event.transaction.status === '1') {
                var orderSave = await orderNow.save(null, { useMasterKey: true });
                var orderUpdateSave = await orderUpdateItem.save(null, { useMasterKey: true });
                
                let pushMessage = "De: " + orderSave.get('owner').get("name");
                //now we send a push
                var jsonBody = {
                    app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
                    small_icon: "ic_notification",
                    large_icon: "ic_big_icon",
                    android_accent_color: "f4e828",
                    contents: { en: pushMessage },
                    headings: { en: "Nuevo pedido Recibido!" },
                    android_sound: "bell_sound",
                    android_channel_id: "d363d148-af2c-4d01-ab98-f48836be28ef",
                    data: { "newOrder": true, "identifier": orderSave.id, "printIfCan": true },
                    priority: 10,
                    ttl: 900,
                    channel_for_external_user_ids: "push",
                    include_external_user_ids: [orderSave.get('store').get("owner").id]
                };
                Parse.Cloud.httpRequest({
                    method: "POST",
                    url: "https://onesignal.com/api/v1/notifications",
                    headers: {
                        "Content-Type": "application/json;charset=utf-8",
                        "Authorization": "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk"
                    },
                    body: JSON.stringify(jsonBody)
                }).then(function (httpResponse) {
                    console.log(httpResponse.text);
                    //logToSlack2("orderv3-push result: " + httpResponse.text)
                }, function (httpResponse) {
                    logToSlack2("[ GLOBALPAY] orderv3-push error result: " + httpResponse.text)
                });
                //now we notify support team via slack
                let slackMessage = "Nuevo Pedido: " + pushMessage + " , total: " + orderSave.attributes.total + " , descuento: " + orderSave.attributes.discount;
                logToSlack2(slackMessage)
            
            }else if(event.transaction.status === '0' || event.transaction.status === '2' || event.transaction.status === '4' || event.transaction.status === '5'){
                var orderSave = await orderNow.save(null, { useMasterKey: true });
                var orderUpdateSave = await orderUpdateItem.save(null, { useMasterKey: true });
            }

            logToSlack2(`[WEBHOOK RESPONSE GLOBALPAY] Event Type: PAGO DESDE GLOBALPAY, Payment ID: ${paymentSave.id}`)
            return res.send();
        }

        logToSlack2(`[WEBHOOK PAYMENT GLOBALPAY] PAYMENT ID: ${paymentSave ? paymentSave.id : 'NOT FOUND'} `);
        logToSlack2(`[WEBHOOK PAYMENT GLOBALPAY] PAYMENT STATUS: ${paymentSave ? paymentSave.attributes.status : 'NOT FOUND'} `);
        return res.status(200).send('Payment problem?');
        
    } catch (error) {
        logToSlack2(error)
        res.status(500).send(error)
    }
  });
  

// Send push for payment invoice
const sendPushNotification = (store, status, startDate) => {
    let pushMessage = ''
    let title = ''
    switch (status) {
        case '1':
            title = 'Pago confirmado'
            pushMessage = `El pago de su factura de ${getMonthEs(startDate.getMonth())} fue confirmada, Gracias.`;
            break;
        case '3':
            title = 'Pago pendiente de confirmación'
            pushMessage = `El pago de su factura de ${getMonthEs(startDate.getMonth())} esta pediente por confirmación del banco. Te avisaremos cuando se confirme.`;
            break;
        default:
            title = 'Pago fallido'
            pushMessage = `El pago de su factura de ${getMonthEs(startDate.getMonth())} ha fallado.`;
            break;
    }
    //now we send a push
    var jsonBody = {
      app_id: "f940ba55-aef5-4214-b8a8-1a99622f6a5b",
      small_icon: "ic_notification",
      large_icon: "ic_big_icon",
      android_accent_color: "f4e828",
      contents: { en: pushMessage },
      headings: { en: title },
      android_sound: "bell_sound",
      android_channel_id: "962d9d5a-97fa-493b-a60d-4c37fa0c1c68",
      channel_for_external_user_ids: "push",
      priority: 10,
      include_external_user_ids: [store.id, store.get("owner").id],
    };
    Parse.Cloud.httpRequest({
      method: "POST",
      url: "https://onesignal.com/api/v1/notifications",
      headers: {
        "Content-Type": "application/json;charset=utf-8",
        Authorization: "Basic MDQwMDlhNmMtODBmOC00Y2NjLWFkYzQtNjY1NWE0ZTg2M2Jk",
      },
      body: JSON.stringify(jsonBody),
    }).then(
      function (httpResponse) {
        console.log(httpResponse.text);
        //logToSlack2("invoice-push-confirmation result: " + httpResponse.text);
      },
      function (httpResponse) {
        logToSlack2("invoice-push-confirmation error result: " + httpResponse.text);
      }
    );
};
  
const getMonthEs = (index) => {
    if (index) {
        var month = new Array();
        month[0] = "Enero";
        month[1] = "Febrero";
        month[2] = "Marzo";
        month[3] = "Abril";
        month[4] = "Mayo";
        month[5] = "Junio";
        month[6] = "Julio";
        month[7] = "Agosto";
        month[8] = "Septiembre";
        month[9] = "Octubre";
        month[10] = "Noviembre";
        month[11] = "Diciembre";
        return month[index];
    }
    return '[Mes no definido]';
};

// normalize amount for stripe 
const normalizeAmountForStipe = (amount) => {
    let num = Number(amount);
    let amountWithDecimals = num.toFixed(2);
    let splitNumber = `${amountWithDecimals}`.split(".")
    
    return Number(`${splitNumber[0]}${splitNumber[1]}`)
}